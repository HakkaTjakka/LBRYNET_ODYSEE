ffmpeg -y -i "../MONKEY/monkey_sound.aac" -loop 1 -i "shit.jpg" -t 00:00:10 -c:v h264_nvenc -pix_fmt yuv420p -shortest out.mp4
burn_video.sh en
ffmpeg -y -i "out/out.English.mp4" -vf "fps=10,scale=400:-1:sws_dither=ed:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse"   "out/out.English.gif"
