#!/bin/bash

rm COMMANDS.SH

LANGUAGE="nl"

echo -------------------------------------------------------------------------- >> error.log

FILENAME=$1
BASENAME="${FILENAME%.*}"

COMMAND="autosub -S $LANGUAGE -D $LANGUAGE "$FILENAME" -o "$BASENAME.$LANGUAGE.srt.double""

echo "$COMMAND" >> COMMANDS.SH
echo "$COMMAND" > command.sh
chmod +x command.sh
./command.sh

# COMMAND="sof/sof "$BASENAME.$LANGUAGE.srt.double""
# 
# echo "$COMMAND" >> COMMANDS.SH
# echo "$COMMAND" > command.sh
# chmod +x command.sh
# ./command.sh

echo $FILENAME > filename.txt

./burn_video.sh
