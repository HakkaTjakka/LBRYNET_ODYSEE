#!/bin/bash

round() {
  printf "%.${2}f" "${1}"
}

echo -------------------------------------------------------------------------- >> error.log

WANTED_LANGUAGE=$1

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g' |  sed 's/ /\\ /g')
#VAR=$(echo $BASENAME | sed 's/ /\\ /g')
#VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')


# convert .vtt to .srt. Can also be done by yt-dlp with --convert-subs srt but only after/when downloading. So when interrupted can be continued.

ONE="1.0"

echo "" > map.txt
echo " \\" > in.txt

echo " -map 0:v:0 -map 0:a:0 \\" >> map.txt
MAP_COUNT=0
#if [ -f "in.txt" ]; then
#	rm in.txt
#fi	

echo " -i \"$FILENAME\" \\" >> in.txt

#for line in $VAR.*.vtt

find . -maxdepth 1 -type f -name "$VAR.*.srt.double" -print0 | sort -z | while IFS= read -r -d '' line; # do
do
	LANGUAGE="${line%.*}"
	LANGUAGE="${LANGUAGE%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	echo LANGUAGE=$LANGUAGE

	LANGUAGE_FULL="Unknown"
    if [ "$LANGUAGE" == "en" ]; 	then LANGUAGE_FULL="English"; fi
    if [ "$LANGUAGE" == "eng" ]; 	then LANGUAGE_FULL="English"; fi
    if [ "$LANGUAGE" == "es" ]; 	then LANGUAGE_FULL="Spanish"; fi
    if [ "$LANGUAGE" == "nl" ]; 	then LANGUAGE_FULL="Dutch"; fi
    if [ "$LANGUAGE" == "nl-vUrwgfI32b8" ]; 	then LANGUAGE_FULL="Dutch"; fi
    if [ "$LANGUAGE" == "fr" ]; 	then LANGUAGE_FULL="French"; fi
    if [ "$LANGUAGE" == "it" ]; 	then LANGUAGE_FULL="Italian"; fi
    if [ "$LANGUAGE" == "de" ]; 	then LANGUAGE_FULL="German"; fi
    if [ "$LANGUAGE" == "tr" ]; 	then LANGUAGE_FULL="Turkish"; fi
    if [ "$LANGUAGE" == "pt" ]; 	then LANGUAGE_FULL="Portuguese"; fi
    if [ "$LANGUAGE" == "ru" ]; 	then LANGUAGE_FULL="Russian"; fi
    if [ "$LANGUAGE" == "uk" ]; 	then LANGUAGE_FULL="Ukrainian"; fi
    if [ "$LANGUAGE" == "ar" ]; 	then LANGUAGE_FULL="Arabic"; fi
    if [ "$LANGUAGE" == "ja" ]; 	then LANGUAGE_FULL="Japanese"; fi
    if [ "$LANGUAGE" == "zh-CN" ]; 	then LANGUAGE_FULL="Chinese (Simplified)"; fi

	MAP_COUNT_NEXT=$(echo "($MAP_COUNT+$ONE)"| bc -l);  
    MAP_COUNT_NEXT="${MAP_COUNT_NEXT%.*}"
	echo -n " -map $MAP_COUNT_NEXT" >> map.txt
	echo " -metadata:s:s:$MAP_COUNT language=$LANGUAGE -metadata:s:s:$MAP_COUNT title=$LANGUAGE_FULL \\" >> map.txt
	MAP_COUNT=$MAP_COUNT_NEXT

	echo " -i \"$BASENAME.$LANGUAGE.srt.double\" \\" >> in.txt
done
echo " " >> map.txt
MAP=$(cat map.txt)
IN=$(cat in.txt)
echo $IN
echo $MAP
# exit
# select wanted languages
#LANG="nl"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Dutch	nl
#LANG="nl"; 		cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Dutch	nl
#LANG="nl-vUrwgfI32b8"; 		cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Dutch	nl
#LANG="en"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# English	en
#LANG="de"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# German	de
#LANG="fr"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# French	fr
#LANG="tr"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Turkish	tr
#LANG="ar"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Arabic	ar
#LANG="zh-Hans"; 	mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Chinese	zh-Hans

LANGUAGE=$WANTED_LANGUAGE
if [ ! -d "out" ]; then
	mkdir "out"
fi	
#echo $BASENAME
#exit
# if test -f "$BASENAME.xx.srt"; then
# 	echo "sof/sof $BASENAME.xx.srt" >> COMMANDS.SH
# 	sof/sof $BASENAME.xx.srt
# fi

for line in "$VAR.$LANGUAGE.srt.double"
#for line in $VAR.*.srt.double
#for line in $VAR.*.srt.single
do
	echo line=$line	
	LANGUAGE="${line%.*}"
	LANGUAGE="${LANGUAGE%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	echo "Language: $LANGUAGE"

#echo "Subtitle fixed: $line"
#echo "Subtitle fixed: $line" >> error.log

	if test -f "out/$BASENAME.$LANGUAGE.mp4"; then
		echo "out/$BASENAME.$LANGUAGE.mp4 exists."
	else

		# FONTNAME="Simply Rounded Bold"
		# FONTNAME="AdobeCorpID-MyriadBl"
		# FONTNAME="Akkordeon-Ten"
		FONTNAME="BMWHelvetica-BlackCond"

#### #1		FONTSIZE="28"
#### 		FONTSIZE="30"
#### #1		FONTSIZE="23"
#### 		# OUTLINE="1.1"
#### 		OUTLINE="1.0"
#### #1		OUTLINE="1.0"
#### 		COLOR="000000FF"
#### #1		COLOR="00FFFFFF"
#### 
#### 		OUTLINE_COLOR="00FFFFFF"
#### #1		OUTLINE_COLOR="00000000"
#### 		BACK_COLOR="80000000"
#### 		BORDERSTYLE="0"
#### 
#### #		OUTLINE_COLOR="00000530"
#### #		BACK_COLOR="e00060ff"
#### #		BORDERSTYLE="4"
#### 
#### 		SHADOW="1.5"
#### #1		SHADOW="0.5"
#### 		ANGLE="0.0"
#### 		ALIGNMENT="2"
#### 		# ALIGNMENT="6"

		FONTSIZE="28"
		OUTLINE="1.0"
		COLOR="00000000"
		OUTLINE_COLOR="00FFFFFF"
		BACK_COLOR="80000000"
		BORDERSTYLE="0"
		SHADOW="1.5"
		ANGLE="0.0"
		ALIGNMENT="2"

		FORCE_STYLE="'Fontname=$FONTNAME,FontSize=$FONTSIZE,Outline=$OUTLINE,PrimaryColour=&H$COLOR,OutlineColour=&H$OUTLINE_COLOR,BackColour=&H$BACK_COLOR,Shadow=$SHADOW,Angle=$ANGLE,BorderStyle=$BORDERSTYLE,Alignment=$ALIGNMENT'"
		SUBTITLES="subtitles=f='$line':force_style=$FORCE_STYLE"

		AUDIO_RATE=$(ffprobe -select_streams a:0 -v error -show_entries stream=bit_rate -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
		AUDIO_RATE=$(round ${AUDIO_RATE} 0)
		echo AUDIO_RATE=$AUDIO_RATE

		VIDEO_RATE=$(ffprobe -select_streams a:0 -v error -show_entries format=bit_rate -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
		VIDEO_RATE=$(round ${VIDEO_RATE} 0)
		echo VIDEO_RATE=$VIDEO_RATE

#		exit

		PARMS_OUT="-strict -2 -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a aac -ac 2"
#		PARMS_OUT="-strict -2 -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a aac -ac 2 -b:a $AUDIO_RATE -b:v $VIDEO_RATE"
		PARMS_IN="-y -hide_banner -progress url -nostdin"

#		MAP="-map 0:v:0 -map 0:a:0"

#		IN="-i \"$FILENAME\""
		# ALIGNMENT="Alignment=2"
#
		# FILTER="-filter_complex \"[0:v]$SUBTITLES\""

#,pad=3840:2160:ow-iw:-1:color=red
#		SCALE="scale=1280:1440:force_original_aspect_ratio=decrease,pad=1280:1440:-1:0:color=0x404040"
		SCALE="scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:-1:-1:color=black"
#		SCALE="scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black"
		FILTER="-filter_complex \"[0:v]$SCALE,$SUBTITLES;[0:a]aresample=44100\""

		# FILTER="-filter_complex \"[0:v]$SCALE,tblend=all_expr='if(eq(mod(X,2),mod(Y,2)),A,B)',$SUBTITLES\""
		OUT="\"out/$BASENAME.$LANGUAGE.PART.mp4\""

		FFMPEG="ffmpeg"
		# echo $FORCE_STYLE

#		COMMAND="$FFMPEG $PARMS_IN $IN $MAP $FILTER $PARMS_OUT $OUT"

		COMMAND="$FFMPEG $PARMS_IN $IN$MAP$FILTER $PARMS_OUT $OUT"


#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style=$FORCE_STYLE\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=22,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="~/ffmpeg-n4.4-latest-linux64-gpl-4.4/bin/ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=20,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="~/ffmpeg-n4.4-latest-linux64-gpl-4.4/bin/ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=20,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="~/ffmpeg-n4.4-latest-linux64-gpl-4.4/bin/ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=2'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="~/ffmpeg-n4.4-latest-linux64-gpl-4.4/bin/ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold.ttf,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="~/ffmpeg-n4.4-latest-linux64-gpl-4.4/bin/ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
		echo "$COMMAND" >> COMMANDS.SH
		echo "$COMMAND" > command.sh
		chmod +x command.sh
		./command.sh

		COMMAND="mv \"out/$BASENAME.$LANGUAGE.PART.mp4\" \"out/$BASENAME.$LANGUAGE.mp4\""
		echo "$COMMAND" >> COMMANDS.SH
		echo "$COMMAND" > command.sh
		chmod +x command.sh
		# burn *(&'r burn
		./command.sh
	fi
done


