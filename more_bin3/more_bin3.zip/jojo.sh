#!/bin/bash

getit.sh "https://x.com/unikgirl11/status/1864842255111995468"