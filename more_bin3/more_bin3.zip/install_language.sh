source ~/git/argos-translate/env/bin/activate
virtualenv ~/git/argos-translate/env
argospm install translate-zh_en