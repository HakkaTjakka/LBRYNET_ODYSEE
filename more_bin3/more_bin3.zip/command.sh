mv "out/..PART.mp4" "out/..mp4"
