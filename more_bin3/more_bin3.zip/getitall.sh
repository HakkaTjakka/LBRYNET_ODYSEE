#!/bin/bash

round() {
  printf "%.${2}f" "${1}"
}

## total="${1}"

# total="5" # for testing
GETVIDEOTS() {
 	# start="186"
 	start="0"
 	total="30"
 	rm FILELIST.txt
 	rm VIDEOLIST.txt
 	rm AUDIOLIST.txt
 	
  	for ((i = start; i <= total; ++i)); do
	 		FILE="https://node-1.cdn.jensen.nl/djs_"$1"/720p/720p"${i}".ts"
  		echo $FILE
###  		yt-dlp "$FILE" -o "FILE_"${i}".ts"
###  		if [ $? -eq 0 ]; then
###  		    echo OK
###  		else
###  		    echo FAIL
###  		    break
###  		fi
 	
 		# echo "file '"FILE_"${i}".mp4"'" >> filelist.txt
 #-t $FILELENGTH 
 # exit
 
 	ffmpeg -loglevel error -hide_banner -y -i "FILE_"${i}".ts" -c:v copy "VIDEO_"${i}".ts"
 	ffmpeg -loglevel error -hide_banner -y -i "FILE_"${i}".ts" -c:a copy "AUDIO_"${i}".aac"
	echo "file '"VIDEO_${i}.ts"'" >> VIDEOLIST.txt
	echo "file '"AUDIO_${i}.aac"'" >> AUDIOLIST.txt
	echo "file '"FILE_${i}.ts"'" >> FILELIST.txt

	VIDEOLENGTH=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "VIDEO_"${i}".ts")
	AUDIOLENGTH=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "AUDIO_"${i}".aac")
	FILELENGTH= $(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "FILE_"${i}".ts")
	echo VIDEOLENGTH = $VIDEOLENGTH
	echo AUDIOLENGTH = $AUDIOLENGTH
	echo FILELENGTH = $FILELENGTH

 
 #	-c:a aac -af aresample=async=1000 -fflags +genpts -bsf:a aac_adtstoasc 
 # 		ffmpeg -hide_banner -y -i "FILE_"${i}".ts" -c:v copy -af apad -shortest "FILE_"${i}"_FIXED.ts"
 
 #  		ffmpeg -hide_banner -y -i "FILE_"${i}".ts" -c copy -fflags +genpts -bsf:a aac_adtstoasc "FILE_"${i}"_FIXED.ts"
 
 #		echo "file '"FILE_${i}_FIXED.ts"'" >> filelist.txt
 
 #		echo "file '720p"${i}" [720p"${i}"].ts'" >> filelist.txt
 	    ## echo "${i}"

 	done


#	ffmpeg -hide_banner -y -f concat -safe 0 -i filelist.txt -c:v copy -c:a aac -af aresample=async=1000 -fflags +genpts -bsf:a aac_adtstoasc $1.mp4

#	ffmpeg -hide_banner -y -f concat -safe 0 -i VIDEOLIST.txt -c:v h264_nvenc -pix_fmt yuv420p -preset fast -map 0:v VIDEO_$1.mp4
#	ffmpeg -hide_banner -y -f concat -safe 0 -i AUDIOLIST.txt -c:a aac -ac 2 -map 0:a AUDIO_$1.aac

	ffmpeg -hide_banner -y -loglevel error -f concat -safe 0 -i VIDEOLIST.txt -map 0:v VIDEO_$1.ts
	ffmpeg -hide_banner -y -loglevel error -f concat -safe 0 -i AUDIOLIST.txt -map 0:a AUDIO_$1.aac
	ffmpeg -hide_banner -y -loglevel error -f concat -safe 0 -i FILELIST.txt  -map 0:v -map 0:a FILE_$1.ts

#	ffmpeg -hide_banner -y -i video.ts -i audio2.aac -c:v h264_nvenc -pix_fmt yuv420p -preset fast -map 0:v -map 1:a -c:a aac -af aresample=async=1000 -fflags +genpts -bsf:a aac_adtstoasc "FILE_"${i}"_FIXED.ts"

## 	FILELENGTH1=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 VIDEO_$1.mp4)
## 	echo FILELENGTH1 = $FILELENGTH1
## 	FILELENGTH2=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 AUDIO_$1.aac)
## 	echo FILELENGTH2 = $FILELENGTH2

	VIDEOLENGTH=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 VIDEO_$1.ts)
	AUDIOLENGTH=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 AUDIO_$1.aac)
	FILELENGTH=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 FILE_$1.ts)
	echo VIDEOLENGTH = $VIDEOLENGTH
	echo AUDIOLENGTH = $AUDIOLENGTH
	echo FILELENGTH = $FILELENGTH

	ffmpeg -hide_banner -y -v error -i VIDEO_$1.ts -i AUDIO_$1.aac -c:v copy -c:a copy -map 0:v -map 1:a  "$1.ts"

#	RATE=$(ffprobe -v error -show_entries stream=sample_rate -of default=noprint_wrappers=1:nokey=1 "audio.aac")
#	echo RATE = $RATE
	
## 	SPEED=$(echo "($FILELENGTH2/$FILELENGTH1)"| bc -l)
## #	SPEED=$(round ${SPEED} 6)
## 	echo SPEED = $SPEED
## 	
## #		[0:a]asetrate=$RATE,aresample=44100,atempo=(1.0/($SPEED))[a] \
## 	ffmpeg -hide_banner -y -i AUDIO_$1.aac \
## 		-filter_complex " \
## 		[0:a]atempo=($SPEED)[a] \
## 		" \
## 		-map "[a]" \
## 		AUDIO2_$1.aac
## 	
## 	FILELENGTH3=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 AUDIO2_$1.aac)
## 	echo FILELENGTH3 = $FILELENGTH3
	#exit

#	ffmpeg -hide_banner -y -i video.ts -i audio2.aac -c:v h264_nvenc -pix_fmt yuv420p -preset fast -map 0:v -map 1:a -c:a aac -af aresample=async=1000 -fflags +genpts -bsf:a aac_adtstoasc "FILE_"${i}"_FIXED.ts"
###	ffmpeg -hide_banner -y -i VIDEO_$1.mp4 -i AUDIO_$1.aac -c:v copy -c:a copy -map 0:v -map 1:a  "$1.mp4"

##	ffmpeg -y -vsync 1 -safe 0 -f concat -i filelist.txt -c copy "JENSEN-"$1".mp4"
	
##	ffmpeg -hide_banner -y -safe 0 -f concat -i filelist.txt -filter_complex "[0:a]aresample=44100" \
##	-async 1 -map 0 -c:v h264_nvenc -pix_fmt yuv420p -preset fast -c:a aac -ac 2 "JENSEN-"$1".mp4"

#	ffmpeg -hide_banner -y -safe 0 -f concat -i filelist.txt -filter_complex \
#                "[0]setpts=PTS-STARTPTS[v2]; \
#                 [0]asetpts=PTS-STARTPTS[a2] \
#                 " \
#       -map "[v2]" -map "[a2]" output.mp4

#	mkdir "JENSEN-"$1
#	mv 720*.ts "JENSEN-"$1
#	mv FILE_*.mp4 "JENSEN-"$1

}

rm filelist.txt

#for f in FILE_*_fixed.mp4; do
##  ffmpeg -i "$f" -c copy -fflags +genpts -bsf:a aac_adtstoasc "${f%.mp4}_fixed.mp4"
#  echo "file '"${f%.mp4}_fixed.mp4"'" >> filelist.txt
#done
#exit

## for ((VID = 704; VID >= 0; --VID)); do
## 	GETVIDEOTS $VID
## done
	GETVIDEOTS 704
# exit

## ffmpeg -y -safe 0 -f concat -i filelist.txt -c copy "combined.mp4"
## 
## ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:a]aresample=44100" \
## 	-c:v h264_nvenc -pix_fmt yuv420p -preset fast -c:a aac -ac 2 "$BASENAME.recoded.mp4"

# some_command
# if [ $? -eq 0 ]; then
#     echo OK
# else
#     echo FAIL
# fi


## ffmpeg -y -vsync 1 -safe 0 -f concat -i filelist.txt \
##     -filter_complex " \
##     [0:a]aresample=44100[a];
##     " \
##     -map "[a]" \
##     -map "v:0" \
##     -c:v h264_nvenc -profile:v high -pix_fmt yuv420p "combined.mp4"

#https://node-1.cdn.jensen.nl/djs_704/720p/720p1535.ts

# ffprobe -v error -select_streams v:0 -show_entries stream=duration -of default=noprint_wrappers=1:nokey=1 IMG_7679.mov
# 16.666016
# ffprobe -v error -select_streams a:0 -show_entries stream=duration -of default=noprint_wrappers=1:nokey=1 IMG_7679.mov
# 16.670998