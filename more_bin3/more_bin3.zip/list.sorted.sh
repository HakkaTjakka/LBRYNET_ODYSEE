# cd ~/movies5

## rm "BURN_VIDEO2.TXT"
## 
## echo " \\" > add_fix.txt
## echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
## echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
## echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=9lhBsn7t5Bw" --language nl

# echo " \\" > add_fix.txt
# echo '	--tags="The Trueman Show" \' >> add_fix.txt
# echo '	--tags="Jorn Luka"' >> add_fix.txt
# 
# ## sa "https://www.youtube.com/watch?v=LPyKV-FbNys" --language nl # 2026-01-22 -  1:59:35 - Waarom therapie vaak NIET werkt (en dit wel) | Psycholoog Ingeborg Bosch | The Trueman Show #261
# ## sa "https://www.youtube.com/watch?v=TT6rGzgENec" --language nl # 2026-01-15 -  2:45:14 - Waarom de maffia eerlijker is dan de overheid | Willem Engel | The Trueman Show #260
# ## sa "https://www.youtube.com/watch?v=U-blZkW811M" --language nl # 2026-01-08 -  2:15:47 - Angstcultuur en LEUGENS bij defensie | Klokkenluider Melchior Verbon | The Trueman Show #259
# sa "https://www.youtube.com/watch?v=ge5epx0eqr8" --language nl # 2024-06-06 -  1:25:33 - The Trueman Show #175 Eelco de Boer 'Nederland is het centrumland'

## echo " \\" > add_fix.txt
## echo '	--tags="Bergsma & Bennink" \' >> add_fix.txt
## echo '	--tags="Trump"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=gXVyE5EbIEA" --language nl # Bergsma & Bennink #24: Is Trump Hitler of toch gewoon The Godfather ?
## 
## cp bin/subtitle_ass_new.sh bin/subtitle_ass.sh
## chmod +x bin/subtitle_ass.sh

## echo " \\" > add_fix.txt
## echo '	--tags="The Trueman Show" \' >> add_fix.txt
## echo '	--tags="Jorn Luka"' >> add_fix.txt
## 
## # sa "https://www.youtube.com/watch?v=YfAmluY9BLM" --language en # 2026-01-01 -  2:25:18 - Why AI is the ULTIMATE Weapon of Control | David Icke | The Trueman Show #258
## 
## sa "https://www.youtube.com/watch?v=GcjNmtZTCIg" --language nl # 2025-12-25 -  2:03:32 - Van Belgische student tot staatsvijand | Politicus Dries van Langenhove | The Trueman Show #257
## sa "https://www.youtube.com/watch?v=loKUJq3dClM" --language nl # 2025-12-18 -  2:20:41 - Dit doet onverwerkt geboortetrauma met je lichaam | Anna Verwaal | Trueman Show #256
## sa "https://www.youtube.com/watch?v=Ww0OMseQsK0" --language nl # 2025-12-11 -  2:39:42 - De ONBEKENDE crisis onder mannen | Patrick Savalle | The Trueman Show #255
## sa "https://www.youtube.com/watch?v=6boChci93mM" --language nl # 2025-12-04 -  2:20:31 - De grootste leugen in de psychiatrie - Psychiater Bram Bakker & zoon Fimme | The Trueman Show #254
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Connect the dots"' >> add_fix.txt
## 
## saa "https://x.com/redpillb0t/status/2016992855408201852?s=20" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="1967"' >> add_fix.txt
## 
## saa "https://x.com/iluminatibot/status/2016987249536356728?s=20" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="tax"' >> add_fix.txt
## 
## saa "https://x.com/BrockRiddickIFB/status/2016504720622317773?s=20" --language en
## echo " \\" > add_fix.txt
## echo '	--tags="The Trueman Show" \' >> add_fix.txt
## echo '	--tags="Jorn Luka"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=XLcHvJLLaKs" --language nl # 2025-11-27 -  2:28:12 - De verborgen oorzaak van jouw klachten - Holistisch dierenarts Eric Laarakker | The Trueman Show
## sa "https://www.youtube.com/watch?v=6IQ9ujq-mMU" --language nl # 2025-11-20 -  2:29:55 - Waarom dit tijdperk móét instorten volgens Drs. Karen Hamaker-Zondag | The Trueman Show #252


## echo " \\" > add_fix.txt
## echo '	--tags="Connect the dots"' >> add_fix.txt
## 
## saa "https://x.com/redpillb0t/status/2016992855408201852?s=20" --language en


### echo " \\" > add_fix.txt
### echo '	--tags="1967"' >> add_fix.txt
### 
### saa "https://x.com/iluminatibot/status/2016987249536356728?s=20" --language en
### 
### 
### echo " \\" > add_fix.txt
### echo '	--tags="tax"' >> add_fix.txt
### 
### saa "https://x.com/BrockRiddickIFB/status/2016504720622317773?s=20" --language en
### 
### echo " \\" > add_fix.txt
### echo '	--tags="JFK" \' >> add_fix.txt
### echo '	--tags="FED" \' >> add_fix.txt
### echo '	--tags="Dollar"' >> add_fix.txt
### 
### saa "https://x.com/MindandEmotion7/status/2017009031538528389?s=20" --language en


## echo " \\" > add_fix.txt
## echo '	--tags="The Trueman Show" \' >> add_fix.txt
## echo '	--tags="Jorn Luka"' >> add_fix.txt
## 
## 
## sa "https://www.youtube.com/watch?v=yVacq740Biw" --language nl # 2025-11-13 -  1:48:15 - Geld, macht en moderne slavernij met financieel expert Mees Wijnants | The Trueman Show
## sa "https://www.youtube.com/watch?v=smp9pYYbr5g" --language nl # 2025-11-06 -  2:27:53 - Henk Fransen over de matrix, heling en innerlijke vrijheid | The Trueman Show #250
## sa "https://www.youtube.com/watch?v=oDyRY7V_BcQ" --language nl # 2025-10-30 -  3:17:51 - Marcel van Silfhout over macht, media en de manipulatie van ons voedsel | The Trueman Show #249
## sa "https://www.youtube.com/watch?v=jlksb5FXmDg" --language nl # 2025-10-23 -  2:05:11 - Richard de Leth over stress, ego en de illusie van controle | The Trueman Show #248
## sa "https://www.youtube.com/watch?v=lStrb_SGXvE" --language nl # 2025-10-16 -  2:08:06 - Advocaat Hester Bais over de grootste financiële fraude van Europa | The Trueman Show #247
## sa "https://www.youtube.com/watch?v=oM-PZgQOYm8" --language nl # 2025-10-09 -  2:08:52 - Wybren van Haga over vrijheid, macht en de rol van de Staat | The Trueman Show #246
## sa "https://www.youtube.com/watch?v=bVRSAW8S-ac" --language nl # 2025-10-02 -  2:46:14 - Brecht Arnaert over Schaduwwerk, Mystieke Ervaringen en een Nieuw Paradigma | The Trueman Show #245
## sa "https://www.youtube.com/watch?v=SgPFsGdrR9s" --language nl # 2025-09-25 -  2:18:27 - Homeopaat Ewald Stöteler over Ziektes, Vaccins en Zelf Genezen | The Trueman Show #244
## sa "https://www.youtube.com/watch?v=4n9VPPmg91s" --language nl # 2025-09-18 -  1:59:02 - Nino over Frequenties, NPC's en Verloren Kennis | The Trueman Show #243

## echo " \\" > add_fix.txt
## echo '	--tags="illuminati" \' >> add_fix.txt
## echo '	--tags="CFR"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=gySJk1rxhyU" --language en

## echo " \\" > add_fix.txt
## echo '	--tags="The Trueman Show" \' >> add_fix.txt
## echo '	--tags="Jorn Luka"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=pcvAh2VeXfc" --language nl # 2025-09-11 -  2:01:08 - Wesley Feijth over Privacy, Big Tech en het Sociaal Kredietsysteem | The Trueman Show #242
## sa "https://www.youtube.com/watch?v=60mSlvCptLk" --language nl # 2025-09-06 -  3:59:30 - Toine Manders over Belasting, Vrijheid (van Meningsuiting) en Emigreren | The Trueman Show #241
## sa "https://www.youtube.com/watch?v=kc6oh1ourFg" --language nl # 2025-08-29 -  2:00:57 - Elze van Hamelen over De Grote Verbouwing van Nederland | The Trueman Show #240
## sa "https://www.youtube.com/watch?v=Rb1HYEujzHk" --language nl # 2025-08-21 -  2:47:29 - ''Het gewone volk wordt geofferd in deze oorlog'' - Ab Gietelink | The Trueman Show #239

## sa "https://www.youtube.com/watch?v=QELBpD_xUvU" --language nl # 2025-08-14 -  2:42:23 - Toeslagenaffaire, kinderhandel, adoptielobby en orgaanhandel met Roelie Post | The Trueman Show #238
## sa "https://www.youtube.com/watch?v=f2Ypf2ZHu2A" --language nl # 2025-08-07 -  2:24:33 - Hollywood, Transgenders en de Cabal met Okkie en Désirée | The Trueman Show #237
## sa "https://www.youtube.com/watch?v=_zVZEbWP3Zg" --language nl # 2025-07-31 -  1:53:29 - Hooggevoeligheid, Energetische Bescherming en Corona in de zorg | The Trueman Show #236
## sa "https://www.youtube.com/watch?v=EmYpMaozSn8" --language nl # 2025-07-24 -  1:52:34 - Pizzagate, dubbelgangers en human trafficking met EllaSter | The Trueman Show #235
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Helen Andrews" \' >> add_fix.txt
## echo '	--tags="Feminization"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=EWLbq7PlrIA" --language en 

## echo " \\" > add_fix.txt
## echo '	--tags="The Trueman Show" \' >> add_fix.txt
## echo '	--tags="Jorn Luka"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=gtXVAFqNDNQ" --language nl # 2025-07-10 -  2:06:18 - Veilig bij jezelf met Fleur van Groningen | The Trueman Show #233
## sa "https://www.youtube.com/watch?v=FoAX4FthYb0" --language nl # 2025-07-03 -  2:34:30 - ''Depopulation is on the Agenda'' with Catherine Austin Fitts | The Trueman Show #232
## sa "https://www.youtube.com/watch?v=DlojeYSwY6s" --language nl # 2025-06-26 -  1:37:12 - Russian Ambassador speaks out during NATO Summit in the Netherlands | The Trueman Show #231
## sa "https://www.youtube.com/watch?v=z_2bVVmGW_A" --language nl # 2025-06-24 -  1:50:30 - ‘’Wat gebeurt er in Iran?’’ Diedert de Wagt | The Trueman Show #230
## sa "https://www.youtube.com/watch?v=huQRwSY77Lc" --language nl # 2025-06-19 -  3:05:13 - ''Dit is letterlijk de diepste vorm van slavernij'' Judith Zeeman | The Trueman Show #229
## sa "https://www.youtube.com/watch?v=kj1NP_DgZww" --language nl # 2025-06-12 -  2:04:02 - ''Alles is abnormaal in dit land'' Ab Flipse | The Trueman Show #228

## sa "https://www.youtube.com/watch?v=TIBgVc7DalE" --language nl # 2025-06-05 -  3:52:32 - ''This is an Anti Human Agenda'' David Icke | The Trueman Show #227
## sa "https://www.youtube.com/watch?v=TgyI_FBG8Q8" --language nl # 2025-05-29 -  2:51:37 - Pete Philly over Lyme, verdeel en heers en de invloed van Big Pharma | The Trueman Show #226
## sa "https://www.youtube.com/watch?v=V0D54J3tbDA" --language nl # 2025-05-22 -  1:56:08 - ''De Natuur waarschuwt, maar niemand luistert'' met Piet Grasspriet | The Trueman Show #225
## sa "https://www.youtube.com/watch?v=5wm8oQ6ClrM" --language nl # 2025-05-15 -  2:09:39 - Jezelf vergeven (voor alles) met Lisette Thooft | The Trueman Show #224
## sa "https://www.youtube.com/watch?v=WbzItqS0DnE" --language nl # 2025-05-08 -  2:18:37 - Vader- en moederwonden met Lars Faber | The Trueman Show #223
## sa "https://www.youtube.com/watch?v=PQ28X-_BpcI" --language nl # 2025-05-01 -  2:14:01 - Rechter klapt uit de school over de nieuwe wereldregering, CBDC en pedofielen| The Trueman Show #222
## sa "https://www.youtube.com/watch?v=CU4rdqMPAfA" --language nl # 2025-04-24 -  2:24:05 - Flavio Pasquino: ‘Was Blckbx van binnenuit aangestuurd?’ | The Trueman Show #221
## sa "https://www.youtube.com/watch?v=NY7BcgIVRVs" --language nl # 2025-04-17 -  2:03:32 - Mannelijk en Vrouwelijk weer in Balans met Marja de Vries | The Trueman Show #220

## echo " \\" > add_fix.txt
## echo '	--tags="Henk Versteeg" \' >> add_fix.txt
## echo '	--tags="Agenda 2030"' >> add_fix.txt
## 
## saf "Aflevering_1_2_en_3_Henk_Versteeg.mp4" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="Rosa Koire" \' >> add_fix.txt
## echo '	--tags="Agenda 2030" \' >> add_fix.txt
## echo '	--tags="SMART city"' >> add_fix.txt
## 
## sa "https://odysee.com/@FwapUK:1/Agenda-21-In-Detail-(2013)-Behind-The-Green-Mask-:5" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="The Trueman Show" \' >> add_fix.txt
## echo '	--tags="Jorn Luka"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=ZcXf2MRT1rg" --language nl # 2025-04-10 -  2:03:52 - Doe Maar oprichter Ernst Jansz over vrede en vrijheid | The Trueman Show #219
## sa "https://www.youtube.com/watch?v=7qheN-qr8zo" --language nl # 2025-04-03 -  2:59:20 - Magie en ‘the Multiverse’ met Benjamin Adamah | The Trueman Show #218
## sa "https://www.youtube.com/watch?v=kIEwxhI-Rs8" --language nl # 2025-03-27 -  2:23:36 - ''Vertrouwen in het Goede'' - Michael Pilarczyk | The Trueman Show #217
## sa "https://www.youtube.com/watch?v=An1IacgADjY" --language nl # 2025-03-20 -  3:06:47 - Illuminati, Khazaren en de Eindtijd met Brecht Arnaert | The Trueman Show #216
## sa "https://www.youtube.com/watch?v=t8EIXpoMFLM" --language nl # 2025-03-13 -  3:05:34 - Desiree Rover over de seksualisering van kinderen en de psychiatrie | The Trueman Show #215
## sa "https://www.youtube.com/watch?v=cqydwgAq-GM" --language nl # 2025-03-06 -  1:54:45 - Jozef Ritman over de Bibliotheca Philosophica Hermetica | The Trueman Show #214
## 
## echo " \\" > add_fix.txt
## echo '	--tags="TESTIMONIAL 2014" \' >> add_fix.txt
## echo '	--tags="ceremonial sacrifices" \' >> add_fix.txt
## echo '	--tags="ANNE MARIE VAN BLIJENBURGH"' >> add_fix.txt
## 
## echo "BURN_VIDEO2.TXT" > "BURN_VIDEO2.TXT"
## 
## saa "https://odysee.com/@Anonymous:bc/TESTIMONIAL-ANNE-MARIE-VAN-BLIJENBURGH-2014-%E2%80%94-ENGLISH-SPOKEN,-DUTCH-SUBTITLES:b" --language en
## 
## rm "BURN_VIDEO2.TXT"

## echo " \\" > add_fix.txt
## echo '	--tags="The Trueman Show" \' >> add_fix.txt
## echo '	--tags="Jorn Luka"' >> add_fix.txt
## 
## 
## sa "https://www.youtube.com/watch?v=XLubq4i1NY4" --language nl # 2025-02-27 -  3:42:20 - Historicus Diedert de Wagt over Project Blue Beam, de CIA en de Derde Tempel | The Trueman Show #213
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Tucker Carlson" \' >> add_fix.txt
## echo '	--tags="Pizzagate"' >> add_fix.txt

## saa "https://x.com/TuckerCarlson/status/2019833474048197053?s=20" --language en

echo " \\" > add_fix.txt
echo '	--tags="The Trueman Show" \' >> add_fix.txt
echo '	--tags="Jorn Luka"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=dEVNF6p9vTI" --language nl # 2025-02-20 -  3:17:35 - Marie Therese ter Haar over Rusland, Vrede en Cultuur | The Trueman Show #212
## sa "https://www.youtube.com/watch?v=0UZitXh9gF0" --language nl # 2025-02-13 -  2:56:43 - Jerome Wehrens over onze maakbare wereld | The Trueman Show #211
## sa "https://www.youtube.com/watch?v=wNVLpbwM1XQ" --language nl # 2025-02-06 -  1:54:34 - Gideon van Meijeren over Baybasin, Ritueel Kindermisbruik en de Elite | The Trueman Show #210
## sa "https://www.youtube.com/watch?v=B0AkNDylhI8" --language nl # 2025-02-05 -     2:55 - Dit is The Trueman Show
## sa "https://www.youtube.com/watch?v=ZmK2lop8BXU" --language nl # 2025-01-30 -  1:31:22 - Kees de Kort over de veranderingen op het wereldtoneel | The Trueman Show #209
## sa "https://www.youtube.com/watch?v=Af0N5X0eMtA" --language nl # 2025-01-23 -  2:48:11 - ''Een individuele revolutie op heldenvoeten'' Steve van Herreweghe | The Trueman Show #208
## sa "https://www.youtube.com/watch?v=AZXk-rPZY8A" --language nl # 2025-01-16 -  1:47:30 - Oud-topambtenaar Hans Siepel over Agenda 2030, de Geest en de Eindtijd | The Trueman Show #207
## sa "https://www.youtube.com/watch?v=9cCx7WMVdP4" --language nl # 2025-01-09 -  1:40:45 - Emeritus hoogleraar Cees Hamelink over oorlog en vrije media | The Trueman Show #206
## sa "https://www.youtube.com/watch?v=T5pVYPQL_VY" --language nl # 2025-01-02 -  2:30:36 - Macht en Schaduwwerk met Karen Hamaker-Zondag | The Trueman Show #205

## sa "https://www.youtube.com/watch?v=YMLKfnicfNg" --language nl # 2024-12-26 -  1:46:45 - Bob de Wit over Artificial Intelligence en het Einde van de Samenleving | The Trueman Show #204
## sa "https://www.youtube.com/watch?v=qIzM-nkLvoQ" --language nl # 2024-12-19 -  2:26:07 - Aquatisch Ecoloog Theo Claassen over de Spiritualiteit in Water | The Trueman Show #203
## sa "https://www.youtube.com/watch?v=hX618OuCGms" --language nl # 2024-12-12 -  1:21:42 - Oud-topvoetballer Ryan Babel over Corona, Brainwashing en Crypto | The Trueman Show #202
## sa "https://www.youtube.com/watch?v=13brHTg3VcY" --language nl # 2024-12-05 -  3:04:40 - Desiree Rover over angstp*rno en Westerse patentgeneeskunde | The Trueman Show #201
## sa "https://www.youtube.com/watch?v=Vr83dXxBKjQ" --language nl # 2024-11-28 -  2:24:39 - De Germaanse Geneeskunde Undercover in Nederland | The Trueman Show #200
## sa "https://www.youtube.com/watch?v=ni1i2rsN53U" --language nl # 2024-11-21 -  2:39:22 - Schadelijke gevolgen van Windmolens met Bert Weteringe | The Trueman Show #199
## 
## echo Toets Enter
## read aaa

## sa "https://www.youtube.com/watch?v=FzyvOBHJlsU" --language nl # 2024-11-14 -  1:53:47 - Nag Hammadi en Gnostiek met Jacob Slavenburg | The Trueman Show #198
## sa "https://www.youtube.com/watch?v=XWf_DcRWl-Y" --language nl # 2024-11-07 -  2:08:23 - Ad Verbrugge: ''We Zetten de Wereld op Zijn Kop'' | The Trueman Show #197
## sa "https://www.youtube.com/watch?v=KXV3D9SdL8Y" --language nl # 2024-10-31 -  1:51:45 - Oorlogsmisdaden van de V.S. met Diedert de Wagt | The Trueman Show #196
## sa "https://www.youtube.com/watch?v=UmpLmNscYJk" --language nl # 2024-10-24 -  1:55:53 - Henk Krol: ''Zet Mensen Nou Niet Weg Als Wappies'' | The Trueman Show #195
## sa "https://www.youtube.com/watch?v=MilFvD7zUAE" --language nl # 2024-10-17 -  2:17:35 - Jan Bommerez: Het Duister Wordt Steeds Meer Zichtbaar | The Trueman Show #194
## sa "https://www.youtube.com/watch?v=2dCufofd08Q" --language nl # 2024-10-10 -  2:43:00 - Huisarts Richard Hoofs Over De Egyptische Wijsheden | The Trueman Show #193
## sa "https://www.youtube.com/watch?v=eLKn5HdG4PE" --language nl # 2024-10-03 -  2:27:06 - Okkie Durham: Dit Is Heftiger Dan Epstein | The Trueman Show #192
## sa "https://www.youtube.com/watch?v=2yzI6oKdJxE" --language nl # 2024-09-30 -  2:17:58 - Nederland Is Het Meest Mysterieuze Land Aller Tijden | The Trueman Show #191
## sa "https://www.youtube.com/watch?v=kqMwi15nvUI" --language nl # 2024-09-19 -  2:24:11 - The Trueman Show #190 Jessie Jazz Vuijk 'Ontwikkel je eigen bullshit-meter'
## sa "https://www.youtube.com/watch?v=CBQCNFvm8Ek" --language nl # 2024-09-12 -  2:02:08 - The Trueman Show #189 Rypke Zeilmaker 'Chemtrails: oorlog tegen het licht'
## sa "https://www.youtube.com/watch?v=YWyNADwhW-4" --language nl # 2024-09-05 -  1:53:16 - The Trueman Show #188 Jan Ott 'De Nederlandse geschiedenis zit anders'
## sa "https://www.youtube.com/watch?v=wQ5d2R6lhEk" --language nl # 2024-08-29 -  1:17:50 - The Trueman Show #187 Pepijn van Houwelingen 'Dick Schoof is het ultieme establishment'
## sa "https://www.youtube.com/watch?v=6Ol7D3j48RY" --language nl # 2024-08-22 -  1:46:41 - The Trueman Show #186 André de Boer '100 jaar Rozenkruis'
## sa "https://www.youtube.com/watch?v=xJpR6lTivFc" --language nl # 2024-08-15 -  2:01:03 - The Trueman Show #185 Lucas Hollertt 'Ze verkopen hun ziel aan de duivel'
## sa "https://www.youtube.com/watch?v=eJ8MMtt0tLA" --language nl # 2024-08-08 -  1:44:11 - The Trueman Show #184 Joep Rovers 'Je kunt het wél zelf'
## sa "https://www.youtube.com/watch?v=6wNv2e5fNbQ" --language nl # 2024-08-01 -  2:58:51 - The Trueman Show #183 Robert Valentine & Boris van de Ven 'Lach om deze clownswereld'
## sa "https://www.youtube.com/watch?v=XbTBTxOob4U" --language nl # 2024-07-25 -  3:16:28 - The Trueman Show #182 Stef Bos 'Het antwoord zit in ons'
## sa "https://www.youtube.com/watch?v=t868Kyv2_gY" --language nl # 2024-07-18 -  1:40:40 - The Trueman Show #181 Eric van de Beek 'Journalisten moeten hun mond houden'
## sa "https://www.youtube.com/watch?v=UCKyaxXY80k" --language nl # 2024-07-11 -  1:35:55 - The Trueman Show #180 Charlotte Labee 'De norm is niet oké'
## sa "https://www.youtube.com/watch?v=aCyd_ScFOug" --language nl # 2024-07-04 -  2:16:34 - The Trueman Show #179 Theo Schetters 'Dit hadden ze niet mogen doen'
## sa "https://www.youtube.com/watch?v=vRXBnJCtE-M" --language nl # 2024-06-27 -  1:39:51 - The Trueman Show #178 Mees Baaijen 'Oorlogen worden gemaakt'
## sa "https://www.youtube.com/watch?v=xyYXy_BrMiI" --language nl # 2024-06-20 -  1:19:49 - The Trueman Show #177 Jucelino da Luz 'I want to prepare people'
## sa "https://www.youtube.com/watch?v=Xju0OddhG8A" --language nl # 2024-06-13 -  2:02:21 - The Trueman Show #176 Lars Faber 'Een kind moet zich geliefd voelen'
## sa "https://www.youtube.com/watch?v=plBMA35wDK0" --language nl # 2024-05-30 -  1:42:02 - The Trueman Show #174 Hylke Bonnema 'Maak contact met je kwetsbaarheid'
## 
## echo press enter 
## read aaa 

## sa "https://www.youtube.com/watch?v=SjRRuqKZlp8" --language nl # 2024-05-23 -  1:32:02 - The Trueman Show #173 Hans Andréa 'Harry Potter is een Rozenkruisers verhaal'
## sa "https://www.youtube.com/watch?v=moxIXTsnwic" --language nl # 2024-05-16 -  1:22:16 - The Trueman Show #172 Bram Bakker 'De wereld is gek, jij niet'
## sa "https://www.youtube.com/watch?v=_I8YrxzMBjU" --language nl # 2024-05-09 -  2:08:49 - The Trueman Show #171 Roy Martina 'Vergeet niet te genieten'
## sa "https://www.youtube.com/watch?v=ge5epx0eqr8" --language nl # 2024-06-06 -  1:25:33 - The Trueman Show #175 Eelco de Boer 'Nederland is het centrumland'
## sa "https://www.youtube.com/watch?v=2hMLDh6Rkno" --language nl # 2024-05-02 -  1:31:23 - The Trueman Show #170 Jay Francis 'Je drijfveer moet groter zijn dan jijzelf'

## sa "https://www.youtube.com/watch?v=Bf_RyrEPaAs" --language nl # 2024-04-25 -  2:01:09 - The Trueman Show #169 Brecht Arnaert 'We zijn niet perfect en dat moet ook niet'
## sa "https://www.youtube.com/watch?v=NZdrp_DJT3g" --language nl # 2024-04-18 -  1:09:11 - The Trueman Show #168 Pierre Capel 'Geef ruimte aan wat je niet snapt'
## sa "https://www.youtube.com/watch?v=1aGA-jS5GUw" --language nl # 2024-04-11 -  1:22:28 - The Trueman Show #167 Bert Janssen 'Jij bepaalt welk spel je speelt'

## sa "https://www.youtube.com/watch?v=XqE9Aka70mA" --language nl # 2024-04-04 -  1:18:00 - The Trueman Show #166 Rients Hofstra 'Het systeem klopt niet'
## 
## echo PRESS ENTER
## read aaa 

echo " \\" > add_fix.txt
echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=r6s5De8LDsk" --language nl

echo " \\" > add_fix.txt
echo '	--tags="The Trueman Show" \' >> add_fix.txt
echo '	--tags="Jorn Luka"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=Kzg_Yuvuy8g" --language nl # 2024-03-28 -  1:27:32 - The Trueman Show #165 Dwight Gefferie & Mariëtte Ruggenberg ‘Omarm realisme in de liefde’
sa "https://www.youtube.com/watch?v=T6wIjTzAunQ" --language nl # 2024-03-21 -  1:22:30 - The Trueman Show #164  Yvonne Toeset 'De mens is geen protocol'
sa "https://www.youtube.com/watch?v=OFRTIoHLs1E" --language nl # 2024-03-14 -  1:31:59 - The Trueman Show #163 Frank Ruesink & Zeno Groenewegen 'Leerplicht is leerlast.'
sa "https://www.youtube.com/watch?v=9XYwEpr9zD4" --language nl # 2024-03-07 -  1:53:04 - The Trueman Show #162 Marina Riemslagh 'Traumaheling hoeft geen drama te zijn'
sa "https://www.youtube.com/watch?v=bym5E4rYLrY" --language nl # 2024-02-29 -  2:00:18 - The Trueman Show #161 Jeremy Nell 'We are living in a very theatrical world'
sa "https://www.youtube.com/watch?v=9bImS7IJszk" --language nl # 2024-02-22 -  2:24:00 - The Trueman Show #160 Stef Bos ‘Niet weten is de grote wetenschap’
sa "https://www.youtube.com/watch?v=LtZP1fVXtUw" --language nl # 2024-02-15 -  2:19:10 - The Trueman Show #159 Michael Tellinger 'We are like a species with amnesia’
sa "https://www.youtube.com/watch?v=YsducVja3WA" --language nl # 2024-02-08 -  1:37:53 - The Trueman Show #158 Hans Peter Roel ‘Manifesteren ten dienste van de Schepping'
sa "https://www.youtube.com/watch?v=kcQYElPlL-M" --language nl # 2024-02-01 -  1:31:43 - The Trueman Show #157 Marleen van den Hout ‘Ademen vanuit je bekken’
sa "https://www.youtube.com/watch?v=Au68INjmNQ0" --language nl # 2024-01-25 -  1:12:15 - The Trueman Show #156 Annemiek Dogan 'Er is niets zo natuurlijk als rouw'
sa "https://www.youtube.com/watch?v=kiyfXt8qSpk" --language nl # 2024-01-18 -  2:17:57 - The Trueman Show #155 Johan Denis 'Germaanse Geneeskunde is de bevrijding'
sa "https://www.youtube.com/watch?v=34ODQwXkSio" --language nl # 2024-01-11 -  1:47:49 - The Trueman Show #154 Dr. Peter Borger 'Evolutietheorie niet langer houdbaar’
# sa "https://www.youtube.com/watch?v=yzKbEOPNNUM" --language nl # 2024-01-04 -       57 - The Trueman Show Theater Tour - De weg naar Vrijheid
sa "https://www.youtube.com/watch?v=0wYxBeD94B8" --language nl # 2024-01-04 -  1:15:03 - The Trueman Show #153 Karin Hogenboom ’Oogheling als poort naar de ziel’
sa "https://www.youtube.com/watch?v=--XWcFU3iFs" --language nl # 2023-12-28 -  1:55:25 - The Trueman Show #152 Maarten Oversier ‘Vrij van angst je lied zingen’
sa "https://www.youtube.com/watch?v=vuF_8GRg4mQ" --language nl # 2023-12-21 -  1:36:28 - The Trueman Show #151 Peter Vereecke 'Ze beschouwen ons als vee'
sa "https://www.youtube.com/watch?v=vvBHjOXzI40" --language nl # 2023-12-14 -  1:40:10 - The Trueman Show #150 Kiesha Crowther 'We are not here to suffer'
sa "https://www.youtube.com/watch?v=KDCTIySgJVk" --language nl # 2023-12-07 -  1:19:56 - The Trueman Show #149 Paul Buitink 'We moeten niet doorslaan in wantrouwen'
sa "https://www.youtube.com/watch?v=RPQNQk4vh8k" --language nl # 2023-11-30 -  1:36:41 - The Trueman Show #148 Jaap van der Wal 'Fenomenologische embryologie'
sa "https://www.youtube.com/watch?v=Yrhsg3wl58c" --language nl # 2023-11-23 -  2:24:08 - The Trueman Show #147 Marijn Poels 'Spiritualiteit is ook wiskunde'
sa "https://www.youtube.com/watch?v=7QwSsPsxbxI" --language nl # 2023-11-16 -  2:03:25 - The Trueman Show #146 Thierry Baudet 'Wel of niet stemmen?'
sa "https://www.youtube.com/watch?v=wpLkEqMnzpc" --language nl # 2023-11-09 -  2:09:24 - The Trueman Show #145 Flavio Pasquino & Sander Compagner 'We kunnen weer gaan bouwen'
sa "https://www.youtube.com/watch?v=Uc-k1xVDD7Y" --language nl # 2023-11-02 -  1:53:30 - The Trueman Show #144 Jan Storms 'In bewustzijn schuilt een onbegrensde kracht'
sa "https://www.youtube.com/watch?v=Xo4NQ480uSM" --language nl # 2023-10-26 -  1:32:23 - The Trueman Show #143 Yama Voorhorst 'Het was een onhoudbare situatie'
sa "https://www.youtube.com/watch?v=paMMxv9DR9w" --language nl # 2023-10-19 -  2:49:59 - The Trueman Show #142 Robert Valentine & Boris van de Ven 'Democratie is onzin'
sa "https://www.youtube.com/watch?v=B177-trFc_8" --language nl # 2023-10-12 -  1:52:44 - The Trueman Show #141 Fresku 'Ik ben geen activist, ik ben een kunstenaar'
sa "https://www.youtube.com/watch?v=5QZkpkGECGI" --language nl # 2023-10-05 -  1:19:17 - The Trueman Show #140 Shanti Schiks ‘Een psychische gevangenis’
sa "https://www.youtube.com/watch?v=ZWhSqRA05s4" --language nl # 2023-09-28 -  1:40:40 - The Trueman Show #139 Carla de Ruiter ‘Er komt een eind aan persoonlijke ontwikkeling’
sa "https://www.youtube.com/watch?v=-swYPp6k9xw" --language nl # 2023-09-21 -  1:05:25 - The Trueman Show #138 Frank Veldman 'De zon is niet je vijand'
sa "https://www.youtube.com/watch?v=UflYlvcwP1g" --language nl # 2023-09-14 -  1:58:46 - The Trueman Show #137 Kees van der Pijl 'Wat daar gebeurt is een horror story'
sa "https://www.youtube.com/watch?v=mXrgZplG3l8" --language nl # 2023-09-07 -  2:06:21 - The Trueman Show #136 Appa ‘Ieder zijn overtuiging’
sa "https://www.youtube.com/watch?v=Xa2y1qV1-Ds" --language nl # 2023-08-31 -  2:21:16 - The Trueman Show #135 Elze van Hamelen ‘De componenten van gedragsbeïnvloeding’
sa "https://www.youtube.com/watch?v=Vnlbbu-Dkpk" --language nl # 2023-08-24 -  1:25:31 - The Trueman Show #134 Arjan Bos ‘De bespeling van onze perceptie’
sa "https://www.youtube.com/watch?v=Br-joTxsafI" --language nl # 2023-08-17 -  1:42:52 - The Trueman Show #133 Tjeerd Andringa 'Mijn ideale wereld is anarchisme'
sa "https://www.youtube.com/watch?v=r47w16Yt568" --language nl # 2023-08-10 -  2:01:09 - The Trueman Show #132 Ab Flipse 'Dit is iets wat ik eigenlijk nooit uit'
sa "https://www.youtube.com/watch?v=7sSZNnm-PGc" --language nl # 2023-08-03 -  1:56:25 - The Trueman Show #131 Monique Timmers 'Ik denk dat wij niet denken'
sa "https://www.youtube.com/watch?v=qHt9IvNGy5Y" --language nl # 2023-07-27 -  1:14:26 - The Trueman Show #130 Ellemieke Vermolen 'Jezelf vergeven is het mooiste wat er is'
sa "https://www.youtube.com/watch?v=lWtClqXvldg" --language nl # 2023-07-26 -  2:16:44 - The Trueman Show #129 Reinoud Eleveld & Daan Jacobs 'Dit zouden alle mensen moeten weten'
sa "https://www.youtube.com/watch?v=KblzTzIGHks" --language nl # 2023-07-13 -  1:51:07 - The Trueman Show #128 Jan Bommerez 'Jouw transformatie transformeert de wereld'
sa "https://www.youtube.com/watch?v=Iqxk7lhJk3Q" --language nl # 2023-07-06 -  1:38:43 - The Trueman Show #127 Patrick Savalle 'De slag om AI'
sa "https://www.youtube.com/watch?v=wIcuma8bEZI" --language nl # 2023-06-29 -  1:58:10 - The Trueman Show #126 Sarah Leers 'Het weten zit in ons'
sa "https://www.youtube.com/watch?v=JXjvtmNxB2I" --language nl # 2023-06-22 -  1:45:19 - The Trueman Show #125 Robert Bridgeman 'Verlichting is niet het doel'
sa "https://www.youtube.com/watch?v=I_2n3A_LesU" --language nl # 2023-06-15 -  2:20:32 - The Trueman Show #124 Saskia Bosman 'Wij mogen Atlantis herkansen'
sa "https://www.youtube.com/watch?v=u7zz5F_oU9U" --language nl # 2023-06-08 -  2:32:46 - The Trueman Show #123 Lars Faber 'Ademhaling is voelen'
sa "https://www.youtube.com/watch?v=Us8sPbOjbus" --language nl # 2023-06-01 -  2:05:56 - The Trueman Show #122 Dino Sarac ‘We zijn allemaal één boom’
sa "https://www.youtube.com/watch?v=i7V_tR9vPjk" --language nl # 2023-05-25 -  1:12:53 - The Trueman Show #121 Ramon Roelofs ‘Het ego moet de pijp uit’
sa "https://www.youtube.com/watch?v=FE2W9amiRvk" --language nl # 2023-05-18 -  1:07:38 - The Trueman Show #120 Alistair Overeem ‘Je pijn is je springplank’
sa "https://www.youtube.com/watch?v=gMFXSuV8HVA" --language nl # 2023-05-11 -  2:06:16 - The Trueman Show #119 Benjamin van Doorslaer ‘De weg naar financiële vrijheid’
sa "https://www.youtube.com/watch?v=XjLUVfIE3Zw" --language nl # 2023-05-04 -  1:37:37 - The Trueman Show #118 Daniel Zavrel ‘Volg je hart en het komt altijd goed’
sa "https://www.youtube.com/watch?v=j4amDg-xGV4" --language nl # 2023-04-27 -  1:41:58 - The Trueman Show #117 Henk Fransen 'Waar je in gelooft, daar zit je leven'
sa "https://www.youtube.com/watch?v=QHu4nuqjZmY" --language nl # 2023-04-20 -  1:11:24 - The Trueman Show #116 Yvette Broch 'De keerzijde van topsport'
sa "https://www.youtube.com/watch?v=dy9MVyRz5gM" --language nl # 2023-04-13 -  1:55:37 - The Trueman Show #115 Thierry Baudet 'Het is tijd voor spiritualiteit'
sa "https://www.youtube.com/watch?v=Cpf8fxCjOjA" --language nl # 2023-04-06 -  1:20:05 - The Trueman Show #114 Pim van Lommel 'Is er leven na de dood?'
sa "https://www.youtube.com/watch?v=vt5Y3mUdkTI" --language nl # 2023-03-30 -  2:01:15 - The Trueman Show #113 Laurens Buijs ‘Gender en de kracht van balans’
sa "https://www.youtube.com/watch?v=_slmUH8y3cU" --language nl # 2023-03-23 -  2:44:36 - The Trueman Show #112 Jandino Asporaat 'Het einddoel is liefde'
sa "https://www.youtube.com/watch?v=NrO1ZbW2Bm8" --language nl # 2023-03-16 -  1:56:23 - The Trueman Show #111 Karen Hamaker-Zondag ‘De wondere wereld’
sa "https://www.youtube.com/watch?v=z-5y9YAfnfM" --language nl # 2023-03-09 -  1:51:28 - The Trueman Show #110 Mattias Desmet ‘Boekverbod op bestseller’
sa "https://www.youtube.com/watch?v=QodVmkslR_g" --language nl # 2023-03-02 -  2:06:35 - The Trueman Show #109 Marcel Crok ‘Klimaatcrisis: echt of niet?’
sa "https://www.youtube.com/watch?v=-BVtXr1X5fM" --language nl # 2023-02-23 -  2:00:16 - The Trueman Show #108 Rolf Nuyts ‘De matrix doorzien’
sa "https://www.youtube.com/watch?v=nJAgfQWNbKk" --language nl # 2023-02-16 -  2:01:41 - The Trueman Show #107 Sander Compagner ‘Wat de F gebeurt er?’
sa "https://www.youtube.com/watch?v=REhKoIQ0X6E" --language nl # 2023-02-09 -  2:18:47 - The Trueman Show #106 Anna Verwaal ‘Hoe was jouw geboorte?’
sa "https://www.youtube.com/watch?v=2PXNst3syAg" --language nl # 2023-02-02 -  1:33:10 - The Trueman Show #105 Anouk Bindels ‘De wijsheid van trauma’
sa "https://www.youtube.com/watch?v=0LHpimxEiqU" --language nl # 2023-01-26 -  1:39:24 - The Trueman Show #104 Fajah Lourens ‘Eigenwijs succesvol’
sa "https://www.youtube.com/watch?v=b6tw3m_wjYw" --language nl # 2023-01-19 -  3:35:30 - The Trueman Show #103 Robert Valentine & Boris van de Ven ‘Filosoferen in de coffeeshop'
sa "https://www.youtube.com/watch?v=1ZuJtiJObh0" --language nl # 2023-01-12 -  1:46:39 - The Trueman Show #102 Willem Glaudemans ‘Vergeven is bevrijding’
sa "https://www.youtube.com/watch?v=qT8ltkQHibg" --language nl # 2023-01-05 -  2:03:56 - The Trueman Show #101 Flavio Pasquino ‘Wat is waarheid?’
sa "https://www.youtube.com/watch?v=FUdfjCkNIto" --language nl # 2022-12-29 -  2:48:08 - The Trueman Show #100 Jorn Luka & Isa Kriens 'Terugblik op 2 jaar The Trueman Show'
sa "https://www.youtube.com/watch?v=J_HAct8I80Y" --language nl # 2022-12-28 -     4:33 - The Trueman Show herijkt
sa "https://www.youtube.com/watch?v=w7HAq6SkIDk" --language nl # 2022-12-08 -  1:08:14 - The Trueman Show #99 Karsten van Asdonk
sa "https://www.youtube.com/watch?v=AV6E_OOz0Zw" --language nl # 2022-12-01 -  1:30:19 - The Trueman Show #98 Janosh
sa "https://www.youtube.com/watch?v=WGQjudVMakQ" --language nl # 2022-11-24 -  1:28:52 - The Trueman Show #97 Steff Beerenfenger
sa "https://www.youtube.com/watch?v=rXD50G09G5Y" --language nl # 2022-11-10 -  1:38:16 - The Trueman Show #95 Nino
sa "https://www.youtube.com/watch?v=No5sjL83-LY" --language nl # 2022-10-27 -  1:40:26 - The Trueman Show #93 Hannah Cuppen
sa "https://www.youtube.com/watch?v=2VYp2bWTWC4" --language nl # 2022-10-13 -  2:16:51 - The Trueman Show #92 Anneke Lucas
sa "https://www.youtube.com/watch?v=asDYCDR_S5A" --language nl # 2022-10-06 -  1:29:23 - The Truemanshow #91 Robert Bridgeman
sa "https://www.youtube.com/watch?v=6B3cUtdomUM" --language nl # 2022-09-22 -  1:36:42 - The Trueman Show #90 Lars Faber
sa "https://www.youtube.com/watch?v=3NYLUlF1ZH8" --language nl # 2022-09-15 -  1:23:44 - The Trueman Show #89 Anton Teuben
sa "https://www.youtube.com/watch?v=CVqfcR63jqc" --language nl # 2022-09-08 -  1:56:04 - The Trueman Show #88 Edwin Selij
sa "https://www.youtube.com/watch?v=cTXtOoPPOnA" --language nl # 2022-09-01 -  1:45:08 - The Trueman Show #87 Swami Purnachaitanya
sa "https://www.youtube.com/watch?v=IqJRkMx0frM" --language nl # 2022-08-25 -  1:24:01 - The Trueman Show #86 Brahman Menor
sa "https://www.youtube.com/watch?v=TZImvPv7aYI" --language nl # 2022-08-18 -  1:21:04 - The Trueman Show #85 Sylvia Slegers
sa "https://www.youtube.com/watch?v=Zbr8jA3lH7M" --language nl # 2022-08-11 -  2:02:23 - The Trueman Show #84 Bart Uytterhaegen
sa "https://www.youtube.com/watch?v=SNBGHhLvSIw" --language nl # 2022-07-28 -  2:00:32 - The Trueman Show #83 Kees de Lange
sa "https://www.youtube.com/watch?v=2XN3Nw8HH1o" --language nl # 2022-07-21 -  1:29:03 - The Trueman Show #82 Jaap Rameijer
sa "https://www.youtube.com/watch?v=pngM71swRm8" --language nl # 2022-07-14 -  1:32:46 - The Trueman Show #81 Ancilla van de Leest
sa "https://www.youtube.com/watch?v=5BGJ7xgE_Jo" --language nl # 2022-07-07 -  1:45:20 - The Trueman Show #80 Richard de Leth
sa "https://www.youtube.com/watch?v=YVFBq6PN2Vo" --language nl # 2022-06-30 -  1:48:23 - The Trueman Show #79 Juno Burger
sa "https://www.youtube.com/watch?v=QkX1ABhT6DM" --language nl # 2022-06-23 -  1:43:07 - The Trueman Show #78 Evi Michelle Maalcke
sa "https://www.youtube.com/watch?v=T7-2Whh_pT0" --language nl # 2022-06-16 -  1:28:24 - The Trueman Show #77 Rudolf de Wit Tour
sa "https://www.youtube.com/watch?v=oWfcMQFqXAM" --language nl # 2022-06-09 -  1:09:54 - The Trueman Show #76 Dinah Veeris Tour
sa "https://www.youtube.com/watch?v=RlROax1ECIA" --language nl # 2022-06-02 -  1:56:52 - The Trueman Show #75 Frans Heslinga
sa "https://www.youtube.com/watch?v=LJ3U83W10UI" --language nl # 2022-05-26 -  1:42:56 - The Trueman Show #74 Astrid van Pluuren
sa "https://www.youtube.com/watch?v=glwLQdxFZY8" --language nl # 2022-05-19 -  2:15:47 - The Trueman Show #73 Marja de Vries
sa "https://www.youtube.com/watch?v=fmIGg-go0gc" --language nl # 2022-05-12 -  2:59:59 - The Trueman Show #72 Marcel Messing Live
sa "https://www.youtube.com/watch?v=BH77086UACk" --language nl # 2022-05-05 -  2:30:19 - The Trueman Show #71 Roy Martina
sa "https://www.youtube.com/watch?v=FJnqHBUmHhg" --language nl # 2022-04-28 -  2:56:23 - The Trueman Show #70 Brecht Arnaert live
sa "https://www.youtube.com/watch?v=fgWEQAT_cVk" --language nl # 2022-04-21 -  2:39:11 - The Trueman Show #69 Ronald Bernard
sa "https://www.youtube.com/watch?v=TFsKoN00cjM" --language nl # 2022-04-14 -  2:06:41 - The Trueman Show #68 Ard Pisa
sa "https://www.youtube.com/watch?v=xoiaS-jeKsg" --language nl # 2022-04-07 -  2:45:17 - The Trueman Show #67 Karen Hamaker-Zondag live
sa "https://www.youtube.com/watch?v=NU9q7v4EKqE" --language nl # 2022-03-31 -  2:01:58 - The Trueman Show #66 Marijn van Oosten
sa "https://www.youtube.com/watch?v=UsTpTboSihs" --language nl # 2022-03-24 -  1:29:16 - The Trueman Show #65 Robert Valentine
sa "https://www.youtube.com/watch?v=FHNquMEqvqA" --language nl # 2022-02-24 -  1:37:44 - The Trueman Show #62 Thierry Baudet
sa "https://www.youtube.com/watch?v=fTnIhWhn-ic" --language nl # 2022-02-10 -  2:02:04 - The Trueman Show #61 Vera Helleman
sa "https://www.youtube.com/watch?v=AGwiNoyjwgc" --language nl # 2022-02-03 -  2:19:07 - The Trueman Show #60 Sven Hulleman
sa "https://www.youtube.com/watch?v=To1mkYiABOo" --language nl # 2022-01-27 -  2:30:29 - The Trueman Show #59 Adelheid Storms
sa "https://www.youtube.com/watch?v=C3Ehd9OeKYo" --language nl # 2022-01-20 -  2:03:27 - The Trueman Show #58 Marcel Messing
sa "https://www.youtube.com/watch?v=Oys6vlz58sw" --language nl # 2022-01-13 -  1:32:23 - The Trueman Show #57 Pascal Griffioen aka Def P
sa "https://www.youtube.com/watch?v=IA77uS6LxP4" --language nl # 2022-01-06 -  1:41:15 - The Trueman Show #56 Arjen Lievers
sa "https://www.youtube.com/watch?v=GyOOc91DMq4" --language nl # 2021-12-30 -  3:01:54 - The Trueman Show #55 Jorn Luka
sa "https://www.youtube.com/watch?v=UrTmP9q8cCQ" --language nl # 2021-12-02 -  1:14:13 - The Trueman Show #53 Annet Wood
sa "https://www.youtube.com/watch?v=1T6ytrl9vQQ" --language nl # 2021-11-25 -  1:51:00 - The Trueman Show #52 Maarten Oversier
sa "https://www.youtube.com/watch?v=bWYgkrjRruk" --language nl # 2021-11-18 -  1:30:06 - The Trueman Show #51 Catherine Austin Fitts
sa "https://www.youtube.com/watch?v=l1l6gLQ9GoA" --language nl # 2021-11-11 -  2:05:33 - The Trueman Show #50 Tijn Touber
sa "https://www.youtube.com/watch?v=wIKSXtWcKUw" --language nl # 2021-11-04 -  1:41:09 - The Trueman Show #49 Rypke Zeilmaker
sa "https://www.youtube.com/watch?v=EfyVAmfEiCo" --language nl # 2021-10-28 -  1:24:45 - The Trueman Show #48 Gideon van Meijeren
sa "https://www.youtube.com/watch?v=Wo6JnfMITkE" --language nl # 2021-10-21 -  2:05:09 - The Trueman Show #47 Isa Kriens
sa "https://www.youtube.com/watch?v=F4abDkEjs9c" --language nl # 2021-10-14 -  1:51:35 - The Trueman Show #46 Nadja van Osch
sa "https://www.youtube.com/watch?v=lJUNk1nm6Bo" --language nl # 2021-10-08 -  1:56:46 - The Trueman Show #45 Jesse van der Velde
sa "https://www.youtube.com/watch?v=ieukuWPuPZI" --language nl # 2021-09-23 -  2:46:46 - The Trueman Show #44 Brecht Arnaert
sa "https://www.youtube.com/watch?v=wGJ_FcDoFfw" --language nl # 2021-09-09 -  2:27:56 - The Trueman Show #42 Marcel Messing
sa "https://www.youtube.com/watch?v=yYVhsMJwokM" --language nl # 2021-09-02 -  2:51:35 - The Trueman Show #41 Michael Pilarczyk
sa "https://www.youtube.com/watch?v=k2UQ4mX9nzM" --language nl # 2021-08-19 -  2:32:00 - The Trueman Show #39 Drs. Karen Hamaker-Zondag
sa "https://www.youtube.com/watch?v=-rBHSn0wvr0" --language nl # 2021-08-12 -  1:48:22 - The Trueman Show #38 Elke Vermeire
sa "https://www.youtube.com/watch?v=CTsP29PdPqE" --language nl # 2021-08-05 -  1:42:53 - The Trueman Show #37 Frank Ruesink
sa "https://www.youtube.com/watch?v=2QKA8qQvJSo" --language nl # 2021-07-29 -  1:59:35 - The Trueman Show #36 Shohreh Feshtali
sa "https://www.youtube.com/watch?v=kdZvPlusPQ0" --language nl # 2021-07-22 -  2:06:14 - The Trueman Show #35 Peter Vereecke
sa "https://www.youtube.com/watch?v=gng9jpouRe4" --language nl # 2021-07-15 -  1:40:54 - The Trueman Show #34 Joël Goudsmit
sa "https://www.youtube.com/watch?v=swu_OGGab1Q" --language nl # 2021-07-08 -  1:50:26 - The Trueman Show #33 Flavio Pasquino
sa "https://www.youtube.com/watch?v=LVnnKNbzsSA" --language nl # 2021-07-01 -  1:35:22 - The Trueman Show #32 Thierry Baudet
sa "https://www.youtube.com/watch?v=E6TnimRCOYQ" --language nl # 2021-06-24 -  2:50:27 - The Trueman Show #31 prof. Mattias Desmet
sa "https://www.youtube.com/watch?v=d4Lq1vzBa9g" --language nl # 2021-06-17 -  2:31:24 - The Trueman Show #30 Marcel Messing
sa "https://www.youtube.com/watch?v=bDz0rztvc6g" --language nl # 2021-06-03 -  2:02:56 - The Trueman Show #28 met Dr. Ir. Coen Vermeeren
sa "https://www.youtube.com/watch?v=cmesbLm7t-w" --language nl # 2021-05-27 -  1:29:59 - The Trueman Show #27 met Tibor Olgers
sa "https://www.youtube.com/watch?v=Lj8RW2Uva8U" --language nl # 2021-05-20 -  2:13:59 - The Trueman Show #26 met Pieter Kuit
sa "https://www.youtube.com/watch?v=iNGc_i7DfGM" --language nl # 2021-05-13 -  1:55:03 - The Trueman Show #25 met George van Houts
sa "https://www.youtube.com/watch?v=IV-b0pPXMJY" --language nl # 2021-05-06 -  1:28:21 - The Trueman Show #24 met Prof. Dr. Bob de Wit
sa "https://www.youtube.com/watch?v=zID94SUVJb4" --language nl # 2021-04-29 -  4:04:41 - The Trueman Show #23 met Rypke Zeilmaker
sa "https://www.youtube.com/watch?v=SlItx4RmS_M" --language nl # 2021-04-22 -  1:08:48 - The Trueman Show #22 met Ad Broere
sa "https://www.youtube.com/watch?v=W-GECU4J7gQ" --language nl # 2021-04-15 -  1:43:42 - The Trueman Show #21 met Daan de Wit
sa "https://www.youtube.com/watch?v=6h-R-qn75d4" --language nl # 2021-04-13 -  2:06:43 - The Trueman Show #20 met Marijn Poels
sa "https://www.youtube.com/watch?v=i482A2aBsLg" --language nl # 2021-04-08 -  1:57:41 - The Trueman Show #19 met Karel van Wolferen
sa "https://www.youtube.com/watch?v=REYcGm_ffv4" --language nl # 2021-04-01 -  1:35:59 - The Trueman Show #18 met Kim Feenstra
sa "https://www.youtube.com/watch?v=72pUeti6oSQ" --language nl # 2021-03-25 -  1:43:51 - The Trueman Show #17 met Jan Vingerhoets
sa "https://www.youtube.com/watch?v=CxckBh_BD6Q" --language nl # 2021-03-18 -  1:19:25 - The Trueman Show #16 met Sven Ake Hulleman
sa "https://www.youtube.com/watch?v=Z1EZq9S2VJc" --language nl # 2021-03-11 -  1:49:46 - The Trueman Show #14 met Jan Storms
sa "https://www.youtube.com/watch?v=x7uO4zMKdys" --language nl # 2021-03-09 -  1:35:11 - The Trueman Show #13 met Isa Kriens en Nadia Duinker
sa "https://www.youtube.com/watch?v=OJvu-tL-ALs" --language nl # 2021-03-04 -  1:15:08 - The Trueman Show #12 met Tisjeboy Jay
sa "https://www.youtube.com/watch?v=zVBb1fHQgpM" --language nl # 2021-02-25 -  1:32:31 - The Trueman Show #11 met Ferdinand Meeus
sa "https://www.youtube.com/watch?v=XTczyk2EwbA" --language nl # 2021-02-18 -  2:35:02 - The Trueman Show #10 met Isa Kriens AKA de kleine activist
sa "https://www.youtube.com/watch?v=hbQ7r0MkGcs" --language nl # 2021-02-11 -  2:15:27 - The Trueman Show #9 met Jan Bonte AKA Jan B Hommel
sa "https://www.youtube.com/watch?v=hAbRNQy66Po" --language nl # 2021-02-04 -  1:53:15 - The Trueman Show #8 met Boris van de Ven
sa "https://www.youtube.com/watch?v=HOMlDbLtyWA" --language nl # 2021-01-28 -  2:43:07 - The Trueman Show #7 met Kees van der Pijl
sa "https://www.youtube.com/watch?v=pthrEWzavo4" --language nl # 2021-01-21 -  2:12:06 - The Trueman Show #6 met Sietske Bergsma
sa "https://www.youtube.com/watch?v=BZmkIAN1bxk" --language nl # 2021-01-14 -  1:48:39 - The Trueman Show #5 met Arno Wellens
sa "https://www.youtube.com/watch?v=YlNyZ0IpCjw" --language nl # 2021-01-07 -  2:33:14 - The Trueman Show #4 met Lange Frans
sa "https://www.youtube.com/watch?v=7SHEoLJMYlU" --language nl # 2020-12-30 -  1:32:04 - The Trueman Show #3 met Josje Huisman
sa "https://www.youtube.com/watch?v=hSwxygUa4Sc" --language nl # 2020-12-24 -  1:14:00 - The Trueman Show #2 met Tim Douwsma
sa "https://www.youtube.com/watch?v=lEBZfv9PbxY" --language nl # 2020-12-17 -  1:24:17 - The Trueman Show #1 met Kaj Gorgels

exit



saf "OmtOFJitiSc1TMKx.mp4" --language en

exit

exit

echo " \\" > add_fix.txt
echo '	--tags="Bill Cooper" \' >> add_fix.txt
echo '	--tags="Age of World Controllers"' >> add_fix.txt

saa "https://x.com/Xx17965797N/status/2015464176139874312?s=20" --language en

exit


# rm "BURN_VIDEO2.TXT"
# 
# echo " \\" > add_fix.txt
# echo '	--tags="COVID" \' >> add_fix.txt
# echo '	--tags="GENOCIDE"' >> add_fix.txt
# 
# saa "https://x.com/DFurneaux/status/2013992692481483109?s=20" --language en

echo " \\" > add_fix.txt
echo '	--tags="Dr. Willie Soon" \' >> add_fix.txt
echo '	--tags="climate"' >> add_fix.txt

saa "https://x.com/WatchGorillaSci/status/2013980026979393756?s=20" --language en

exit


echo " \\" > add_fix.txt
echo '	--tags="Trump" \' >> add_fix.txt
echo '	--tags="Davos 2026" \' >> add_fix.txt
echo '	--tags="WEF"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=QzWhQh-NleM" --language en 

exit



## #cd ~/movies
## rm "BURN_VIDEO2.TXT"
## 
## echo " \\" > add_fix.txt
## echo '	--tags="COVID" \' >> add_fix.txt
## echo '	--tags="GENOCIDE"' >> add_fix.txt
## 
## # saa "https://x.com/DFurneaux/status/2013631201538404619?s=20" --language en
## # saa "https://x.com/karma44921039/status/1774796877994623199?s=20" --language en
## 
## saa "https://x.com/PBDsPodcast/status/2013597511244546280?s=20" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="WEF" \' >> add_fix.txt
## echo '	--tags="LARRY FLINK" \' >> add_fix.txt
## echo '	--tags="PARODY"' >> add_fix.txt
## 
## saa "https://x.com/PapiTrumpo/status/2013838675038122405?s=20" --language en

echo " \\" > add_fix.txt
echo '	--tags="vaccines"' >> add_fix.txt

saa "https://x.com/iluminatibot/status/2013803523905900958?s=20" --language en

cd ~/movies

echo " \\" > add_fix.txt
echo '	--tags="Anthony Weiner’s laptop" \' >> add_fix.txt
echo '	--tags="David Collum"' >> add_fix.txt

sa "https://x.com/ValerieAnne1970/status/2013695340050866249?s=20" --language en

cd ~/movies5

echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT

sa "https://x.com/MyLordBebo/status/2013554430507880650?s=20" --language ru

rm "BURN_VIDEO2.TXT"

echo " \\" > add_fix.txt
echo '	--tags="COVID" \' >> add_fix.txt
echo '	--tags="GENOCIDE"' >> add_fix.txt

sa "https://x.com/sophiadahl1/status/2013795343662743932?s=20" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=IcMPmKNNPUQ" --language nl

echo " \\" > add_fix.txt
echo '	--tags="The club of Rome" \' >> add_fix.txt
echo '	--tags="United Nations" \' >> add_fix.txt
echo '	--tags="Calin Georgescu"' >> add_fix.txt

saa "https://x.com/iluminatibot/status/2012880245259452604?s=20" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="William Cooper" \' >> add_fix.txt
echo '	--tags="Mystery Babylon" \' >> add_fix.txt
echo '	--tags="The Dawn of Man"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=ZozDeLFhrZ0" --language en
sa "https://www.youtube.com/watch?v=lwvbZKrc6nc" --language en

exit


#echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## 
## saf "Terugkijken_Debat_over_de_Coronacrisis_deelrapport_Aanpak_Coronacrisis_Coronadebat_Tweede_Kamer-[EngWkzHCn08].000.mp4" --language nl
## 
## echo PRESS ENTER 
## read AAA 

### echo " \\" > add_fix.txt
### echo '	--tags="illuminatibot" \' >> add_fix.txt
### echo '	--tags="FBI" \' >> add_fix.txt
### echo '	--tags="false flags"' >> add_fix.txt
### 
### saa "https://x.com/iluminatibot/status/2008628621800599916?s=20" --language en
### 
### echo " \\" > add_fix.txt
### echo '	--tags="Mike Benz" \' >> add_fix.txt
### echo '	--tags="CIA" \' >> add_fix.txt
### echo '	--tags="Cocaine Trafficking In Venezuela"' >> add_fix.txt
### 
### saa "https://x.com/MikeBenzCyber/status/2008634599459475558?s=20" --language en
### 
### echo " \\" > add_fix.txt
### echo '	--tags="Coronacrisis" \' >> add_fix.txt
### echo '	--tags="Coronadebat" \' >> add_fix.txt
### echo '	--tags="Tweede Kamer"' >> add_fix.txt

## saf "Terugkijken_Debat_over_de_Coronacrisis_deelrapport_Aanpak_Coronacrisis_Coronadebat_Tweede_Kamer-[EngWkzHCn08].001.mp4" --language nl
## saf "Terugkijken_Debat_over_de_Coronacrisis_deelrapport_Aanpak_Coronacrisis_Coronadebat_Tweede_Kamer-[EngWkzHCn08].002.mp4" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="Wierd Duk"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=0En_qjUu4YI" --language nl # 2022-01-06 -    49:08 - ‘Er woedt een oorlog tegen levensstijl van lagere klassen’ | Het Land van Wierd Duk | Podcast
## 
## echo " \\" > add_fix.txt
## echo '	--tags="TPV Sean" \' >> add_fix.txt
## echo '	--tags="TPV Murdering Millions" \' >> add_fix.txt
## echo '	--tags="Bill Gates"' >> add_fix.txt
## 
## saa "https://x.com/tpvsean/status/2005999746561839282?s=20" --language en 
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Wierd Duk"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=yLgrAm0xzb8" --language nl # 2022-01-21 -    55:51 - ‘Grote minderheid wordt door politiek niet bediend’ | Het Land van Wierd Duk | Podcast


## sa "https://www.youtube.com/watch?v=Dc3cDvI-Yuc" --language nl # 2022-01-27 -    48:45 - Komt de oorlog naar Europa? | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=XRnV_lZVIqs" --language nl # 2022-02-03 -    47:12 - 'Elke kritiek op de macht is ‘extreemrechts’' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=dCAD7OonhXM" --language nl # 2022-02-10 -    47:26 - 'Wie verdient excuses voor aandeel DNB in slavernij?' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=FXohon_3d3I" --language nl # 2022-02-17 -    44:30 - ‘Nederlandse politiek beloont degenen die falen, zoals Hugo de Jonge’  | Het Land van Wierd Duk
## sa "https://www.youtube.com/watch?v=BwdS6PkLMxk" --language nl # 2022-02-24 -    52:49 - ‘Wat bezielt Vladimir Poetin?’ | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=Us8lY29gVYo" --language nl # 2022-03-10 -    38:25 - 'Dreigt Balkanisering van Oekraïense slagveld?' | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=cbZw_Kh6oO4" --language nl # 2022-03-17 -    41:39 - Poetins onheilspellende dreiging | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=_Ylu-2dFBSg" --language nl # 2024-05-25 -  1:15:19 - ‘Links bestaat enkel uit Wilders-bashers’  | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=VMQ8zuAJHNc" --language nl # 2024-06-01 -    59:16 - ‘Slecht plan: ongekozen topambtenaar als premier'  | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=zBzp0Xihgas" --language nl # 2024-06-08 -  1:00:14 - ‘Eén stap verwijderd van oorlog met Rusland’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=0SPTT0ppOAM" --language nl # 2024-06-15 -    53:31 - 'Voor Ali B is het onmogelijk om schuld te bekennen' | Het Land van Wierd Duk | Podcast

## sa "https://www.youtube.com/watch?v=zuF56VV8UVw" --language nl # 2024-06-22 -  1:02:08 - 'Ongelofelijke fout om Martin Bosma te weren bij Keti Koti' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=moWxxle3ebw" --language nl # 2024-06-29 -    48:14 - 'Rechts buigt voor links gedram’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=oZEVjIt-pq4" --language nl # 2024-07-06 -  1:04:21 - “Linkse oppositie heeft niets geleerd”  | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=Wvp3-ZBWZkk" --language nl # 2024-07-13 -  1:05:59 - 'Gemeentes saboteren asielbeleid nieuwe regering' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=q6WxErpg9pU" --language nl # 2024-07-28 -  1:06:32 - ‘Zorgelijke hetze tegen andersdenkenden’
## sa "https://www.youtube.com/watch?v=eZ_KCYtcIq8" --language nl # 2024-08-04 -  1:02:53 - 'Westen moet veel trotser zijn' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=aAtK8JR9-_M" --language nl # 2024-08-10 -    49:45 - ‘Geest uit de fles in Verenigd Koninkrijk’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=jYf2afurFWk" --language nl # 2024-08-17 -    55:13 - 'Schrikbarende roep om censuur' | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=GQV0-FUwMEQ" --language nl # 2024-09-01 -    56:58 - ‘Duitsland bepaalt uitkomst immigratiecrisis’ | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=15yjFrnyacw" --language nl # 2024-09-07 -  1:05:24 - 'Er woedt een oorlog tegen vrouwen' | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=LSd1s3h6ggU" --language nl # 2024-09-15 -    58:21 - 'Vraag is: bezwijkt Europa onder de immigratie?' | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=mIYbhCJCF8o" --language nl # 2024-09-21 -    56:39 - 'Natuurlijk kan Nederland een opt-out bedingen'  | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=ExGYSnYwGnQ" --language nl # 2024-10-05 -    52:18 - Joodse onderzoeker: ‘NOS wakkert antisemitisme aan’ | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=QWu23hEPJNM" --language nl # 2024-10-13 -  1:01:05 - 'Te veel mensen herkennen het Kwaad niet' | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=d5_pySK2R74" --language nl # 2024-10-19 -  1:04:10 - ‘Je kunt niet de hele wereld opvangen’ | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=UUm9Q10ipww" --language nl # 2024-10-27 -    55:47 - 'Westen staat op kruispunt'  | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=YFPaIhsh7LY" --language nl # 2024-10-31 -    58:54 - “Overal in Westen verliest gevestigde orde terrein” | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=wyof3VzuoP0" --language nl # 2024-11-08 -  1:00:11 - ‘Zonder eigen verhaal blijft links verliezen’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=rOf-c0yIkOw" --language nl # 2024-11-10 -  1:03:42 - Lale Gül: 'Niemand durft islam nog te bekritiseren' | Het Land van Wierd Duk | Podcast

## echo " \\" > add_fix.txt
## echo '	--tags="TPV Sean" \' >> add_fix.txt
## echo '	--tags="Bill Gates" \' >> add_fix.txt
## echo '	--tags="Cloned Thousands of Babies"' >> add_fix.txt
## 
## saa "https://x.com/tpvsean/status/2007168430781206664?s=20" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Mike Benz" \' >> add_fix.txt
## echo '	--tags="Ukraine" \' >> add_fix.txt
## echo '	--tags="Tales Of Regime Change"' >> add_fix.txt
## 
## saa "https://x.com/MikeBenzCyber/status/2007411162896576687?s=20" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="cp/m" \' >> add_fix.txt
## echo '	--tags="microsoft" \' >> add_fix.txt
## echo '	--tags="dos"' >> add_fix.txt
## 
## saa "https://x.com/Scobleizer/status/1875486795720487418" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Wierd Duk"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=XBapH2leG8A" --language nl # 2024-11-17 -  1:15:56 - Martin Sommer: ‘Standenstaat Nederland sluit andersdenkenden uit’ | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=s7CzSyidAjA" --language nl # 2024-11-22 -    49:36 - ‘Joden mógen geen slachtoffer zijn’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=8bW6qHACZwQ" --language nl # 2024-12-08 -    58:49 - 'Laat geïntegreerde allochtonen met rust'
## sa "https://www.youtube.com/watch?v=csf3wbhNWdY" --language nl # 2024-12-15 -    49:48 - ‘Syrië wordt een terreurstaat'| Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=0J1He503U50" --language nl # 2024-12-22 -  1:34:22 - “Kletsende klasse móet in de spiegel kijken” | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=z5xBxs1q_aA" --language nl # 2025-01-10 -    54:10 - ‘Trump kondigt nieuwe wereldorde aan’ | Het land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=e4xQHP_UJtk" --language nl # 2025-01-24 -  1:15:13 - 'We moeten onze beschaving verdedigen'
## sa "https://www.youtube.com/watch?v=mpuEsvTGeQU" --language nl # 2025-01-31 -    54:25 - Politieke revolutie in Duitsland | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=2_Vj1s3XRSY" --language nl # 2025-02-07 -  1:12:16 - ‘Na genitale verminking voelde ik de eenzaamheid’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=EifMN2iAVo0" --language nl # 2025-02-13 -    58:09 - ‘Trump zet alles op z’n kop’
## sa "https://www.youtube.com/watch?v=gFXvJLJuDk0" --language nl # 2025-02-21 -  1:03:44 - 'Krankzinnig: een coalitie van Rusland en VS-conservatieven' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=gYQ0T-c_bFI" --language nl # 2025-02-25 -    34:30 - 'In Duitsland dreigt verdere stagnatie' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=u9r3BG0HGhs" --language nl # 2025-02-28 -    59:19 - ‘Universiteitsbesturen zijn laf’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=pU-zNkPx58s" --language nl # 2025-03-07 -    56:03 - 'Kabinet: stop islamisering van de overheid’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=freziDl3qX8" --language nl # 2025-03-14 -  1:15:43 - 'EU blundert aan lopende band' | Het Land van Wierd Duk | Podcast
## 
## echo " \\" > add_fix.txt
## echo '	--tags="De Begrenzers" \' >> add_fix.txt
## echo '	--tags="Rob Roos" \' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=qE9l0jsvNpU" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Wierd Duk"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=LaGag8fzj_M" --language nl # 2025-03-14 -    54:11 - ‘Mensen leven in aparte werelden’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=GWU9p56jMXs" --language nl # 2025-03-21 -  1:04:39 - 'Politici moeten zich eindelijk om Nederlandse burger bekommeren' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=p3aD_n-BWGs" --language nl # 2025-03-27 -  1:16:32 - ‘Massavorming rond Oekraïne is levensgevaarlijk’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=s6qdjTjTO1o" --language nl # 2025-03-28 -    50:21 - 'Stop met aanjagen van oorlogsangst' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=5DIU7RShh74" --language nl # 2025-03-29 -  1:04:51 - 'We moeten China veel beter leren kennen'
## sa "https://www.youtube.com/watch?v=JHClLJHuYZg" --language nl # 2025-04-04 -    47:06 - 'Cultuuroorlog draait niet alleen om immigratie' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=iu017MDo4PQ" --language nl # 2025-04-11 -    53:36 - ‘Te veel Nederlanders zijn geïndoctrineerd’
## sa "https://www.youtube.com/watch?v=5Tjflr3y5Lk" --language nl # 2025-04-19 -  1:01:47 - ‘Nederlanders, pas op, de islamisten kloppen aan de deur'
## sa "https://www.youtube.com/watch?v=dcZ3josNOY8" --language nl # 2025-04-24 -  1:02:46 - ‘Trump vindt ons geweldig’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=ImplXvD_PYQ" --language nl # 2025-05-02 -    56:15 - 'Herdenking massamoord op de Joden moet centraal staan' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=7TmNRc2-rHI" --language nl # 2025-05-09 -  1:01:23 - 'Haat jegens Westen zit enorm diep' | Het Land van Wierd Duk | Podcast
## 
## echo " \\" > add_fix.txt
## echo '	--tags="October 18, 2019" \' >> add_fix.txt
## echo '	--tags="plandemic" \' >> add_fix.txt
## echo '	--tags="event 201"' >> add_fix.txt
## 
## saa "https://x.com/__luzid__/status/2008252998401880331?s=20" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Wierd Duk"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=LtTwxsGFXWA" --language nl # 2025-05-16 -  1:07:21 - ‘Autochtone Nederlanders gaan hun gemeenschappen verdedigen’ | Het Land van Wierd Duk | Podcast
## # echo "press enter..."
## # read aaaa
## 
## sa "https://www.youtube.com/watch?v=NJEf4KN_ETA" --language nl # 2025-05-23 -  1:03:18 - 'Wie stopt triomftocht van Hamas-activisme?' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=W6ZdKL9Byi0" --language nl # 2025-05-29 -  1:00:04 - 'Intimideren van christenen moet stoppen' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=-CjhoxNLS5Q" --language nl # 2025-05-31 -  1:03:31 - ‘Intoleranten maken misbruik van onze vrijheden’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=p7ZvRnD3iiQ" --language nl # 2025-06-06 -    49:56 - 'Nederland heeft bulldozer als Donald Trump nodig'
## sa "https://www.youtube.com/watch?v=wWg-4QRGAng" --language nl # 2025-06-13 -  1:01:41 - ‘Onder VVD’ers dreigt opstand’ | Het Land van Wierd Duk | Podcast

# echo " \\" > add_fix.txt
# echo '	--tags="Coronacrisis" \' >> add_fix.txt
# echo '	--tags="Coronadebat" \' >> add_fix.txt
# echo '	--tags="Tweede Kamer"' >> add_fix.txt
# 
# saa "https://www.youtube.com/watch?v=EngWkzHCn08" --language nl
 
## echo " \\" > add_fix.txt
## echo '	--tags="Wierd Duk"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=nxVZw1YXV5Q" --language nl # 2025-06-21 -  1:02:54 - 'Conservatieve kiezer in steek gelaten' | Podcast | Het Land van Wierd Duk
## sa "https://www.youtube.com/watch?v=LA64LtWz_HI" --language nl # 2025-06-27 -    50:13 - 'Radicaal links loert op de macht'
## sa "https://www.youtube.com/watch?v=3zsPPUquAJI" --language nl # 2025-07-03 -    58:54 - Gesprek met ex-IDF Raouf Leeraar: 'Vraag is of Europa standhoudt' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=OVV2DsYSWaY" --language nl # 2025-07-10 -    59:56 - ‘Nederlanders moeten meer kinderen krijgen’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=WogYOpoEGJo" --language nl # 2025-07-18 -  1:07:15 - ‘Stel scherpere voorwaarden aan Nederlanderschap’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=LYd9Dc3yidQ" --language nl # 2025-07-31 -  1:07:27 - ‘Propaganda van Hamas is enorm effectief’ | Podcast | Het Land van Wierd Duk
## sa "https://www.youtube.com/watch?v=u__-jdwHYcM" --language nl # 2025-08-07 -    58:07 - 'Witwassen van Hamas is verbijsterend' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=ccClZZAuoKE" --language nl # 2025-08-14 -  1:09:36 - 'Red de democratie!' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=5zXjYLqe-RM" --language nl # 2025-08-22 -  1:15:54 - ‘Oorlog in Gaza verziekt onze samenleving’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=VaflolRGmF0" --language nl # 2025-08-29 -    59:40 - ‘Nexit is de enige oplossing’ | Het Land van Wierd Duk | Podcast
## 
## echo "press enter..."
## read aaaa

## echo " \\" > add_fix.txt
## echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
## echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
## echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=BBgFlSTGCpg" --language nl
## 
echo " \\" > add_fix.txt
echo '	--tags="Wierd Duk"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=CDqLX8RGIK4" --language nl # 2025-09-05 -  1:01:33 - ‘Hysterische reacties op ‘rechtse’ talkshows’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=2Adzyf61aqo" --language nl # 2025-09-12 -  1:00:50 - 'Vrije samenleving onder vuur door moord Charlie Kirk' | Het Land van Wierd Duk | Podcast

## sa "https://www.youtube.com/watch?v=TN7KL--RIBk" --language nl # 2025-09-19 -  1:19:59 - 'Blijf zelf nadenken!' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=OysWezNaDns" --language nl # 2025-09-26 -  1:12:52 - Stop met de zelfhaat' | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=58JAR_myhUY" --language nl # 2025-10-03 -  1:04:52 - ‘Met Faber werden alle rechtse kiezers gegrild’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=Z4ZKbxV7rvQ" --language nl # 2025-10-10 -  1:09:34 - Frits Barend: ‘Mijn Israëlische familie hunkert naar vrede’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=CMnOztA4F70" --language nl # 2025-10-17 -    55:31 - ‘Verzet je tegen de denkpolitie’ | Het Land van Wierd Duk | Podcast
## sa "https://www.youtube.com/watch?v=U92P-vFiiPA" --language nl # 2025-10-24 -    56:51 - 'Politiek-correct tijdperk komt ten einde' | Het Land van Wierd Duk | Podcast

sa "https://www.youtube.com/watch?v=tObD96aXYX8" --language nl # 2025-10-31 -  1:02:01 - 'JA21 is brug tussen afgehaakten en tevredenen' | Het Land van Wierd Duk | Podcast
sa "https://www.youtube.com/watch?v=0li0ZX9yusM" --language nl # 2025-11-07 -  1:04:22 - "Joden uitsluiten? Geen probleem in Nederland”
sa "https://www.youtube.com/watch?v=m9rcRbV40sA" --language nl # 2025-11-14 -  1:01:22 - 'Stop met buigen voor islamitische eisen'
sa "https://www.youtube.com/watch?v=IhphISDbzoA" --language nl # 2025-11-16 -    57:35 - 'Rot in media veel breder dan BBC' | Het Land van Wierd Duk | Podcast
sa "https://www.youtube.com/watch?v=UrH6nRipuN0" --language nl # 2025-11-21 -  1:07:04 - ‘Nederland moet weerbaarder worden’ | Het Land van Wierd Duk | Podcast

## echo press enter
## read aaa 

sa "https://www.youtube.com/watch?v=n4N5pT6rWU4" --language nl # 2025-11-28 -    56:59 - 'Poortwachters verzieken het publieke debat' | Het Land van Wierd Duk | Podcast
sa "https://www.youtube.com/watch?v=c9lXDXAANWw" --language nl # 2025-12-05 -  1:10:11 - 'Middencoalitie gaat Nederland niet redden'
sa "https://www.youtube.com/watch?v=4_2fp_A1dfw" --language nl # 2025-12-12 -    52:23 - 'Amerikanen hebben gelijk over alarmerende staat van Europa'
sa "https://www.youtube.com/watch?v=5QEinjLbWTc" --language nl # 2025-12-30 -    59:48 - ‘Radicale maatregelen nodig om Nederland en Europa uit slop te halen’

exit

## echo " \\" > add_fix.txt
## echo '	--tags="FSOC" \' >> add_fix.txt
## echo '	--tags="Promethean Action"' >> add_fix.txt
## 
## saa "https://x.com/PrometheanActn/status/2001393764493934721?s=20" --language en
## 
## echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## 
## saa "https://x.com/AKRule/status/2001952505383760145?s=20" --language en
## 
## rm "BURN_VIDEO2.TXT"

echo " \\" > add_fix.txt
echo '	--tags="mind control" \' >> add_fix.txt
echo '	--tags="gaslightning" \' >> add_fix.txt
echo '	--tags="Tony Robbins"' >> add_fix.txt

saa "https://odysee.com/@AlexJonesChannel:c/VIDEO--Tony-Robbins-Social-Experiment-Exposes-Mind-Control-and-Gaslighting-Affects-the-Population:8" --language en
exit

#saa "https://odysee.com/@Heimat:0/Der-Fall-Marianne-Bachmeier-keine-Zeit-f%C3%BCr-Tr%C3%A4nen---Abschnitt1(00_00_37.737-01_21_26.214):7" --language de
saa "https://odysee.com/@vintage:f/annas-mutter-murder-in-revenge-(1984):b" --language de
saa "https://odysee.com/@Sasquatch:6/aabbddfwiioqqqqqqqqqq:e" --language de
exit

saa "https://www.youtube.com/watch?v=WFWizN3QoPg" --language en

echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT

echo " \\" > add_fix.txt
echo '	--tags="mRNA" \' >> add_fix.txt
echo '	--tags="Alex Jones" \' >> add_fix.txt
echo '	--tags="Michael Yeadon"' >> add_fix.txt

saa "https://x.com/RealAlexJones/status/2000725498796605817" --language en


#date: 2025-11-18 - length:  1:00:10 - title: "EU KIDNAP BABIES - James Grundvig interviews Dutch Filomena"
sa "https://odysee.com/The-EU-kidnap-babies--James-Grundvig-interviews-Dutch-Filomena:e47edd77ab1f51c49851d61b9458ce9424b28a02" --language nl

#date: 2025-09-30 - length:    46:32 - title: "THE HIDDEN TRUTH ABOUT THE MOON - SOMETHING IS WRONG (4K-ai)"
sa "https://odysee.com/the-hidden-truth-about-the-moon:06c962c37be2b68c2322b0171ba6fa924bc81c20" --language nl

#date: 2025-08-11 - length:  1:56:35 - title: "NAVAL OFFICER WILLIAM COOPER EXPLAINS THE NEW WORLD ORDER | WHISTLEBLOWER"
sa "https://odysee.com/william-cooper-explains-the-new-world-order:ab96fa23fd5c095ce1d0438f7c314cc6859045fd" --language nl

#date: 2025-02-19 - length:     4:30 - title: "The Fort Knox Gold Robbery"
sa "https://odysee.com/The-Fort-Knox-Gold-Robbery:73e7bd745268f7dabc9915081192d8ca3fadfb66" --language nl

#date: 2025-02-16 - length:    32:19 - title: "JD Vance goes after European allies in Munich Security Conference speech | DW News"
sa "https://odysee.com/JD-Vance-goes-after-European-allies-in-Munich-Security-Conference-speech---DW-News:f6adb3cdc6d64960bc2b61f7269676adf4cc99e9" --language nl

#date: 2025-02-12 - length:    31:56 - title: "President Trump & Elon Musk Take Multiple Questions From Reporters In The Oval Office"
sa "https://odysee.com/President-Trump--Elon-Musk--1202-2025--Take-Multiple-Questions-From-Reporters-In-The-Oval-Office:aa411d165447d048eb768b7416d29afc05469f0c" --language nl

#date: 2025-02-12 - length:    15:49 - title: "JD Vance Puts European Leaders On Notice About Trying To Regulate U.S. Tech Giants"
sa "https://odysee.com/FULL-REMARKS-JD-Vance-Puts-European-Leaders-On-Notice-About-Trying-To-Regulate-U.S.-Tech-Giants:209270bc77b6971eaab5ab548f5c315d53fe1c43" --language nl

#date: 2025-02-11 - length:     3:31 - title: "USAID uncovered by X - Trump - Alex Jones - Elon Musk"
sa "https://odysee.com/USAID-uncovered-by-X---Trump---Alex-Jones---Elon-Musk:3f32bdfe47caa222afa2bdc3857dfaa9b74e3efb" --language nl

#date: 2025-02-10 - length:    18:36 - title: "BAN MRNA VACCINATIONS IN MONTANA FOR HUMANS | HB371"
sa "https://odysee.com/Ban-mRNA-vaccinations-in-montana:5defc677b4b1d11eb64721e0dd0c898a67100984" --language nl

#date: 2025-02-02 - length:    27:02 - title: "Judge Orders Bill Gates To Stand Trial for 'Murdering Millions' via mRNA Jabs"
sa "https://odysee.com/judge-orders-bill-gates-to-stand-trial-for-murdering-millions-via-mrna-jabs:91ad9f80251bca5fa46cd4c7e81e295c94805281" --language nl

#date: 2025-02-01 - length:    46:13 - title: "Bryan Ardis - Henry Ealy - Mike Adams about healing OUTSIDE the broken pharma system"
sa "https://odysee.com/Bryan-Ardis--Henry-Ealy--Mike-Adams-about-healing-OUTSIDE-the-broken-pharma-system:943a8d617a070e1e901277c679835bbfc9cff240" --language nl

#date: 2025-01-24 - length:    14:03 - title: "Moshiach (Trump) ushers in New World Order of AI (Project Stargate)"
sa "https://odysee.com/Moshiach-(Trump)-ushers-in-New-World-Order-of-AI-(Project-Stargate):6afd258630279252c47d7449b2feced97dd0a886" --language nl

#date: 2025-01-21 - length:    31:16 - title: "Trump Speech (Full Version) of the 60th Inaugural Ceremonies at the U.S. Capitol"
sa "https://odysee.com/Trump-Speech-60th-Inaugural-Ceremonies:4448ea26ee7d7b32915f568e0b87435bcb9c4f33" --language nl

#date: 2025-01-19 - length:     6:30 - title: "Historisch - Vaccinatieslachtoffer spreekt via vader in Leeuwarder Bodemprocedure 18 september 2024"
sa "https://odysee.com/Historisch---Vaccinatieslachtoffer-spreekt-via-vader-in-Leeuwarder-Bodemprocedure-18-september-2024:afffe4d4170a602438cf6ce21f959aa4c09485ea" --language nl

#date: 2024-11-27 - length:    31:07 - title: "GLOBAL POISONING WITH DNA PLASMIDS  | Dr. Bryan Ardis"
sa "https://odysee.com/global-poisoning:fd6cfa7e303ab84f81c068f1aa78610ac2f0a53b" --language nl

#date: 2024-11-11 - length:    35:41 - title: "Professor Dr. Bhakdi finally also unraveling covid / entschlüsselt Covid / ontrafelt COVID (NL Subs)"
sa "https://odysee.com/bhakdi-unraveling-covid:232a5145d0fc864627c24deb4c12e142ccea8a67" --language nl

#date: 2024-09-23 - length:  1:27:02 - title: "Zitting Incident Bill Gates inzake Covid-19 vaccinatieschade letselschade 18 September 2024 (Official 4K)"
sa "https://odysee.com/Zitting-Incident-Bill-Gates-inzake-Covid-19-vaccinatieschade-letselschade-18-September-2024:5f8912be0aa2582adda778429f18508578e75aea" --language nl

#date: 2024-09-19 - length:  1:08:22 - title: "Persconferentie - Recht Oprecht - nav zaak tegen Bill Gates Leeuwarden 1809-2024"
sa "https://odysee.com/persconferentie-rechtoprecht-18-september-2024:4296838fe11fc9a38f5a8323185f15e377cf2706" --language nl

#date: 2024-09-16 - length:  1:52:35 - title: "The Dr. Ardis Show | How to Identify a Psychopath with Dr. Lee Merritt | Episode July 24 - 2024"
sa "https://odysee.com/How-to-Identify-a-Psychopath-Bryan-Ardis--Lee-Merritt:94b95b3928c53ab0b0fc2855e6fc57bdcf43410e" --language nl

#date: 2024-09-07 - length:     4:49 - title: "Dr Fauci admits social distancing was not science based"
sa "https://odysee.com/Dr-Fauci-admits-social-distancing-was-not-science-based:bd49d9c9e66cb1a64f0fa793b57bcc20f15e76e4" --language nl

#date: 2024-09-06 - length:     2:35 - title: "M Pox emergency canceled on behalf of W.H.O. / Tedros"
sa "https://odysee.com/mpox-emergency-canceled-who-tedros:18428b4ec52b57188553f5b5521b8e4dc1f57432" --language nl

#date: 2024-09-05 - length:    23:51 - title: "Bill Gates voor de Nederlandse rechter? | DVO Nieuws"
sa "https://odysee.com/Bill-Gates-voor-de-Nederlandse-rechter:705d44f50c21acee8f3cd6ce44494c0460564118" --language nl

#date: 2024-09-05 - length:    23:51 - title: "Bill Gates before the Dutch court? | DVO News (English subs)"
sa "https://odysee.com/Bill-Gates-before-the-dutch-court:d0f4122e51e125344c1d625f730b8d2bda70a2d5" --language nl

#date: 2024-08-30 - length:    14:05 - title: "5G Journaal - De drie problemen met 5G | De Vrije Omroep"
sa "https://odysee.com/5G-journaal:5dd43b4b6b6af2f400f12f21d9366af986e6d6a8" --language nl

#date: 2024-08-28 - length:     2:35 - title: "Informatie-operatie of wel informatieoorlog | WNL op zondag"
sa "https://odysee.com/informatieoorlog-wnl-op-zondag:92390e1a69d2d7e034a030593637ed8746ff5507" --language nl

#date: 2024-04-03 - length:  2:31:52 - title: "THE ANTIDOTE - Origin and Antidote for Covid-19 | Bryan Ardis broke covid-19 (EN Subs)"
sa "https://odysee.com/THE-ANTIDOTE-Bryan-Ardis-broke-covid-19:31cbb276bfb0c2ec6c50068bf8cc0bb243ac9c08" --language nl

#date: 2024-04-01 - length:    13:39 - title: "Oorlogsretoriek in historische muziekcompilatie - SoulFlix-Introductie 26 maart 2024 | NON Nieuwsflits #3"
sa "https://odysee.com/non-nieuwsflits-3-oorlogsretoriek-en-muziekcompilatie-intro-soulflixpresentatie-26-maart-2024:9535bfa619a4bd30de5089349160beda8bb20acf" --language nl

#date: 2024-03-21 - length:     4:51 - title: "The Covid-19 Proceedings - November 22, 2023"
sa "https://odysee.com/The-Covid-19-Proceedings--2023-November-22:726d79d53fabac689782f662796b9c0cc9bb85df" --language nl

#date: 2024-03-21 - length:    11:00 - title: "'The New Pandemic Treaty' Powergrab of WHO addressed by Philipp Kruse and commented by Dr. John Campbell (Shorter)"
sa "https://odysee.com/WHO-powergrab-addressed-by-Philipp-Kruse-commented-by-Dr.-John-Campbell:5cfd01680cbeb97c0998f2ce30ee003d0ef560c2" --language nl

#date: 2024-03-06 - length:    17:44 - title: "Trudeau covered up massive PRC infiltration of his government"
sa "https://odysee.com/trudeau-covered-up-massive-PRC-infiltration-of-his-government:72f4366c58acca5b13aa0dfe8f1bb4125b061c8d" --language nl

#date: 2024-03-05 - length:    15:38 - title: "The Rothschild family is funding all wars from both sides | Rothschild documentary"
sa "https://odysee.com/The-Rothschild-family-is-funding-all-wars-from-both-sides:089482a7a2b2bf8fa4956e352a40d4938eaef18c" --language nl

#date: 2024-03-03 - length:  2:07:21 - title: "The Vladimir Putin Interview by Tucker Carlson (Febr 6, 2024) (1080p)"
sa "https://odysee.com/vladimir-putin-interview-by-tucker-carlson-february-6-2024:7f3b86094ce2e31a3cdd3a670b4748ce8ed0a5fd" --language nl

#date: 2024-03-02 - length:     7:54 - title: "Aladdin - The BlackRock Financial Computer Intelligence (AI) - The NWO robot that is set out to own everything"
sa "https://odysee.com/aladdin-blackrock-financial-computer:3a5de0c7a9fa2092167084cae553cd432576ddae" --language nl

#date: 2024-03-02 - length:    19:59 - title: "How to protect yourself from the $21 Trillion financial control grid ALADDIN weaponized by BlackRock"
sa "https://odysee.com/how-to-protect-yourself-from-aladdin:2676ac0310c241dfa92dcbb4f9c179605b9438fd" --language nl

#date: 2024-02-03 - length:     9:12 - title: "Database administrator who revealed how many people died after Pfizer jab hounded by government"
sa "https://odysee.com/Database-administrator-who-revealed-how-many-people-died-after-Pfizer-jab-hounded-by-government:99183a91446e96c92ffb9f75f8d74492ad1c7c8e" --language nl

#date: 2024-02-03 - length:    42:42 - title: "THE BIG FLIP (DUTCH SUBTITLES) (4K) "
sa "https://odysee.com/The-Big-Flip-Explained--NL:65e0acf320960a8f0b0acefa0494d5fd5398a7fd" --language nl

#date: 2024-02-03 - length:  1:27:06 - title: "Beerput Nederland (2017)"
sa "https://odysee.com/Beerput-Nederland-(2017):6eb01e99d7ff0946673cda6c9580f8bbf1c4f425" --language nl

#date: 2024-02-03 - length:    10:58 - title: "THE DEEP STATE AMERICANS DID IT - NORD STREAM (update 01-10-2022)"
sa "https://odysee.com/biden-promises-to-bring-down-nord-stream-pipeline:ded0f121838c3ffcf51568cd7475cf6117b8a0d7" --language nl

#date: 2024-02-02 - length:     4:45 - title: "Cutting off the Head of the Snake in Geneva | V I R A L 🇨🇭🤝🇺🇸 Documentary (4K)"
sa "https://odysee.com/who-geneva-poisened-the-world:bbc5b8af187ff6b1e876da65eee9db389aba2358" --language nl

#date: 2024-02-02 - length:    24:52 - title: "Steve Kirsch testifies on vaccine unsafety before the Medical Freedom Panel of the US Senate in Pennsylvania in 2023 "
sa "https://odysee.com/steve-kirsch-2023-medical-freedom-panel:34dcaf91891b3278477e39b709bf1cc229834dd9" --language nl

#date: 2024-01-24 - length:    53:11 - title: "The Truth about MH17 and MH370"
sa "https://odysee.com/the-truth-about-MH370-and-MH17:c0b8a929207cc3cf3fe485c4b3951c4d9ef05d41" --language nl

#date: 2023-12-02 - length:    51:02 - title: "Ted Gunderson says "There is a conspiracy" | The Corruption network (1080P-ai)"
sa "https://odysee.com/Ted-Gunderson--There-is-a-conspiracy:3cf281386965fbff8c83616f287204b110d8e03d" --language nl

#date: 2023-11-16 - length:  1:00:55 - title: "Loose Change 1 (4K-ai) | Challenging the 911 storyline"
sa "https://odysee.com/loose-change--challenging-the-911-storyline:784ff4fc1b43c65575e8fcf86097c6dd0a63076f" --language nl

#date: 2023-11-12 - length:     6:55 - title: "Proof of stolen 2020 US election"
sa "https://odysee.com/proof-of-stolen-2020-us-election:40630d3d40a4b1e73ec9cd4b80ff3caa6e26f273" --language nl

#date: 2023-11-07 - length:    27:27 - title: "The Catalytic Converter - The deadliest weapon of depopulation"
sa "https://odysee.com/the-catalytic-converter--the-deadliest-weapon:08d67b0293d452db51d869f7be56a0e705d5ab18" --language nl

#date: 2023-10-31 - length:    49:02 - title: "PAYLOAD 2 - NANOCAPSULES (1080p-ai)"
sa "https://odysee.com/payload-2--nanocapsules:61a5c46e43916b0839686e43e38c95e9def89601" --language nl

#date: 2023-09-08 - length:  3:27:55 - title: "From JFK to 911 Everything Is A Rich Man's Trick (1080p)"
sa "https://odysee.com/everything-is-a-rich-mans-trick:49df984bbbd6496168b29dc90b70a16e7ca93aa6" --language nl

#date: 2023-09-08 - length:    12:25 - title: "Maui - What really happened"
sa "https://odysee.com/maui-what-really-happened:d94a8efb73c05b5f269bce84079f60327145ed75" --language nl

#date: 2023-09-03 - length:     4:59 - title: "The pentagon admits Direct Energy Weapons (DEW) | Were they used to start fires?"
sa "https://odysee.com/the-pentagon-admits-direct-energy-weapons--were-they-used-to-start-fires:b2dd40020999ac4c06b7ca487c21693aa918c618" --language nl

#date: 2023-09-03 - length:  1:14:37 - title: "UNconventional Grey (1080p)"
sa "https://odysee.com/unconventional-grey--thegeoengeneering-documentary:273f1c4a6ef67b79fdd10df8f8e62a8b03bb3c71" --language nl

#date: 2023-08-19 - length:     1:00 - title: ""Thrown To The Wind" - Whale Deaths and Wind Farms ARE CONNECTED - Trailer 1080P"
sa "https://odysee.com/thrown-to-the-wind--trailer:904dea1ab19129a3fb533f16f6b8dc549ae488aa" --language nl

#date: 2023-08-13 - length:     9:32 - title: "COVID-19: The Great Reset - Dutch proceedings on the merits personal injury"
sa "https://odysee.com/COVID-19---The-Great-Reset-Dutch-proceedings-on-the-merits-personal-Injury:c1454d882a0d52ec75210ece8d6e166a75e11ff6" --language nl

#date: 2023-07-20 - length:    14:03 - title: "DVO NIEUWS #6 - IS 'THE GREAT RESET' EEN ONDERDEEL VAN AGENDA 2030? - VERVOLG MET MR. DRS. ARNO VAN KESSEL"
sa "https://odysee.com/DVO-Nieuws-06-Arno-van-Kessel-vervolg-agenda-2030:00d4d69f09d9bee0e4065c03e64ea568b65afeca" --language nl

#date: 2023-07-05 - length:     2:04 - title: "The World Health Organization (WHO) tries to legalize sex for kids"
sa "https://odysee.com/who-legalizing-sex-for-kids:819c29e7ec9f6212d1fb8b0e6a97065aae2b7188" --language nl

#date: 2023-06-06 - length:    59:45 - title: "MI6 JOHN COLEMAN EXPLAINS THE NEW WORLD ORDER IN 1990 | WHISTLEBLOWER"
sa "https://odysee.com/dr-john-coleman-explains-nwo--whistleblower:cb60d7fff31f166efabcbe8e21396aff94ab5f46" --language nl

#date: 2023-06-01 - length:  7:57:32 - title: "INTERNATIONAL COVID SUMMIT III | MAY 3 - 2023 - EU PARLIAMENT (4K)"
sa "https://odysee.com/international-covid-summit-III-2023-_-4K-:b122e508cb4c10e38b8b9c542c40793deb109b5c" --language nl

#date: 2023-05-25 - length:     8:24 - title: "Morpheus Uncensored"
sa "https://odysee.com/morpheus-uncensored:a979cff7234a817b8b4df10c38198fe78f8819dd" --language nl

#date: 2023-05-23 - length:  1:38:53 - title: "FLUORIDE: POISON ON TAP (2015 documentary)"
sa "https://odysee.com/fluoride-poison-on-tap-2015-documentary:1e7b0c645df77f43f64087570a669aa04e1d441e" --language nl

#date: 2023-02-28 - length:  2:38:29 - title: "Aaron Russo Exposes the Global Elite - Central Banks - NWO & Microchips - 2005 Alex Jones interview"
sa "https://odysee.com/Aaron-Russo-interview---Alex-Jones:34263ab23db9754efdeba9151573b9bfc25863e6" --language nl

#date: 2023-02-20 - length:    51:39 - title: "They paid doctors and nurses to murder innocent patients... | The Time Is Now 2023 Version"
sa "https://odysee.com/the-time-is-now-government-crimes:1de36b285940b603a6b9e52677c829fc93025e51" --language nl

#date: 2023-02-06 - length:     4:13 - title: "POST-IT ACTIE BIJ NOS HILVERSUM - Nu al de beste Demonstratie van 2023"
sa "https://odysee.com/PostIt-Actie-Nos-Hilversum:1e0857b602dd6f42797f0b55eb3f2ab2aa2ff2d2" --language nl

#date: 2023-01-29 - length:    39:59 - title: "GEHEIMEN VAN DE VERENIGDE NATIES - Wat iedereen zou moeten weten!"
sa "https://odysee.com/geheimen-van-de-verenigde-naties:cfea5822c81b14e31311487b883467a9278e5108" --language nl

#date: 2022-12-06 - length:    36:21 - title: "DVO VACCIN JOURNAAL | DVO JOURNAAL #8"
sa "https://odysee.com/vaccin-journaal-8:6856cf5198a89d4febb69e7dd4d1684fbe0813c4" --language nl

#date: 2022-10-11 - length:  1:02:30 - title: "HET CORONA-JAAR-JOURNAAL | DE VRIJE OMROEP -  DVO"
sa "https://odysee.com/Jaarjournaal-8.3.2-2.1Mbit-Master-1:e9a124db6a8dc181dac9eb52778443ea6bff1875" --language nl

#date: 2022-09-14 - length:    52:17 - title: "Satanic Ritual abuse survivor Jeanette Archer exposes the Royal Family"
sa "https://odysee.com/satanic-ritual-abuse-survivor-Jeanette-Archer:ce7f6661cb068e77f197f4da52a6f7ce4ff6cf3a" --language nl

#date: 2022-05-28 - length:  1:10:15 - title: "LOOSE CHANGE - SECOND EDITION ( 1080P AI ) | DVO SHARE"
sa "https://odysee.com/loose-change-2nd-Edition:e21929ef26e3dbc15122f7905966ed679f4b5912" --language nl

#date: 2022-03-30 - length:  1:04:25 - title: "DVO NIEUWS #5 - JURIDISCHE ANALYSE VAN DE COVID-19 CRISIS MET MR DRS ARNO VAN KESSEL"
sa "https://odysee.com/dvo-nieuws-5:e7f6de520cf51327a80a6a506facb70afbbc52f0" --language nl

#date: 2022-02-27 - length:     2:00 - title: "JULIAN ASSANGE - MEDIA LIES RESULT IN WARS | DVO SHARE"
sa "https://odysee.com/julian-assange-media-lies-result-in-wars:3fda6dbaa3b1b3425ce2138f4fb0aa96de150d1b" --language nl

#date: 2022-02-22 - length:     5:29 - title: "CANADA FREEDOM CONVOY REPORTAGE #2 | DVO SHARE"
sa "https://odysee.com/dvo-canada-reportage_2:8070d1f2059711aed35ed828da35f953991cf497" --language nl

#date: 2022-02-22 - length:     2:53 - title: "CANADA FREEDOM CONVOY REPORTAGE #1 | DVO SHARE"
sa "https://odysee.com/dvo-canada-reportage_1:bb2c43545a9593ec61c0e7bde13e8c1039eae2c6" --language nl

#date: 2022-02-22 - length:     2:36 - title: "DE LEUGENS ROND HET COVID PASPOORT | DVO SHARE"
sa "https://odysee.com/dvo_digitaal-paspoort_1:71876a1e19d3bac27f76a6dcb7f7aa35e238b3f1" --language nl

#date: 2022-02-21 - length:    21:34 - title: "DVO WEEK NIEUWS - VERVOLG CANADA EN VERGOEDING BIJ VACCINSCHADE | FEBRUARI #4"
sa "https://odysee.com/DVO_weeknieuws-4:0f71f9d199f32f1629a2b9e345890e2ca1f5f441" --language nl

#date: 2022-02-21 - length:    13:07 - title: "WIE VERGOEDT DE KOSTEN IN HET GEVAL VAN VACCINATIESCHADE? | DVO SHARE"
sa "https://odysee.com/vaccinatieschade-vergoeding-nl:c974ab052c24d0d0d44d3a7436fe79910223fc07" --language nl

#date: 2022-02-18 - length:    15:08 - title: "DVO WEEK NIEUWS MET FALENDE OMT ANGSTZAAIERIJ EN DE CANADA REVOLUTIE | JANUARI #3"
sa "https://odysee.com/DVO_week-nieuws-3:a597b0f2e1dbc05d2e936b866a7fb23b733316e8" --language nl

#date: 2022-01-28 - length:    11:22 - title: "DVO WEEK NIEUWS MET EVA VAN ZEELAND | JANUARI #2"
sa "https://odysee.com/DVO_week-nieuws-2:8aeb3af41cce5c2f95a85f029d8c28ae7805aa6c" --language nl

#date: 2022-01-27 - length:     9:59 - title: "JOURNAAL #4 CENSUUR OVER PCR EN VACCIN | De Vrije Omroep (DVO) "
sa "https://odysee.com/DVO-JOURNAAL-0401:d8ef4c82a2b314b495c48cac5c73611210f24802" --language nl

#date: 2022-01-27 - length:    13:03 - title: "JOURNAAL #5 FINANCIËLE BELANGEN VACCIN-DICTATUUR | De Vrije Omroep DVO"
sa "https://odysee.com/dvo-journaal-05:099a924020d7a46173c07076dd856f6aeaf73a6f" --language nl

#date: 2022-01-26 - length:    13:15 - title: "DE RELATIE TUSSEN ZENDMASTEN - COVID19 EN KLIMAAT | DVO JOURNAAL #6: "
sa "https://odysee.com/journaal-6:e0fe85954732c801cae344e6f63c55ca05c178e7" --language nl

#date: 2022-01-25 - length:    10:52 - title: "CODE ROOD 🆘 DVO JOURNAAL #9"
sa "https://odysee.com/code-rood-dvo-journaal-9:66fb683228a85686c96b59a48858593c40fb2d2e" --language nl

#date: 2022-01-24 - length:     9:48 - title: "DVO WEEK NIEUWS MET EVA VAN ZEELAND | JANUARI #1"
sa "https://odysee.com/Dvo-Week-Nieuws-no1:aabf06be87ccfa6acab853df3807e7edd020ebf3" --language nl

#date: 2021-11-10 - length:    14:50 - title: "KINDERMISBRUIK EN MOORD DOOR DE ELITE VAN DE WERELD - SATANIC CHILD MURDERS | DVO EVIDENCE"
sa "https://odysee.com/kindermisbruik-en-moord-door-de-elite-van-de-wereld:d595784e3bce4e39e53a8ba72f4978d38dce698f" --language nl

#date: 2021-08-25 - length:  1:02:25 - title: "DVO CORONA 1ST YEAR NEWS (Dutch with English subs)"
sa "https://odysee.com/dvo-corona-year-news:cef1c47368df89d7f8c6fb9c9f1294dd27f7cbb8" --language nl

#date: 2021-04-21 - length:     8:09 - title: "JOURNAAL#3 POLITIEGEWELD | De Vrije Omroep (DVO) (Full-HD)"
sa "https://odysee.com/Dvo-Journaal-03-03-Politiegeweld-14-Maart-1080p:8254b1b1c27c4bbcde5f88e6f5ccbe9457aab95e" --language nl

#date: 2021-04-09 - length:     2:21 - title: "JOURNAAL #2 REINER FUELLMICH | De Vrije Omroep DVO (Full-HD)"
sa "https://odysee.com/dvo-journaal-04-01-fuellmich_1080p:6d713adf16aa5bba6bb7ecbaa82110e5430c2318" --language nl

#date: 2021-03-23 - length:     8:40 - title: "HET (CORONA) JAAR JOURNAAL DEEL 3 | De Vrije Omroep DVO"
sa "https://odysee.com/corona-jaar-journaal_deel-3:0efdf2909f7c6d0a3593f9ae7601f662a3223170" --language nl

#date: 2021-03-23 - length:    17:50 - title: "HET (CORONA) JAAR JOURNAAL DEEL 1 | De Vrije Omroep DVO"
sa "https://odysee.com/corona-jaar-journaal_deel-1:78c58a0de0a48e0f82301cced601aeb5bd7551a9" --language nl

#date: 2021-03-23 - length:    15:14 - title: "HET (CORONA) JAAR JOURNAAL DEEL 5 | De Vrije Omroep DVO"
sa "https://odysee.com/corona-jaar-journaal_deel-5:59413078f6273f0f71d85626bf314d5c7a385ff0" --language nl

#date: 2021-03-23 - length:    11:33 - title: "HET (CORONA) JAAR JOURNAAL DEEL 2 | De Vrije Omroep DVO"
sa "https://odysee.com/corona-jaar-journaal_deel-2:ccc02cace7445376f4f34e9051b7fa633a5c24da" --language nl

#date: 2021-03-23 - length:    10:41 - title: "HET (CORONA) JAAR JOURNAAL DEEL 4 | De Vrije Omroep DVO"
sa "https://odysee.com/corona-jaar-journaal_deel-4:7919a26f9b7a4196a1af14236c22997c553ded15" --language nl



exit

echo " \\" > add_fix.txt
echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=BBgFlSTGCpg" --language nl

exit


echo " \\" > add_fix.txt
echo '	--tags="Kill Box" \' >> add_fix.txt
echo '	--tags="Katherine Watt"' >> add_fix.txt

sa "https://odysee.com/@scamdemic:7d/bankers-kill-box-katherine-watt:5" --language en

echo " \\" > add_fix.txt
echo '	--tags="PREP Act" \' >> add_fix.txt
echo '	--tags="Katherine Watt"' >> add_fix.txt

sa "https://odysee.com/@TGHeretic:7/The-PREP-Act-An-act-of-treason-:6" --language en

exit 

echo " \\" > add_fix.txt
echo '	--tags="Matthias Rath" \' >> add_fix.txt
echo '	--tags="Dr. Rath" \' >> add_fix.txt
echo '	--tags="cancer"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=tcvQWYbhwUw" --language de
saa "https://www.youtube.com/watch?v=OYy9LQZVEdw" --language de

echo '	--tags="Matthias Rath" \' >> add_fix.txt
echo '	--tags="EU" \' >> add_fix.txt
echo '	--tags="NAZI"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=-88HO_HMm8Y" --language de
saa "https://www.youtube.com/watch?v=5uqwUXO7x6Y" --language pl
exit

echo " \\" > add_fix.txt
echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=MEur6iNAWvE" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="Thoughty2" \' >> add_fix.txt
## echo '	--tags="Netherlands" \' >> add_fix.txt
## echo '	--tags="The Dutch"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=ylwIhnb8jOE" --language en 
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Hindsight" \' >> add_fix.txt
## echo '	--tags="DRONES" \' >> add_fix.txt
## echo '	--tags="Russia"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=yGeG5xm4kMM" --language en 

## exit
## 
## echo " \\" > add_fix.txt
## echo '	--tags="The Age of Disclosure"' >> add_fix.txt
## 
## saf2 "Disclosure" --language en 

## rm BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Ab Gietelink" \' >> add_fix.txt
## echo '	--tags="Peter Baars" \' >> add_fix.txt
## echo '	--tags="blckbx"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=p_6UsQAnLDw" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="lighthousetv" \' >> add_fix.txt
## echo '	--tags="lighthouse-tv"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=NkXmg25vX6E" --language nl # 2025-11-16 -  1:24:11 - Soul Session met Jan Wolfkamp, “Je hoeft niet alles te weten om het te ervaren.”
## sa "https://www.youtube.com/watch?v=GoT2VBadxnc" --language nl # 2025-11-14 -    50:14 - IEDEREEN een basisinkomen — deze vergeten documentaire voorspelde exact waar we nú staan
## sa "https://www.youtube.com/watch?v=CAdIUb9ci4A" --language nl # 2025-11-14 -    18:28 - Wie neemt het stokje over bij BVNL na het aftreden van Wybren van Haga als partijleider?!
## sa "https://www.youtube.com/watch?v=5GngZyb92dM" --language nl # 2025-11-13 -    16:17 - BBC gepakt met manipulatie Trump-speech J6 (Capitoolbestorming)
## sa "https://www.youtube.com/watch?v=_qpOGheUwNs" --language nl # 2025-11-13 -    14:41 - Ongekend! D66 en CDA mogen drie weken lang de koers van het kabinet bepalen
## sa "https://www.youtube.com/watch?v=lYQ8lYaXnRA" --language nl # 2025-11-13 -  1:17:34 - Van pepperspray tot parlement: grenzen aan gezag | blckbx Today #409
## sa "https://www.youtube.com/watch?v=lbl2KBoj0hE" --language nl # 2025-11-12 -  1:02:37 - 'Bizar’ formatie-advies Jetten-kabinet | Wybren stopt! | BBC-top vertrekt door Trump | LHTV#61
## sa "https://www.youtube.com/watch?v=2V5JDIWrORM" --language nl # 2025-11-11 -  1:18:21 - Harry van Bommel en Ab Gietelink over de Nederlandse verkiezingen, Saoedi-Arabië, Oekraïne & Gaza

## sa "https://www.youtube.com/watch?v=4LBPuBRBCv0" --language nl # 2025-11-10 -    39:53 - De ondernemers achter LHTV – sluit je aan en bouw mee aan vrije journalistiek!
## sa "https://www.youtube.com/watch?v=nuI1V1WrwZE" --language nl # 2025-11-09 -  1:25:36 - Soul Session met Marja West, “Als ik hier twee weken ben wordt het tijd dat ik terugga.”
## sa "https://www.youtube.com/watch?v=yI9zkXrR5uM" --language nl # 2025-11-07 -    26:00 - Misstanden rond stemproces zwellen aan! Bas Reijnierse belde met de Kiesraad
## sa "https://www.youtube.com/watch?v=W6u9X_jk7us" --language nl # 2025-11-07 -  1:02:50 - Documentaire: Inside mRNA Vaccins – The Movie
## sa "https://www.youtube.com/watch?v=1cJzm5JXYrA" --language nl # 2025-11-06 -    23:20 - Digitale Euro door naar ‘laatste fase’: wat staat ons te wachten?
## sa "https://www.youtube.com/watch?v=BhV2vpMOXiw" --language nl # 2025-11-06 -    14:00 - Jetten op wankele benen: geen middenkabinet, maar buigen naar rechts?
## sa "https://www.youtube.com/watch?v=2nkbNBKEp4A" --language nl # 2025-11-06 -  1:28:06 - blckbx today #408 Van stembus tot databank: wantrouwen en de macht achter de schermen
## sa "https://www.youtube.com/watch?v=h5GuKo1bqWk" --language nl # 2025-11-05 -  1:13:40 - Was er stemfraude? | Wat wordt kabinet Jetten-l? | Digitale euro komt eraan! | LHTV#60
## sa "https://www.youtube.com/watch?v=9HUtXTCQgeI" --language nl # 2025-11-04 -  1:15:52 - Blckbx Debat #1 Prof. Kees vd. Pijl, Pepijn van Houwelingen (FvD) en Ab Gietelink
## sa "https://www.youtube.com/watch?v=QF9xXHpj5g8" --language nl # 2025-11-03 -     8:34 - Lidewij de Vos (FVD) viert overwinning: volledige speech na behalen van 7 zetels!
## sa "https://www.youtube.com/watch?v=48SC69bsrmg" --language nl # 2025-11-03 -    51:10 - Robert Malone EXPOSES how Big Pharma and AI are reshaping medicine, media and free speech
## sa "https://www.youtube.com/watch?v=v9W8FlocGB4" --language nl # 2025-11-03 -     3:29 - Winst voor D66: wat nu? Gijs Tuinman over Oost-Europa, Defensie en de toekomst van het kabinet
## sa "https://www.youtube.com/watch?v=ZmJAElNIGqo" --language nl # 2025-11-02 -  1:51:47 - Soul Session met Sietske Bergsma, “..dat is wat ik graag zou zien, dat we ons opnieuw uitvinden”
## sa "https://www.youtube.com/watch?v=IpdDOCj8rB0" --language nl # 2025-11-01 -     8:33 - Harm Beertema reageert op 0 zetels voor BVNL, vertrekkende Timmermans en winst Rob Jetten met D66
## sa "https://www.youtube.com/watch?v=G2T-3q8zabs" --language nl # 2025-11-01 -     3:14 - Theo Schetters over wat verlies BVNL betekent voor zijn inzet in het coronadossier
## sa "https://www.youtube.com/watch?v=SRMAEwsiGFY" --language nl # 2025-11-01 -  1:31:32 - An Inconvenient Study (Nederlands ondertiteld)
## sa "https://www.youtube.com/watch?v=tshxQSCvIJk" --language nl # 2025-10-31 -     6:47 - GÉÉN ZETEL! BVNL-leider Wybren van Haga reageert op uitslag
## sa "https://www.youtube.com/watch?v=KtaHSOK2Lto" --language nl # 2025-10-31 -    57:57 - Fleur Agema zonder filter: PVV-uitslag, NAVO/NCTV-rel, Wilders-ruzie én waarom ze stopte | ADWK#4

## sa "https://www.youtube.com/watch?v=jUst7ZWgEdo" --language nl # 2025-10-31 -     4:01 - Minister Mona Keijzer (BBB) reageert op magere uitslag, D66-winst en centrumrechts kabinet
## sa "https://www.youtube.com/watch?v=b8dsHiZDl-Y" --language nl # 2025-10-31 -     3:19 - BBB-europarlementariër Jessika Van Leeuwen reageert op D66-winst
## sa "https://www.youtube.com/watch?v=KkE3lsAhiGc" --language nl # 2025-10-31 -     2:59 - 7 zetels voor FVD! Eerste reactie Lidewij de Vos over verkiezingsuitslag!
## sa "https://www.youtube.com/watch?v=V_jemVP-c_o" --language nl # 2025-10-30 -     5:08 - Thierry Baudet reageert op voorlopige verkiezingsuitslag FVD!
## sa "https://www.youtube.com/watch?v=zHY2oKAmVIA" --language nl # 2025-10-30 -     2:51 - Caroline van der Plas reageert op uitslag: gaan dingen veranderen bij BBB na halvering?
## sa "https://www.youtube.com/watch?v=h1pUNcx-Kto" --language nl # 2025-10-30 -  1:27:52 - blckbx today #407 - Tussen verkiezingen en Halloween: is er een weg uit donkere tijden?
## sa "https://www.youtube.com/watch?v=ArI3UqylU7M" --language nl # 2025-10-28 -  1:04:29 - Patrick Savalle en Ab Gietelink in gesprek over Palantir: data, surveillance en macht
## sa "https://www.youtube.com/watch?v=ef-2_YzhTlo" --language nl # 2025-10-27 -    17:09 - "Wat drijft jouw stemgedrag?", Huibrecht Boluijt op De Derde Kamer
## sa "https://www.youtube.com/watch?v=I0jp6DhYvbA" --language nl # 2025-10-27 -  1:03:04 - Mona Keijzer over verkiezingen, macht en trouw blijven aan je geweten | ADWK#3
## sa "https://www.youtube.com/watch?v=ggHnt2U3OMo" --language nl # 2025-10-26 -    57:20 - de Derde Kamer Verkiezingsdebat: BVNL, Vrede voor Dieren, FvD, Piratenpartij en de Libertaire Partij
## sa "https://www.youtube.com/watch?v=o5e6a_DBE-w" --language nl # 2025-10-26 -  1:32:49 - Soul Session met Arnold Karskens, “Ik geloof in de kracht van de mens”
## sa "https://www.youtube.com/watch?v=q84qx6hhHWQ" --language nl # 2025-10-25 -    27:09 - de Derde Kamer speeddate met FvD, Vrede voor Dieren, BVNL, de Libertaire Partij en de Piratenpartij
## sa "https://www.youtube.com/watch?v=QRTe_u1UR40" --language nl # 2025-10-24 -    58:59 - DeepDive met Ancilla van de Leest: Toine Manders, de onverzettelijke Libertariër

## sa "https://www.youtube.com/watch?v=e7osz7L2r8I" --language nl # 2025-10-24 -    28:04 - CO₂-belasting aan de pomp en in huis? Marcel Crok: ‘niemand praat hierover tijdens verkiezingen’
## sa "https://www.youtube.com/watch?v=lGnZWgY2KMY" --language nl # 2025-10-24 -  1:22:02 - Documentaire: An Inconvenient Study - van Del Bigtree!
## sa "https://www.youtube.com/watch?v=DNtH8x11sC8" --language nl # 2025-10-23 -    38:15 - Nog 7 dagen: Maurice de Hond verwacht wéér een grote gamechanger In de laatste dagen!
## sa "https://www.youtube.com/watch?v=APs5jvAmrWU" --language nl # 2025-10-23 -    21:30 - ALLES-OF-NIETS voor BVNL en Van Haga voor een Kamerzetel
## sa "https://www.youtube.com/watch?v=IqI4AP7Ps4w" --language nl # 2025-10-23 -  1:53:01 - blckbx today #406 | Van digital ID tot 15-minute cities: wat kiest Nederland?
## sa "https://www.youtube.com/watch?v=IGyZW0KPlPI" --language nl # 2025-10-22 -     8:04 - Déze bijzondere uitzendingen zie je komende week bij LightHouseTV!
## sa "https://www.youtube.com/watch?v=UmAZr_26004" --language nl # 2025-10-22 -  1:46:36 - De Hond voorspelt gamechanger | LP waarschuwt voor CO₂-agenda | alles-of-niets voor BVNL | LHTV#58
## 
## echo PRESS ENTER 
## read aaaaa
## 
## echo " \\" > add_fix.txt
## echo '	--tags="10 cities" \' >> add_fix.txt
## echo '	--tags="Netherlands" \' >> add_fix.txt
## echo '	--tags="scam"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=mmCgJQOM86M" --language en

echo " \\" > add_fix.txt
echo '	--tags="lighthousetv" \' >> add_fix.txt
echo '	--tags="lighthouse-tv"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=64wI1773a1c" --language nl # 2025-10-22 -    14:31 - Pseudodemocratie of Referendumdemocratie? Column van Ab Gietelink voor de Derde Kamer

## sa "https://www.youtube.com/watch?v=iZFgRkztcFg" --language nl # 2025-10-21 -  1:35:41 - Oud 2e Kamerlid over het FvD Programma, Oekraïne en Gaza. Ab Gietelink interviewt Ralf Dekker
## sa "https://www.youtube.com/watch?v=3PkAVIOfI04" --language nl # 2025-10-20 -  1:19:53 - Nieuwe FVD-lijsttrekker verrast heel Nederland: wie is Lidewij de Vos? | ADWK#2
## sa "https://www.youtube.com/watch?v=jl8jpTC8iO4" --language nl # 2025-10-19 -  1:16:42 - Soul Session met Catherine Keijl, “Wat jij niet wil dat bestaat dat moet ook weg”
## sa "https://www.youtube.com/watch?v=U7WpBVEreJ8" --language nl # 2025-10-17 -    21:29 - Verbod op Nederlandse vlag?! Cultuur onder Vuur in de bres voor Nederlandse waarden
## sa "https://www.youtube.com/watch?v=QbdITKdINDQ" --language nl # 2025-10-17 -  1:11:54 - Wat we niet mochten weten! Documentaire 'Inside The Vaccine Trials' onthult de waarheid...
## sa "https://www.youtube.com/watch?v=gJiItH0u6NI" --language nl # 2025-10-16 -    22:37 - Felle discussie over Nederlandse wapensteun aan Oekraïne
## sa "https://www.youtube.com/watch?v=OPdGDxhBlZY" --language nl # 2025-10-16 -    19:56 - Theo Schetters: cruciaal vaccinatiesterfteonderzoek op de plank blijven liggen
## sa "https://www.youtube.com/watch?v=Aog-J3Z0H8w" --language nl # 2025-10-16 -  1:57:02 - Wetenschap, vrijheid en boerenbelangen: hoe krijgen we Nederland weer op koers?
## sa "https://www.youtube.com/watch?v=6-FExtc1fUM" --language nl # 2025-10-15 -  1:19:28 - Wat ze ons niet vertelden over vaccinatie | NAVO-overleg in Brussel | Cultuur in crisis | LHTV#57
## sa "https://www.youtube.com/watch?v=-elmljb19-M" --language nl # 2025-10-14 -  1:07:15 - Wat wil de Libertaire partij? Lijsttrekker Tom van Lamoen geïnterviewd door Ab Gietelink
## sa "https://www.youtube.com/watch?v=0rD4ci9uXlY" --language nl # 2025-10-13 -     1:54 - Vanavond om 19:00 uur: Aan de Waterkant #1 met tech-filosofe Martijntje Smits!
## sa "https://www.youtube.com/watch?v=X-osCSQOjWg" --language nl # 2025-10-13 -  1:17:09 - De wereld in 2050: Brits Digital ID, AI en moraliteit - met tech-filosofe Martijntje Smits | ADWK#1
## 
## echt Press enter
## read aaa
## 
## sa "https://www.youtube.com/watch?v=Z2aEbEM-HKA" --language nl # 2025-10-12 -  1:20:26 - Soul Session met Henk Krol: "Mensonterend was die ziekte!"
## sa "https://www.youtube.com/watch?v=-9ZQDWz_sWc" --language nl # 2025-10-11 -     6:10 - LightHouseTV reageert op overlijden Bauke Geersing
## sa "https://www.youtube.com/watch?v=4a2kRJk_G8A" --language nl # 2025-10-10 -    23:58 - Thierry Baudet (FVD) clasht met Henk Vermeer (BBB) over steun aan Oekraïne
## sa "https://www.youtube.com/watch?v=QpdGf3XJQs0" --language nl # 2025-10-09 -    28:04 - De werkelijke oorzaak van de woningnood: hoe lossen we het EINDELIJK op?
## sa "https://www.youtube.com/watch?v=giW-u1KB9yI" --language nl # 2025-10-09 -    20:48 - Van oude naar nieuwe media: contentmaker Doelah Verzijde over de macht van Mediaconcerns
## sa "https://www.youtube.com/watch?v=JyGabaAoVV0" --language nl # 2025-10-09 -  1:40:40 - blckbx Today #404 | Transhumanisme, transparantie & de strijd om de toekomst
## sa "https://www.youtube.com/watch?v=IWTx033Tm4s" --language nl # 2025-10-09 -    11:44 - 'Daar ga je, Henk!' - Thierry Baudet (FVD) confronteert Henk Vermeer (BBB) over stikstof
## sa "https://www.youtube.com/watch?v=P5LSAXbFnUA" --language nl # 2025-10-08 -    25:35 - Winst 'Tsjechische Trump’, Wilders & Orbán – Libertaire Partij over anti-EU-golf
## sa "https://www.youtube.com/watch?v=_yq7Nxq2LaE" --language nl # 2025-10-08 -    23:36 - Pepijn van Houwelingen over vergaande surveillance plannen EU
## sa "https://www.youtube.com/watch?v=C4xpvCXI6Wo" --language nl # 2025-10-08 -    21:23 - Van protest tot confrontatie: de groei van verzet tegen AZC’s
## sa "https://www.youtube.com/watch?v=gBbq-r0QsAA" --language nl # 2025-10-08 -    20:17 - Asielcrisis in Nederland escaleert: wie durft nog in te grijpen?
## sa "https://www.youtube.com/watch?v=iW1TxEdwDa8" --language nl # 2025-10-08 -    15:40 - Zorgwekkende framing conservatieve en nationalistische kiezers in politiek debat
## sa "https://www.youtube.com/watch?v=rEdAiYxkJr8" --language nl # 2025-10-07 -    26:06 - Turning Point NL aan tafel: waarom Charlie Kirks beweging nu ook in Nederland begint
## sa "https://www.youtube.com/watch?v=2N0XUfz27uM" --language nl # 2025-10-07 -    18:02 - Jonathan Krispijn over zijn vertrek bij Ongehoord Nederland
## sa "https://www.youtube.com/watch?v=xlYV9tKqGGo" --language nl # 2025-10-07 -  1:08:18 - Trump, Goud, Tarieven en Her-industrialisatie. Ab Gietelink interviewt Sander Boon
## sa "https://www.youtube.com/watch?v=Bf8T2SJdaQ0" --language nl # 2025-10-05 -    28:16 - Religie & onderwijs en waarom corona-critici eindigen bij God
## sa "https://www.youtube.com/watch?v=ID_WbpBcxPo" --language nl # 2025-10-05 -    24:56 - Oneervol ontslag: dit gebeurt er als een marechaussee zich uitspreekt tegen de overheid
## sa "https://www.youtube.com/watch?v=m6T2yn7U68o" --language nl # 2025-10-05 -  1:31:12 - Soul Session met Kees van der Pijl: "Ik ben eigenlijk permanent bang"
## sa "https://www.youtube.com/watch?v=RpZaCllFxlc" --language nl # 2025-10-04 -    15:23 - Waarom Mees Wijnants de EU verliet – en bijna 50% jonge ondernemers ook weg wil
## sa "https://www.youtube.com/watch?v=E7XGsN-32Mo" --language nl # 2025-10-03 -    20:20 - Europees Hof: boetes blijven voor Corona-artsen ondanks geslaagde HCQ/Ivermectine-behandelingen
## sa "https://www.youtube.com/watch?v=bScO07TRypY" --language nl # 2025-10-02 -    29:50 - StemWijzer blijkt misleidend, manipulatief en mist ‘belangrijkste’ thema’s
## sa "https://www.youtube.com/watch?v=a9eMjY_Io3I" --language nl # 2025-10-02 -    27:14 - Het échte verhaal achter de Britse Digital ID met journalist Lewis Brackpool
## sa "https://www.youtube.com/watch?v=U3Oo7ujcQfM" --language nl # 2025-10-02 -  1:33:13 - blckbx Today #403 | Framing, filtering & grenspolitiek: de nieuwe frontlines van controle
## sa "https://www.youtube.com/watch?v=MAw5uKjlpX4" --language nl # 2025-10-01 -    21:28 - De wolf als verdienmodel - Annemieke van Straaten waarschuwt voor de gevolgen van 'rewilding'
## sa "https://www.youtube.com/watch?v=UXjbPJA7G1U" --language nl # 2025-10-01 -    17:15 - Matthijs Pontier over de zaak van Bits of Freedom tegen META en cybersecurity
## sa "https://www.youtube.com/watch?v=p15aGROv2FQ" --language nl # 2025-10-01 -    14:04 - Wie gaan er boeten voor de gesignaleerde drones boven Europa?
## sa "https://www.youtube.com/watch?v=RYn9ObozwZ4" --language nl # 2025-09-30 -    25:44 - Door Frankema geeft haar visie op persconferentie Trump over onderzoek naar oorzaak autisme
## sa "https://www.youtube.com/watch?v=4TeR6VeFDZE" --language nl # 2025-09-30 -    22:21 - Nog één maand tot de verkiezingen – Maurice de Hond over peilingen, premierstrijd en gamechangers
## sa "https://www.youtube.com/watch?v=Jp884p5zEZo" --language nl # 2025-09-30 -    22:00 - ‘Russische proeftuin’ Moldavië kiest na politieke inmenging toch voor EU-kamp
## sa "https://www.youtube.com/watch?v=4k1SQNHmfEc" --language nl # 2025-09-30 -    20:33 - Elsfest demonstranten eenzijdig belicht door media en politici
## sa "https://www.youtube.com/watch?v=5FxGADJiz-s" --language nl # 2025-09-30 -  1:16:22 - Wat wil de Piratenpartij? Ab Gietelink interviewt lijsttrekker Matthijs Pontier
## sa "https://www.youtube.com/watch?v=VxJopOVtmp8" --language nl # 2025-09-28 -    17:19 - Haagse rellen aangegrepen voor gezichtsherkenning, chat-toegang en verbod anonieme social accounts
## sa "https://www.youtube.com/watch?v=HzZb9D_VghQ" --language nl # 2025-09-28 -  1:30:23 - Soul Session met Frénk van der Linden: “Wij hadden de ander kunnen zijn”
## sa "https://www.youtube.com/watch?v=dHsC3rNnF6Q" --language nl # 2025-09-27 -    14:59 - Ex-COA-medewerker onthult ‘wanpraktijken’ binnen AZC’s
## sa "https://www.youtube.com/watch?v=XSUktXxQmjU" --language nl # 2025-09-27 -    13:46 - EU wil meekijken op je telefoon en zet door met ChatControl-wet
## sa "https://www.youtube.com/watch?v=pKyB-5PaqrI" --language nl # 2025-09-26 -    33:50 - Digitale euro start in 2026: zullen Europeanen deze massaal adopteren? *
## sa "https://www.youtube.com/watch?v=cXzHjT7ne5s" --language nl # 2025-09-25 -    27:16 - Haagse rellen: ex-NOS-baas fileert Jetten, Schimmelpenninck & AIVD over ‘Wilders-frame’
## sa "https://www.youtube.com/watch?v=TyIMCQVLRIE" --language nl # 2025-09-25 -    27:11 - Nieuwe prikronde bij 60-plussers: veilig en effectief of niet?
## sa "https://www.youtube.com/watch?v=HEgZkqIbkC8" --language nl # 2025-09-25 -    20:32 - Biolabs, verdwenen kinderen onder Biden, VN-invasies, de 'green energy scam' en meer
## sa "https://www.youtube.com/watch?v=jPXfk1CruLw" --language nl # 2025-09-25 -    20:03 - Vrijheid van meningsuiting onder druk na moord op Charlie Kirk
## sa "https://www.youtube.com/watch?v=hKvFuC7MjDk" --language nl # 2025-09-25 -    18:10 - Rico Brouwer: “Journalistiek is een vrij beroep, waarom zou dat beperkt moeten worden?”
## sa "https://www.youtube.com/watch?v=wX4MD5MHnLk" --language nl # 2025-09-25 -  1:41:48 - blckbx Today #402 | Van vaccins tot digitale privacy: de strijd om waarheid en vrijheid
## sa "https://www.youtube.com/watch?v=6iVc57GnBIc" --language nl # 2025-09-24 -    24:05 - Kees van der Pijl over 9/11 en de veranderende publieke opinie 24 jaar later
## sa "https://www.youtube.com/watch?v=BbLq7L9cGnI" --language nl # 2025-09-24 -    21:37 - George van Houts over de moord op Charlie Kirk
## sa "https://www.youtube.com/watch?v=LVrtwSNqCNo" --language nl # 2025-09-24 -    20:27 - Nieuwe partij Vrede voor Dieren: ‘STOP oorlogsmiljarden van NAVO en EU!’
## sa "https://www.youtube.com/watch?v=CBAipCJq33Y" --language nl # 2025-09-24 -    19:22 - Wybren van Haga over protest op het Malieveld tegen massa-immigratie
## sa "https://www.youtube.com/watch?v=o0yDbKihDxw" --language nl # 2025-09-24 -    12:15 - Paul Buitink over de Economische crisis in Frankrijk
## sa "https://www.youtube.com/watch?v=7a7eWPlfAoA" --language nl # 2025-09-23 -    20:40 - De Linie van ex-50PLUS-leider wil afrekenen met ‘bureaucratische’ wooncrisis
## sa "https://www.youtube.com/watch?v=jVu3Xf7mQM8" --language nl # 2025-09-23 -    17:43 - Partij voor de Rechtstaat in de bres tegen ‘onbetrouwbare’ overheid
## sa "https://www.youtube.com/watch?v=kFUNgPIUkRk" --language nl # 2025-09-23 -  1:52:51 - Verkiezingen, EU, Trump, Oekraïne & Palestina – Ab Gietelink in gesprek met Jelle van Baardewijk
## sa "https://www.youtube.com/watch?v=__Ot7LZnLhI" --language nl # 2025-09-22 -    21:55 - Romeo's, Antifa, hooligans? Wie zat er achter de escalatie van Malieveld-demo 'Elsfest'?
## sa "https://www.youtube.com/watch?v=pDjjVEZalF0" --language nl # 2025-09-21 -    18:17 - NAVO ‘Operation Eastern Sentry’ en EU ‘Defence Union’: verdediging of routekaart naar oorlog?
## sa "https://www.youtube.com/watch?v=QpQrdRPmwaQ" --language nl # 2025-09-21 -  1:41:39 - Soul Session met Machiel de Graaf: "Zo, van jou zijn we af. Haha, dat had je gedacht!"

# sa "https://www.youtube.com/watch?v=Xrbv5_GrfEA" --language nl # 2025-09-20 -    18:36 - FVD-motie om Antifa als terroristische organisatie aan te merken aangenomen
# sa "https://www.youtube.com/watch?v=lk-NGUsIW3A" --language nl # 2025-09-20 -    16:46 - Algemene Politieke Beschouwingen: theater voor de bühne of serieuze koers voor de toekomst?
# sa "https://www.youtube.com/watch?v=jTehuSzOC1A" --language nl # 2025-09-19 -    22:59 - De ware cijfers en het verhaal achter faillissementen in Nederland
## sa "https://www.youtube.com/watch?v=B9LMqqAJiz0" --language nl # 2025-09-19 -  1:07:32 - Antifa verboden na FVD-motie? | ‘Operation Eastern Sentry’ |'Kleuterklas' bij APB 2025 | LHTV#47

# echo press enter
# read aaa

## sa "https://www.youtube.com/watch?v=FYyZwP-vO5w" --language nl # 2025-09-18 -    22:12 - Dit is waar het bij de politieke beschouwingen NIET over gaat
## sa "https://www.youtube.com/watch?v=TC6CDUFhcDg" --language nl # 2025-09-18 -    16:30 - Miljoenennota blijkt miljardennota van 500mld: hoe lang gaat dit nog goed?
## sa "https://www.youtube.com/watch?v=nygGg5LE6Z4" --language nl # 2025-09-18 -  1:39:59 - blckbx today #401 | Vrijheid van meningsuiting onder druk: van Malieveld tot medische wetenschap
## sa "https://www.youtube.com/watch?v=Vr0Q5oTUHt4" --language nl # 2025-09-17 -       36 - De Derde Kamer; hét verkiezingsdebat waar vragen worden gesteld die er wél toe doen!
## sa "https://www.youtube.com/watch?v=z_Jp2zKpp2Q" --language nl # 2025-09-17 -    24:57 - Scenario’s rond Israëlische Mossad en Charlie Kirk zwellen aan: waar gaat dit precies over?
## sa "https://www.youtube.com/watch?v=MWszOwsAGEU" --language nl # 2025-09-17 -  1:14:42 - Miljoenennota-special: Dit schuilt er achter de rooskleurige cijfers van Den Haag | LHTV#46
## sa "https://www.youtube.com/watch?v=nH3xcEFhGKs" --language nl # 2025-09-16 -    25:23 - Bob Vylan ontleed: wordt politiek geweld genormaliseerd?
## sa "https://www.youtube.com/watch?v=-y8RpAbXbPE" --language nl # 2025-09-16 -    20:58 - Tommy Robinsons massale demo in Londen met Eva en Elon: "Fight back or die"
## sa "https://www.youtube.com/watch?v=7OEEiC_N4bM" --language nl # 2025-09-16 -  1:20:06 - Vredesperspectieven Hoorn Afrika, Oekraïne en Gaza. Gietelink interviewt oud-minister Jan Pronk
## sa "https://www.youtube.com/watch?v=UxzLSZxc1ak" --language nl # 2025-09-15 -    14:14 - Wat zeggen de recordstanden van goud- en beurskoersen ons?
## sa "https://www.youtube.com/watch?v=WUCNpwDgmgM" --language nl # 2025-09-14 -    16:29 - Waarom blijft Arno van Kessel vastzitten?
## sa "https://www.youtube.com/watch?v=JnZwtJkzRhw" --language nl # 2025-09-14 -    16:22 - Waarom de moord op Charlie Kirk ons niet uit elkaar moet spelen
## sa "https://www.youtube.com/watch?v=4jr28NMmHP0" --language nl # 2025-09-14 -  1:26:15 - Soul Session met Dina-Perla Portnaar: "Tempelberg in Jeruzalem plat; we zijn de weg kwijt."


## sa "https://www.youtube.com/watch?v=FFHSel03aNI" --language nl # 2025-09-12 -    20:58 - Waarom politici het deze verkiezingen niet over stikstof willen hebben
## sa "https://www.youtube.com/watch?v=jH2TsiC6gUU" --language nl # 2025-09-11 -    31:50 - Arno van Kessel blijft vastzitten tot 4 december
## sa "https://www.youtube.com/watch?v=7Ufadh8wm5I" --language nl # 2025-09-11 -    13:23 - NAVO-artikel 4 na ‘Russische drones boven Polen’ – escalatie of politiek frame?
## sa "https://www.youtube.com/watch?v=UUgNeNg_TxU" --language nl # 2025-09-11 -  1:21:04 - blckbx Today #400: Aanslag Charlie Kirk | 9/11: 24 jaar later |  Economische crisis treft Frankrijk

## echo press enter
## read aaa 
## 
## sa "https://www.youtube.com/watch?v=pY0MYNyns8o" --language nl # 2025-09-10 -    22:10 - Toine Manders wil dat belasting rechtstreeks bij de burger wordt geheven.
## sa "https://www.youtube.com/watch?v=0VsYZe0-GlI" --language nl # 2025-09-10 -    17:01 - EU introduceert 'toegangspoortje' voor internet: verplichte leeftijdscontrole
## sa "https://www.youtube.com/watch?v=omztcwGgJJo" --language nl # 2025-09-09 -    21:41 - Djamila Le Pair: "De nieuwe persrichtlijn maakt mijn werk als onafhankelijke journalist onmogelijk."
## sa "https://www.youtube.com/watch?v=OsFkibPdFJg" --language nl # 2025-09-09 -    21:25 - Is het komende kabinet al beslist? - ‘er gaat niets veranderen’
## sa "https://www.youtube.com/watch?v=ZMrqU9LMVrc" --language nl # 2025-09-09 -    18:16 - Alle onderzochte mRNA-vaccins verontreinigd: ‘Wanneer stopt Nederland met deze prikken?’
## sa "https://www.youtube.com/watch?v=yy2TX_jqOKI" --language nl # 2025-09-09 -  1:25:35 - Ex-Kamerlid Pepijn van Houwelingen over FVD-programma, geïnterviewd door Ab Gietelink
## sa "https://www.youtube.com/watch?v=3CZ95XvZYWI" --language nl # 2025-09-08 -    22:45 - De EU Identiteitsapp: Bescherming of Surveillance?
## sa "https://www.youtube.com/watch?v=HX_md8GqpRU" --language nl # 2025-09-08 -  1:15:02 - Vaccins verontreinigd | Bert voorspelt kabinet |  Leeftijdsslot internet via Digital ID | LHTV#42
## sa "https://www.youtube.com/watch?v=xb2voJK2kRs" --language nl # 2025-09-07 -    19:09 - ‘Flauwekulrapport’ Barbara Baarsma stuurt aan op verplaatsen van Nederlandse bedrijven

## sa "https://www.youtube.com/watch?v=mcipnsCCmiw" --language nl # 2025-09-07 -  1:41:36 - Soul Session met Dorien Rookmaker: "Ik was altijd de meest rebelse"
## sa "https://www.youtube.com/watch?v=dJ-nAM5-BkA" --language nl # 2025-09-07 -    10:46 - Chinees machtsvertoon op militaire parade brengt Westen in verlegenheid
## sa "https://www.youtube.com/watch?v=Re6Ri3Fsni0" --language nl # 2025-09-06 -    12:07 - 7 AfD'ers overleden in twee weken tijd vlak voor Duitse verkiezingen
## sa "https://www.youtube.com/watch?v=x8eVr3GOQjI" --language nl # 2025-09-05 -    13:20 - Onderzoek: klimaatdoelen 2035 onhaalbaar - 42% kan simpelweg niet meedoen
## sa "https://www.youtube.com/watch?v=0lro1DQWDKM" --language nl # 2025-09-04 -    18:47 - 50% koopkrachtverlies in 20 jaar - inflatie in NL blijkt 'sluipmoordenaar' spaargeld & pensioen
## sa "https://www.youtube.com/watch?v=UFnAQqD-fCc" --language nl # 2025-09-04 -  1:43:34 - blckbx Today #399: OnlyFans / Wikileaks & Journalistiek / Digital ID / Libertarisme
## 
## echo press enter
## read aaa 
## 
## sa "https://www.youtube.com/watch?v=P-7-Wa4dwRc" --language nl # 2025-09-04 -    12:26 - Inspectie: de menselijke maat is zoek bij de Belastingdienst
## sa "https://www.youtube.com/watch?v=YYW8dGTLnnI" --language nl # 2025-09-03 -    23:21 - "Destructieve mensen functioneren anders" | Vrouwveiligheid: Zijn mannen het probleem?
## sa "https://www.youtube.com/watch?v=q1NYkt6zLiE" --language nl # 2025-09-03 -    20:01 - Hoe gaat Defensie aan 200.000 man komen?
## sa "https://www.youtube.com/watch?v=uWG1aQNGF-Y" --language nl # 2025-09-03 -    18:11 - Dominee David: "Liefde en oordeel gaat niet echt samen, toch?" | Van New Age naar Jezus
## sa "https://www.youtube.com/watch?v=IqwdtKuwLfA" --language nl # 2025-09-02 -    19:00 - Trump dreigt EU-functionarissen met persoonlijke straffen om Big Tech-wetten
## sa "https://www.youtube.com/watch?v=kOebfGSRqJM" --language nl # 2025-09-02 -    17:18 - Xi, Poetin en Modi zetten zich af van het Westen tijdens SCO-top
## sa "https://www.youtube.com/watch?v=VTdhERUqqtA" --language nl # 2025-09-02 -  1:18:11 - "De mensen in de Donbas zien de Russen als bevrijders". Ab Gietelink spreekt met Sonja van den Ende
## sa "https://www.youtube.com/watch?v=PVubF3nsKsU" --language nl # 2025-09-01 -    17:45 - Frank Ruesink over het onderwijssysteem: "Kinderen worden ontzield"
## sa "https://www.youtube.com/watch?v=OmEgsUy_0jU" --language nl # 2025-08-31 -    17:08 - Zit Oekraïne achter opblazen Nord Stream?
## sa "https://www.youtube.com/watch?v=t4VkXlTDvUY" --language nl # 2025-08-31 -  1:35:02 - Soul Session met Emeritus hoogleraar Bob de Wit: ‘Ik dacht wat doe ik hier in Godsnaam’
## 
## echo press enter
## read aaa 
## 
## sa "https://www.youtube.com/watch?v=o10aooPtLpo" --language nl # 2025-08-31 -     1:11 - blckbx organiseert op zaterdag 18 oktober de Derde Kamer: het verkiezingsdebat dat je moet meemaken!
## sa "https://www.youtube.com/watch?v=MlrwIa36PsQ" --language nl # 2025-08-30 -    21:04 - Mona Keijzer aan de tand gevoeld door Tom de Nooijer over explosieve migratieweek
## sa "https://www.youtube.com/watch?v=G6zoyP61T18" --language nl # 2025-08-30 -    13:05 - Gevaren van nieuwe coronaprikrondes
## sa "https://www.youtube.com/watch?v=A-G9BHdXhMs" --language nl # 2025-08-29 -    19:05 - Nigel Farage (Reform UK)  kondigt massale deportaties aan
## sa "https://www.youtube.com/watch?v=e3Aqv3pXphs" --language nl # 2025-08-29 -  1:42:22 - blckbx Today #398: De Begrenzers / Georganiseerd Misbruik / Man vs Vrouw / Spirituele shift
## sa "https://www.youtube.com/watch?v=Cz13CTTuPCg" --language nl # 2025-08-28 -    19:21 - Hoogleraren leggen partijprogramma’s onder het mes: maken ze de economie beter of kapot?
## sa "https://www.youtube.com/watch?v=V0dm1_f-XHE" --language nl # 2025-08-28 -    16:46 - Waarom doet de Nederlandse overheid sinds 2011 geheimzinnig over data-analyse Palantir?
## sa "https://www.youtube.com/watch?v=IILYK6Zwfhs" --language nl # 2025-08-27 -    25:19 - Vrijheidsbijdrage en 'dienstplicht' in verkiezingsprogramma CDA
## sa "https://www.youtube.com/watch?v=rmxlm-kVrUI" --language nl # 2025-08-26 -    34:03 - Nederland in shock door tragische moord op Lisa (17)
## sa "https://www.youtube.com/watch?v=Q1PlBF-q74A" --language nl # 2025-08-26 -    28:49 - Henk Vermeer (BBB) vs. Bob de Wit – zit Nederland democratisch muurvast?
## sa "https://www.youtube.com/watch?v=Sthk52BNnaE" --language nl # 2025-08-26 -  1:21:33 - "70% van de ondertoezichtstellingen zijn onnodig". Ab Gietelink spreekt met Harry Berndsen.
## sa "https://www.youtube.com/watch?v=P4QY5TsYn8Q" --language nl # 2025-08-24 -    21:50 - Veteranen delen schaduwzijde buitenlandse missies Nederland
## sa "https://www.youtube.com/watch?v=aMq7u36mnFQ" --language nl # 2025-08-24 -  1:27:18 - Soul Session met Michaéla Schippers: "Het is een soort indoctrinatie die z’n weerga niet kent."
## sa "https://www.youtube.com/watch?v=0390WGuFpRg" --language nl # 2025-08-23 -    22:36 - Austin Fitts & Dekker: Waarom ondanks potentiële vredesdeal tientallen miljarden naar Defensie gaan
## sa "https://www.youtube.com/watch?v=KRQkKobYf4c" --language nl # 2025-08-23 -    19:08 - Zó verleidt Defensie jongeren om het leger in te gaan
## sa "https://www.youtube.com/watch?v=6q0NJObaK_M" --language nl # 2025-08-22 -    20:25 - Wat bespraken Trump, Zelensky en de EU-leiders in Het Witte Huis?

## echo press enter
## read aaa 
## 
## sa "https://www.youtube.com/watch?v=WhnO5I3hR-I" --language nl # 2025-08-21 -    29:26 - Sietske Bergsma vs. Thomas Bruning (NVJ) over 'bedreigende' European Media Freedom Act
## sa "https://www.youtube.com/watch?v=nfCTpu6w8lo" --language nl # 2025-08-21 -    19:17 - Eerste partijprogramma’s onthuld: met deze standpunten begint de strijd om jouw stem
## sa "https://www.youtube.com/watch?v=938fQ1GND7s" --language nl # 2025-08-20 -    15:31 - Moestuin? Gelekt politie-document toont 'verdachte' complotdenkers
## sa "https://www.youtube.com/watch?v=2v4bZII16qs" --language nl # 2025-08-19 -    58:16 - "Nederland moet Zwitsers referendumdemocratie-model volgen". Ab Gietelink spreekt met Cees Hamelink.
## sa "https://www.youtube.com/watch?v=r7NV1liDXrc" --language nl # 2025-08-19 -    29:55 - Vraagtekens bij nieuwe informatie rond opgepakte advocaat Arno van Kessel
## sa "https://www.youtube.com/watch?v=MOPKHbB4ak0" --language nl # 2025-08-19 -    24:53 - ‘Krim opgeven en geen NAVO’: accepteert Oekraïne de deal van Trump en Poetin?
## sa "https://www.youtube.com/watch?v=--XE1Iuyexk" --language nl # 2025-08-18 -    28:32 - Van Haga (BVNL): ‘Nederland en Europa buiten spel bij Trump/Poetin onderhandelingen’
## sa "https://www.youtube.com/watch?v=siRNmQ7pjb4" --language nl # 2025-08-17 -  1:35:40 - Soul Session met Ab Gietelink: “Ouders die hun kinderen begraven, dat is oorlog.”
## sa "https://www.youtube.com/watch?v=2_VAhchMUYU" --language nl # 2025-08-16 -    21:56 - Trump & Poetin ontmoeten elkaar in Alaska
## sa "https://www.youtube.com/watch?v=KguBGXYudQg" --language nl # 2025-08-16 -    18:59 - Hoe de wereld eruit kan zien na een Trump/Poetin-deal: vrede of Koude Oorlog?
## sa "https://www.youtube.com/watch?v=JUjc3Th6QE8" --language nl # 2025-08-15 -    18:15 - Einde open internet door 'Online Safety Act' in Verenigd Koninkrijk
## sa "https://www.youtube.com/watch?v=e7n0OeB2T5o" --language nl # 2025-08-15 -  1:00:32 - DeepDive: Lareb, RIVM & Dodelijk Systeemfalen met George van Houts en Leon Kuunders - Deel 3
## sa "https://www.youtube.com/watch?v=rQDbD-1S6lI" --language nl # 2025-08-14 -    23:10 - Zelensky en EU buitenspel bij Trumps vredesgesprek met Poetin: ‘EU is toeschouwer!’
## sa "https://www.youtube.com/watch?v=ztimyYvypGE" --language nl # 2025-08-14 -    19:51 - De 'nederlaag' van von der Leyen in 'the biggest deal ever' met Trump
## 
## echo press enter
## read aaa 
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Pim Fortuyn" \' >> add_fix.txt
## echo '	--tags="PateoMedia"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=1dmMkDedY_4" --language nl
## 
## echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="911" \' >> add_fix.txt
## echo '	--tags="PateoMedia"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=Xo4BWWTmJX4" --language nl
## 
## rm BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="lighthousetv" \' >> add_fix.txt
## echo '	--tags="lighthouse-tv"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=9bMmqEH8xp0" --language nl # 2025-08-12 -  1:21:08 - Nieuwsreflectie: Oekraïne, Gaza, NAVO en 29 Okt. Ab Gietelink in gesprek met Prof. Kees vd Pijl
## sa "https://www.youtube.com/watch?v=cMesX-2uJvE" --language nl # 2025-08-11 -    34:44 - Klinisch ethicus dr. Erwin Kompanje, vijf jaar geleden
## 
## echo press enter
## read aaa 
## 
## sa "https://www.youtube.com/watch?v=5pYmx1KQIu4" --language nl # 2025-08-10 -  1:19:04 - Soul Session met Frank van de Goot: "Er zijn rustige lichamen en onrustige lichamen"
## sa "https://www.youtube.com/watch?v=3mNb4XqOWp0" --language nl # 2025-08-08 -    53:37 - DeepDive: Lareb, RIVM & Dodelijk Systeemfalen met George van Houts en Leon Kuunders - Deel 2
## sa "https://www.youtube.com/watch?v=Ahyfp9D9OBA" --language nl # 2025-08-08 -    19:41 - Anja Brokken, 5 jaar later
## sa "https://www.youtube.com/watch?v=jZVtRwHK01g" --language nl # 2025-08-06 -    19:52 - Anja Brokken, vijf jaar geleden
## sa "https://www.youtube.com/watch?v=4G3mG0GQEMk" --language nl # 2025-08-05 -  1:26:25 - Russian Ambassador: "Russia is liberating the 4 regions" | Interview by Ab Gietelink
## sa "https://www.youtube.com/watch?v=zHwctu23o3I" --language nl # 2025-08-04 -    55:19 - Coen Vermeeren: 'De Chemtrailagenda', #4
## sa "https://www.youtube.com/watch?v=qVtwaY1lkP4" --language nl # 2025-08-03 -  1:33:23 - Soul Session met Paul Cliteur: "De overheid bestraft mensen die iets aan de orde stellen"
## sa "https://www.youtube.com/watch?v=hRla9Z5Ehkw" --language nl # 2025-08-01 -    26:57 - Wendy Kroeze,  Het Bloemenmeisje, vijf jaar later
## sa "https://www.youtube.com/watch?v=wm_hJ23slzY" --language nl # 2025-08-01 -  1:02:26 - DeepDive: Lareb, RIVM & Dodelijk Systeemfalen met George van Houts en Leon Kuunders
## sa "https://www.youtube.com/watch?v=NppChX2Wh3U" --language nl # 2025-07-30 -    20:40 - Wendy Kroeze, alias 'Het Bloemenmeisje', 5 jaar geleden
## sa "https://www.youtube.com/watch?v=h2TkUV1L_6w" --language nl # 2025-07-30 -    18:00 - Willem Engel: "de overheid is een superorganisme dat steeds meer bezit en invloed wil in ons leven."
## sa "https://www.youtube.com/watch?v=KtfTyTKTqTk" --language nl # 2025-07-29 -    17:03 - Eddie Tjon Fo reflecteert op het leven van Michel Reijinga: "een onverzettelijke strijder"
## sa "https://www.youtube.com/watch?v=z023sEM4yh4" --language nl # 2025-07-28 -    45:26 - Coen Vermeeren: 'Elites & Valse Goden', #3
## sa "https://www.youtube.com/watch?v=gBCDGPVTmmA" --language nl # 2025-07-28 -    17:51 - Imker Gerard van de Braak: "het staat niet op de goedgekeurde lijst, dus ik mag het niet zeggen.”
## sa "https://www.youtube.com/watch?v=AVjzl90yWOQ" --language nl # 2025-07-27 -    23:55 - Marcel Crok over klimaat lawfare: "Het gerechtshof spreekt nu het eigen IPCC rapport tegen"
## sa "https://www.youtube.com/watch?v=26cuIyNBXWk" --language nl # 2025-07-27 -  1:34:32 - Soul Session met Maurice de Hond: "wie bang is, krijgt ook klappen"
## sa "https://www.youtube.com/watch?v=Kje3T9qOGQA" --language nl # 2025-07-25 -    25:06 - Kees Faasse 5 jaar later
## sa "https://www.youtube.com/watch?v=FXxlM1WLpXw" --language nl # 2025-07-25 -  1:35:35 - blckbx Today: Gezondheidclaims Honing / Politiek Post-Corona / Klimaat Lawfare / Hoop en Wanhoop
## sa "https://www.youtube.com/watch?v=yh2bD3gAAa4" --language nl # 2025-07-23 -    34:23 - Kees Faasse, het eerste corona-interview in 2020
## sa "https://www.youtube.com/watch?v=JVZKPeI3xLs" --language nl # 2025-07-23 -    17:01 - Hoe schoon is ons drinkwater? Karel Thieme test het water live in de blckbx studio.
## sa "https://www.youtube.com/watch?v=O5dOV0Nlwiw" --language nl # 2025-07-23 -     1:10 - Nieuw bij blckbx: Soul Session met psycholoog Huibrecht Boluijt – vanaf 27 juli 20:00
## sa "https://www.youtube.com/watch?v=44RB-WVAqrE" --language nl # 2025-07-22 -    18:19 - Iris de Boer vreest dat ze door vaccinatieschade nooit meer de oude zal worden.
## sa "https://www.youtube.com/watch?v=4oz7xIq-x4Q" --language nl # 2025-07-21 -    54:11 - Coen Vermeeren: 'Ufo's bestaan gewoon', #2
## sa "https://www.youtube.com/watch?v=__fQkWx5lkQ" --language nl # 2025-07-21 -    18:47 - Antoon Huigens over de arrestatie van Arno van Kessel: "Het lijkt op een kanon op een mug"
## sa "https://www.youtube.com/watch?v=XTRoqOmck-8" --language nl # 2025-07-20 -    12:39 - 300.000 ADHD-medicaties: Jaimie Peeters onthult wat er echt achter de klachten zit
## sa "https://www.youtube.com/watch?v=P8tUYmxnLO8" --language nl # 2025-07-18 -  1:18:40 - blckbx Today #396: De ADHD-mythe / Vaccinatieschade / Zaak Arno van Kessel / Drinkwater veilig?
## sa "https://www.youtube.com/watch?v=0A5zE5EYGt0" --language nl # 2025-07-18 -  1:05:20 - Documentaire 'The Agenda' - Deel 2 (Nederlands ondertiteld)
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Elon Musk" \' >> add_fix.txt
## echo '	--tags="Joe Rogan"' >> add_fix.txt
## 
## echo BURN_VIDEO2.TXT > BURN_VIDEO2.TXT
## 
## sa "https://x.com/elonmusk/status/1996859010650398918?s=20" --language en 

rm BURN_VIDEO2.TXT

echo " \\" > add_fix.txt
echo '	--tags="lighthousetv" \' >> add_fix.txt
echo '	--tags="lighthouse-tv"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=s_Dc0ZNCrTk" --language nl # 2025-07-16 -    53:08 - Documentaire 'The Agenda' - Deel 1  (Nederlands ondertiteld)
## sa "https://www.youtube.com/watch?v=ZE_MauT7t0Q" --language nl # 2025-07-16 -    15:03 - BRICS-top Rio: Dollar onder druk, nieuwe wereldorde?
## sa "https://www.youtube.com/watch?v=HKufNwYi6v0" --language nl # 2025-07-15 -    16:56 - Geopolitieke Chaos in 2025: Oorlog, Macht en Propaganda Ontrafeld
## sa "https://www.youtube.com/watch?v=zNhSvjRXo8c" --language nl # 2025-07-14 -    59:11 - Coen Vermeeren: 'Het TU Delft- & 9/11-dossier', #1
## sa "https://www.youtube.com/watch?v=4kp2HDN6_u0" --language nl # 2025-07-14 -    15:41 - Ab Gietelink over de vaccindeal: "Die transparantie hoort er te zijn"
## sa "https://www.youtube.com/watch?v=PAnX8CuR0RE" --language nl # 2025-07-13 -    25:18 - Waarom alternatieve media zijn begonnen naast MSM
## sa "https://www.youtube.com/watch?v=DAtF6-Fr9vc" --language nl # 2025-07-13 -    17:21 - Ido Dijkstra duidt arrestatie advocaat Arno van Kessel in zaak tegen Bill Gates, Rutte & de Staat!
## sa "https://www.youtube.com/watch?v=y6YL2b2DOg0" --language nl # 2025-07-13 -    15:32 - Wat staat ons te doen als je de agenda's doorziet?
## sa "https://www.youtube.com/watch?v=OAUw9AvNH8E" --language nl # 2025-07-12 -    22:49 - DPG vergroot 'mediamonopolie' na overname RTL: vrije pers verder onder druk?
## sa "https://www.youtube.com/watch?v=2NjYeN5y8aQ" --language nl # 2025-07-11 -    36:27 - Thierry Baudet presenteert plan voor een succesvolle Nexit
## sa "https://www.youtube.com/watch?v=r53TTFbreqU" --language nl # 2025-07-11 -  1:21:54 - blckbx today #395: Arrestatie Arno van Kessel / Vaccindeal Ursula von der Leyen / BRICS vs. dollar
## sa "https://www.youtube.com/watch?v=XBg9KskDL7I" --language nl # 2025-07-10 -    21:05 - Verslag van de rechtszaak in Leeuwarden tegen Bill Gates, Rutte, Koopmans en andere hoofdrolspelers
## sa "https://www.youtube.com/watch?v=q5bdH5iP9Jo" --language nl # 2025-07-10 -    19:12 - Demissionair kabinet ‘draait visserij de nek om’
## sa "https://www.youtube.com/watch?v=RbP6H0H3rEU" --language nl # 2025-07-09 -    21:42 - Waarom Iran bij de BRICS Amerika grote zorgen baart
## sa "https://www.youtube.com/watch?v=0lr7_T1P1t4" --language nl # 2025-07-09 -    10:17 - Verlies van grip: Nederland en de nationale politiek in crisis
## sa "https://www.youtube.com/watch?v=Miw1UN-OCLg" --language nl # 2025-07-08 -    26:20 - BRICS-top rekent af met Westerse ‘Golden Billion’ en bouwt nieuwe veiligheidsorde
## sa "https://www.youtube.com/watch?v=PSZCwnMCNWY" --language nl # 2025-07-08 -    16:36 - Systemisch werk en preventieve zorg: Marjan Meddens verbindt lichaam en geest
## sa "https://www.youtube.com/watch?v=G-Zj7w9-vrU" --language nl # 2025-07-08 -    14:45 - Hoe Europa zichzelf buiten spel zet
## sa "https://www.youtube.com/watch?v=KGk9kccnJKE" --language nl # 2025-07-07 -    16:17 - De Begrenzers: vrijheid herwinnen, systemen aanpakken
## sa "https://www.youtube.com/watch?v=Pk5SKs9g9WA" --language nl # 2025-07-06 -    20:34 - Hoe ontsnap je uit ‘de financiële piramide van de elite?’
## sa "https://www.youtube.com/watch?v=tYpOLAv2fQ8" --language nl # 2025-07-06 -    11:35 - Trump's tarieven dreigen Europa te ontwrichten: handelsbalans in crisismodus!
## sa "https://www.youtube.com/watch?v=DxJ11oPOheM" --language nl # 2025-07-05 -    22:02 - FBI ontdekt grootste medische fraude ooit in VS: 15 miljard aan valse zorgclaims
## sa "https://www.youtube.com/watch?v=KIdajkqgDdI" --language nl # 2025-07-05 -    16:25 - Trumps AI-plan geblokkeerd! Hoeveel controle willen wij op AI?
## sa "https://www.youtube.com/watch?v=DazYN0YfA2M" --language nl # 2025-07-04 -    21:11 - Hoe democratisch is een toekomst met Artificiële Intelligentie?
## sa "https://www.youtube.com/watch?v=Dd6FzgeOoc4" --language nl # 2025-07-04 -    16:05 - Ambtenaren willen hypotheekrenteaftrek schrappen - huizenmarkt op kantelpunt?

## sa "https://www.youtube.com/watch?v=L1rHmN_PMuE" --language nl # 2025-07-04 -  1:20:51 - blckbx today #394: De Begrenzers | Importheffingen | Grip op Politiek? | Gezondheid in verbinding
## sa "https://www.youtube.com/watch?v=A9-be6ACdYA" --language nl # 2025-07-03 -    28:28 - Defensie onteigent: boeren raken land, bedrijf en huis kwijt
## sa "https://www.youtube.com/watch?v=yRvlDIOYdBI" --language nl # 2025-07-03 -    22:05 - Herinvoering dienstplicht voor onder andere asielzoekers?

## sa "https://www.youtube.com/watch?v=iM1pKAtIkY8" --language nl # 2025-07-03 -    21:06 - "Daar kunnen wij veel van leren" zegt Marie-Thérèse ter Haar over de Oost-Europa's identiteit
## sa "https://www.youtube.com/watch?v=SPf0WyJ7L1Q" --language nl # 2025-07-03 -    15:56 - "We hebben ze alleen maar wapens verschaft" bekritiseert Ab Gietelink de NAVO
## sa "https://www.youtube.com/watch?v=pnZLlmT4Zug" --language nl # 2025-07-02 -  2:55:44 - DeepDive met Ancilla van de Leest: het ongefilterde verhaal van Jorn Luka

## sa "https://www.youtube.com/watch?v=n9QFGOHCZMY" --language nl # 2025-07-02 -    22:19 - NAVO-top: historisch of een zwarte bladzijde in de Europese geschiedenis?
## sa "https://www.youtube.com/watch?v=kKFRG_rgwUY" --language nl # 2025-07-02 -    19:14 - AZC in Haarlem? Buurtbewoners sterk verdeeld over plannen
## sa "https://www.youtube.com/watch?v=IMUOME_LHvE" --language nl # 2025-07-01 -    25:30 - Prof. Schippers en 36 wetenschappers publiceren vernietigend onderzoek naar coronabeleid
## sa "https://www.youtube.com/watch?v=erMQQh1q8QE" --language nl # 2025-07-01 -    19:49 - Parkeren op je eigen oprit op de tocht
## sa "https://www.youtube.com/watch?v=knTyrFZ8-1s" --language nl # 2025-07-01 -    13:26 - 'Ze kunnen de pleuris krijgen!' - AZC-demo in Haarlem zet demonstranten lijnrecht tegenover elkaar
## sa "https://www.youtube.com/watch?v=BYJbvnNGLiw" --language nl # 2025-06-29 -    18:59 - Zelensky en Ursula von der Leyens "full-scale war"
## sa "https://www.youtube.com/watch?v=lMsIRnCJw20" --language nl # 2025-06-28 -    25:40 - Wat doodt onze bijen? 5G, pesticiden en andere factoren onder de loep
## sa "https://www.youtube.com/watch?v=gHGTmsZFciU" --language nl # 2025-06-28 -    23:42 - Wat als Nederland de NAVO verlaat? Een alternatief plan
## sa "https://www.youtube.com/watch?v=nEctK-HBf68" --language nl # 2025-06-27 -    22:25 - NOS weigert rectificatie na 'nepnieuws' over migratiepolitiek in Italië
## sa "https://www.youtube.com/watch?v=0JTrCCEwcJI" --language nl # 2025-06-27 -  1:27:54 - blckbx today #393: NAVO-top / Oost-Europa's identiteit / Conflict Midden-Oosten / AI & Democratie
## sa "https://www.youtube.com/watch?v=0amoV8arkUo" --language nl # 2025-06-26 -    22:08 - Plottwist na Iran-aanval: Pentagon-lek stelt dat ‘uranium grotendeels intact’ bleef - Trump ontkent

sa "https://www.youtube.com/watch?v=IpGCe81NwOM" --language nl # 2025-06-26 -    21:25 - NAVO-top ten einde: lidstaten moeten verantwoording gaan afleggen aan de NAVO over 5%-norm
sa "https://www.youtube.com/watch?v=DlbjG-AiX54" --language nl # 2025-06-25 -    23:49 - AZC De Bilt slaat in als een bom: ‘Honderden jonge mannen uit Eritrea en Syrië op komst!’
sa "https://www.youtube.com/watch?v=15wI-f6Z7bU" --language nl # 2025-06-24 -    22:10 - NAVO-top van start: overschatten we 'de Russische dreiging'?
sa "https://www.youtube.com/watch?v=-GYFqtGQ_fc" --language nl # 2025-06-24 -    18:39 - Trump slaat toe met gewaagde 'Top Gun'-operatie in Iran
sa "https://www.youtube.com/watch?v=D2aEHzuSG9c" --language nl # 2025-06-22 -    15:37 - Waarom Eerste Kamerlid Eric Kemperman brak met BBB
sa "https://www.youtube.com/watch?v=kHCaP4RLCCw" --language nl # 2025-06-21 -    20:36 - Timmermans wil Iron Dome schrappen: ‘Israëlische burgers zijn hier zelf verantwoordelijk voor’
sa "https://www.youtube.com/watch?v=UUT1LZEgKvY" --language nl # 2025-06-21 -    19:48 - Klimaatneutraal in 2050: Europese ‘Net Zero-droom’ dreigt nachtmerrie te worden
sa "https://www.youtube.com/watch?v=0wSPpJRSMxM" --language nl # 2025-06-21 -  1:26:45 - blckbx today #392: Luchtoorlog Israël-Iran / NAVO-top / Nieuwe Vredesbeweging
sa "https://www.youtube.com/watch?v=cY3XmC4ClBs" --language nl # 2025-06-20 -    24:51 - NAVO-top ‘vreest’ voor rellen na groots aangekondigde demonstraties!
sa "https://www.youtube.com/watch?v=_syUExogh8c" --language nl # 2025-06-19 -    27:31 - Valt Amerika Iran aan en breekt Trump zijn belofte?
sa "https://www.youtube.com/watch?v=_V0CO2R54ic" --language nl # 2025-06-19 -    23:29 - Nieuw wetsvoorstel geeft ruimte aan verbod op politieke partijen
sa "https://www.youtube.com/watch?v=-coLRhTBlRM" --language nl # 2025-06-18 -    23:54 - ‘Rode Lijn-protest’ met 150.000 Gaza-demonstranten roept vragen op
sa "https://www.youtube.com/watch?v=HVPHfGIVO_o" --language nl # 2025-06-17 -    29:26 - Demissionair kabinet wil 5% van de economie naar Defensie - wie draait hiervoor op?
sa "https://www.youtube.com/watch?v=5btj17R_7CY" --language nl # 2025-06-17 -    24:40 - Iran slaat terug: raketaanvallen raken Israëlische steden
sa "https://www.youtube.com/watch?v=RMDpAQz545E" --language nl # 2025-06-15 -    16:25 - Team blckbx neemt afscheid van Erwin Taams
sa "https://www.youtube.com/watch?v=adBPPp1gk_I" --language nl # 2025-06-15 -    15:51 - EU’s afhankelijkheid pijnlijk blootgelegd na grondstoffendeal VS & China
sa "https://www.youtube.com/watch?v=vf7MPF0TALg" --language nl # 2025-06-14 -     9:43 - Arno van Kessel, advocaat die tegen Rutte en Gates procedeert, zelf gearresteerd
sa "https://www.youtube.com/watch?v=G_DuS0NSDVs" --language nl # 2025-06-14 -    17:25 - Israël slaat toe in Iran: dreigt een nucleaire escalatie?
sa "https://www.youtube.com/watch?v=vWB0E-3XAJE" --language nl # 2025-06-14 -  1:43:00 - blckbx today #391: Israel valt Iran aan / De doofpotcommissie / Arrestatie soevereinen
sa "https://www.youtube.com/watch?v=KAYU_-zNo28" --language nl # 2025-06-13 -    21:07 - Preppen voor noodscenario's. Paniekzaaierij of gezonde zelfredzaamheid?
sa "https://www.youtube.com/watch?v=rWgUGmqyX-I" --language nl # 2025-06-12 -    28:00 - Wilders wéér de grootste, maar mag niet regeren — Kan ons politieke systeem nog functioneren?
sa "https://www.youtube.com/watch?v=j_C-_7gdj6Q" --language nl # 2025-06-12 -    15:53 - Koelwagens vol gesneuvelde soldaten aan de Oekraïense grens 'geweigerd' door Zelensky
sa "https://www.youtube.com/watch?v=YvmHzOSGdTE" --language nl # 2025-06-11 -    26:43 - Docu: 'De Nederlandse asielcrisis in beeld’ over extra AZC’s in Brabant
sa "https://www.youtube.com/watch?v=ZSV8ctryI2o" --language nl # 2025-06-10 -    34:44 - ‘Noodwet’ in de maak: Defensie wil uitzonderlijke bevoegdheden
sa "https://www.youtube.com/watch?v=H4JX_xS-oz8" --language nl # 2025-06-10 -    23:05 - Burgercontrole bij grens Ter Apel: actievoerder sluit nieuwe acties niet uit
sa "https://www.youtube.com/watch?v=oAR_ZnD4b30" --language nl # 2025-06-08 -    28:50 - Val kabinet luidt dramatische periode in voor Wiersma en de boeren
sa "https://www.youtube.com/watch?v=5SY-YZc4FXI" --language nl # 2025-06-07 -    20:11 - Facebook en Instagram bespioneren Android-gebruikers via achterdeur
sa "https://www.youtube.com/watch?v=TsVVyShYj-g" --language nl # 2025-06-07 -    18:23 - Ongelooflijke ruzie Musk en Trump: wat speelt er écht?
sa "https://www.youtube.com/watch?v=5a_zWcRQT-g" --language nl # 2025-06-07 -  1:05:54 - blckbx today #390: Kabinetscrisis immigratiebeleid / Huurbevriezing geschrapt / AI in Speelfilms
sa "https://www.youtube.com/watch?v=LwPkih6-hSw" --language nl # 2025-06-06 -    15:12 - Dedollarisatie, afkalvende middenklasse en ‘de grote reset’ met monetair econoom Brecht Arnaert
sa "https://www.youtube.com/watch?v=ePl3WZ2O5bo" --language nl # 2025-06-05 -    38:00 - 29 oktober verkiezingen! Hoe komt NL uit impasse na val kabinet?
sa "https://www.youtube.com/watch?v=hcO9FPWwzDQ" --language nl # 2025-06-05 -    15:04 - Wie zit er achter de drone-aanval die 'Ruslands Pearl Harbor' wordt genoemd?
sa "https://www.youtube.com/watch?v=ydb6MfVuym0" --language nl # 2025-06-04 -    19:01 - Waarom komen de nieuwe media in België zo traag op gang?
sa "https://www.youtube.com/watch?v=FLMNU1q6ZNc" --language nl # 2025-06-03 -    19:16 - Ondersterfte in Bulgarije vs oversterfte in Nederland - hoe kan dit?
sa "https://www.youtube.com/watch?v=g_ShcLs6MW8" --language nl # 2025-06-03 -    18:52 - Einde kabinet? Wilders zinspeelt op vertrek na crisisoverleg
sa "https://www.youtube.com/watch?v=OdQBVn6AC8I" --language nl # 2025-06-01 -    23:34 - Start Trump met zijn 'Golden Dome' een wapenwedloop in de ruimte?
sa "https://www.youtube.com/watch?v=uYUHWA8X5I0" --language nl # 2025-05-31 -    31:55 - Felle Russische reactie op Duitse steun bij productie Taurus-raketten voor Oekraïne
sa "https://www.youtube.com/watch?v=7PyE0eis0UY" --language nl # 2025-05-31 -    20:22 - Kennedy’s MAHA-rapport onder vuur - Spiegelbeeld Magazine over alternatieve kijk op gezondheid
sa "https://www.youtube.com/watch?v=1gUXWsBlXKk" --language nl # 2025-05-31 -  1:07:04 - blckbx Today Interview: de achtergronden van de Gaza-oorlog met Jaap Hamburger (EAJG)
sa "https://www.youtube.com/watch?v=dIZe8Q-odQ8" --language nl # 2025-05-30 -    17:39 - Non Dualisme redde het leven van Patrick Kicken.
sa "https://www.youtube.com/watch?v=U0qEBOmzq3M" --language nl # 2025-05-29 -    24:14 - Waarom Gideon van Meijeren uit de parlementaire enquêtecommissie corona stapte
sa "https://www.youtube.com/watch?v=w4Ee80RFgg8" --language nl # 2025-05-29 -    21:45 - Mini docu: "Kill the Boer”. Genocide – ja of nee?
sa "https://www.youtube.com/watch?v=bexJ4jp76Uo" --language nl # 2025-05-29 -    14:41 - Waarom de NOS en MSM het geweld op blanke boeren in Zuid-Afrika verzwijgen
sa "https://www.youtube.com/watch?v=w4o6iSs4hhE" --language nl # 2025-05-29 -    13:59 - Opvallende wending Roemeense verkiezingen.
sa "https://www.youtube.com/watch?v=bRZk2JMhFCk" --language nl # 2025-05-29 -    13:14 - Hoe objectief is het Klimaatexamen? Journaliste Danielle van Wallinga deed onderzoek
sa "https://www.youtube.com/watch?v=2FLwH1C8q00" --language nl # 2025-05-28 -    24:34 - 140 uur taakstraf. Mogelijk eerste politieke veroordeling in relatie tot coronamaatregelen
sa "https://www.youtube.com/watch?v=n6qEOR2FRM0" --language nl # 2025-05-28 -    15:42 - Mees Wijnants over Kajsa Ollongren, netwerkcorruptie en de nieuwe generatie
sa "https://www.youtube.com/watch?v=f79tP_2cAGY" --language nl # 2025-05-27 -    21:20 - Raad van State torpedeert ‘stikstofdoorbraak’ kabinet: FVD komt met meetbaar alternatief
sa "https://www.youtube.com/watch?v=Zrc9N4htYQI" --language nl # 2025-05-27 -    20:36 - Defensie onthult 57 locaties voor uitbreiding van de krijgsmacht in Nederland
sa "https://www.youtube.com/watch?v=u129-D5sjZI" --language nl # 2025-05-26 -    21:34 - Minister Wiersma negeert Woo-verzoek voor privacy van boeren
sa "https://www.youtube.com/watch?v=mtS7R8KtWzM" --language nl # 2025-05-25 -    19:30 - 16 miljard euro ‘verdwenen’ bij Buitenlandse Zaken – Verantwoordingsdag 2025
sa "https://www.youtube.com/watch?v=cDKWxnUTXRo" --language nl # 2025-05-25 -    13:27 - Ontmaskerd: EU's propagandaoorlog van 650 miljoen tegen de vrijheid van meningsuiting
sa "https://www.youtube.com/watch?v=VlNtoB_czhM" --language nl # 2025-05-24 -  1:22:51 - blckbx today #389: Doorbraak Coronabeleid? / Roemeense verkiezingen / Leven zonder Stress
sa "https://www.youtube.com/watch?v=4i5rMx5ozoA" --language nl # 2025-05-23 -    21:21 - Politie negeert Woo én rechterlijk bevel in openbaren van geheime burgerdata
sa "https://www.youtube.com/watch?v=Q8LzRQflyQo" --language nl # 2025-05-23 -  1:03:52 - LightHouseTV #9: Censuuroorlog EU | Wiersma vs Woo privégegevens boeren | 'Miljardenzwendel' kabinet
sa "https://www.youtube.com/watch?v=QaM_1JvDWl0" --language nl # 2025-05-22 -    20:27 - Wat verandert het EU-besluit nu voor de Nederlandse wolf?
sa "https://www.youtube.com/watch?v=vh_VL2AkGwg" --language nl # 2025-05-22 -    17:28 - WHO akkoord over pandemieverdrag: wat zijn de gevolgen?
sa "https://www.youtube.com/watch?v=8YF3GzB4P_c" --language nl # 2025-05-21 -    24:30 - Dreigt er na 2030 een watertekort in Nederland en wat is er nodig?
sa "https://www.youtube.com/watch?v=zSRpdpOtdwg" --language nl # 2025-05-21 -  1:10:36 - LightHouseTV #8: Pandemieverdrag akkoord | Politie negeert Woo | Einde wolfbescherming?
sa "https://www.youtube.com/watch?v=yTO5rSYsCnE" --language nl # 2025-05-20 -    24:18 - Nederland op weg naar een black-out door energietransitie?
sa "https://www.youtube.com/watch?v=vEY9aqFBRaA" --language nl # 2025-05-20 -    21:55 - Pandemieverdrag bij WHO-vergadering in Genève: Wat staat Nederland te wachten?
sa "https://www.youtube.com/watch?v=q4EwGVovSg4" --language nl # 2025-05-18 -    20:32 - Rutte noemt Poetins 'no show' bij het vredesoverleg een grote fout: "He is in trouble"
sa "https://www.youtube.com/watch?v=z4ET8VvQJB0" --language nl # 2025-05-17 -    19:45 - Inspectiedienst tikt politie op de vingers over intimiderend huisbezoek
sa "https://www.youtube.com/watch?v=HVgrjhxusOQ" --language nl # 2025-05-17 -    14:06 - BVNL wint van overheid in rechtszaak en clasht met minister Agema over pandemieverdrag!
sa "https://www.youtube.com/watch?v=7FB4QC4uFl8" --language nl # 2025-05-17 -  1:31:26 - blckbx today #388: Vredesonderhandelingen / Einde Tegenlicht / Democratie vraagt om actie
sa "https://www.youtube.com/watch?v=V40pJ0dxuK4" --language nl # 2025-05-16 -    18:11 - Robin van Beek over NLP: Grip op jezelf in de waanzin van deze wereld
sa "https://www.youtube.com/watch?v=U-1K9VkKZb4" --language nl # 2025-05-16 -    16:27 - Pensioenwet: Hoe Nederland de controle over 1500 miljard pensioengeld dreigt te verliezen
sa "https://www.youtube.com/watch?v=yebLFZPw0D4" --language nl # 2025-05-15 -    27:23 - Kees van der Pijl over 5 mei protesten
sa "https://www.youtube.com/watch?v=S3I4W0im_j4" --language nl # 2025-05-15 -    16:10 - Welke deal van 600 miljard dollar sloot Trump met Saoedi-Arabië?
sa "https://www.youtube.com/watch?v=49Gxpa6K4mo" --language nl # 2025-05-15 -    13:51 - Zzp'ers klagen opdrachtgevers aan voor schijnzelfstandigheid, opdrachtgevers betalen tienduizenden
sa "https://www.youtube.com/watch?v=i0UphLVUBYo" --language nl # 2025-05-14 -    17:46 - Huisarts onthult hoe Nederlanders vertrouwen kwijtraken in de medische wetenschap
sa "https://www.youtube.com/watch?v=gMVcq9sr1sg" --language nl # 2025-05-13 -    26:50 - Oversterfte-onderzoek Meester vraagt om antwoorden - waarom blijft actie uit?
sa "https://www.youtube.com/watch?v=JiRiGi99PHU" --language nl # 2025-05-13 -    21:16 - Duizenden missende doodsoorzaakverklaringen per jaar — CBS registratie faalt
sa "https://www.youtube.com/watch?v=Ro2yWSZCziA" --language nl # 2025-05-12 -    26:56 - Ab Gietelink over 100 dagen Trump
sa "https://www.youtube.com/watch?v=XdrXtqy2PSg" --language nl # 2025-05-11 -    20:45 - Coronaherstelfonds van 800 miljard gefileerd door Europese Rekenkamer
sa "https://www.youtube.com/watch?v=8iEAuyy4XJY" --language nl # 2025-05-10 -    28:00 - ECB versnelt uitrol CBDC – Wat zit er achter deze haast?
sa "https://www.youtube.com/watch?v=KmL1SZtXdzI" --language nl # 2025-05-10 -  1:46:02 - blckbx today #387: 100 dagen Trump / Spanning Bevrijdingsdag / NLP
sa "https://www.youtube.com/watch?v=S4SQ48AXf8M" --language nl # 2025-05-10 -    13:17 - Cultureel erfgoed in gevaar na nieuwe plannen voor Zaanse Schans
sa "https://www.youtube.com/watch?v=DHi9xYHt5BI" --language nl # 2025-05-08 -    17:20 - Van Blackrock naar Duitse bondskanselier: Friedrich Merz
sa "https://www.youtube.com/watch?v=TEXJQA9EIXU" --language nl # 2025-05-08 -    16:15 - Stikstofultimatum en dreigende rechtszaken voor Minister Wiersma als koers niet verandert
sa "https://www.youtube.com/watch?v=-NxrJe2LgK0" --language nl # 2025-05-08 -    15:48 - RIVM adviseert geen particuliere eieren meer te eten. Wijs advies of nieuwe angstcampagne?
sa "https://www.youtube.com/watch?v=nC6HDcSfcCQ" --language nl # 2025-05-07 -    14:26 - Reform UK van Nigel Farage - de man achter Brexit - wint opnieuw in Verenigd Koninkrijk
sa "https://www.youtube.com/watch?v=zXNjo0qZkt8" --language nl # 2025-05-06 -    13:07 - Het economische spel achter Trumps invoerheffingen
sa "https://www.youtube.com/watch?v=_X3b7xFvkug" --language nl # 2025-05-06 -    12:34 - Zijn Bevrijdingsdag en dodenherdenking te verenigen met oorlogen van ons kabinet?
sa "https://www.youtube.com/watch?v=ScaVOR2sY4g" --language nl # 2025-05-03 -  1:29:52 - blckbx today #386: Stroomstoring Spanje / Protest NAVO-top / Mei Social Vrij
sa "https://www.youtube.com/watch?v=wXg7jgQ2phY" --language nl # 2025-05-02 -     1:01 - We Zijn er (Bijna) Klaar Voor!
sa "https://www.youtube.com/watch?v=wKtgzOMP5Nc" --language nl # 2025-04-30 -    21:48 - Nederlandse staat veroordeeld voor het schenden van mensenrechten.
sa "https://www.youtube.com/watch?v=PDweDzpynbA" --language nl # 2025-04-28 -    17:20 - Vredesonderhandelingen Rusland-Oekraïne bereiken cruciaal punt
sa "https://www.youtube.com/watch?v=7vqSXyo0J8c" --language nl # 2025-04-26 -  1:06:26 - blckbx today #385: Vredesonderhandeling / Uitspraak Europees Hof uithuisplaatsing / Burn-out genezen
sa "https://www.youtube.com/watch?v=6M3S_gVvyOw" --language nl # 2025-04-25 -     4:14 - Crowdfund uitgelegd: dit doet LightHouseTV met je donaties
sa "https://www.youtube.com/watch?v=iX60_ewZ5CA" --language nl # 2025-04-19 -  1:44:16 - Blckbx Today - de verzoening,  het bestuur aan het woord
sa "https://www.youtube.com/watch?v=J3zia_lMLT0" --language nl # 2025-04-18 -     3:06 - Dít is LightHouseTV- Steun onze lancering op 5 mei!
sa "https://www.youtube.com/watch?v=XQAzfI7kQ-0" --language nl # 2025-04-17 -    20:09 - Flavio Pasquino lanceert LightHouseTV op MVO2025 en zoekt ondernemers met LEF!
sa "https://www.youtube.com/watch?v=wvh1LK3jOIg" --language nl # 2025-04-16 -     1:26 - Steun LightHouseTV en bouw mee!
sa "https://www.youtube.com/watch?v=W_LL91ShnJs" --language nl # 2025-04-11 -     4:25 - Blckbx, de verzoening. Want de missie moet door!
sa "https://www.youtube.com/watch?v=QXhHAlHvuw0" --language nl # 2025-04-02 -     6:54 - Afscheid Flavio Pasquino van Blckbx
sa "https://www.youtube.com/watch?v=GNVonFqmcU4" --language nl # 2025-04-02 -    15:10 - Groenland en Denemarken verzetten zich tegen inlijving door V.S.
sa "https://www.youtube.com/watch?v=SuXvp4oU7-Q" --language nl # 2025-04-01 -    22:37 - Steeds meer boeren krijgen spijt van uitkoop
sa "https://www.youtube.com/watch?v=BTQcSnQ3Xp8" --language nl # 2025-04-01 -    17:15 - 100 miljard ABP-pensioengeld naar EU-defensie?! Hoe Buitenhof misinformatie verspreidde
sa "https://www.youtube.com/watch?v=pGqejEM_ZuA" --language nl # 2025-03-30 -    23:16 - Ministerie reageert op virale ‘box-3-analyse’ voor woonhuisbezitters Pim van Rijswijk
sa "https://www.youtube.com/watch?v=9nKIdBu8fpA" --language nl # 2025-03-30 -    16:46 - Einde rechtbankverslaggeving door onafhankelijke journalisten?
sa "https://www.youtube.com/watch?v=_ftxi2L-LJs" --language nl # 2025-03-29 -    26:07 - Felle discussie over verbod op Russische media na verloren RT-rechtszaak
sa "https://www.youtube.com/watch?v=NM5xJyqqBxk" --language nl # 2025-03-29 -    13:14 - WOO-onthulling: bol vroeg RIVM welke ‘complotboeken’ label moesten krijgen tijdens COVID
sa "https://www.youtube.com/watch?v=HX4xS60tL0U" --language nl # 2025-03-28 -    22:04 - De onthulling van de piramide van Gizeh
sa "https://www.youtube.com/watch?v=LT1YHEGidJM" --language nl # 2025-03-28 -  1:35:51 - Rutte over toekomst Poetin | Belasten overwaarde ontkracht? | RT-zaak verloren | DWIV #43
sa "https://www.youtube.com/watch?v=dNnArtlgnvk" --language nl # 2025-03-27 -    18:32 - ‘Pro-EU’-onderzoek rammelt aan alle kanten – maar media en politici verkopen het als waarheid
sa "https://www.youtube.com/watch?v=j0wgdoDdmBo" --language nl # 2025-03-27 -    14:54 - De toekomst van de wolf in Nederland
sa "https://www.youtube.com/watch?v=yvHJInJiZ4k" --language nl # 2025-03-26 -    17:57 - Waar legt Den Haag de rekening van de energietransitie neer?
sa "https://www.youtube.com/watch?v=98v5C-SdtBk" --language nl # 2025-03-25 -    26:46 - Massale slachtpartijen in Syrië onder HTS-regime
sa "https://www.youtube.com/watch?v=knSn-MdCtRw" --language nl # 2025-03-25 -    23:55 - Aachboun ‘uitgenodigd’ door NAVO na juridische doorbraak tegen Rutte: ‘NAVO beïnvloedde justitie!’
sa "https://www.youtube.com/watch?v=7JYubPysbgI" --language nl # 2025-03-23 -    19:11 - Nieuwe film ‘persona non grata’ toont de demonisering van David Icke + WINACTIE
sa "https://www.youtube.com/watch?v=21evIIv4VZo" --language nl # 2025-03-22 -    17:23 - Waarom Oekraïners en Russen totaal verdeeld zijn over Trump en ‘ReArm Europe’
sa "https://www.youtube.com/watch?v=9OY_zVD-3e8" --language nl # 2025-03-22 -    14:35 - Raad van State beboet alsnog vier artsen voor
sa "https://www.youtube.com/watch?v=YDf36NYlQNo" --language nl # 2025-03-21 -    15:51 - BVNL vs. Rijksoverheid: Waarom houdt de overheid de ‘geheime’ brief aan de WHO achter?
sa "https://www.youtube.com/watch?v=U50lqCGf5a4" --language nl # 2025-03-21 -  1:13:30 - HCQ-rechtszaak verloren! | Rusland, Oekraïne en ReArm Europe | David Icke documentaire | DWIV #42
sa "https://www.youtube.com/watch?v=NTWn5I0FiQI" --language nl # 2025-03-20 -    21:00 - Koophuis verhuist mogelijk van box 1 naar box 3
sa "https://www.youtube.com/watch?v=BN_sWYJJjt8" --language nl # 2025-03-20 -    18:44 - Wat bespraken Poetin en Trump tijdens hun laatste telefoongesprek over Oekraïne?
sa "https://www.youtube.com/watch?v=QpBwY4YdFU0" --language nl # 2025-03-19 -    15:24 - Hoe bang zijn we voor de Russen? - peiling Maurice de Hond
sa "https://www.youtube.com/watch?v=UTC0ufGgM3A" --language nl # 2025-03-18 -    22:05 - Geheime diensten gingen altijd uit van COVID lab-lek, maar verzwegen het
sa "https://www.youtube.com/watch?v=0kUsXLaNko8" --language nl # 2025-03-18 -    14:27 - Parkeerbeleid Nederlandse steden geeft winkeliers kopzorgen
sa "https://www.youtube.com/watch?v=2XYzvpLQa8s" --language nl # 2025-03-16 -    14:07 - Frank Hoogerbeets voorspelt aardbevingen via planeetinvloeden
sa "https://www.youtube.com/watch?v=3biGrp9P0Xw" --language nl # 2025-03-15 -    15:26 - Trump en Rutte in gesprek: waarom de toekomst van Oekraïne minder zeker is dan je denkt
sa "https://www.youtube.com/watch?v=O52cwmrq43Q" --language nl # 2025-03-15 -    12:57 - Nieuw algoritme toont de onhoudbaarheid van overheidsbeleid aan
sa "https://www.youtube.com/watch?v=wkF6s1FB280" --language nl # 2025-03-14 -    58:44 - Schoof negeert motie | Rutte bij Trump over Oekraïne | Doorbraak aardbevingen voorspellen | DWIV #41
sa "https://www.youtube.com/watch?v=m9WLAqxiOB4" --language nl # 2025-03-14 -    22:09 - Blokkeert Nederland de financiering van ReArm Europe?
sa "https://www.youtube.com/watch?v=sI7Q6ELJA_0" --language nl # 2025-03-13 -    19:40 - “Kippenvaccin” zorgt voor ophef: hoe veilig is deze pilot écht?
sa "https://www.youtube.com/watch?v=TJhl-u07EIU" --language nl # 2025-03-13 -    15:55 - Zelensky terug op de weg naar een vredesdeal via bestand
sa "https://www.youtube.com/watch?v=OREEAODK13Y" --language nl # 2025-03-12 -    19:43 - Deadline ECB voor Digitale Euro (CBDC): oktober 2025
sa "https://www.youtube.com/watch?v=rsUo3ZUIXAU" --language nl # 2025-03-11 -    19:00 - Brussel trekt portemonnee voor oorlog, maar zwijgt over Eurobonds
sa "https://www.youtube.com/watch?v=Jf0h6ncO_1o" --language nl # 2025-03-11 -    18:34 - Rellen na uitsluiting Roemeens presidentskandidaat Georgescu
sa "https://www.youtube.com/watch?v=iGk47Q3CQuA" --language nl # 2025-03-08 -    26:45 - Jakob de Jonge over de Europese "oorlogshysterie" en "het verval van het Westen"
sa "https://www.youtube.com/watch?v=KeE6gJri4iA" --language nl # 2025-03-08 -    24:47 - Wie was verantwoordelijk voor de goedkeuring van de coronavaccins?
sa "https://www.youtube.com/watch?v=SsfsIsxkBk0" --language nl # 2025-03-07 -    20:42 - Tegen welke prijs wordt de menselijke evolutie naar eigen hand gezet?
sa "https://www.youtube.com/watch?v=Y8ol8qXRGdo" --language nl # 2025-03-07 -    14:50 - Komt er een Europees leger?
sa "https://www.youtube.com/watch?v=wm_ECyv_gsE" --language nl # 2025-03-07 -  1:23:42 - Wie keurde de vaccins goed? | 'Oorlogshysterie' Westen | De ontzieling van de samenleving | DWIV #40
sa "https://www.youtube.com/watch?v=a6XfP7C2enY" --language nl # 2025-03-06 -    17:09 - De draai van Zelensky en de herbewapening van Europa
sa "https://www.youtube.com/watch?v=ejOFItZAhOA" --language nl # 2025-03-06 -    15:06 - Torenhoge supermarktprijzen moeten omlaag, maar wie betaalt de rekening?
sa "https://www.youtube.com/watch?v=mNpXYSvmWes" --language nl # 2025-03-05 -    24:55 - Europese leiders in vredes- of oorlogsbesprekingen?
sa "https://www.youtube.com/watch?v=b6erWvJuyoI" --language nl # 2025-03-04 -    22:01 - Waarom moest Zelensky vertrekken uit Het Witte Huis?
sa "https://www.youtube.com/watch?v=uLHS3gt14jA" --language nl # 2025-03-04 -    19:10 - Poetins lot na vrede met Oekraïne: wat gebeurt er met Rusland?
sa "https://www.youtube.com/watch?v=7oaTsY0_ldU" --language nl # 2025-03-02 -    12:43 - Zijn we een lui volk omdat we kampioen deeltijdwerken zijn?
sa "https://www.youtube.com/watch?v=bxKedaa-ivw" --language nl # 2025-03-01 -    18:20 - Kennedy’s eerste werkweek schudt de wereld op – Komt zijn revolutie naar Europa?
sa "https://www.youtube.com/watch?v=7nWqNN4egzc" --language nl # 2025-03-01 -    17:14 - 'Gekochte journalisten'
sa "https://www.youtube.com/watch?v=2eoZ8th62eM" --language nl # 2025-02-28 -    15:27 - CPAC ‘25: wat betekent de rechtse golf in Amerika voor Nederland?
sa "https://www.youtube.com/watch?v=d8XC5SBemuk" --language nl # 2025-02-28 -  1:05:27 - Robert F. Kennedy | ‘Gekochte Journalisten' | Parttime werken verdubbeld | DWIV #39
sa "https://www.youtube.com/watch?v=3cjZdQn9nsk" --language nl # 2025-02-27 -    19:18 - Duitse verkiezingsuitslag splijt Duitsland, maar verenigt conservatief Europa
sa "https://www.youtube.com/watch?v=gPymRpxxdeI" --language nl # 2025-02-27 -    14:58 - Wat betekent Trumps handelsoorlog voor Nederland?
sa "https://www.youtube.com/watch?v=nSlhw79_rQs" --language nl # 2025-02-26 -    21:28 - Jeffrey Sachs' genadeloze toespraak legt de vinger op de zere plek van het Westen
sa "https://www.youtube.com/watch?v=bLkT-ZrFddQ" --language nl # 2025-02-25 -    18:22 - Is het tijd voor een Dutch DOGE?
sa "https://www.youtube.com/watch?v=6c9pvRj0jZg" --language nl # 2025-02-25 -    15:59 - AfD tweede partij in Duitsland, maar waarschijnlijk buitenspel gezet
sa "https://www.youtube.com/watch?v=wdO-zLfLHx4" --language nl # 2025-02-23 -    22:19 - Hoogleraar Bob de Wit waarschuwt het onderwijs voor radicale veranderingen door AI
sa "https://www.youtube.com/watch?v=2Gu-uwIQhY8" --language nl # 2025-02-22 -    21:43 - Controversiële ON-hoofdredacteur Joost Niemöller: Jonathan vs. Mordechai Chrispijn!
sa "https://www.youtube.com/watch?v=tWZxVghiKks" --language nl # 2025-02-22 -    13:59 - VS en Rusland besluiten over Oekraïne – de EU Kijkt machteloos toe
sa "https://www.youtube.com/watch?v=tNIp4zRwRpI" --language nl # 2025-02-21 -    21:12 - Mogelijk miljarden euro’s verwaterd door falende aanbestedingsprocedure voor windmolenparken
sa "https://www.youtube.com/watch?v=bKUxtVE-H9E" --language nl # 2025-02-21 -  1:19:40 - ON over Joost Niemöller | Trump geeft EU nakijken | Onderwijs verouderd door AI? | DWIV #38
sa "https://www.youtube.com/watch?v=Rz2_Ie-L8lo" --language nl # 2025-02-20 -    26:47 - CBS registreert geen vaccinatiedoden ondanks erkenning RIVM & LAREB
sa "https://www.youtube.com/watch?v=y636dy-e0L4" --language nl # 2025-02-20 -    21:52 - Wat is er besproken op het vredesoverleg tussen Rusland en Amerika?
sa "https://www.youtube.com/watch?v=aREL0aQHzos" --language nl # 2025-02-19 -    22:52 - ZZP-wet leidt tot ontwrichting op de arbeidsmarkt
sa "https://www.youtube.com/watch?v=wNrvNsGLL98" --language nl # 2025-02-19 -  1:19:54 - blckbx today #373: Vrede zonder Zelensky? | CBS negeert vaccindoden | 10 miljard naar windpark
sa "https://www.youtube.com/watch?v=9oCkwUOhxiM" --language nl # 2025-02-18 -    26:35 - JD Vance haalt uit naar Europa en Trump koerst op vrede af
sa "https://www.youtube.com/watch?v=yBSPk--GYRQ" --language nl # 2025-02-18 -    17:57 - Milieudefensie vecht door: Klimaatzaak tegen Shell krijgt nieuwe wending
sa "https://www.youtube.com/watch?v=j6EfUrrZGS4" --language nl # 2025-02-16 -     9:46 - Rutte ontkent belofte van NAVO-lidmaatschap aan Oekraïne
sa "https://www.youtube.com/watch?v=JvL6P7hU2FY" --language nl # 2025-02-16 -    17:53 - Jij kunt iemand blij maken! Stichting The Gift geeft elke dag een gift weg – zo werkt het
sa "https://www.youtube.com/watch?v=nvVONf0JAZQ" --language nl # 2025-02-15 -     9:24 - Kaag verdeelde bijna 1 miljard euro belastinggeld onder strategische partners: ‘propaganda dus’
sa "https://www.youtube.com/watch?v=gKMl2PopeUg" --language nl # 2025-02-15 -    15:34 - Marcel van Silfhout onderzocht de EU-regels en miljardenindustrie achter insecten in ons voedsel
sa "https://www.youtube.com/watch?v=fBPrqhFRokk" --language nl # 2025-02-15 -    13:00 - Zorg-wekkende theatervoorstelling 'Delirium' toont de horror in de zorg
sa "https://www.youtube.com/watch?v=0vQgrvai1C0" --language nl # 2025-02-14 -    16:06 - Hoe de ‘Gold Run’ in Londen goudvoorraden bedreigt voor beleggers en overheden
sa "https://www.youtube.com/watch?v=4LOCa3vyR3g" --language nl # 2025-02-14 -  1:15:54 - Insecten in jouw eten | Kaag & USAID | 'Delirium' zorgmisstanden | 'The Gift' | DWIV #37
sa "https://www.youtube.com/watch?v=IE6B4NEwPq0" --language nl # 2025-02-13 -    24:00 - Tweede Kamerlid Gideon van Meijeren vernietigend over ‘beangstigend’ WTMO-wetsvoorstel
sa "https://www.youtube.com/watch?v=tGmCqSCha7A" --language nl # 2025-02-13 -    18:53 - Trump wil 500 miljard dollar aan Oekraïnse bodemschatten als onderpand
sa "https://www.youtube.com/watch?v=UWEJjRQm6B0" --language nl # 2025-02-12 -    17:24 - NSC-Kamerlid Bruyning over clash met Wilders over gevangenispersoneelstekort
sa "https://www.youtube.com/watch?v=wiTMFL4BmiA" --language nl # 2025-02-11 -    16:55 - Musk eist antwoorden: waar verdwijnen de biljoenen van de Federal Reserve?
sa "https://www.youtube.com/watch?v=GkEhcFvPHNw" --language nl # 2025-02-11 -    16:11 - DPG Media ontvangt honderden miljoenen uit Brussel
sa "https://www.youtube.com/watch?v=lCH4J9h_qpo" --language nl # 2025-02-09 -    13:29 - Toch geen einde aan USAID - Wat heeft de 'hulporganisatie' op haar kerfstok?
sa "https://www.youtube.com/watch?v=6pHqZsIu2YQ" --language nl # 2025-02-08 -    11:58 - Bitcoin als Amerikaanse reservemunt?!
sa "https://www.youtube.com/watch?v=xld6ic4czlg" --language nl # 2025-02-08 -    11:05 - Loodgieters dreigen met Amsterdam-boycot: “We kunnen hier niet meer werken!”
sa "https://www.youtube.com/watch?v=58RqTf_JiOQ" --language nl # 2025-02-07 -    55:16 - Loodgieters boycotten A'dam | Bitcoin & Trumps handelsoorlog | USAID-tentakels | DWIV #36
sa "https://www.youtube.com/watch?v=Te7PdyMPHnI" --language nl # 2025-02-07 -    18:14 - Nieuwe detailhandelsvisie legt dorpswinkels en ondernemers aan banden
sa "https://www.youtube.com/watch?v=fE5uDAkImiA" --language nl # 2025-02-06 -    20:11 - Handelsoorlog VS en China dreigt door importheffing, Europa mogelijk volgende doelwit
sa "https://www.youtube.com/watch?v=RglR0yR1AbY" --language nl # 2025-02-06 -    15:35 - Uitspraak 'mondkapjes-deal': miljoenen moeten terug en staat wist ervan
sa "https://www.youtube.com/watch?v=QGNCXl1ZYzE" --language nl # 2025-02-05 -    16:01 - Is Trump's ontmanteling van USAID een aanval op de deepstate?
sa "https://www.youtube.com/watch?v=j3SiImuab4c" --language nl # 2025-02-04 -    25:56 - Minister Agema: Pandemische Paraatheid maakt plaats voor NAVO-Weerbaarheidsdoelen
sa "https://www.youtube.com/watch?v=Zb18i17d3eE" --language nl # 2025-02-04 -    18:34 - Vissers slaan alarm: EU-handhaving voert ‘intimiderende razzia’s’ uit op Noordzee
sa "https://www.youtube.com/watch?v=-KGaV4IJU_U" --language nl # 2025-02-01 -    15:33 - Documentaire oversterfte: Waarom is er oversterfte?
sa "https://www.youtube.com/watch?v=R2ehK-DcxEA" --language nl # 2025-02-01 -    15:18 - Waarom we wereldwijd vast blijven zitten in voortdurende conflicten
sa "https://www.youtube.com/watch?v=UQxiubYKAOU" --language nl # 2025-02-01 -    13:28 - Boerderijwinkels dreigen te moeten verdwijnen
sa "https://www.youtube.com/watch?v=-0iCGBg2kQQ" --language nl # 2025-01-31 -    23:59 - DeepSeek AI - Wat zijn gevolgen van de Chinese ChatGPT voor het Westen?
sa "https://www.youtube.com/watch?v=z5FkkxvuEBg" --language nl # 2025-01-31 -  1:08:41 - Documentaire oversterfte | Einde boerderijwinkels? | De Spiegel van Conflicten DWIV #35
sa "https://www.youtube.com/watch?v=aPqJ5rkYxu0" --language nl # 2025-01-30 -    22:14 - Dit zit er achter de rechtszaak van Karim Aachboun vs. Mark Rutte en de NAVO
sa "https://www.youtube.com/watch?v=75sZzDCp1lk" --language nl # 2025-01-30 -    19:49 - Trump botst met Verenigde Naties over twee-statenoplossing Israël en Gaza
sa "https://www.youtube.com/watch?v=Z1KHT468vCs" --language nl # 2025-01-29 -    17:11 - Wordt vogelgriep de nieuwe pandemie?
sa "https://www.youtube.com/watch?v=su7TxNeljNQ" --language nl # 2025-01-28 -    24:58 - Dit zijn de gevolgen van de Greenpeace-stikstofuitspraak voor Nederland
sa "https://www.youtube.com/watch?v=AvtVnWCFD2g" --language nl # 2025-01-28 -    18:32 - Terugblik World Economic Forum 2025
sa "https://www.youtube.com/watch?v=52DXo29Enk8" --language nl # 2025-01-26 -     7:03 - Trump verrast met “CBDC-verbod” – Wat nu?
sa "https://www.youtube.com/watch?v=7Cp1JSVaZXg" --language nl # 2025-01-26 -    10:02 - Nederlanders koploper in kinderen naar de opvang sturen
sa "https://www.youtube.com/watch?v=SO5PiSlLYM0" --language nl # 2025-01-25 -    17:13 - Verdeling in relaties: hoe ga je om met polarisatie in liefde, familie en vriendschap?
sa "https://www.youtube.com/watch?v=meDr8xLHH9A" --language nl # 2025-01-25 -    15:28 - WEF vs Trump in Davos: wat besprak Trump met Schwab-panel?
sa "https://www.youtube.com/watch?v=oRuuM1Nn4CQ" --language nl # 2025-01-25 -    11:30 - Steeds meer mensen mijden nieuws – zo blijf je op de hoogte zonder stress!
sa "https://www.youtube.com/watch?v=yzeDhRIaqrQ" --language nl # 2025-01-24 -    46:16 - Ex-Top Official Catherine Austin Fitts: The Trump Administration's Road to the Future
sa "https://www.youtube.com/watch?v=OjptO_f7ekg" --language nl # 2025-01-24 -    19:17 - Slimme Meter verplicht door overheid- Hoe jouw energiegebruik wordt gecontroleerd
sa "https://www.youtube.com/watch?v=DHietPdinxI" --language nl # 2025-01-24 -  1:09:25 - Kundalini Yoga | Trump bij WEF in Davos | Toxische relaties, hoe ga jij hiermee om?  DWIV #34
sa "https://www.youtube.com/watch?v=Qr8LEL_V8EE" --language nl # 2025-01-23 -    22:09 - Burgerberaad Klimaat “misleidend” en “veronderstelt dat klimaatactie nodig is”
sa "https://www.youtube.com/watch?v=U08lEwxP06E" --language nl # 2025-01-23 -    21:03 - Welke decreten tekende Trump op de eerste dag van zijn presidentschap?
sa "https://www.youtube.com/watch?v=5QyKF7u1UiM" --language nl # 2025-01-22 -    23:03 - Hoe houdbaar is het Israël-Hamas bestand?
sa "https://www.youtube.com/watch?v=_QVkk0RJjGw" --language nl # 2025-01-21 -    25:42 - WEF ‘25 van start! Dit wordt er besproken in Davos deze week
sa "https://www.youtube.com/watch?v=-EcL4uJdazM" --language nl # 2025-01-21 -    23:46 - Wat volgt er na Trumps inauguratie voor Europa? - “Make Europe Great Again”
sa "https://www.youtube.com/watch?v=hWyHeBBoRiw" --language nl # 2025-01-19 -    14:09 - Inflatie vooral 'tussen de oren' of harde realiteit?
sa "https://www.youtube.com/watch?v=iZe2eNipM_Y" --language nl # 2025-01-18 -    17:41 - Hoe één familie met drie generaties volledig zelfvoorzienend leeft – en hoe jij dat ook kan!
sa "https://www.youtube.com/watch?v=FZ8kUB51yPM" --language nl # 2025-01-18 -    17:29 - Ilaaf wilde soldaten bij het Ministerie van Defensie ‘cultureel bewust’ maken
sa "https://www.youtube.com/watch?v=UfnW5ntVUUs" --language nl # 2025-01-17 -    19:40 - Rutte wil EU-geld, zelfs als het ten koste gaat van sociale voorzieningen
sa "https://www.youtube.com/watch?v=xvXVxF4wkCM" --language nl # 2025-01-17 -  1:11:08 - Oorlog en moraal | Hoe leef jij zelfvoorzienend? | Zit inflatie tussen de oren? | DWIV #33
sa "https://www.youtube.com/watch?v=aWaJsGezYrE" --language nl # 2025-01-16 -    22:46 - Mark Zuckerberg en Joe Rogan over Facebookcensuur en de toekomst
sa "https://www.youtube.com/watch?v=nVKM3wbH86M" --language nl # 2025-01-16 -    21:17 - Voorbeschouwing World Economic Forum ‘25 - Controle of vrijheid voor AI en Crypto?
sa "https://www.youtube.com/watch?v=640uKSSfXi4" --language nl # 2025-01-15 -    24:25 - Noodpakketten, supermarkten en oorlog: Familieopsteller Hylke Bonnema over onze collectieve psyche
sa "https://www.youtube.com/watch?v=rfSM-68tEsk" --language nl # 2025-01-14 -    29:26 - Komt er eindelijk een staakt-het-vuren in Gaza?
sa "https://www.youtube.com/watch?v=eyB4yEtgSKQ" --language nl # 2025-01-14 -    18:33 - Verwoestende bosbranden in L.A. - hoe kon het zover komen?
sa "https://www.youtube.com/watch?v=9RC3rsu9b6E" --language nl # 2025-01-12 -     7:29 - België herintroduceert mondkapjes: ‘’Draag ze bij griepverschijnselen’’
sa "https://www.youtube.com/watch?v=aIkGTc1dgpo" --language nl # 2025-01-12 -    22:33 - Jakobien reisde tegen alle adviezen in naar Pakistan en gaat naar Afghanistan
sa "https://www.youtube.com/watch?v=DolK4908vag" --language nl # 2025-01-11 -    23:02 - Tim Douwsma: van bekendheid naar ge-canceled – “Mijn meest intense reis ooit”
sa "https://www.youtube.com/watch?v=hDSvUcXdFB4" --language nl # 2025-01-11 -    15:09 - Facebook zegt vooringenomen 'fact-checkers' vaarwel
sa "https://www.youtube.com/watch?v=qsvdrnfF7dM" --language nl # 2025-01-10 -    17:05 - Georgië: het beeld en de werkelijkheid
sa "https://www.youtube.com/watch?v=13ShCJDUKko" --language nl # 2025-01-10 -  1:25:06 - Tim Douwsma | Meta stopt met factcheckers | Het leven in Pakistan | DWIV #32
sa "https://www.youtube.com/watch?v=Vk2J0y3-4BQ" --language nl # 2025-01-09 -    28:14 - De Britse ‘grooming gangs’ doofpot: hoe groot is het misbruikschandaal?
sa "https://www.youtube.com/watch?v=XzC9XEK976I" --language nl # 2025-01-09 -    22:40 - Nieuwe wending in Trump’s buitenlandpolitiek zorgt voor wereldwijde verbazing
sa "https://www.youtube.com/watch?v=iZSas3mDqJ4" --language nl # 2025-01-08 -    15:57 - Oekraïne stopt gasdoorvoer vanuit Rusland naar Europa, wat zijn de gevolgen?
sa "https://www.youtube.com/watch?v=LF35eRXeNr4" --language nl # 2025-01-07 -    20:09 - Crisis of kans? Financiële vooruitblik 2025 met Ab Flipse
sa "https://www.youtube.com/watch?v=u5-rIKpMMpU" --language nl # 2025-01-07 -    15:06 - Wat schuilt er achter het HTS-regime in ‘het nieuwe Syrië’?
sa "https://www.youtube.com/watch?v=LgQPQJM4Az0" --language nl # 2025-01-05 -     7:03 - Blckbx Classic #3 "Een Sprookje over Macht & Indoctrine",  2 + 2 = 5
sa "https://www.youtube.com/watch?v=PNRZsjKywD4" --language nl # 2025-01-04 -    47:35 - Documentaire Nitrogen2000: het Nederlandse stikstofbeleid vanuit internationaal perspectief
sa "https://www.youtube.com/watch?v=PqBapqTjejI" --language nl # 2025-01-03 -  1:29:26 - Blckbx Classic #2 De Eindtijd en het teken van het Beest in Bijbels perspectief...
sa "https://www.youtube.com/watch?v=IiNaw1aG4os" --language nl # 2025-01-01 -     4:36 - Nieuwjaarswens 2025 | blckbx special
sa "https://www.youtube.com/watch?v=mdCNh1Hx7AY" --language nl # 2024-12-31 -    39:32 - "Doodlopende weg” Oudejaarsconference 2024 van Paul Schoolderman, Hart voor Humor...
sa "https://www.youtube.com/watch?v=uI_-7VOh654" --language nl # 2024-12-29 -     7:04 - Eindejaarsinterviews 2024 4/5 | blckbx special
sa "https://www.youtube.com/watch?v=xdpPaVCY8Zs" --language nl # 2024-12-28 -  1:01:53 - Blckbx Classic #1 "Overheid offert 520.000 levensjaren!” blijkt uit WOO verzoek van ex CBS directeur
sa "https://www.youtube.com/watch?v=Th3PKdJH-U4" --language nl # 2024-12-27 -     5:20 - Eindejaarsinterviews 2024 3/5 | blckbx special
sa "https://www.youtube.com/watch?v=jc-goYoC0c0" --language nl # 2024-12-26 -     1:00 - De prik die alles veranderde voor Heiko Sepp…
sa "https://www.youtube.com/watch?v=J9YOrmSGrnc" --language nl # 2024-12-25 -     6:58 - Eindejaarsinterviews 2024 2/5 | blckbx special
sa "https://www.youtube.com/watch?v=B3oAlgA-4XQ" --language nl # 2024-12-23 -     5:54 - Eindejaarsinterviews 2024 1/5 | blckbx special
sa "https://www.youtube.com/watch?v=-y488V7w-mU" --language nl # 2024-12-22 -    17:11 - Mainstream vs. nieuwe media: Viola Holt blikt vooruit op 2025!
sa "https://www.youtube.com/watch?v=su-UFpWjCFI" --language nl # 2024-12-22 -    10:17 - Kabinet valt in 2025? Paragnost en visionair doen hun voorspelling!
sa "https://www.youtube.com/watch?v=7JJH6lKGGm8" --language nl # 2024-12-21 -     6:31 - Zelensky spreekt op de Europese Raad: “we are just people”
sa "https://www.youtube.com/watch?v=zzQGjyQRIps" --language nl # 2024-12-21 -    20:26 - 2024: Een terugblik op een politiek bewogen jaar
sa "https://www.youtube.com/watch?v=EgBxTYtreeU" --language nl # 2024-12-20 -    22:46 - Top 3 Mind Control 2024 & hoe je het tegengaat in 2025
sa "https://www.youtube.com/watch?v=yCbKXqgd718" --language nl # 2024-12-19 -    25:55 - “‘De Joodse gemeenschap’ bestaat niet!” – Stichting Een Ander Joods Geluid over Israël en Gaza
sa "https://www.youtube.com/watch?v=9jByPpkkxo8" --language nl # 2024-12-19 -    17:46 - Wie is Peter Thiel - de CIA-dienstverlener achter Trump en JD Vance?
sa "https://www.youtube.com/watch?v=ugDrYvpX_B8" --language nl # 2024-12-18 -    17:52 - Trump vs. EU: Waarom Europa’s achterstand op de VS jouw portemonnee gaat raken
sa "https://www.youtube.com/watch?v=dkYnLRJ2pQA" --language nl # 2024-12-17 -    36:53 - UAP’s boven de VS: wat zijn het en wat zit erachter?
sa "https://www.youtube.com/watch?v=qnnj-EPqUcU" --language nl # 2024-12-17 -    24:12 - Hoe Syrië in handen van terroristen viel
sa "https://www.youtube.com/watch?v=Rb7n5z8pD1g" --language nl # 2024-12-16 -     5:19 - Bitcoin bereikt historische mijlpaal van 100.000 dollar!
sa "https://www.youtube.com/watch?v=SXpcWKiaRck" --language nl # 2024-12-16 -    14:40 - Gaat RFK Jr. zijn belofte 'to make America healthy again' waarmaken?
sa "https://www.youtube.com/watch?v=tdtiged4BYM" --language nl # 2024-12-16 -    13:52 - Interview Lavrov, de Deepstate en de krachten achter de oorlog in Oekraïne
sa "https://www.youtube.com/watch?v=Wv4lmNPdTuM" --language nl # 2024-12-15 -    23:33 - Vernietigende onderwijsbezuinigingen raken kwetsbare leerlingen
sa "https://www.youtube.com/watch?v=pfpGoh02arw" --language nl # 2024-12-15 -    23:13 - Syrië overlopen door jihadisten - Assad vlucht naar Moskou
sa "https://www.youtube.com/watch?v=yf2ZcvkKZIE" --language nl # 2024-12-15 -    15:59 - Het politieke machtsspel van het Westen in Roemenië, Moldavië en Georgië
sa "https://www.youtube.com/watch?v=41345BSLdgg" --language nl # 2024-12-15 -    14:19 - Waarom de overheid en media voorsorteren op oorlog met Rusland
sa "https://www.youtube.com/watch?v=BdgQeUVtxgU" --language nl # 2024-12-14 -    19:41 - Propaganda als instrument in de psychologische oorlogsvoering
sa "https://www.youtube.com/watch?v=preO-LtqBQI" --language nl # 2024-12-14 -    15:52 - Rutte: ‘Voorbereiden op oorlog’ – Hoe behoud je balans in tijden van angst en spanning?
sa "https://www.youtube.com/watch?v=RJr5AMyUzD0" --language nl # 2024-12-14 -  1:53:46 - De Waarheid over Rusland in de docu “Een Verloren Vrede” van Marie Thérèse ter Haar...
sa "https://www.youtube.com/watch?v=i2JqTbhmbvs" --language nl # 2024-12-14 -    12:55 - Plan voor 2,5 miljoen zonnepanelen op het Ijselmeer tegen klimaatverandering
sa "https://www.youtube.com/watch?v=Sioo0pJsFFw" --language nl # 2024-12-13 -    22:14 - Ongekend bombardement van Israël, Turkije en de V.S. op Syrië na vertrek Assad
sa "https://www.youtube.com/watch?v=D0VllI8ck_k" --language nl # 2024-12-13 -    19:41 - 250.000 zzp’ers mogelijk de klos door handhaving
sa "https://www.youtube.com/watch?v=uhSxxLvQ4Vg" --language nl # 2024-12-13 -  1:07:46 - Polariserende propaganda | Zonnepark op IJsselmeer? | Disease X in Congo; Covid 2.0? | DWIV #30
sa "https://www.youtube.com/watch?v=CB1V3k8NszY" --language nl # 2024-12-12 -    18:36 - Plannen om steden volledig zero-emissie te maken! - Wat betekent dit voor jouw auto?
sa "https://www.youtube.com/watch?v=3e_5xCJQPPw" --language nl # 2024-12-05 -    21:14 - ‘Subcommittee’ VS ondersteunt lab-leak theorie en fileert corona-maatregelen
sa "https://www.youtube.com/watch?v=icBqykw8K9o" --language nl # 2024-12-05 -    19:59 - Digitale identiteit stap dichterbij door nieuwe Europese regelgeving
sa "https://www.youtube.com/watch?v=A32jkZplS-0" --language nl # 2024-12-04 -    15:22 - ECB presenteert nieuw CBDC-rapport: Verdwijnt contant geld door de digitale euro?
sa "https://www.youtube.com/watch?v=G5zPYOuiw1A" --language nl # 2024-12-03 -    37:47 - "Wij zijn gebruikt" zegt Marie-Thérèse ter Haar met haar docu, Een Verloren Vrede...
sa "https://www.youtube.com/watch?v=se5XApX6Z84" --language nl # 2024-12-03 -    17:58 - Australië legt sociale media-verbod op voor jongeren onder 16 jaar
sa "https://www.youtube.com/watch?v=8C1MTZWWiZg" --language nl # 2024-12-03 -    13:32 - Wie zit er achter het jihadistische offensief in Syrië van de afgelopen dagen?
sa "https://www.youtube.com/watch?v=h-RFF-ndXIg" --language nl # 2024-12-02 -     5:44 - Gratie van Joe Biden voor zoon Hunter: Vaderlijke bescherming of machtsmisbruik?
sa "https://www.youtube.com/watch?v=eufdfmTvjbs" --language nl # 2024-12-02 -     5:37 - Auteur Tessa Koop over subliminale technieken in Katy Perry’s Chained to the Rhythm videoclip
sa "https://www.youtube.com/watch?v=wGixnM1qHEM" --language nl # 2024-12-01 -    19:05 - Rechter doet uitspraak tegen CBG! - Waarom schorste medicijnwaakhond coronavaccins niet?
sa "https://www.youtube.com/watch?v=4RQ3JpZgET4" --language nl # 2024-12-01 -    13:10 - Ondernemer Vincent Vandeputte legt met humor de vinger op de zere plek
sa "https://www.youtube.com/watch?v=TzubB5vow9Q" --language nl # 2024-11-30 -     5:53 - Zero-emissiezones breiden uit: einde aan benzine- en dieselauto’s in de stad?
sa "https://www.youtube.com/watch?v=vvwJl9n5N6U" --language nl # 2024-11-30 -    10:02 - Vrijspraak voor 'koffiedrinkers' Museumplein
sa "https://www.youtube.com/watch?v=IRSY2SjWlBA" --language nl # 2024-11-29 -    18:55 - VS-senatoren dreigen Nederland met ‘Den Haag Invasiewet’ na arrestatiebevel Netanyahu
sa "https://www.youtube.com/watch?v=73cQSo_WzcY" --language nl # 2024-11-29 -  1:00:40 - DWIV #28: Vrijspraak ‘Koffiedrinkers’ | Verbod benzineauto? | Uitspraak Voorwaarheid vs CBG
sa "https://www.youtube.com/watch?v=6iN3DgGSLQc" --language nl # 2024-11-28 -    44:48 - Hoe werkt Propaganda & Mindcontrol? Interessante sprekers delen hun kennis...
sa "https://www.youtube.com/watch?v=iCvkvnm23OY" --language nl # 2024-11-28 -    20:10 - Onthulling ‘Covid cover-up’ verder in de steigers gezet door Trump-getrouwen
sa "https://www.youtube.com/watch?v=KCWCYB1MXr0" --language nl # 2024-11-28 -    16:31 - Is de NAVO uit op een 'preventieve aanval' op Rusland?
sa "https://www.youtube.com/watch?v=eYPmA6YNqp0" --language nl # 2024-11-26 -     6:55 - Dr. Aseem Malhotra definitief Kennedy’s nieuwe adviseur in Trump-kabinet!
sa "https://www.youtube.com/watch?v=GbTG20IO39E" --language nl # 2024-11-26 -    59:55 - ‘This is Character Assassination!’ says Wim Hof about alleged violence and abuse...
sa "https://www.youtube.com/watch?v=99fqtu83bZ0" --language nl # 2024-11-26 -    58:10 - Wim hof doet zijn verhaal over vermeend huiselijk geweld…
sa "https://www.youtube.com/watch?v=GTrlCGFF5Ug" --language nl # 2024-11-23 -     5:34 - Moet de politie meelezen met appgroepen om geweld te stoppen?
sa "https://www.youtube.com/watch?v=hd40fJyWz8Q" --language nl # 2024-11-23 -    14:39 - Hoe is het leven in Iran anno 2024 werkelijk?
sa "https://www.youtube.com/watch?v=lh28S-voIu0" --language nl # 2024-11-21 -    27:01 - BBB-Europarlementariër over nieuwe Europese boerenprotesten
sa "https://www.youtube.com/watch?v=zm-vuqYP96Y" --language nl # 2024-11-21 -    18:00 - BVNL en Van Haga dagen VWS voor rechter om inhoud ‘OMT-tapes’ te onthullen
sa "https://www.youtube.com/watch?v=aEKRoSOU_Kg" --language nl # 2024-11-21 -  1:05:13 - “Of ze zijn dom. Of het is een plan?!” zegt Marijn Poels over frequenties en onze gezondheid…
sa "https://www.youtube.com/watch?v=PXmNuk_qm1A" --language nl # 2024-11-19 -    22:43 - Kabinet stond op rand van de afgrond - Wat gebeurde er echt vrijdagavond?
sa "https://www.youtube.com/watch?v=p3GKZDoU318" --language nl # 2024-11-17 -    18:49 - Trump's ‘Dream Team’ Kabinet: RFK Jr., Musk, Gabbard en Neoconservatieven – Wat Nu?
sa "https://www.youtube.com/watch?v=NCiXc9I1YA8" --language nl # 2024-11-16 -     8:42 - NPO simuleert ‘Black-out’ na cyberaanval: predictive programming?
sa "https://www.youtube.com/watch?v=r8VgmK7UV9I" --language nl # 2024-11-16 -     6:17 - Kabinetsval afgewend? Kabinetscrisis na ontslag NSC-staatssecretaris Achahbar vanwege 'racisme'!
sa "https://www.youtube.com/watch?v=RhNGNiZ-p24" --language nl # 2024-11-16 -    17:16 - Wat we allemaal niet weten over ons Sinterklaasfeest
sa "https://www.youtube.com/watch?v=gGg22xoWUpw" --language nl # 2024-11-12 -    19:16 - Recordaantal Rechtszaken rond Amerikaanse Verkiezingen – hoe betrouwbaar is de uitslag?
sa "https://www.youtube.com/watch?v=XhysX28I4Jg" --language nl # 2024-11-10 -    15:26 - Faillissementsgolf NL: blijven of vertrekken?

exit

rm BURN_VIDEO2.TXT

echo " \\" > add_fix.txt
echo '	--tags="The American Conservative" \' >> add_fix.txt
echo '	--tags="John Mearsheimer" \' >> add_fix.txt
echo '	--tags="European Union"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=wnnOQefj0Uc" --language en

echo " \\" > add_fix.txt
echo '	--tags="Tom Bilyeu" \' >> add_fix.txt
echo '	--tags="AI" \' >> add_fix.txt
echo '	--tags="Superintelligence"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=2bbSgSIQsac" --language en


exit




## rm BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Patrick Savalle" \' >> add_fix.txt
## echo '	--tags="blckbx" \' >> add_fix.txt
## echo '	--tags="Palantir"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=ArI3UqylU7M" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Patrick Savalle" \' >> add_fix.txt
## echo '	--tags="The Trueman Show" \' >> add_fix.txt
## echo '	--tags="ai"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=Iqxk7lhJk3Q" --language nl

echo " \\" > add_fix.txt
echo '	--tags="Patrick Savalle" \' >> add_fix.txt
echo '	--tags="Willem Engel" \' >> add_fix.txt
echo '	--tags="Palantir"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=rgSV0Maexy0" --language nl

echo " \\" > add_fix.txt
echo '	--tags="Patrick Savalle" \' >> add_fix.txt
echo '	--tags="ai" \' >> add_fix.txt
echo '	--tags="Palantir"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=xBqZbuAUXJY" --language nl

echo " \\" > add_fix.txt
echo '	--tags="TEDx Talks" \' >> add_fix.txt
echo '	--tags="decentralized society" \' >> add_fix.txt
echo '	--tags="Johann Gevers"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=8oeiOeDq_Nc" --language en

echo " \\" > add_fix.txt
echo '	--tags="Backwards Brain Bicycle" \' >> add_fix.txt
echo '	--tags="SmarterEveryDay" \' >> add_fix.txt
echo '	--tags="Plastic brain"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=MFzDaBzBlL0" --language en

echo " \\" > add_fix.txt
echo '	--tags="Bitcoin" \' >> add_fix.txt
echo '	--tags="Blockchain" \' >> add_fix.txt
echo '	--tags="Odyssey"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=gKC2oelL878" --language nl

echo " \\" > add_fix.txt
echo '	--tags="fossils"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=LF-9dH-1HxM" --language en
sa "https://www.youtube.com/watch?v=i6DxWXMnwjc" --language en


echo '	--tags="Patrick Savalle" \' >> add_fix.txt
echo '	--tags="Eric van de Beek" \' >> add_fix.txt
echo '	--tags="conspiracythinkers"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=WpkJE_2egLI" --language nl

echo " \\" > add_fix.txt
echo '	--tags="Patrick Savalle" \' >> add_fix.txt
echo '	--tags="Blue Tiger Studio" \' >> add_fix.txt
echo '	--tags="madness"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=mX_Wk_JNmf0" --language nl

echo " \\" > add_fix.txt
echo '	--tags="Patrick Savalle" \' >> add_fix.txt
echo '	--tags="Blue Tiger Studio" \' >> add_fix.txt
echo '	--tags="5th generation warfare"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=NkzzQls0Xb8" --language nl

echo " \\" > add_fix.txt
echo '	--tags="AI" \' >> add_fix.txt
echo '	--tags="Eliezer Yudkowsky" \' >> add_fix.txt
echo '	--tags="Chris Williamson"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=nRvAt4H7d7E" --language nl

echo '	--tags="AI" \' >> add_fix.txt
echo '	--tags="Eliezer Yudkowsky" \' >> add_fix.txt
echo '	--tags="The Ezra Klein Show"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=2Nn0-kAE5c0" --language en

echo " \\" > add_fix.txt
echo '	--tags="LUBACH" \' >> add_fix.txt
echo '	--tags="ai"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=Q_5jTOFX5Wc" --language nl

echo " \\" > add_fix.txt
echo '	--tags="Edward Bernays" \' >> add_fix.txt


sa "https://www.youtube.com/watch?v=aXF39TCacwE" --language en
sa "https://www.youtube.com/watch?v=N4xQboiF9aw" --language en
sa "https://www.youtube.com/watch?v=ul6ym0LsCKA" --language en
sa "https://www.youtube.com/watch?v=lVIYYfQO2f8" --language en
sa "https://www.youtube.com/watch?v=cahKfTJqgsw" --language en
sa "https://www.youtube.com/watch?v=cjyg6MFrlfg" --language nl
sa "https://www.youtube.com/watch?v=DpP4GyK8zug" --language en

exit
exit

echo " \\" > add_fix.txt
echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=JUg7BW-GI14" --language nl


echo " \\" > add_fix.txt
echo '	--tags="fern" \' >> add_fix.txt
echo '	--tags="Meth" \' >> add_fix.txt
echo '	--tags="Drugs"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=K4E1u3_S1p8" --language en

exit

echo BURN_VIDEO2.TXT > BURN_VIDEO2.TXT
#rm BURN_VIDEO2.TXT

echo " \\" > add_fix.txt
echo '	--tags="NATO" \' >> add_fix.txt
echo '	--tags="Ukraine" \' >> add_fix.txt
echo '	--tags="Russia"' >> add_fix.txt

saa "https://x.com/YossiBenYakar/status/1984981841175011689" --language en
saa "https://x.com/ivan_8848/status/1969102545462124959" --language ru
saa "https://x.com/ivan_8848/status/1985748317209305324" --language en

exit

## sa "https://rumble.com/v3nep5a-the-un-agenda-for-world-domination.part-2.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-06 - length:  1:16:06 - title: "The UN agenda for World Domination.Part 2"
## 
## sa "https://rumble.com/v3negi1-vaxxed.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-06 - length:  1:32:29 - title: "Vaxxed | Vaccination Misery (2 parts)"
## 
## sa "https://rumble.com/v3nesg1-who-is-bill-gates.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-06 - length:  2:05:56 - title: "Who is Bill Gates | By James Corbett"
## 
## sa "https://rumble.com/v3nsd8a-cultural-marxism-a-corruptive-system-which-leads-to-poverty.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-08 - length:  1:38:38 - title: "Cultural Marxism: A Corruptive System Which Leads To Poverty!"
## 
## sa "https://rumble.com/v3ouv3e-zionist-genocidal-quotes-zionism-is-not-judaism.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-12 - length:    35:12 - title: "Zionist Genocidal Quotes -"
## 
## sa "https://rumble.com/v3ozqu2-un-agenda-for-world-domination-part-1.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-13 - length:  1:20:38 - title: "UN Agenda for World Domination- Part 1"
## 
## sa "https://rumble.com/v3ozmj7-who-controls-the-u.s.-government-aka-the-world.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-13 - length:  1:35:11 - title: "Who Controls The U.S. Government? AKA- The World"
## 
## sa "https://rumble.com/v3p4l0m-covid-vaccine-was-a-biological-weapon-of-genocide-dr.drew-dr.david-martin-d.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-13 - length:  1:51:06 - title: "COVID-Vaccine Was A "Biological Weapon of Genocide!" Dr.Drew - Dr.David Martin -  Dr.Kelly Victory"
## 
## sa "https://rumble.com/v3ozw1z-prominent-jewish-rabbi-exposes-truth-about-adolf-hitler-jews-communismbolsh.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-13 - length:    15:19 - title: "Prominent Jewish Rabbi Exposes Truth About Adolf Hitler, Jews, Communism/Bolshevism"
## 
## sa "https://rumble.com/v3p1qob-alex-jones-a-100-false-idol.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-13 - length:  2:00:23 - title: "Alex Jones - A 100% False Idol!"
## 
## sa "https://rumble.com/v3p9c9g-the-truth-about-hamas-exposed-zionism-is-not-judaism.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-14 - length:  1:03:22 - title: "The Truth about Hamas EXPOSED!!"
## 
## sa "https://rumble.com/v3p8ynv-the-fossil-fuel-scarcity-hoax.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-14 - length:    12:13 - title: "The Fossil Fuel Scarcity HOAX!!"
## 
## sa "https://rumble.com/v3p8n7d-911-zionists-goal-mass-destruction-by-constant-war-and-mass-immigration.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-14 - length:  1:29:59 - title: "9/11 Zionists Goal: Mass Destruction By Constant War and Mass Immigration!"
## 
## sa "https://rumble.com/v3pfmtq-what-you-need-to-know-about-money-simply-explained.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-15 - length:    29:54 - title: "What You Need to Know About MONEY!!! (Simply Explained)"
## 
## sa "https://rumble.com/v3peqmj-what-on-earth-happened-why-is-antarctica-hidden-from-us.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-15 - length:  8:14:36 - title: "What on Earth Happened? Why is Antarctica Hidden from Us?"
## 
## sa "https://rumble.com/v3pyh24-the-belt-and-road-wars-by-the-bankers-for-a-multi-polar-world.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-17 - length:  2:34:31 - title: "The Belt And Road Wars By The Bankers For A Multi-Polar World"
## 
## sa "https://rumble.com/v3qfi7p-the-usa-lobby-judaism-is-not-zionism.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-19 - length:  1:13:20 - title: "RESULT OF FUNDING EVIL | BANNED VIDEO"
## 
## sa "https://rumble.com/v3qk0ym-defamation-lies-schmear-and-vicitmize.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-20 - length:  1:30:54 - title: "Defamation, Lies, Schmear & Vicitmize"
## 
## sa "https://rumble.com/v3ql0pp-all-wars-have-the-same-founders-and-funders-the-new-world-order.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-20 - length:    22:34 - title: "ALL WARS HAVE THE SAME FOUNDERS AND FUNDERS | The New World Order"
## 
## sa "https://rumble.com/v3qkgq4-finally-bill-gates-admits-his-criminal-activities-or....html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-20 - length:     3:48 - title: "FINALLY, Bill Gates Admits his Criminal Activities or..."
## 
## sa "https://rumble.com/v3qka4v-how-blackrock-conqueres-the-entire-world-by-james-corbett.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-20 - length:    58:48 - title: "How BlackRock Conqueres The Entire World | By James Corbett"
## 
## sa "https://rumble.com/v3r6eb4-the-corrupt-reality-of-the-world-health-organization.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-23 - length:  1:25:13 - title: "The Corrupt Reality of the World Health Organization"
## 
## sa "https://rumble.com/v3r61mp-bilderberg-group-they-dont-care-about-you.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-23 - length:  1:44:01 - title: "Bilderberg Group | They Don't Care About YOU!"
## 
## sa "https://rumble.com/v3r5ucd-the-real-zionist-maffia.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-23 - length:    32:24 - title: "The REAL Zionist Maffia"
## 
## sa "https://rumble.com/v3r5x07-the-toxic-plant-based-meat-scam.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-23 - length:    38:52 - title: "The Toxic Plant Based Meat Scam!"
## 
## sa "https://rumble.com/v3s11ys-october-27-2023.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-27 - length:    30:13 - title: "BECAUSE IT’S WRITTEN IT’S ALLOWED😳😡"
## 
## sa "https://rumble.com/v3s28gn-the-originators-behind-the-nwo-agenda-of-chaos-2030.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-10-27 - length:    30:56 - title: "The Originators Behind the NWO | Agenda of Chaos 2030!"
## 
## sa "https://rumble.com/v3to8xs-democracy-the-biggest-lie-in-history-jones-plantation-trailer.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-11-04 - length:     2:38 - title: "DEMOCRACY - THE BIGGEST LIE IN HISTORY (Jones Plantation- Trailer)"
## 
## sa "https://rumble.com/v3ux621-the-forgers-of-history-and-truth.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-11-10 - length:  1:06:15 - title: "The Forgers of History and Truth!"
## 
## sa "https://rumble.com/v3v9uz7-the-sad-reality-of-this-world-beyond-the-great-reset.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-11-12 - length:    27:58 - title: "THE SAD REALITY OF THIS WORLD - BEYOND THE GREAT RESET"
## 
## sa "https://rumble.com/v3wcjm7-the-architect-parasites-of-the-population.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-11-17 - length:    45:37 - title: "THE ARCHITECT | Parasites of The Population"
## 
## sa "https://rumble.com/v3wq0q7-religion-of-green-the-true-climate-change-agenda.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-11-19 - length:    20:38 - title: "RELIGION OF GREEN: The True 'Climate Change' Agenda!"
## 
## sa "https://rumble.com/v3wvr61-utopia-the-future-of-a-cbdc-world.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-11-20 - length:    21:55 - title: "UTOPIA | The Future of a CBDC World"
## 
## sa "https://rumble.com/v3xlaps-the-biggest-secret-hidden-from-us.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-11-24 - length:       58 - title: "THE BIGGEST SECRET HIDDEN FROM US"
## 
## sa "https://rumble.com/v3zd49v-december-3-2023.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-12-03 - length:  4:11:33 - title: "The Puppetmasters of Evil"
## 
## sa "https://rumble.com/v3zj6z2-fluoride-the-evil-history-and-harm-for-humanity.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-12-04 - length:  1:38:53 - title: "FLUORIDE | The EVIL History and HARM for Humanity"
## 
## sa "https://rumble.com/v41lozv-bernays-master-of-propaganda-and-mind-control.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-12-16 - length:    58:45 - title: "BERNAYS | Master of Propaganda & Mind Control"


## sa "https://rumble.com/v42rxro-the-real-truth-about-vaccinations-and-viruses.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-12-22 - length:  2:56:17 - title: "THE REAL TRUTH ABOUT VACCINATIONS AND VIRUSES"
## 
## sa "https://rumble.com/v43uxu3-secrets-of-the-united-nations-war-against-humanity.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-12-28 - length:    50:17 - title: "SECRETS OF THE UNITED NATIONS | War Against Humanity"
## 
## sa "https://rumble.com/v440g13-mind-control-ideological-subversion-by-ex-kgb-yuri-bezmenov.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-12-29 - length:    35:17 - title: "MIND CONTROL | Ideological Subversion - by EX-KGB Yuri Bezmenov"
## 
## sa "https://rumble.com/v445cvx-the-gaza-plan-.html?e9s=src_v1_ucp_a" --language en
## #date: 2023-12-30 - length:       56 - title: "THE GAZA PLAN |"
## 
## sa "https://rumble.com/v487puu-the-truth-about-the-jew-nathanael-kapner-and-stew-peters.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-01-20 - length:  1:23:19 - title: "THE TRUTH ABOUT THE JEW | Nathanael Kapner & Stew Peters"
## 
## sa "https://rumble.com/v488fko-who-indoctrinated-us-.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-01-20 - length:  3:06:55 - title: "WHO INDOCTRINATED US ?"
## 
## sa "https://rumble.com/v49abko-if-you-dont-know-the-jew-you-know-sht.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-01-25 - length:  4:28:18 - title: "IF YOU DON'T KNOW THE JEW, YOU KNOW SH*T!"
## 
## sa "https://rumble.com/v49fhu9-they-rewrote-the-scriptures.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-01-26 - length:  1:28:23 - title: "THEY REWROTE THE SCRIPTURES?"
## 
## sa "https://rumble.com/v4ajfzu-mass-migration-destruction-of-western-society.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-01-31 - length:  2:49:41 - title: "MASS MIGRATION | DESTRUCTION OF WESTERN SOCIETY"
## 
## sa "https://rumble.com/v4b4or3-occupation-starvation-and-heinous-murder-hidden-history.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-02-03 - length:  2:31:07 - title: "OCCUPATION, STARVATION AND HEINOUS MURDER | HIDDEN HISTORY"
## 
## sa "https://rumble.com/v4cljeo-controlled-opposition-tucker-carlson.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-02-10 - length:    40:41 - title: "CONTROLLED OPPOSITION - TUCKER CARLSON"
## 
## sa "https://rumble.com/v4d7x95-the-puppet-the-idiot-and-david-icke-at-infowars-11-02-2024.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-02-13 - length:  1:43:26 - title: "THE PUPPET – THE IDIOT & DAVID ICKE | AT INFOWARS 11-02-2024"
## 
## sa "https://rumble.com/v4ds2tl-the-real-mandela-a-communist-free-mason.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-02-16 - length:    59:53 - title: "THE REAL MANDELA | A JEW CONTROLLED COMMUNIST FREE MASON"
## 
## sa "https://rumble.com/v4e0lef-protocols-of-the-learned-elders-of-zion-world-domination.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-02-17 - length:  3:35:26 - title: "PROTOCOLS OF THE LEARNED ELDERS OF ZION | WORLD DOMINATION"
## 
## sa "https://rumble.com/v4e7lve-stop-jew-supremacy-by-brother-nathanael-kapner.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-02-18 - length:  1:22:35 - title: "STOP JEW SUPREMACY | By Brother Nathanael Kapner"
## 
## sa "https://rumble.com/v4f7obl-behind-the-clouds-un-inhumane-agenda-3-parts.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-02-23 - length:  1:14:37 - title: "BEHIND THE CLOUDS | UN INHUMANE AGENDA (3 parts)"
## 
## sa "https://rumble.com/v4ffxho-the-swarm-the-connected-rulers-by-dr.-shiva.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-02-24 - length:  1:44:15 - title: "THE SWARM | 'THE CONNECTED RULERS' - By Dr. Shiva"
## 
## sa "https://rumble.com/v4i04lf-because-its-written-the-rulers-of-the-world.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-03-08 - length:  2:32:22 - title: ""BECAUSE IT'S WRITTEN!" | The Rulers of the World"
## 
## sa "https://rumble.com/v4ilqit-children-in-our-food-interview-with-rabbi-abraham-finkelstein.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-03-11 - length:     3:40 - title: "OUR SECRET INGREDIENT IS OUR PEOPLE | Interview with rabbi Abraham Finkelstein"
## 
## sa "https://rumble.com/v4mf77o-behind-pink-ribbon-inc.-the-breast-cancer-lobby.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-03-30 - length:  1:37:51 - title: "BEHIND PINK RIBBON INC. - THE BREAST CANCER LOBBY"
## 
## sa "https://rumble.com/v4mgxxl-praying-for-armageddon-a-deadly-partnership.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-03-30 - length:  1:46:07 - title: "PRAYING FOR ARMAGEDDON | A Deadly Partnership"
## 
## sa "https://rumble.com/v4o9j9i-the-race-of-mass-destruction-thou-shall-make-war.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-04-08 - length:  5:39:00 - title: "THE RACE OF MASS DESTRUCTION | Thou Shall Make War"
## 
## sa "https://rumble.com/v4p4p1w-the-isra-hell-lie-about-the-killed-babies-banned-video.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-04-12 - length:    57:10 - title: "THE ISRA-HELL LIE ABOUT THE KILLED BABIES | Banned Video"
## 
## sa "https://rumble.com/v4qxfqn-communism-2.0-the-great-reset-depopulation.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-04-22 - length:  1:54:58 - title: "COMMUNISM 2.0 | THE GREAT RESET- DEPOPULATION"
## 
## sa "https://rumble.com/v4tew50-we-are-in-the-midst-of-communism-find-out-for-yourself-in-this-lecture..html?e9s=src_v1_ucp_a" --language en
## #date: 2024-05-05 - length:  3:01:08 - title: "WE ARE IN THE MIDST OF COMMUNISM! - Find out for yourself in this lecture."
## 
## sa "https://rumble.com/v4uqmj3-meet-the-feminists-to-destroy-western-society.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-05-12 - length:    46:32 - title: "MEET THE FEMINISTS | HELPERS TO DESTROY WESTERN SOCIETY!"
## 
## sa "https://rumble.com/v4vxii2-the-occupation-of-the-western-mind-by-roger-waters.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-05-18 - length:  1:59:54 - title: "THE OCCUPATION OF THE WESTERN MIND"
## 
## sa "https://rumble.com/v4yxhhq-the-mass-migration-plan-lie.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-06-01 - length:  1:20:06 - title: "THE MASS MIGRATION PLAN / LIE"
## 
## sa "https://rumble.com/v51mtpl-weather-manipulation-to-enslave-us.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-06-14 - length:    46:08 - title: "WEATHER MANIPULATION | TO ENSLAVE US"
## 
## sa "https://rumble.com/v51xk1x-the-biggest-lie-of-the-20th-century-debunked.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-06-16 - length:    58:01 - title: "THE BIGGEST LIE OF THE 20th CENTURY | DEBUNKED"
## 
## sa "https://rumble.com/v54gc93-the-media-matrix-no-media-no-war.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-06-29 - length:  1:13:09 - title: "THE MEDIA MATRIX | NO MEDIA - NO WAR"
## 
## sa "https://rumble.com/v55karc-rutte-de-leugenaar.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-07-04 - length:    34:20 - title: "RUTTE | DE LEUGENAAR"
## 
## sa "https://rumble.com/v55vvo2-fossil-fuel-abundance-malthusian-oligarchy-ideology.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-07-07 - length:  1:13:16 - title: "FOSSIL FUEL ABUNDANCE | MALTHUSIAN OLIGARCHY IDEOLOGY"
## 
## sa "https://rumble.com/v561jl6-6-million-lies-hatred-and-destruction.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-07-08 - length:  1:55:56 - title: "6 MILLION LIES HATRED & DESTRUCTION"
## 
## sa "https://rumble.com/v56819p-order-out-of-chaos-weather-manipulation.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-07-09 - length:    30:17 - title: "ORDER OUT OF CHAOS | WEATHER MANIPULATION"
## 
## sa "https://rumble.com/v56oz6y-the-anti-tourism-movement-paid-by-the-globalists.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-07-12 - length:    16:05 - title: "THE ANTI TOURISM MOVEMENT | PAID BY THE GLOBALISTS"
## 
## sa "https://rumble.com/v56wmjx-predictive-programming-divide-and-conquer.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-07-14 - length:    19:53 - title: "PREDICTIVE PROGRAMMING | DIVIDE & CONQUER PT 2 in Description Below"
## 
## sa "https://rumble.com/v57p3cj-how-america-benefits-from-wars.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-07-20 - length:    22:20 - title: "HOW AMERICA BENEFITS FROM WARS"
## 
## sa "https://rumble.com/v57v6ua-von-der-leyen-who-sucks-europe-dry.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-07-21 - length:    40:23 - title: "VON DER LEYEN | WHO SUCKS EUROPE 'DRY'"
## 
## sa "https://rumble.com/v59gpcl-the-beginning-of-the-end-of-the-world-as-we-knew-it.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-08-02 - length:  2:26:28 - title: "THE BEGINNING OF THE END OF THE WORLD AS WE KNEW IT"
## 
## sa "https://rumble.com/v5abzh7-the-plan-behind-orchestrated-riots.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-08-09 - length:    29:47 - title: "THE PLAN BEHIND ORCHESTRATED RIOTS"
## 
## sa "https://rumble.com/v5ap0j9-the-truth-beneath-the-surface-the-missing-children.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-08-12 - length:    16:27 - title: "THE TRUTH BENEATH THE SURFACE | THE MISSING CHILDREN"
## 
## sa "https://rumble.com/v5bchqr-the-monkeypox.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-08-17 - length:     1:14 - title: "THE MONKEYPOX"
## 
## sa "https://rumble.com/v5bcgsi-the-bragging-one-for-the-chosen-ones.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-08-17 - length:     7:44 - title: "THE BRAGGING ONE FOR THE CHOSEN ONES"
## 
## sa "https://rumble.com/v5buv95-george-soros-a-heartless-monster.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-08-21 - length:    51:12 - title: "GEORGE SOROS | A HEARTLESS MONSTER (read the text below)"
## 
## sa "https://rumble.com/v5c48xx-the-biggest-lie-ever-told.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-08-23 - length:  2:46:32 - title: "THE BIGGEST LIE EVER TOLD"
## 
## sa "https://rumble.com/v5cz04t-protocols-of-the-learned-elders-of-zion-nederlands-ondertiteld-world-domina.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-08-30 - length:  3:38:29 - title: "PROTOCOLS OF THE LEARNED ELDERS OF ZION (Nederlands Ondertiteld) | WORLD DOMINATION"
## 
## 
## echo press enter
## read aaa
## 
## sa "https://rumble.com/v5dq36z-bill-gates-the-malthusian-depopulation-advocate.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-09-05 - length:  1:02:38 - title: "BILL GATES | THE MALTHUSIAN DEPOPULATION ADVOCATE"
## 
## sa "https://rumble.com/v5gnflp-our-leaders-are-psychopaths.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-09-28 - length:  1:04:54 - title: "OUR LEADERS ARE PSYCHOPATHS !!!"
## 
## sa "https://rumble.com/v5ue8bh-occupied-by-the-chosen-ones-warning-sensitive-content-viewer-discretion-is-.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-11-29 - length:  1:47:55 - title: "OCCUPIED BY 'THE CHOSEN ONES' !! WARNING! Sensitive Content, Viewer Discretion is Advised!"
## 
## sa "https://rumble.com/v5y1b4k-the-chosen-ones-part-1-2-3-4-in-description-below.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-12-10 - length:  2:07:34 - title: "THE 'CHOSEN' ONES - PART 1+2  |  3+4 in Description below"
## 
## sa "https://rumble.com/v5zl1ot-goyim-life-control-through-money-fear-and-energy.html?e9s=src_v1_ucp_a" --language en
## #date: 2024-12-15 - length:    53:03 - title: "GOYIM LIFE | CONTROL THROUGH MONEY, FEAR & ENERGY"

## sa "https://rumble.com/v6899s1-the-nwo-agent-trump.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-01-11 - length:    19:09 - title: "THE NWO AGENT | TRUMP"
## 
## sa "https://rumble.com/v6d1o3j-how-presidents-keep-their-job.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-01-24 - length:     1:44 - title: "HOW PRESIDENTS KEEP THEIR JOB"
## 
## sa "https://rumble.com/v6iq55v-for-the-trumptards.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-02-09 - length:     1:50 - title: "FOR THE TRUMPTARDS"
## 
## sa "https://rumble.com/v6k0z64-trumps-financiers.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-02-12 - length:     3:03 - title: "Trump’s Financiers"
## 
## sa "https://rumble.com/v6l8w54-how-many-more-lies-do-we-have-to-bear-and-pay-for.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-02-15 - length:    54:45 - title: "HOW MANY MORE LIES DO WE HAVE TO BEAR AND PAY FOR?"
## 
## sa "https://rumble.com/v6njv9l-the-ugly-truth-behind-abortion-the-human-right-scam.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-02-21 - length:     5:13 - title: "THE UGLY TRUTH BEHIND ABORTION | The Human Right Scam!"
## 
## sa "https://rumble.com/v6nl126-de-modelburger-de-natte-droom-van-de-overheid-dutch.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-02-21 - length:     6:53 - title: "DE MODELBURGER | De Natte Droom van de Overheid (Dutch)"
## 
## sa "https://rumble.com/v6qe9ng-a-dead-cult-build-on-destruction-the-lying-chosen-ones.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-03-09 - length:    31:55 - title: "A 'DEAD CULT' BUILD ON DESTRUCTION | The Lying Chosen Ones"
## 
## sa "https://rumble.com/v6rfk08-geoengineering-against-humanity-dutch-subtitles.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-03-30 - length:  1:41:43 - title: "GEOENGINEERING AGAINST HUMANITY (Dutch Subtitles)"
## 
## sa "https://rumble.com/v6sakcn-extermination-of-the-white-race-it-wont-work-.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-04-19 - length:    32:41 - title: "EXTERMINATION OF THE WHITE RACE | IT WON'T WORK !"
## 
## sa "https://rumble.com/v6savd9-the-real-picture-behind-child-trafficking-the-real-perpetrators.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-04-19 - length:  3:35:16 - title: "THE 'REAL' PICTURE BEHIND CHILD TRAFFICKING| The Real Perpetrators"
## 
## sa "https://rumble.com/v6syinp-destruction-of-the-white-nuclear-family.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-05-04 - length:  1:27:11 - title: "DESTRUCTION OF THE WHITE NUCLEAR FAMILY"
## 
## sa "https://rumble.com/v6t4nh1-who-runs-the-monetary-system-who-has-the-money.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-05-08 - length:    31:33 - title: "WHO RUNS THE MONETARY SYSTEM? Who has the Money"
## 
## sa "https://rumble.com/v6tbgqr-the-underground-world-of-the-elites.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-05-13 - length:    27:54 - title: "THE UNDERGROUND WORLD OF THE ELITES"
## 
## sa "https://rumble.com/v6tvul3-the-enemy-the-ones-you-are-not-allowed-to-talk-aboutt.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-05-26 - length:    10:14 - title: "THE ENEMY | THE ONES YOU ARE NOT ALLOWED TO TALK ABOUTT"
## 
## sa "https://rumble.com/v6u16z7-the-technocrat-billionaires-what-they-want.....html?e9s=src_v1_ucp_a" --language en
## #date: 2025-05-29 - length:    28:59 - title: "THE TECHNOCRAT BILLIONAIRES | What They Want...."
## 
## sa "https://rumble.com/v6u18dv-euthanasia-acces-to-mature-minors-without-parental-consent.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-05-29 - length:     8:31 - title: "EUTHANASIA ACCES TO MATURE 'MINORS' WITHOUT PARENTAL CONSENT"
## 
## sa "https://rumble.com/v6uc9ut-the-palantir-surveillance-dystopia.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-06-05 - length:    46:56 - title: "THE PALANTIR SURVEILLANCE DYSTOPIA"
## 
## sa "https://rumble.com/v6v7ufn-wat-u-altijd-al-hebt-willen-weten-dutch.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-06-23 - length:     4:58 - title: "WAT U ALTIJD AL HEBT WILLEN WETEN (DUTCH) LUISTERBOEK"

## sa "https://rumble.com/v6vq6a7-indoctrination-by-ugly-fat-feminist-or-lesbians-woman.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-07-04 - length:  1:13:24 - title: "INDOCTRINATION BY: UGLY, FAT, FEMINIST OR LESBIANS WOMAN"
## 
## sa "https://rumble.com/v6z15qs-the-global-impact-of-inbreeding.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-09-16 - length:  1:28:00 - title: "THE GLOBAL IMPACT OF INBREEDING"
## 
## sa "https://rumble.com/v6z5b5k-the-khazar-myth.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-09-18 - length:    24:57 - title: "THE KHAZAR MYTH"
## 
## sa "https://rumble.com/v6zq6uo-the-gog-and-magog-prophecy.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-10-01 - length:     7:18 - title: "The Gog and Magog Prophecy"
## 
## sa "https://rumble.com/v70flz0-lgbtq-history-repeates-itself.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-10-17 - length:  1:32:13 - title: "LGBTQ | HISTORY REPEATES ITSELF"
## 
## sa "https://rumble.com/v70fpeq-the-destructive-multiculturalism.html?e9s=src_v1_ucp_a" --language en
## #date: 2025-10-17 - length:    42:56 - title: "THE DESTRUCTIVE MULTICULTURALISM"
## 
## rm BURN_VIDEO2.TXT

## exit
## echo " \\" > add_fix.txt
## echo '	--tags="Climate Change" \' >> add_fix.txt
## echo '	--tags="Scam" \' >> add_fix.txt
## echo '	--tags="Prof Dr. Kees de Lange"' >> add_fix.txt
## 
## saa "https://x.com/ducom99/status/1982055837850902981" --language nl
## 
## exit
## 
## echo " \\" > add_fix.txt
## echo '	--tags="China" \' >> add_fix.txt
## echo '	--tags="DeCode"' >> add_fix.txt
## sa "https://www.youtube.com/watch?v=u9Ji_p0ODKk" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="China" \' >> add_fix.txt
## echo '	--tags="Joe HaTTab"' >> add_fix.txt
## sa "https://www.youtube.com/watch?v=0S0LvVmn_xU" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Boston Dynamics" \' >> add_fix.txt
## echo '	--tags="Atlas" \' >> add_fix.txt
## echo '	--tags="AI Tech Academy"' >> add_fix.txt
## sa "https://www.youtube.com/watch?v=bzKDh6cRe3E" --language en
## 
## exit
## 
## echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## saa "https://x.com/kadmitriev/status/1981393064179470393" --language ru
## rm BURN_VIDEO2.TXT
## 
## exit
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Cafe Weltschmerz"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=8tdWvDssir0" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="AI" \' >> add_fix.txt
## echo '	--tags="Singularity" \' >> add_fix.txt
## echo '	--tags="Peter H. Diamandis"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=VfwNK9OVsrM" --language en
## 
## exit

## echo " \\" > add_fix.txt
## echo '	--tags="Wybren van Haga" \' >> add_fix.txt
## echo '	--tags="BVNL" \' >> add_fix.txt
## echo '	--tags="Haarlem105"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=RwLlCUtLQ7s" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=QXhHAlHvuw0" --language nl # 2025-04-02 -     6:54 - Afscheid Flavio Pasquino van Blckbx
## sa "https://www.youtube.com/watch?v=wvh1LK3jOIg" --language nl # 2025-04-16 -     1:26 - Steun LightHouseTV en bouw mee!
## sa "https://www.youtube.com/watch?v=XQAzfI7kQ-0" --language nl # 2025-04-17 -    20:09 - Flavio Pasquino lanceert LightHouseTV op MVO2025 en zoekt ondernemers met LEF!
## sa "https://www.youtube.com/watch?v=J3zia_lMLT0" --language nl # 2025-04-18 -     3:06 - Dít is LightHouseTV- Steun onze lancering op 5 mei!
## sa "https://www.youtube.com/watch?v=6M3S_gVvyOw" --language nl # 2025-04-25 -     4:14 - Crowdfund uitgelegd: dit doet LightHouseTV met je donaties
## sa "https://www.youtube.com/watch?v=wXg7jgQ2phY" --language nl # 2025-05-02 -     1:01 - We Zijn er (Bijna) Klaar Voor!
## sa "https://www.youtube.com/watch?v=t5dW-X5UpUE" --language nl # 2025-05-05 -    52:05 - LightHouseTV #1: Bevrijdingsdag | Nigel Farage wint met Reform UK | Trumps plan achter handelsoorlog
## sa "https://www.youtube.com/watch?v=_X3b7xFvkug" --language nl # 2025-05-06 -    12:34 - Zijn Bevrijdingsdag en dodenherdenking te verenigen met oorlogen van ons kabinet?
## sa "https://www.youtube.com/watch?v=zXNjo0qZkt8" --language nl # 2025-05-06 -    13:07 - Het economische spel achter Trumps invoerheffingen
## sa "https://www.youtube.com/watch?v=mGaWrdR6FPU" --language nl # 2025-05-07 -  1:02:57 - LightHouseTV #2: Stikstofultimatum Wiersma | Blackrocks bondskanselier | PFAS eieren gevaarlijk?
## sa "https://www.youtube.com/watch?v=nC6HDcSfcCQ" --language nl # 2025-05-07 -    14:26 - Reform UK van Nigel Farage - de man achter Brexit - wint opnieuw in Verenigd Koninkrijk
## sa "https://www.youtube.com/watch?v=-NxrJe2LgK0" --language nl # 2025-05-08 -    15:48 - RIVM adviseert geen particuliere eieren meer te eten. Wijs advies of nieuwe angstcampagne?
## sa "https://www.youtube.com/watch?v=TEXJQA9EIXU" --language nl # 2025-05-08 -    16:15 - Stikstofultimatum en dreigende rechtszaken voor Minister Wiersma als koers niet verandert
## sa "https://www.youtube.com/watch?v=DHi9xYHt5BI" --language nl # 2025-05-08 -    17:20 - Van Blackrock naar Duitse bondskanselier: Friedrich Merz
## sa "https://www.youtube.com/watch?v=T3zXtJAmaGc" --language nl # 2025-05-09 -  1:17:08 - LightHouseTV #3: EU-coronafonds gefileerd | 'Wanhoopsoffensief' CBDC | Toekomst Zaanse Schans
## sa "https://www.youtube.com/watch?v=S4SQ48AXf8M" --language nl # 2025-05-10 -    13:17 - Cultureel erfgoed in gevaar na nieuwe plannen voor Zaanse Schans
## sa "https://www.youtube.com/watch?v=8iEAuyy4XJY" --language nl # 2025-05-10 -    28:00 - ECB versnelt uitrol CBDC – Wat zit er achter deze haast?
## sa "https://www.youtube.com/watch?v=XdrXtqy2PSg" --language nl # 2025-05-11 -    20:45 - Coronaherstelfonds van 800 miljard gefileerd door Europese Rekenkamer
## sa "https://www.youtube.com/watch?v=bwJxPLtt1jQ" --language nl # 2025-05-12 -  1:16:30 - LightHouseTV #4: De aanhoudende oversterfte in Nederland doorgelicht - Wat weten we nu?
## sa "https://www.youtube.com/watch?v=JiRiGi99PHU" --language nl # 2025-05-13 -    21:16 - Duizenden missende doodsoorzaakverklaringen per jaar — CBS registratie faalt
## sa "https://www.youtube.com/watch?v=gMVcq9sr1sg" --language nl # 2025-05-13 -    26:50 - Oversterfte-onderzoek Meester vraagt om antwoorden - waarom blijft actie uit?
## sa "https://www.youtube.com/watch?v=5VD2jW-gakM" --language nl # 2025-05-14 -  1:00:05 - LightHouseTV #5: Dreiging zzp-rechtszaken | Pensioenen onder vuur | Megadeals Trump in Saoedi-Arabië
## sa "https://www.youtube.com/watch?v=i0UphLVUBYo" --language nl # 2025-05-14 -    17:46 - Huisarts onthult hoe Nederlanders vertrouwen kwijtraken in de medische wetenschap
## sa "https://www.youtube.com/watch?v=49Gxpa6K4mo" --language nl # 2025-05-15 -    13:51 - Zzp'ers klagen opdrachtgevers aan voor schijnzelfstandigheid, opdrachtgevers betalen tienduizenden
## sa "https://www.youtube.com/watch?v=S3I4W0im_j4" --language nl # 2025-05-15 -    16:10 - Welke deal van 600 miljard dollar sloot Trump met Saoedi-Arabië?
## sa "https://www.youtube.com/watch?v=XrOPsf-6Q8I" --language nl # 2025-05-16 -  1:09:01 - LightHouseTV #6: BVNL wint WHO-rechtszaak | Politie aan huis demonstranten | 'No-show' Poetin
## 
## echo " \\" > add_fix.txt
## echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
## echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
## echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=JDEwk7O-6rE" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="RichardDWolff" \' >> add_fix.txt
## echo '	--tags="Wolff Responds" \' >> add_fix.txt
## echo '	--tags="globalising"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=QpY4xQk9_8I"  --language en

## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=U-1K9VkKZb4" --language nl # 2025-05-16 -    16:27 - Pensioenwet: Hoe Nederland de controle over 1500 miljard pensioengeld dreigt te verliezen
## sa "https://www.youtube.com/watch?v=HVgrjhxusOQ" --language nl # 2025-05-17 -    14:06 - BVNL wint van overheid in rechtszaak en clasht met minister Agema over pandemieverdrag!
## sa "https://www.youtube.com/watch?v=z4ET8VvQJB0" --language nl # 2025-05-17 -    19:45 - Inspectiedienst tikt politie op de vingers over intimiderend huisbezoek
## sa "https://www.youtube.com/watch?v=q4EwGVovSg4" --language nl # 2025-05-18 -    20:32 - Rutte noemt Poetins 'no show' bij het vredesoverleg een grote fout: "He is in trouble"
## sa "https://www.youtube.com/watch?v=VX9e2qQE2nU" --language nl # 2025-05-19 -  1:20:14 - LightHouseTV #7: Blackouts in Nederland? | Pandemieverdrag en autonomie | Dreigt er een watertekort?
## sa "https://www.youtube.com/watch?v=vEY9aqFBRaA" --language nl # 2025-05-20 -    21:55 - Pandemieverdrag bij WHO-vergadering in Genève: Wat staat Nederland te wachten?
## sa "https://www.youtube.com/watch?v=yTO5rSYsCnE" --language nl # 2025-05-20 -    24:18 - Nederland op weg naar een black-out door energietransitie?

## sa "https://www.youtube.com/watch?v=zSRpdpOtdwg" --language nl # 2025-05-21 -  1:10:36 - LightHouseTV #8: Pandemieverdrag akkoord | Politie negeert Woo | Einde wolfbescherming?
## sa "https://www.youtube.com/watch?v=8YF3GzB4P_c" --language nl # 2025-05-21 -    24:30 - Dreigt er na 2030 een watertekort in Nederland en wat is er nodig?
## sa "https://www.youtube.com/watch?v=vh_VL2AkGwg" --language nl # 2025-05-22 -    17:28 - WHO akkoord over pandemieverdrag: wat zijn de gevolgen?
## sa "https://www.youtube.com/watch?v=CzVFrcbO_T0" --language nl # 2025-05-21 -  1:08:57 - LightHouseTV #8: Pandemieverdrag akkoord | Politie negeert Woo | Einde wolfbescherming?
## sa "https://www.youtube.com/watch?v=QaM_1JvDWl0" --language nl # 2025-05-22 -    20:27 - Wat verandert het EU-besluit nu voor de Nederlandse wolf?
## sa "https://www.youtube.com/watch?v=Q8LzRQflyQo" --language nl # 2025-05-23 -  1:03:52 - LightHouseTV #9: Censuuroorlog EU | Wiersma vs Woo privégegevens boeren | 'Miljardenzwendel' kabinet
## sa "https://www.youtube.com/watch?v=4i5rMx5ozoA" --language nl # 2025-05-23 -    21:21 - Politie negeert Woo én rechterlijk bevel in openbaren van geheime burgerdata
## sa "https://www.youtube.com/watch?v=cDKWxnUTXRo" --language nl # 2025-05-25 -    13:27 - Ontmaskerd: EU's propagandaoorlog van 650 miljoen tegen de vrijheid van meningsuiting
## sa "https://www.youtube.com/watch?v=mtS7R8KtWzM" --language nl # 2025-05-25 -    19:30 - 16 miljard euro ‘verdwenen’ bij Buitenlandse Zaken – Verantwoordingsdag 2025
## sa "https://www.youtube.com/watch?v=qINuzrkK3yA" --language nl # 2025-05-26 -  1:08:53 - LighthouseTV #10: Defensie vs. burger | 'Stikstofdoorbraak' afgeschoten | Geopolitiek voor jongeren
## sa "https://www.youtube.com/watch?v=u129-D5sjZI" --language nl # 2025-05-26 -    21:34 - Minister Wiersma negeert Woo-verzoek voor privacy van boeren
## sa "https://www.youtube.com/watch?v=Zrc9N4htYQI" --language nl # 2025-05-27 -    20:36 - Defensie onthult 57 locaties voor uitbreiding van de krijgsmacht in Nederland
## sa "https://www.youtube.com/watch?v=f79tP_2cAGY" --language nl # 2025-05-27 -    21:20 - Raad van State torpedeert ‘stikstofdoorbraak’ kabinet: FVD komt met meetbaar alternatief
## sa "https://www.youtube.com/watch?v=lKlNO5wpvNo" --language nl # 2025-05-28 -  1:05:15 - LightHouseTV #11: Klimaatexamen | FVD uit coronacommissie | ‘Blanke genocide’: complottheorie?
## sa "https://www.youtube.com/watch?v=n6qEOR2FRM0" --language nl # 2025-05-28 -    15:42 - Mees Wijnants over Kajsa Ollongren, netwerkcorruptie en de nieuwe generatie
## sa "https://www.youtube.com/watch?v=bRZk2JMhFCk" --language nl # 2025-05-29 -    13:14 - Hoe objectief is het Klimaatexamen? Journaliste Danielle van Wallinga deed onderzoek
## sa "https://www.youtube.com/watch?v=bexJ4jp76Uo" --language nl # 2025-05-29 -    14:41 - Waarom de NOS en MSM het geweld op blanke boeren in Zuid-Afrika verzwijgen
## sa "https://www.youtube.com/watch?v=w4Ee80RFgg8" --language nl # 2025-05-29 -    21:45 - Mini docu: "Kill the Boer”. Genocide – ja of nee?
## sa "https://www.youtube.com/watch?v=U0qEBOmzq3M" --language nl # 2025-05-29 -    24:14 - Waarom Gideon van Meijeren uit de parlementaire enquêtecommissie corona stapte
## sa "https://www.youtube.com/watch?v=mnP1D1SxsoA" --language nl # 2025-05-30 -  1:43:12 - LightHouseTV #12: Trumps Golden Dome | RFK Jr. onder vuur! | Moskou dreigt na wapensteun
## 
## echo " \\" > add_fix.txt
## echo '	--tags="🐇" \' >> add_fix.txt
## echo '	--tags="The White Rabbit Podcast"' >> add_fix.txt
## 
## saa "https://x.com/AllBiteNoBark88/status/1973204968401412501" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="RadioGenoa" \' >> add_fix.txt
## echo '	--tags="UK" \' >> add_fix.txt
## echo '	--tags="censorship"' >> add_fix.txt
## 
## sa "https://x.com/nogulagsagain/status/1972645818768519567" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=7PyE0eis0UY" --language nl # 2025-05-31 -    20:22 - Kennedy’s MAHA-rapport onder vuur - Spiegelbeeld Magazine over alternatieve kijk op gezondheid
## sa "https://www.youtube.com/watch?v=uYUHWA8X5I0" --language nl # 2025-05-31 -    31:55 - Felle Russische reactie op Duitse steun bij productie Taurus-raketten voor Oekraïne
## 
## echo " \\" > add_fix.txt
## echo '	--tags="blckbx" \' >> add_fix.txt
## echo '	--tags="Piratenpartij" \' >> add_fix.txt
## echo '	--tags="Matthijs Pontie"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=5FxGADJiz-s" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Carl Jung" \' >> add_fix.txt
## echo '	--tags="The Silent War"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=uOa7SR6o_hI" --language en
## 
## echo '	--tags="Jordan Peterson" \' >> add_fix.txt
## echo '	--tags="Empaths"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=iQ8oTXlhfcw" --language en
## 
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=OdQBVn6AC8I" --language nl # 2025-06-01 -    23:34 - Start Trump met zijn 'Golden Dome' een wapenwedloop in de ruimte?
## sa "https://www.youtube.com/watch?v=aRuwgfmvYHo" --language nl # 2025-06-02 -  1:14:36 - LightHouseTV #13: Einde kabinet? | Oversterfte: NL vs Bulgarije | Oekraïne toch bij de NAVO?
## sa "https://www.youtube.com/watch?v=g_ShcLs6MW8" --language nl # 2025-06-03 -    18:52 - Einde kabinet? Wilders zinspeelt op vertrek na crisisoverleg
## sa "https://www.youtube.com/watch?v=FLMNU1q6ZNc" --language nl # 2025-06-03 -    19:16 - Ondersterfte in Bulgarije vs oversterfte in Nederland - hoe kan dit?
## sa "https://www.youtube.com/watch?v=cKrSo4Frg-M" --language nl # 2025-06-04 -  1:18:28 - LightHouseTV #14: Val kabinet: hoe nu verder? | Monetaire 'big reset' | 'Ruslands Pearl Harbor'
## sa "https://www.youtube.com/watch?v=ydb6MfVuym0" --language nl # 2025-06-04 -    19:01 - Waarom komen de nieuwe media in België zo traag op gang?
## sa "https://www.youtube.com/watch?v=hcO9FPWwzDQ" --language nl # 2025-06-05 -    15:04 - Wie zit er achter de drone-aanval die 'Ruslands Pearl Harbor' wordt genoemd?
## sa "https://www.youtube.com/watch?v=ePl3WZ2O5bo" --language nl # 2025-06-05 -    38:00 - 29 oktober verkiezingen! Hoe komt NL uit impasse na val kabinet?
## sa "https://www.youtube.com/watch?v=NyzP86q_BK8" --language nl # 2025-06-06 -  1:21:26 - LightHouseTV #15: Breuk Trump & Musk | Bespioneerd door META | Landbouw vogelvrij na val kabinet?
## sa "https://www.youtube.com/watch?v=LwPkih6-hSw" --language nl # 2025-06-06 -    15:12 - Dedollarisatie, afkalvende middenklasse en ‘de grote reset’ met monetair econoom Brecht Arnaert
## sa "https://www.youtube.com/watch?v=TsVVyShYj-g" --language nl # 2025-06-07 -    18:23 - Ongelooflijke ruzie Musk en Trump: wat speelt er écht?
## sa "https://www.youtube.com/watch?v=5SY-YZc4FXI" --language nl # 2025-06-07 -    20:11 - Facebook en Instagram bespioneren Android-gebruikers via achterdeur
## sa "https://www.youtube.com/watch?v=oAR_ZnD4b30" --language nl # 2025-06-08 -    28:50 - Val kabinet luidt dramatische periode in voor Wiersma en de boeren
## sa "https://www.youtube.com/watch?v=_ZRYI3tRu8Q" --language nl # 2025-06-09 -  1:32:38 - LightHouseTV #16: Burgers houden grenscontroles Ter Apel | Noodwet Defensie | 'Asielcrisis in beeld'
## sa "https://www.youtube.com/watch?v=T6fsc5nqbEQ" --language nl # 2025-06-09 -  2:24:45 - Livestream Demonstratie AZC Dordrecht
## sa "https://www.youtube.com/watch?v=H4JX_xS-oz8" --language nl # 2025-06-10 -    23:05 - Burgercontrole bij grens Ter Apel: actievoerder sluit nieuwe acties niet uit
## sa "https://www.youtube.com/watch?v=ZSV8ctryI2o" --language nl # 2025-06-10 -    34:44 - ‘Noodwet’ in de maak: Defensie wil uitzonderlijke bevoegdheden
## sa "https://www.youtube.com/watch?v=lrumaOaUvKo" --language nl # 2025-06-11 -  1:24:49 - LightHouseTV #17: Weigert Kiev dodenruil? | Wilders grootste na uitsluiting! | Preppen in crisistijd
## sa "https://www.youtube.com/watch?v=YvmHzOSGdTE" --language nl # 2025-06-11 -    26:43 - Docu: 'De Nederlandse asielcrisis in beeld’ over extra AZC’s in Brabant
## sa "https://www.youtube.com/watch?v=j_C-_7gdj6Q" --language nl # 2025-06-12 -    15:53 - Koelwagens vol gesneuvelde soldaten aan de Oekraïense grens 'geweigerd' door Zelensky
## sa "https://www.youtube.com/watch?v=rWgUGmqyX-I" --language nl # 2025-06-12 -    28:00 - Wilders wéér de grootste, maar mag niet regeren — Kan ons politieke systeem nog functioneren?
## sa "https://www.youtube.com/watch?v=tT89Xlyyyrw" --language nl # 2025-06-13 -  1:03:09 - LightHouseTV #18: Arrestatie 'soevereinen' | Bilderberg | WOIII Iran vs Israël? | Machtsspel China
## sa "https://www.youtube.com/watch?v=KAYU_-zNo28" --language nl # 2025-06-13 -    21:07 - Preppen voor noodscenario's. Paniekzaaierij of gezonde zelfredzaamheid?
## sa "https://www.youtube.com/watch?v=G_DuS0NSDVs" --language nl # 2025-06-14 -    17:25 - Israël slaat toe in Iran: dreigt een nucleaire escalatie?
## sa "https://www.youtube.com/watch?v=vf7MPF0TALg" --language nl # 2025-06-14 -     9:43 - Arno van Kessel, advocaat die tegen Rutte en Gates procedeert, zelf gearresteerd
## sa "https://www.youtube.com/watch?v=adBPPp1gk_I" --language nl # 2025-06-15 -    15:51 - EU’s afhankelijkheid pijnlijk blootgelegd na grondstoffendeal VS & China
## sa "https://www.youtube.com/watch?v=N5BMmf6LzMg" --language nl # 2025-06-16 -  1:31:37 - LightHouseTV #19: Iran vs Israël | Wie draait op voor NAVO-norm? | Rode Lijn demonstratie Den Haag
## sa "https://www.youtube.com/watch?v=5btj17R_7CY" --language nl # 2025-06-17 -    24:40 - Iran slaat terug: raketaanvallen raken Israëlische steden
## sa "https://www.youtube.com/watch?v=HVPHfGIVO_o" --language nl # 2025-06-17 -    29:26 - Demissionair kabinet wil 5% van de economie naar Defensie - wie draait hiervoor op?
## sa "https://www.youtube.com/watch?v=CD3e9kB1s2U" --language nl # 2025-06-18 -  1:34:34 - LightHouseTV #20: Valt Trump Iran aan? | Gevreesde rellen bij NAVO-top | Partijverbod op de loer?
## sa "https://www.youtube.com/watch?v=-coLRhTBlRM" --language nl # 2025-06-18 -    23:54 - ‘Rode Lijn-protest’ met 150.000 Gaza-demonstranten roept vragen op
## sa "https://www.youtube.com/watch?v=_V0CO2R54ic" --language nl # 2025-06-19 -    23:29 - Nieuw wetsvoorstel geeft ruimte aan verbod op politieke partijen
## sa "https://www.youtube.com/watch?v=_syUExogh8c" --language nl # 2025-06-19 -    27:31 - Valt Amerika Iran aan en breekt Trump zijn belofte?
## sa "https://www.youtube.com/watch?v=jAEqhks_5g4" --language nl # 2025-06-20 -  1:07:46 - LightHouseTV #21: 'Absurde' Israël-motie GL-PvdA | NAVO-top vs parlement | Klimaatdoelen 2050
## 
## echo " \\" > add_fix.txt
## echo '	--tags="planned obsolescence"' >> add_fix.txt
## 
## saa "https://x.com/itsme_urstruly/status/1974074980926415206" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Reiner Fuellmich" \' >> add_fix.txt
## echo '	--tags="Arno van Kessel"' >> add_fix.txt
## 
## saa "https://x.com/FreeFuellmich/status/1970923486114988254" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=cY3XmC4ClBs" --language nl # 2025-06-20 -    24:51 - NAVO-top ‘vreest’ voor rellen na groots aangekondigde demonstraties!
## 
## echo " \\" > add_fix.txt
## echo '	--tags="mandatory" \' >> add_fix.txt
## echo '	--tags="consent"' >> add_fix.txt
## 
## saa "https://www.facebook.com/100069189664601/videos/1266740845138269" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=UUT1LZEgKvY" --language nl # 2025-06-21 -    19:48 - Klimaatneutraal in 2050: Europese ‘Net Zero-droom’ dreigt nachtmerrie te worden
## sa "https://www.youtube.com/watch?v=kHCaP4RLCCw" --language nl # 2025-06-21 -    20:36 - Timmermans wil Iron Dome schrappen: ‘Israëlische burgers zijn hier zelf verantwoordelijk voor’
## sa "https://www.youtube.com/watch?v=D2aEHzuSG9c" --language nl # 2025-06-22 -    15:37 - Waarom Eerste Kamerlid Eric Kemperman brak met BBB
## sa "https://www.youtube.com/watch?v=38Byx5oEMkE" --language nl # 2025-06-23 -  1:15:28 - LightHouseTV #22: Aanval VS-Iran | Vooruitblik NAVO-top & 'Russische dreiging' | Opstand AZC De Bilt
## sa "https://www.youtube.com/watch?v=-GYFqtGQ_fc" --language nl # 2025-06-24 -    18:39 - Trump slaat toe met gewaagde 'Top Gun'-operatie in Iran
## sa "https://www.youtube.com/watch?v=15wI-f6Z7bU" --language nl # 2025-06-24 -    22:10 - NAVO-top van start: overschatten we 'de Russische dreiging'?
## sa "https://www.youtube.com/watch?v=7_2Jwp4fF6M" --language nl # 2025-06-25 -  1:24:15 - LightHouseTV #23: VS-aanval Iran 'mislukt' | Nepnieuws-claim tegen NOS | NAVO-top voorbij: en nu?
## sa "https://www.youtube.com/watch?v=DlbjG-AiX54" --language nl # 2025-06-25 -    23:49 - AZC De Bilt slaat in als een bom: ‘Honderden jonge mannen uit Eritrea en Syrië op komst!’
## sa "https://www.youtube.com/watch?v=IpGCe81NwOM" --language nl # 2025-06-26 -    21:25 - NAVO-top ten einde: lidstaten moeten verantwoording gaan afleggen aan de NAVO over 5%-norm
## sa "https://www.youtube.com/watch?v=0amoV8arkUo" --language nl # 2025-06-26 -    22:08 - Plottwist na Iran-aanval: Pentagon-lek stelt dat ‘uranium grotendeels intact’ bleef - Trump ontkent
## sa "https://www.youtube.com/watch?v=IbyoC5nsIaM" --language nl # 2025-06-27 -  1:27:40 - LightHouseTV #24: Bijensterfte door 5G? | Zelensky & Ursula's "full-scale war" | Analyse NAVO-top
## sa "https://www.youtube.com/watch?v=nEctK-HBf68" --language nl # 2025-06-27 -    22:25 - NOS weigert rectificatie na 'nepnieuws' over migratiepolitiek in Italië
## sa "https://www.youtube.com/watch?v=gHGTmsZFciU" --language nl # 2025-06-28 -    23:42 - Wat als Nederland de NAVO verlaat? Een alternatief plan
## sa "https://www.youtube.com/watch?v=lMsIRnCJw20" --language nl # 2025-06-28 -    25:40 - Wat doodt onze bijen? 5G, pesticiden en andere factoren onder de loep
## sa "https://www.youtube.com/watch?v=BYJbvnNGLiw" --language nl # 2025-06-29 -    18:59 - Zelensky en Ursula von der Leyens "full-scale war"
## sa "https://www.youtube.com/watch?v=hs_q_GgPMss" --language nl # 2025-06-30 -  1:22:11 - LightHouseTV #25: prof. kraakt coronamaatregelen | AZC-demo Haarlem | Parkeerverbod eigen oprit?
## sa "https://www.youtube.com/watch?v=knTyrFZ8-1s" --language nl # 2025-07-01 -    13:26 - 'Ze kunnen de pleuris krijgen!' - AZC-demo in Haarlem zet demonstranten lijnrecht tegenover elkaar
## sa "https://www.youtube.com/watch?v=erMQQh1q8QE" --language nl # 2025-07-01 -    19:49 - Parkeren op je eigen oprit op de tocht
## sa "https://www.youtube.com/watch?v=IMUOME_LHvE" --language nl # 2025-07-01 -    25:30 - Prof. Schippers en 36 wetenschappers publiceren vernietigend onderzoek naar coronabeleid
## sa "https://www.youtube.com/watch?v=y6mCvLMz5LQ" --language nl # 2025-07-02 -  1:20:51 - LightHouseTV #26: Defensie onteigent boeren | 'stop hypotheekrenteaftrek' | Dienstplicht offensief
## sa "https://www.youtube.com/watch?v=kKFRG_rgwUY" --language nl # 2025-07-02 -    19:14 - AZC in Haarlem? Buurtbewoners sterk verdeeld over plannen
## sa "https://www.youtube.com/watch?v=yRvlDIOYdBI" --language nl # 2025-07-03 -    22:05 - Herinvoering dienstplicht voor onder andere asielzoekers?
## sa "https://www.youtube.com/watch?v=A9-be6ACdYA" --language nl # 2025-07-03 -    28:28 - Defensie onteigent: boeren raken land, bedrijf en huis kwijt
## sa "https://www.youtube.com/watch?v=jlIn0i5nyvg" --language nl # 2025-07-04 -  1:12:01 - LightHouseTV #27: AI, financiële vrijheid en gezondheid - Hoe willen we het dan wél?
## sa "https://www.youtube.com/watch?v=Dd6FzgeOoc4" --language nl # 2025-07-04 -    16:05 - Ambtenaren willen hypotheekrenteaftrek schrappen - huizenmarkt op kantelpunt?
## sa "https://www.youtube.com/watch?v=KIdajkqgDdI" --language nl # 2025-07-05 -    16:25 - Trumps AI-plan geblokkeerd! Hoeveel controle willen wij op AI?
## sa "https://www.youtube.com/watch?v=DxJ11oPOheM" --language nl # 2025-07-05 -    22:02 - FBI ontdekt grootste medische fraude ooit in VS: 15 miljard aan valse zorgclaims
## sa "https://www.youtube.com/watch?v=Pk5SKs9g9WA" --language nl # 2025-07-06 -    20:34 - Hoe ontsnap je uit ‘de financiële piramide van de elite?’
## sa "https://www.youtube.com/watch?v=wcbBy0pdWV8" --language nl # 2025-07-07 -  1:16:08 - LightHouseTV #28: BRICS-top: Global South vs. het Westen: wie wint de strijd om werelddominantie?
## sa "https://www.youtube.com/watch?v=G-Zj7w9-vrU" --language nl # 2025-07-08 -    14:45 - Hoe Europa zichzelf buiten spel zet
## sa "https://www.youtube.com/watch?v=Miw1UN-OCLg" --language nl # 2025-07-08 -    26:20 - BRICS-top rekent af met Westerse ‘Golden Billion’ en bouwt nieuwe veiligheidsorde
## sa "https://www.youtube.com/watch?v=Ti2e2GS9KLU" --language nl # 2025-07-09 -  1:39:13 - LightHouseTV #29: Baudet over NEXIT | Verslag rechtszaak Bill Gates | Sanering garnalenvissers
## sa "https://www.youtube.com/watch?v=RbP6H0H3rEU" --language nl # 2025-07-09 -    21:42 - Waarom Iran bij de BRICS Amerika grote zorgen baart
## sa "https://www.youtube.com/watch?v=q5bdH5iP9Jo" --language nl # 2025-07-10 -    19:12 - Demissionair kabinet ‘draait visserij de nek om’
## sa "https://www.youtube.com/watch?v=XBg9KskDL7I" --language nl # 2025-07-10 -    21:05 - Verslag van de rechtszaak in Leeuwarden tegen Bill Gates, Rutte, Koopmans en andere hoofdrolspelers
## sa "https://www.youtube.com/watch?v=3jFcMdDH1tQ" --language nl # 2025-07-11 -  1:48:40 - LightHouseTV #30: Seizoensafsluiter! – De rol van nieuwe media: wat kunnen we en wat móeten we doen?
## sa "https://www.youtube.com/watch?v=2NjYeN5y8aQ" --language nl # 2025-07-11 -    36:27 - Thierry Baudet presenteert plan voor een succesvolle Nexit
## sa "https://www.youtube.com/watch?v=OAUw9AvNH8E" --language nl # 2025-07-12 -    22:49 - DPG vergroot 'mediamonopolie' na overname RTL: vrije pers verder onder druk?
## sa "https://www.youtube.com/watch?v=y6YL2b2DOg0" --language nl # 2025-07-13 -    15:32 - Wat staat ons te doen als je de agenda's doorziet?
## sa "https://www.youtube.com/watch?v=PAnX8CuR0RE" --language nl # 2025-07-13 -    25:18 - Waarom alternatieve media zijn begonnen naast MSM
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Doug Macgregor" \' >> add_fix.txt
## echo '	--tags="Daniel Davis" \' >> add_fix.txt
## echo '	--tags="Deep Dive"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=aqkUlZH-c0E" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=zNhSvjRXo8c" --language nl # 2025-07-14 -    59:11 - Coen Vermeeren: 'Het TU Delft- & 9/11-dossier', #1
## sa "https://www.youtube.com/watch?v=s_Dc0ZNCrTk" --language nl # 2025-07-16 -    53:08 - Documentaire 'The Agenda' - Deel 1  (Nederlands ondertiteld)
## sa "https://www.youtube.com/watch?v=0A5zE5EYGt0" --language nl # 2025-07-18 -  1:05:20 - Documentaire 'The Agenda' - Deel 2 (Nederlands ondertiteld)
## sa "https://www.youtube.com/watch?v=4oz7xIq-x4Q" --language nl # 2025-07-21 -    54:11 - Coen Vermeeren: 'Ufo's bestaan gewoon', #2
## sa "https://www.youtube.com/watch?v=yh2bD3gAAa4" --language nl # 2025-07-23 -    34:23 - Kees Faasse, het eerste corona-interview in 2020
## sa "https://www.youtube.com/watch?v=Kje3T9qOGQA" --language nl # 2025-07-25 -    25:06 - Kees Faasse 5 jaar later
## sa "https://www.youtube.com/watch?v=z023sEM4yh4" --language nl # 2025-07-28 -    45:26 - Coen Vermeeren: 'Elites & Valse Goden', #3
## 
## echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## ## 
## echo " \\" > add_fix.txt
## echo '	--tags="MORAL CORRUPTION" \' >> add_fix.txt
## echo '	--tags="LHBTQ" \' >> add_fix.txt
## echo '	--tags="SEXUALIZATION"' >> add_fix.txt
## 
## saa "https://rumble.com/v5hscwi-a-history-of-sexualization-and-moral-corruption-of-twentieth-century-german.html" --language en
## 
## rm BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=NppChX2Wh3U" --language nl # 2025-07-30 -    20:40 - Wendy Kroeze, alias 'Het Bloemenmeisje', 5 jaar geleden
## sa "https://www.youtube.com/watch?v=hRla9Z5Ehkw" --language nl # 2025-08-01 -    26:57 - Wendy Kroeze,  Het Bloemenmeisje, vijf jaar later
## sa "https://www.youtube.com/watch?v=zHwctu23o3I" --language nl # 2025-08-04 -    55:19 - Coen Vermeeren: 'De Chemtrailagenda', #4
## sa "https://www.youtube.com/watch?v=jZVtRwHK01g" --language nl # 2025-08-06 -    19:52 - Anja Brokken, vijf jaar geleden
## sa "https://www.youtube.com/watch?v=Ahyfp9D9OBA" --language nl # 2025-08-08 -    19:41 - Anja Brokken, 5 jaar later
## sa "https://www.youtube.com/watch?v=cMesX-2uJvE" --language nl # 2025-08-11 -    34:44 - Klinisch ethicus dr. Erwin Kompanje, vijf jaar geleden
## sa "https://www.youtube.com/watch?v=HnpLnuS6vdc" --language nl # 2025-08-13 -  1:25:15 - LightHouseTV #31: Trump clasht met EU & Zelensky | Einde open internet | EU-handelsakkoord

## echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="MORAL CORRUPTION" \' >> add_fix.txt
## echo '	--tags="LHBTQ" \' >> add_fix.txt
## echo '	--tags="SEXUALIZATION"' >> add_fix.txt
## 
## saa "https://rumble.com/v5hscwi-a-history-of-sexualization-and-moral-corruption-of-twentieth-century-german.html" --language en
## 
## rm BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=ztimyYvypGE" --language nl # 2025-08-14 -    19:51 - De 'nederlaag' van von der Leyen in 'the biggest deal ever' met Trump
## sa "https://www.youtube.com/watch?v=rQDbD-1S6lI" --language nl # 2025-08-14 -    23:10 - Zelensky en EU buitenspel bij Trumps vredesgesprek met Poetin: ‘EU is toeschouwer!’
## sa "https://www.youtube.com/watch?v=NkERHujOwRg" --language nl # 2025-08-15 -  1:40:40 - LightHouseTV #32: Voorbeschouwing en analyse historische vredesbespreking van Trump-Poetin in Alaska
## sa "https://www.youtube.com/watch?v=JUjc3Th6QE8" --language nl # 2025-08-15 -    18:15 - Einde open internet door 'Online Safety Act' in Verenigd Koninkrijk

## echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="911"' >> add_fix.txt
## 
## # saf_911 "102 Minutes That Changed America 15th Anniversary Edition.mkv" --language en
## # saf_911 "102 Minutes That Changed America.avi" --language en
## # saf_911 "15 Septembers Later 2016.mkv" --language en
## # saf_911 "15 Years Later 2016.mkv" --language en
## saf_911 "16 Acres The Struggle to Rebuild Ground Zero.mkv" --language en
## saf_911 "1st hit 2002 cbs version.avi" --language en
## saf_911 "1st hit 2006 version.avi" --language en
## saf_911 "1st hit dvd version.avi" --language en
## saf_911 "2002 cbs version.avi" --language en
## saf_911 "2006 extra content.avi" --language en
## saf_911 "2006 version.avi" --language en
## saf_911 "2nd hit 2002 cbs version.avi" --language en
## saf_911 "2nd hit 2006 version.avi" --language en
## saf_911 "2nd hit dvd version.avi" --language en
## saf_911 "910 The Final Hours.mkv" --language en
## saf_911 "911 After the Towers Fell.avi" --language en
## saf_911 "911 - Control the Skies 2019.mkv" --language en
## saf_911 "911 Crime Scene Investigators.avi" --language en
## saf_911 "9 11 Emergency Room.mp4" --language en
## saf_911 "911 Firehouse Ground Zero.avi" --language en
## saf_911 "9-11 Inside Air Force One 2019.mkv" --language en
## saf_911 "911 Inside the Pentagon 2016 (2).mkv" --language en
## saf_911 "911 Inside the Pentagon 2016.mkv" --language en
## saf_911 "911 Remembered  A Day of Infamy.mp4" --language en
## saf_911 "911 Rescue Cops.mp4" --language en
## saf_911 "911 Science and Conspiracy.mkv" --language en
## saf_911 "9 11 State of Emergency 2010.mkv" --language en
## saf_911 "9-11 The Final Minutes of Flight 93 2020.mkv" --language en
## saf_911 "911 The Heartland Tapes.mkv" --language en
## saf_911 "911 The Lost Tapes.avi" --language en
## saf_911 "911 The Woman Who Wasn't There.mkv" --language en
## saf_911 "9-11 Timeline Of Terror.avi" --language en
## saf_911 "911 Washington Under Attack.avi" --language en
## saf_911 "911 Where Were You.mp4" --language en
## saf_911 "Air Crash Investigation S16E02 911 The Pentagon Attack.avi" --language en
## saf_911 "Americas 911 Flag Rise From The Ashes 2016.mkv" --language en
## saf_911 "BBC That September Day 2011.mkv" --language en
## saf_911 "Beyond 911 Portraits of Resilience.mp4" --language en
## saf_911 "Boatlift - An Untold Tale of 9 11.mp4" --language en
## saf_911 "Brothers on Holy Ground 911.mp4" --language en
## saf_911 "Ch4 Children of 911 Our Story.mkv" --language en
## saf_911 "Days That Shaped America 911.mkv" --language en
## saf_911 "Giuliani  Commanding 911.mp4" --language en
## saf_911 "Ground Zero - Shockin 911.mp4" --language en
## saf_911 "Heroes of 9 11.mp4" --language en
## saf_911 "History Channel  911 the Days After 1.mp4" --language en
## saf_911 "History Channel  911 the Days After 2.mp4" --language en
## saf_911 "History Channel  911 the Days After 3.mp4" --language en
## saf_911 "History Channel  911 the Days After 4.mp4" --language en
## saf_911 "History Channel  911 the Days After 5.mp4" --language en
## saf_911 "History Channel  911 the Days After 6.mp4" --language en
## saf_911 "hoppa" --language en
## saf_911 "In Memoriam New York City  911 2002.mp4" --language en
## saf_911 "I Survived.. 9 11.mp4" --language en
## saf_911 "ITV 911 Life Under Attack.mkv" --language en
## saf_911 "itv - 911 The Day That Changed The World [MP4-AAC](oan).mp4" --language en

## rm "BURN_VIDEO2.TXT"
## echo " \\" > add_fix.txt
## echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
## echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
## echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=MSOdM_JSt5g" --language nl

echo " \\" > add_fix.txt
echo '	--tags="911"' >> add_fix.txt

echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT

## saf_911 "National Geographic Inside 9-11 Witness DC 9-11.mkv" --language en
## saf_911 "NG 9 11 One Day in America 1of6 First Response.mkv" --language en
## saf_911 "NG 9 11 One Day in America 2of6 The South Tower.mkv" --language en
## saf_911 "NG 9 11 One Day in America 3of6 Collapse.mkv" --language en
## saf_911 "NG 9 11 One Day in America 4of6 The Cloud.mkv" --language en
## saf_911 "NG 9 11 One Day in America 5of6 I'm Coming for You Brother.mkv" --language en
## saf_911 "NG 9 11 One Day in America 6of6 It's All Gone Kid.mkv" --language en
## saf_911 "PBS 9-11 Emergency Room.mkv" --language en
## saf_911 "PBS 911 Escape from the Impact Zone.mkv" --language en
## saf_911 "President George W. Bush  The 911 Interview.mp4" --language en
## saf_911 "Rising Rebuilding Ground Zero 1of6 Reclaiming the Skyline 1.avi" --language en
## saf_911 "Rising Rebuilding Ground Zero 2of6 Reclaiming the Skyline 2.avi" --language en

## saf_911 "Rising Rebuilding Ground Zero 3of6 A Gateway to New York.avi" --language en
## saf_911 "Rising Rebuilding Ground Zero 4of6 A New City.avi" --language en
## saf_911 "Rising Rebuilding Ground Zero 5of6 Stories from the Pile.avi" --language en
## saf_911 "Rising Rebuilding Ground Zero 6of6 A Place to Mourn.avi" --language en
## 
## rm "BURN_VIDEO2.TXT"
## echo " \\" > add_fix.txt
## echo '	--tags="FIRST AMMENDEMENT"' >> add_fix.txt 
## 
## saa "https://x.com/GoldRepublic/status/1976596503314551036" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="911"' >> add_fix.txt
## 
## echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## 
## saf_911 "Seconds From Disaster S01E13 Pentagon 911.avi" --language en
## saf_911 "Seconds from Disaster S04E01 911.avi" --language en
## saf_911 "September 11 2001 Tribute (15 years later).mp4" --language en
## saf_911 "September 11th As It Happened  The Definitive Live News Montage.mp4" --language en
## saf_911 "Smithsonian 911 Stories In Fragments.mkv" --language en
## saf_911 "The 911 Surfer.mp4" --language en
## saf_911 "The Air Traffic Controllers of 911.mp4" --language en
## saf_911 "The Day that Shook the World.mp4" --language en
## saf_911 "The Last Hour of Flight 11.mp4" --language en
## saf_911 "The Last Secrets of 911.mp4" --language en
## saf_911 "the Miracle of Stairwell B.mp4" --language en
## saf_911 "Voices From Inside the Towers 2011.mkv" --language en
## saf_911 "VTS_01_1.VOB" --language en
## saf_911 "VTS_01_2.VOB" --language en
## saf_911 "VTS_01_4.VOB" --language en
## saf_911 "VTS_01_5.VOB" --language en
## saf_911 "World Trade Center Anatomy of the Collapse.mkv" --language en
## 
## rm BURN_VIDEO2.TXT
## 
## exit

## echo " \\" > add_fix.txt
## echo '	--tags="TPV Sean" \' >> add_fix.txt
## echo '	--tags="chemtrails"' >> add_fix.txt
## 
## saa "https://x.com/tpvsean/status/1978171985973698789" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="RUTTE" \' >> add_fix.txt
## echo '	--tags="INSANE" \' >> add_fix.txt
## echo '	--tags="NATO"' >> add_fix.txt
## 
## echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## saa "https://x.com/PMG_RIP/status/1978219312696451243" --language ru
rm BURN_VIDEO2.TXT

echo " \\" > add_fix.txt
echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=KguBGXYudQg" --language nl # 2025-08-16 -    18:59 - Hoe de wereld eruit kan zien na een Trump/Poetin-deal: vrede of Koude Oorlog?
## sa "https://www.youtube.com/watch?v=2_VAhchMUYU" --language nl # 2025-08-16 -    21:56 - Trump & Poetin ontmoeten elkaar in Alaska
## sa "https://www.youtube.com/watch?v=6yGke2EIvPI" --language nl # 2025-08-18 -  1:36:13 - LightHouseTV #33: Slikt Zelensky Trumps voorstel? | ‘Moestuinpolitie’ | Update Arno van Kessel
## sa "https://www.youtube.com/watch?v=--XE1Iuyexk" --language nl # 2025-08-18 -    28:32 - Van Haga (BVNL): ‘Nederland en Europa buiten spel bij Trump/Poetin onderhandelingen’
## sa "https://www.youtube.com/watch?v=MOPKHbB4ak0" --language nl # 2025-08-19 -    24:53 - ‘Krim opgeven en geen NAVO’: accepteert Oekraïne de deal van Trump en Poetin?
## sa "https://www.youtube.com/watch?v=r7NV1liDXrc" --language nl # 2025-08-19 -    29:55 - Vraagtekens bij nieuwe informatie rond opgepakte advocaat Arno van Kessel
## sa "https://www.youtube.com/watch?v=YI098qxVzAk" --language nl # 2025-08-20 -  1:34:00 - LightHouseTV #34: "EU bedreigt pers" | Gesprek Poetin & Zelensky? | Verkiezingsupdate Bert Brandsma

## sa "https://www.youtube.com/watch?v=938fQ1GND7s" --language nl # 2025-08-20 -    15:31 - Moestuin? Gelekt politie-document toont 'verdachte' complotdenkers
## 
## echo EDIT SCRIPT, PRESS ANY KEY 
## read aaa
## 
## sa "https://www.youtube.com/watch?v=nfCTpu6w8lo" --language nl # 2025-08-21 -    19:17 - Eerste partijprogramma’s onthuld: met deze standpunten begint de strijd om jouw stem
## sa "https://www.youtube.com/watch?v=WhnO5I3hR-I" --language nl # 2025-08-21 -    29:26 - Sietske Bergsma vs. Thomas Bruning (NVJ) over 'bedreigende' European Media Freedom Act
## sa "https://www.youtube.com/watch?v=9AGhodaG5GI" --language nl # 2025-08-22 -  1:17:51 - LightHouseTV #35: Defensiespecial – Militaire wervingscampagnes & 'schaduwzijde' Nederlandse missies
## sa "https://www.youtube.com/watch?v=6q0NJObaK_M" --language nl # 2025-08-22 -    20:25 - Wat bespraken Trump, Zelensky en de EU-leiders in Het Witte Huis?
## sa "https://www.youtube.com/watch?v=KRQkKobYf4c" --language nl # 2025-08-23 -    19:08 - Zó verleidt Defensie jongeren om het leger in te gaan
## sa "https://www.youtube.com/watch?v=0390WGuFpRg" --language nl # 2025-08-23 -    22:36 - Austin Fitts & Dekker: Waarom ondanks potentiële vredesdeal tientallen miljarden naar Defensie gaan
## sa "https://www.youtube.com/watch?v=P4QY5TsYn8Q" --language nl # 2025-08-24 -    21:50 - Veteranen delen schaduwzijde buitenlandse missies Nederland
## sa "https://www.youtube.com/watch?v=QRVA4X5JiRY" --language nl # 2025-08-25 -  1:46:54 - Van moord tot campagne | NAVO-taks en dienstplicht CDA | Nederlandse democratie muurvast?
## sa "https://www.youtube.com/watch?v=Q1PlBF-q74A" --language nl # 2025-08-26 -    28:49 - Henk Vermeer (BBB) vs. Bob de Wit – zit Nederland democratisch muurvast?
## sa "https://www.youtube.com/watch?v=rmxlm-kVrUI" --language nl # 2025-08-26 -    34:03 - Nederland in shock door tragische moord op Lisa (17)

## sa "https://www.youtube.com/watch?v=eerJ0FEt9nE" --language nl # 2025-08-27 -  1:15:41 - CDA: "Veiligheid is niet gratis" | Geheime aanschaf Palantir? | Massale deportaties VK | LHTV#37
## sa "https://www.youtube.com/watch?v=IILYK6Zwfhs" --language nl # 2025-08-27 -    25:19 - Vrijheidsbijdrage en 'dienstplicht' in verkiezingsprogramma CDA
## sa "https://www.youtube.com/watch?v=V0dm1_f-XHE" --language nl # 2025-08-28 -    16:46 - Waarom doet de Nederlandse overheid sinds 2011 geheimzinnig over data-analyse Palantir?
## sa "https://www.youtube.com/watch?v=Cz13CTTuPCg" --language nl # 2025-08-28 -    19:21 - Hoogleraren leggen partijprogramma’s onder het mes: maken ze de economie beter of kapot?
## sa "https://www.youtube.com/watch?v=dAirEQ8jZ6o" --language nl # 2025-08-29 -  1:08:15 - Gevaar nieuwe prikrondes | Mona Keijzer belt Flavio | Blies Oekraïne Nord Stream op? – LHTV #38
## sa "https://www.youtube.com/watch?v=A-G9BHdXhMs" --language nl # 2025-08-29 -    19:05 - Nigel Farage (Reform UK)  kondigt massale deportaties aan
## sa "https://www.youtube.com/watch?v=G6zoyP61T18" --language nl # 2025-08-30 -    13:05 - Gevaren van nieuwe coronaprikrondes
## sa "https://www.youtube.com/watch?v=MlrwIa36PsQ" --language nl # 2025-08-30 -    21:04 - Mona Keijzer aan de tand gevoeld door Tom de Nooijer over explosieve migratieweek
## sa "https://www.youtube.com/watch?v=OmEgsUy_0jU" --language nl # 2025-08-31 -    17:08 - Zit Oekraïne achter opblazen Nord Stream?
## sa "https://www.youtube.com/watch?v=TJUXGQySjCw" --language nl # 2025-09-01 -  1:24:46 - Shanghai-top nieuwe wereldorde | Trump dreigt Brusselse top | Defensie wil 200.000 mensen - LHTV#39
## sa "https://www.youtube.com/watch?v=kOebfGSRqJM" --language nl # 2025-09-02 -    17:18 - Xi, Poetin en Modi zetten zich af van het Westen tijdens SCO-top
## sa "https://www.youtube.com/watch?v=IqwdtKuwLfA" --language nl # 2025-09-02 -    19:00 - Trump dreigt EU-functionarissen met persoonlijke straffen om Big Tech-wetten
## sa "https://www.youtube.com/watch?v=q1NYkt6zLiE" --language nl # 2025-09-03 -    20:01 - Hoe gaat Defensie aan 200.000 man komen?
## sa "https://www.youtube.com/watch?v=YLCJjB_MxUg" --language nl # 2025-09-03 -    56:08 - "Sluipmoordenaar" inflatie raakt NL | Inspectie fileert fiscus | 42% mist energietransitie - LHTV#40
## sa "https://www.youtube.com/watch?v=P-7-Wa4dwRc" --language nl # 2025-09-04 -    12:26 - Inspectie: de menselijke maat is zoek bij de Belastingdienst

## sa "https://www.youtube.com/watch?v=0lro1DQWDKM" --language nl # 2025-09-04 -    18:47 - 50% koopkrachtverlies in 20 jaar - inflatie in NL blijkt 'sluipmoordenaar' spaargeld & pensioen
## sa "https://www.youtube.com/watch?v=x8eVr3GOQjI" --language nl # 2025-09-05 -    13:20 - Onderzoek: klimaatdoelen 2035 onhaalbaar - 42% kan simpelweg niet meedoen
## sa "https://www.youtube.com/watch?v=I19D5pD2DEk" --language nl # 2025-09-05 -    59:20 - 7 AfD'ers dood | Pim fileert rapport Baarsma | Chinees machtsvertoon op parade? | LHTV#41
## sa "https://www.youtube.com/watch?v=Re6Ri3Fsni0" --language nl # 2025-09-06 -    12:07 - 7 AfD'ers overleden in twee weken tijd vlak voor Duitse verkiezingen
## sa "https://www.youtube.com/watch?v=dJ-nAM5-BkA" --language nl # 2025-09-07 -    10:46 - Chinees machtsvertoon op militaire parade brengt Westen in verlegenheid
## sa "https://www.youtube.com/watch?v=xb2voJK2kRs" --language nl # 2025-09-07 -    19:09 - ‘Flauwekulrapport’ Barbara Baarsma stuurt aan op verplaatsen van Nederlandse bedrijven
## sa "https://www.youtube.com/watch?v=HX_md8GqpRU" --language nl # 2025-09-08 -  1:15:02 - Vaccins verontreinigd | Bert voorspelt kabinet |  Leeftijdsslot internet via Digital ID | LHTV#42
## sa "https://www.youtube.com/watch?v=ZMrqU9LMVrc" --language nl # 2025-09-09 -    18:16 - Alle onderzochte mRNA-vaccins verontreinigd: ‘Wanneer stopt Nederland met deze prikken?’
## sa "https://www.youtube.com/watch?v=OsFkibPdFJg" --language nl # 2025-09-09 -    21:25 - Is het komende kabinet al beslist? - ‘er gaat niets veranderen’
## sa "https://www.youtube.com/watch?v=0VsYZe0-GlI" --language nl # 2025-09-10 -    17:01 - EU introduceert 'toegangspoortje' voor internet: verplichte leeftijdscontrole
## sa "https://www.youtube.com/watch?v=7Ufadh8wm5I" --language nl # 2025-09-11 -    13:23 - NAVO-artikel 4 na ‘Russische drones boven Polen’ – escalatie of politiek frame?
## sa "https://www.youtube.com/watch?v=jH2TsiC6gUU" --language nl # 2025-09-11 -    31:50 - Arno van Kessel blijft vastzitten tot 4 december
## sa "https://www.youtube.com/watch?v=DgwDDKTjkEs" --language nl # 2025-09-12 -  1:29:40 - Arno van Kessel BLIJFT VASTZITTEN! | NAVO-artikel 4 drones Polen | nieuwe stikstofwending | LHTV#43
## sa "https://www.youtube.com/watch?v=FFHSel03aNI" --language nl # 2025-09-12 -    20:58 - Waarom politici het deze verkiezingen niet over stikstof willen hebben
## sa "https://www.youtube.com/watch?v=8SKhbxk7IqY" --language nl # 2025-09-12 -    59:54 - Verdeling om Charlie Kirk | Goudprijs kanarie in kolenmijn? | Uitspraak Arno van Kessel | LHTV#44
## sa "https://www.youtube.com/watch?v=JnZwtJkzRhw" --language nl # 2025-09-14 -    16:22 - Waarom de moord op Charlie Kirk ons niet uit elkaar moet spelen
## sa "https://www.youtube.com/watch?v=WUCNpwDgmgM" --language nl # 2025-09-14 -    16:29 - Waarom blijft Arno van Kessel vastzitten?
## sa "https://www.youtube.com/watch?v=T75lXjjno3E" --language nl # 2025-09-15 -  1:39:25 - Bob Vylan: moet kunnen? | Massale demo Londen | Was Kirk té kritisch voor Israël? | LHTV#45
## sa "https://www.youtube.com/watch?v=UxzLSZxc1ak" --language nl # 2025-09-15 -    14:14 - Wat zeggen de recordstanden van goud- en beurskoersen ons?
## sa "https://www.youtube.com/watch?v=-y8RpAbXbPE" --language nl # 2025-09-16 -    20:58 - Tommy Robinsons massale demo in Londen met Eva en Elon: "Fight back or die"
## sa "https://www.youtube.com/watch?v=nH3xcEFhGKs" --language nl # 2025-09-16 -    25:23 - Bob Vylan ontleed: wordt politiek geweld genormaliseerd?
## sa "https://www.youtube.com/watch?v=MWszOwsAGEU" --language nl # 2025-09-17 -  1:14:42 - Miljoenennota-special: Dit schuilt er achter de rooskleurige cijfers van Den Haag | LHTV#46
## sa "https://www.youtube.com/watch?v=z_Jp2zKpp2Q" --language nl # 2025-09-17 -    24:57 - Scenario’s rond Israëlische Mossad en Charlie Kirk zwellen aan: waar gaat dit precies over?
## sa "https://www.youtube.com/watch?v=TC6CDUFhcDg" --language nl # 2025-09-18 -    16:30 - Miljoenennota blijkt miljardennota van 500mld: hoe lang gaat dit nog goed?
## sa "https://www.youtube.com/watch?v=FYyZwP-vO5w" --language nl # 2025-09-18 -    22:12 - Dit is waar het bij de politieke beschouwingen NIET over gaat
## sa "https://www.youtube.com/watch?v=B9LMqqAJiz0" --language nl # 2025-09-19 -  1:07:32 - Antifa verboden na FVD-motie? | ‘Operation Eastern Sentry’ |'Kleuterklas' bij APB 2025 | LHTV#47
## sa "https://www.youtube.com/watch?v=jTehuSzOC1A" --language nl # 2025-09-19 -    22:59 - De ware cijfers en het verhaal achter faillissementen in Nederland
## sa "https://www.youtube.com/watch?v=lk-NGUsIW3A" --language nl # 2025-09-20 -    16:46 - Algemene Politieke Beschouwingen: theater voor de bühne of serieuze koers voor de toekomst?
## sa "https://www.youtube.com/watch?v=Xrbv5_GrfEA" --language nl # 2025-09-20 -    18:36 - FVD-motie om Antifa als terroristische organisatie aan te merken aangenomen
## sa "https://www.youtube.com/watch?v=pDjjVEZalF0" --language nl # 2025-09-21 -    18:17 - NAVO ‘Operation Eastern Sentry’ en EU ‘Defence Union’: verdediging of routekaart naar oorlog?
## sa "https://www.youtube.com/watch?v=oFQdCLLtVgY" --language nl # 2025-09-22 -  1:35:26 - Wybren over ‘Elsfest’ & nieuwe politieke partijen over de problemen van Nederland | LHTV#48
## #sa "https://www.youtube.com/watch?v=__Ot7LZnLhI" --language nl # 2025-09-22 -    21:55 - Romeo's, Antifa, hooligans? Wie zat er achter de escalatie van Malieveld-demo 'Elsfest'?
## sa "https://www.youtube.com/watch?v=jVu3Xf7mQM8" --language nl # 2025-09-23 -    17:43 - Partij voor de Rechtstaat in de bres tegen ‘onbetrouwbare’ overheid
## sa "https://www.youtube.com/watch?v=7a7eWPlfAoA" --language nl # 2025-09-23 -    20:40 - De Linie van ex-50PLUS-leider wil afrekenen met ‘bureaucratische’ wooncrisis

echo " \\" > add_fix.txt
echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=6s8xl24ukcc" --language nl # 2025-09-24 -  1:35:49 - Oud-NOS-baas grilt framing | Digitale euro: juni 2026 | Trump bij VN: EU-landen gaan eraan |LHTV#49

echo " \\" > add_fix.txt
echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=fNJyT3uhz9g" --language nl # 2025-09-24 -  1:35:49 - Oud-NOS-baas grilt framing | Digitale euro: juni 2026 | Trump bij VN: EU-landen gaan eraan |LHTV#49

sa "https://www.youtube.com/watch?v=LVrtwSNqCNo" --language nl # 2025-09-24 -    20:27 - Nieuwe partij Vrede voor Dieren: ‘STOP oorlogsmiljarden van NAVO en EU!’
sa "https://www.youtube.com/watch?v=HEgZkqIbkC8" --language nl # 2025-09-25 -    20:32 - Biolabs, verdwenen kinderen onder Biden, VN-invasies, de 'green energy scam' en meer
sa "https://www.youtube.com/watch?v=cXzHjT7ne5s" --language nl # 2025-09-25 -    27:16 - Haagse rellen: ex-NOS-baas fileert Jetten, Schimmelpenninck & AIVD over ‘Wilders-frame’
sa "https://www.youtube.com/watch?v=pKyB-5PaqrI" --language nl # 2025-09-26 -    33:50 - Digitale euro start in 2026: zullen Europeanen deze massaal adopteren? *
sa "https://www.youtube.com/watch?v=2qUaS-Rt5h0" --language nl # 2025-09-26 -    56:30 - Haagse rellen ‘misbruikt’ | ChatControl EU zet door | Probleemjeugd in azc’s | LHTV #50
sa "https://www.youtube.com/watch?v=XSUktXxQmjU" --language nl # 2025-09-27 -    13:46 - EU wil meekijken op je telefoon en zet door met ChatControl-wet
sa "https://www.youtube.com/watch?v=dHsC3rNnF6Q" --language nl # 2025-09-27 -    14:59 - Ex-COA-medewerker onthult ‘wanpraktijken’ binnen AZC’s
sa "https://www.youtube.com/watch?v=VxJopOVtmp8" --language nl # 2025-09-28 -    17:19 - Haagse rellen aangegrepen voor gezichtsherkenning, chat-toegang en verbod anonieme social accounts
exit

exit

## echo " \\" > add_fix.txt
## echo '	--tags="Ben Knapen" \' >> add_fix.txt
## echo '	--tags="Het Grote Complot" \' >> add_fix.txt
## echo '	--tags="The Great Conspiracy"' >> add_fix.txt
## 
## sa2 "https://www.youtube.com/watch?v=0Axr1LjIzyg" --language nl # 2008-08-02 -     8:25 - De Moraalridders - Het grote complot 1-1
## sa2 "https://www.youtube.com/watch?v=kinzO1gddEE" --language nl # 2008-08-02 -     9:13 - De Moraalridders - Het grote complot 1-2
## sa2 "https://www.youtube.com/watch?v=_lzm4v05ibs" --language nl # 2008-08-02 -     6:09 - De Moraalridders - Het grote complot 1-3
## sa2 "https://www.youtube.com/watch?v=wAHkdltmrsI" --language nl # 2008-08-02 -     5:54 - De Moraalridders - Het grote complot 2-1
## sa2 "https://www.youtube.com/watch?v=ZgLRLZy47g4" --language nl # 2008-08-02 -     7:23 - De Moraalridders - Het grote complot 2-2
## sa2 "https://www.youtube.com/watch?v=uqOptXXlzK8" --language nl # 2008-08-02 -     9:33 - De Moraalridders - Het grote complot 2-3
## sa2 "https://www.youtube.com/watch?v=rDkN2FsP47c" --language nl # 2008-08-02 -     8:25 - De Moraalridders - Het grote complot 3-1
## sa2 "https://www.youtube.com/watch?v=mAqaC2iMuBU" --language nl # 2008-08-02 -     6:50 - De Moraalridders - Het grote complot 3-2
## sa2 "https://www.youtube.com/watch?v=4QJmi-eoWGM" --language nl # 2008-08-02 -     7:59 - De Moraalridders - Het grote complot 3-3
## sa2 "https://www.youtube.com/watch?v=5xerKPszNV0" --language nl # 2008-08-02 -     6:51 - De Moraalridders - Het grote complot 4-1
## sa2 "https://www.youtube.com/watch?v=ipdz5im4Yds" --language nl # 2008-08-02 -     7:34 - De Moraalridders - Het grote complot 4-2
## sa2 "https://www.youtube.com/watch?v=n4Sf4HKe3TU" --language nl # 2008-08-02 -     8:22 - De Moraalridders - Het grote complot 4-3
## sa2 "https://www.youtube.com/watch?v=BkZRrCGGJNs" --language nl # 2008-08-02 -     7:46 - De Moraalridders - Het grote complot 5-1
## sa2 "https://www.youtube.com/watch?v=cDgQAJ6NkOU" --language nl # 2008-08-02 -     7:54 - De Moraalridders - Het grote complot 5-2
## sa2 "https://www.youtube.com/watch?v=B9Ai49eVY-I" --language nl # 2008-08-02 -     7:56 - De Moraalridders - Het grote complot 5-3
## sa2 "https://www.youtube.com/watch?v=FPXzuNiInhs" --language nl # 2008-08-02 -     8:27 - De Moraalridders - Het grote complot 6-1
## sa2 "https://www.youtube.com/watch?v=XCPkTImRSo8" --language nl # 2008-08-02 -     7:27 - De Moraalridders - Het grote complot 6-2
## sa2 "https://www.youtube.com/watch?v=Q-ta_XH7WS8" --language nl # 2008-08-02 -     7:43 - De Moraalridders - Het grote complot 6-3

echo " \\" > add_fix.txt
echo '	--tags="The Zeitgeist Movement" \' >> add_fix.txt
echo '	--tags="Occupy"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=dkinHuvLEaU"
saa "https://www.youtube.com/watch?v=DYH57Cw644k" --language en
saa "https://www.youtube.com/watch?v=4mkRFCtl2MI" --language en

echo " \\" > add_fix.txt
echo '	--tags="Doug Stanhope" \' >> add_fix.txt
echo '	--tags="Voice of America"' >> add_fix.txt


sa2 "https://www.youtube.com/watch?v=ooWailmzEoQ" --language en
sa2 "https://www.youtube.com/watch?v=YkgDhDa4HHo" --language en
sa2 "https://www.youtube.com/watch?v=9Oww4Ap3YZA" --language en

echo " \\" > add_fix.txt
echo '	--tags="Christopher Hitchens"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=mQorzOS-F6w"


echo " \\" > add_fix.txt
echo '	--tags="TED" \' >> add_fix.txt
echo '	--tags="Sam Harris" \' >> add_fix.txt
echo '	--tags="morals" \' >> add_fix.txt

saa "https://www.youtube.com/watch?v=Hj9oB4zpHww"


echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt

#date: 2024-07-30 - length:    27:59 - title: "The Car Payment Pandemic Is Out Of Control.. THIS IS KEEPING YOU BROKE!"
sa "https://www.youtube.com/watch?v=Qp86yWPDJyw" --language en

echo " \\" > add_fix.txt
echo '	--tags="Jim Gray" \' >> add_fix.txt
echo '	--tags="Drug Prohibition" \' >> add_fix.txt
echo '	--tags="War on Drugs"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=b6t1EM4Onao" --language en

echo " \\" > add_fix.txt
echo '	--tags="Pat Condell" \' >> add_fix.txt
echo '	--tags="Children Of A Stupid God"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=rEtfdzNAE74"

echo " \\" > add_fix.txt
echo '	--tags="Aspirational tv" \' >> add_fix.txt
echo '	--tags="Charlie Brooker"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=59OJ17raqWw" --language en

exit


### echo " \\" > add_fix.txt
### echo '	--tags="Jews" \' >> add_fix.txt
### echo '	--tags="Israel"' >> add_fix.txt
### 
### # saa "https://x.com/jovany1124/status/1967961512989077679" --language en
### saa "https://odysee.com/@VerumQuaerimus:2/2022-09-21-09-32-09_Trim:f" --language en
### # saa "https://x.com/Girlpatriot1974/status/1967822336704516592" --language en
### # saa "https://odysee.com/@Thor'sHammer:5/The-Other-Israel,-Ted-Pike---1987:e" --language en
### # saa "https://odysee.com/@WhitestGoyUKnow:2/Rev.-Ted-Pike---The-Insane-Religion-Of-Kabbalistic:c" --language en
### # saa "https://odysee.com/@thisworldworks:1/Ted-Pike---Hate-Laws-Making-Criminals-of-Christians-2001.mp4:d" --language en
### 
### exit

## echo " \\" > add_fix.txt
## echo '	--tags="planned obsolescence" \' >> add_fix.txt
## echo '	--tags="climate change" \' >> add_fix.txt
## echo '	--tags="Hayden Schreier"' >> add_fix.txt
## 
## ## 
## #date: 2025-09-16 - length:    36:49 - title: "Everything You Own Is DESIGNED TO BREAK in 2025…"
## ## sa "https://www.youtube.com/watch?v=65oWQN6jY0E" --language en
## 
## #date: 2025-09-11 - length:    40:42 - title: "I Caught Even CRAZIER Influencer LIES! | IT'S ALL A SCAM! PART 4"
## sa "https://www.youtube.com/watch?v=jV5I2RL9y-U" --language en
## 
## #date: 2025-09-09 - length:    40:18 - title: "Fall Decorating is OUT OF CONTROL (and COSTING You Thousands)"
## sa "https://www.youtube.com/watch?v=9Y7AR_B9RKg" --language en
## 
## 
## echo "BURN_VIDEO2.TXT" > "BURN_VIDEO2.TXT"
## 
## echo " \\" > add_fix.txt
## echo '	--tags="covid" \' >> add_fix.txt
## echo '	--tags="mRNA" \' >> add_fix.txt
## echo '	--tags="vaccines"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=BZrJraN2nOQ" --language en
## 
## rm "BURN_VIDEO2.TXT"
## 
## echo " \\" > add_fix.txt
## echo '	--tags="humanoid" \' >> add_fix.txt
## echo '	--tags="robots"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=Eys5oQabMF8" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="planned obsolescence" \' >> add_fix.txt
## echo '	--tags="climate change" \' >> add_fix.txt
## echo '	--tags="Hayden Schreier"' >> add_fix.txt
## 
## #date: 2025-09-04 - length:    43:49 - title: "Your Car Payment is Why You’ll NEVER GET AHEAD in 2025…"
## sa "https://www.youtube.com/watch?v=KOxzuU2Fd2o" --language en
## 
## #date: 2025-09-02 - length:    33:02 - title: ""Restock" Influencers Have OFFICIALLY RUINED FALL!"
## sa "https://www.youtube.com/watch?v=2zdbqsowBjc" --language en
## 
## #date: 2025-08-28 - length:    42:58 - title: "Used Cars Don’t Suck… PEOPLE DO! (at maintaining them)"
## sa "https://www.youtube.com/watch?v=A-xC4A3uR7I" --language en
## 
## #date: 2025-08-26 - length:    28:30 - title: ""Restock" Influencers Are Already RUINING Halloween!"
## sa "https://www.youtube.com/watch?v=TGT9qKn7TQY" --language en
## 
## #date: 2025-08-21 - length:    39:30 - title: "New Construction Homes Are a Total SCAM in 2025…"
## sa "https://www.youtube.com/watch?v=ATKHBkeKBI4" --language en
## 
## #date: 2025-08-19 - length:    45:00 - title: "New Cars are DESIGNED TO FAIL in 2025…"
## sa "https://www.youtube.com/watch?v=hGU9hqXpk0Q" --language en
## 
## #date: 2025-08-14 - length:    36:12 - title: "Your Collections Are Making You BROKE in 2025!"
## sa "https://www.youtube.com/watch?v=3PdSEG3adwU" --language en
## 
## #date: 2025-08-12 - length:    34:13 - title: "“Restock” Influencers are DESTROYING Your Finances…"
## sa "https://www.youtube.com/watch?v=3f4jWwTnuFA" --language en
## 
## #date: 2025-08-07 - length:    38:11 - title: "People Are Posting Their Net Worth Online and it’s INSANE!"
## sa "https://www.youtube.com/watch?v=DgVQOvkXlYY" --language en
## 
## #date: 2025-08-05 - length:    36:23 - title: "Mass Layoffs Are OUT OF CONTROL in 2025… (Don’t QUIT Your Job Yet)"
## sa "https://www.youtube.com/watch?v=Eazic8lZflY" --language en
## 
## #date: 2025-08-01 - length:    42:12 - title: "People Are Posting Their Salaries Online and it’s INSANE! PART 2"
## sa "https://www.youtube.com/watch?v=v_okMKPq9Oc" --language en
## 
## #date: 2025-07-30 - length:    25:42 - title: "I Bought a Brand New Car… and It Was a NIGHTMARE!"
## sa "https://www.youtube.com/watch?v=uGLBIeRHPtg" --language en
## 
## #date: 2025-07-24 - length:    30:09 - title: "Identity Theft in 2025 is OUT OF CONTROL…"
## sa "https://www.youtube.com/watch?v=Ch5jEkGwQ6w" --language en
## 
## #date: 2025-07-22 - length:    33:48 - title: "I Caught Companies LYING About Their Products! | Shrinkflation 2025"
## sa "https://www.youtube.com/watch?v=UACfTu6w1Yg" --language en
## 
## #date: 2025-07-17 - length:    39:55 - title: "Consumerism Has DEBT EXPLODING in 2025…."
## sa "https://www.youtube.com/watch?v=e4jtJw6GOQY" --language en
## 
## #date: 2025-07-15 - length:    37:31 - title: "People Are Posting Their Salaries Online and it’s INSANE!"
## sa "https://www.youtube.com/watch?v=-a6iT8fV-5A" --language en
## 
## #date: 2025-07-10 - length:    35:52 - title: "Used Cars Aren’t the Problem… YOU ARE! - PART 2"
## sa "https://www.youtube.com/watch?v=NtlIMF_JNrk" --language en
## 
## #date: 2025-07-08 - length:    39:16 - title: "Why The Cost of Living in 2025 is a COMPLETE DISASTER…"
## sa "https://www.youtube.com/watch?v=B83tSZJLS7Q" --language en
## 
## #date: 2025-07-03 - length:    32:00 - title: "Taxes Are COMPLETELY Out of Control in 2025…"
## sa "https://www.youtube.com/watch?v=0PjLWxhlr1Y" --language en
## 
## #date: 2025-07-01 - length:    33:04 - title: "I Caught Even MORE Influencers LYING About Their Lifestyle! | IT'S ALL A SCAM! PART 3"
## sa "https://www.youtube.com/watch?v=1y9Sl_OUK_Y" --language en
## 
## #date: 2025-06-26 - length:    40:31 - title: "You're BROKE Because of Your Spending Addiction! (How to Save Money)"
## sa "https://www.youtube.com/watch?v=Rm2d1oFltR8" --language en
## 
## #date: 2025-06-24 - length:    37:07 - title: "Electric Cars in 2025 are a COMPLETE DISASTER…"
## sa "https://www.youtube.com/watch?v=vsk0OQj8Je4" --language en
## 
## #date: 2025-06-19 - length:    40:47 - title: "New Cars in 2025 are a COMPLETE DISASTER…"
## sa "https://www.youtube.com/watch?v=waRnGHq1Pk8" --language en
## 
## mv add_fix.txt add_fix.txt.backup
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Soros" \' >> add_fix.txt
## echo '	--tags="terrorism" \' >> add_fix.txt
## echo '	--tags="ngo"' >> add_fix.txt
## 
## sa "https://x.com/ryanmauro/status/1968478985072804302" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Mike Benz" \' >> add_fix.txt
## echo '	--tags="NGO" \' >> add_fix.txt
## echo '	--tags="CIA"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=33vwRTrSmv8" --language en
## 
### echo " \\" > add_fix.txt
### echo '	--tags="USAID" \' >> add_fix.txt
### echo '	--tags="Foreign Affairs" \' >> add_fix.txt
### echo '	--tags="NGO"' >> add_fix.txt
### 
### saa "https://www.youtube.com/watch?v=s5Rsw0n30sk" --language en
### 
### echo '	--tags="planned obsolescence" \' >> add_fix.txt
### echo '	--tags="climate change" \' >> add_fix.txt
### echo '	--tags="Hayden Schreier"' >> add_fix.txt
### 
### 
### #date: 2025-06-17 - length:    13:46 - title: "I Tried Dumpster Diving… You Won’t Believe What I Found!"
### sa "https://www.youtube.com/watch?v=MQGPNk4HySg" --language en
### 
### echo '	--tags="charlie kirk" \' >> add_fix.txt
### echo '	--tags="oktober 7" \' >> add_fix.txt
### echo '	--tags="border"' >> add_fix.txt
### 
### saa "https://www.youtube.com/live/fQ9VOlaBBeo" --language en
### 
### echo '	--tags="planned obsolescence" \' >> add_fix.txt
### echo '	--tags="climate change" \' >> add_fix.txt
### echo '	--tags="Hayden Schreier"' >> add_fix.txt
### 
### #date: 2025-06-12 - length:    30:17 - title: "Why You Should NEVER Co-Sign a Car… - Reddit AITA"
### sa "https://www.youtube.com/watch?v=0FoDbx7JOVQ" --language en
### 
### #date: 2025-06-10 - length:    39:20 - title: "People are REFUSING to Pay Off Their Student Loan Debt in 2025…"
### sa "https://www.youtube.com/watch?v=MAMmxCQlTjg" --language en
### 
### #date: 2025-06-06 - length:    38:47 - title: "Credit Card Debt is CRUSHING People in 2025…"
### sa "https://www.youtube.com/watch?v=vkiWPweEe54" --language en
### 
### #date: 2025-06-03 - length:    30:10 - title: "These Amazon ‘Must-Haves’ Influencers Are Getting EMBARRASSING..."
### sa "https://www.youtube.com/watch?v=qqdtnpzIOOg" --language en
### 
### echo " \\" > add_fix.txt
### echo '	--tags="North Stream" \' >> add_fix.txt
### echo '	--tags="warmongers"' >> add_fix.txt
### 
### saa "https://x.com/NiemandsKnegt/status/1958612852803346469" --language nl

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt

### #date: 2025-05-29 - length:    42:04 - title: "Car Payments are Literally DESTROYING People in 2025…"
### sa "https://www.youtube.com/watch?v=fxeLpD0KYy4" --language en
### 
### #date: 2025-05-27 - length:    31:15 - title: "Scams in 2025 Are Getting INSANE – No One Is Safe…"
### sa "https://www.youtube.com/watch?v=5xpFi72hSk0" --language en
### 
### #date: 2025-05-22 - length:    31:50 - title: "New Homes are Literally FALLING APART in 2025…"
### sa "https://www.youtube.com/watch?v=BdAJXp0AA4E" --language en
### 
### #date: 2025-05-20 - length:    30:31 - title: "“Restock” Influencers Are Turning Spring Into a SPENDING NIGHTMARE!"
### sa "https://www.youtube.com/watch?v=dK_P_HM7xoc" --language en
### 
### #date: 2025-05-15 - length:    31:03 - title: "Dumpster Diving in 2025 is Absolutely INSANE…"
### sa "https://www.youtube.com/watch?v=vOKjmIE0Csw" --language en
### 
### #date: 2025-05-13 - length:    28:41 - title: "YOU REALLY KLARNA’D INTO COACHELLA FOR THIS?!"
### sa "https://www.youtube.com/watch?v=fEbU3jKV40g" --language en
### 
### #date: 2025-05-08 - length:    32:11 - title: "32 Minutes of People Making HORRIBLE Money Decisions in 2025..."
### sa "https://www.youtube.com/watch?v=WLs_FH4NlpU" --language en
### 
### #date: 2025-05-06 - length:    40:32 - title: "Used Cars Aren’t the Problem… YOU ARE!!!"
### sa "https://www.youtube.com/watch?v=AHpd22BEleA" --language en
### 
### #date: 2025-05-01 - length:    44:35 - title: "New Cars are Literally FALLING APART in 2025…"
### sa "https://www.youtube.com/watch?v=Wg-DyG5XA-8" --language en
### 
### #date: 2025-04-29 - length:    33:34 - title: "Subscription Culture is OUT OF CONTROL in 2025…"
### sa "https://www.youtube.com/watch?v=xmzjvBOseF8" --language en
### 
### #date: 2025-04-24 - length:    27:26 - title: "“Restock” Influencers are Back for Easter and DESTROYING Your Finances…"
### sa "https://www.youtube.com/watch?v=vTY4ci8-4Eo" --language en
### 
### #date: 2025-04-22 - length:    31:52 - title: "Let’s Expose the ‘Buy Now Pay Later’ Trap."
### sa "https://www.youtube.com/watch?v=ZRCq7ruEuyw" --language en
### 
### #date: 2025-04-17 - length:    30:35 - title: "How Gen Z Will Own Nothing and be Broke Forever…"
### sa "https://www.youtube.com/watch?v=VVVX2UHiuTA" --language en


#date: 2025-04-15 - length:    27:16 - title: "“Restock” Influencers are LYING to You About Your Car…"
## sa "https://www.youtube.com/watch?v=f4I0PlY4Uyg" --language en

## echo " \\" > add_fix.txt
## echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
## echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
## echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=OM6WNS3Ia3Q" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="Elon Musk" \' >> add_fix.txt
## echo '	--tags="Unite The Kingdom" \' >> add_fix.txt
## echo '	--tags="protest"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=sSETb5QRLW0" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt


#date: 2025-04-10 - length:    33:55 - title: "Peoples Mortgages Are SKYROCKETING in 2025..."
sa "https://www.youtube.com/watch?v=UI29rOXUxXo" --language en

#date: 2025-04-08 - length:    35:47 - title: "How ‘Buy Now Pay Later’ is DESTROYING Your Finances in 2025…"
sa "https://www.youtube.com/watch?v=CjbqPGZZLrI" --language en

#date: 2025-04-03 - length:    30:58 - title: "“Fake Designer Hauls” Are INSANE CONSUMERISM in 2025..."
sa "https://www.youtube.com/watch?v=dl_j3mO96SQ" --language en

#date: 2025-04-01 - length:    37:05 - title: "I Found The WORST Financial Advice on The Internet…"
sa "https://www.youtube.com/watch?v=TtfVR6cercs" --language en

#date: 2025-03-28 - length:    35:22 - title: "You're BROKE Because You’re High Maintenance!"
sa "https://www.youtube.com/watch?v=00q5bZIAOv8" --language en

#date: 2025-03-26 - length:    38:23 - title: "New Cars are Still HORRIBLE in 2025…"
sa "https://www.youtube.com/watch?v=n07x1Z2uk4I" --language en

#date: 2025-03-20 - length:    34:45 - title: "CATCHING BEAUTY INFLUENCERS LYING! They’re RUINING Your Skin & Your Finances…"
sa "https://www.youtube.com/watch?v=HMvlO6lmK9Q" --language en

#date: 2025-03-18 - length:    34:48 - title: "New Cars are HORRIBLE in 2025…"
sa "https://www.youtube.com/watch?v=Awg5kffgqss" --language en

#date: 2025-03-13 - length:    41:06 - title: "Stop WASTING MONEY on Skincare — Here's Why You're Broke!"
sa "https://www.youtube.com/watch?v=1bnOxdxhsY8" --language en

echo " \\" > add_fix.txt
echo '	--tags="chemtrails" \' >> add_fix.txt
echo '	--tags="bill gates" \' >> add_fix.txt
echo '	--tags="tpvsean"' >> add_fix.txt

saa "https://x.com/thehealthb0t/status/1969898121296781340" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt

#date: 2025-03-11 - length:    28:03 - title: "Skincare Consumerism is OUT OF CONTROL in 2025…"
sa "https://www.youtube.com/watch?v=fhtoRdWQg_E" --language en

#date: 2025-03-06 - length:    32:18 - title: "Amazon "Must-Haves" Influencers Are OUT OF CONTROL..."
sa "https://www.youtube.com/watch?v=-PCrUO9pJWw" --language en

#date: 2025-03-04 - length:    41:15 - title: "7 Things Influencers Have Brainwashed Us Into Thinking Are Normal (But They’re Not)"
sa "https://www.youtube.com/watch?v=K5vP4ArkI1E" --language en

#date: 2025-02-27 - length:    31:38 - title: "PET OWNERS ARE GOING BROKE IN 2025..."
sa "https://www.youtube.com/watch?v=c2lGTNJ2iXg" --language en

#date: 2025-02-25 - length:    33:02 - title: "“Restock” Influencers Have RUINED Valentine’s Day…"
sa "https://www.youtube.com/watch?v=sNfcgUGMwm8" --language en

#date: 2025-02-20 - length:    32:07 - title: "How to Become Successful In 2025 | Only 7 Rules"
sa "https://www.youtube.com/watch?v=PVuqdBCwMiM" --language en

#date: 2025-02-18 - length:    31:09 - title: "New Construction Homes are STILL HORRIBLE in 2025…"
sa "https://www.youtube.com/watch?v=lEEoedXSMhM" --language en

#date: 2025-02-13 - length:    34:28 - title: "Valentine’s Day Consumerism is a SCAM! (Stop WASTING Your Money!)"
sa "https://www.youtube.com/watch?v=xE69CRVAE3g" --language en

#date: 2025-02-11 - length:    32:32 - title: "I Caught Influencers LYING About Their Wealth & Lifestyle! | IT'S ALL A FAKE! PART 2"
sa "https://www.youtube.com/watch?v=pmgrJX9ZU9w" --language en

#date: 2025-02-07 - length:    32:12 - title: "32 Minutes of TERRIBLE Credit Card Debt in 2025…"
sa "https://www.youtube.com/watch?v=ga4lfxtdloU" --language en

#date: 2025-02-05 - length:    35:32 - title: "35 Minutes of HORRIBLE Car Payments in 2025…"
sa "https://www.youtube.com/watch?v=XrjsOWdH4SI" --language en

echo " \\" > add_fix.txt
echo '	--tags="Tucker Carlson" \' >> add_fix.txt
echo '	--tags="Kirk Moore" \' >> add_fix.txt
echo '	--tags="covid"' >> add_fix.txt

saa "https://x.com/TuckerCarlson/status/1965097804365234399" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt

#date: 2025-02-03 - length:    26:02 - title: "The "Fridgescaping" Trend is Making You BROKE and MISERABLE!"
sa "https://www.youtube.com/watch?v=yuuBMItTR9c" --language en

#date: 2025-01-30 - length:    33:06 - title: "You're BROKE Because of Your Shopping Addiction! - REACTION"
sa "https://www.youtube.com/watch?v=khKjV7sN-Hs" --language en

#date: 2025-01-28 - length:    33:30 - title: "I Exposed Influencers LYING About Their Wealth and Lifestyle Again! | IT’S ALL FAKE!"
sa "https://www.youtube.com/watch?v=y3JxVkSzQ8g" --language en

#date: 2025-01-24 - length:    29:12 - title: "“Restock” Influencers are DESTROYING Your Fridge and Your Finances…"
sa "https://www.youtube.com/watch?v=0K23I-qUnL0" --language en

#date: 2025-01-22 - length:    34:18 - title: "Crumbl Cookie Overconsumption is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=kf30FAKwvtg" --language en

#date: 2025-01-20 - length:    33:20 - title: "The BIGGEST Job Layoff Just Happened in 2025… TikTok Banned"
sa "https://www.youtube.com/watch?v=7qfaSEhrWjc" --language en

#date: 2025-01-17 - length:    31:36 - title: "The 2024 “Spending Wrapped” TikTok Trend is OUT OF CONTROL…"
sa "https://www.youtube.com/watch?v=fPwHKVaXKgI" --language en

#date: 2025-01-15 - length:    35:34 - title: "This TikTok Influencers Spending is OUT OF CONTROL…(Dougherty Dozen)"
sa "https://www.youtube.com/watch?v=5ddHY7qyYYk" --language en

#date: 2025-01-13 - length:    34:36 - title: "Renovating Your “Rental” Apartment in 2025 is INSANE…"
sa "https://www.youtube.com/watch?v=3nxiZ1bHcYw" --language en

#date: 2025-01-09 - length:    32:51 - title: "“No Buy 2025” The GENIUS Trend That Could Make You Rich…"
sa "https://www.youtube.com/watch?v=InVqjY5NuQE" --language en

#date: 2025-01-07 - length:    33:17 - title: "Christmas “Clearance Sales” are OUT OF CONTROL. 90% OFF?!?…"
sa "https://www.youtube.com/watch?v=w94rS39dueo" --language en

#date: 2025-01-02 - length:    34:33 - title: "Rich Kid “Christmas Hauls” are OUT OF CONTROL… PT2"
sa "https://www.youtube.com/watch?v=GtYguZgeiKs" --language en

#date: 2024-12-30 - length:    28:58 - title: "The “Burr Basket” Tiktok Trend is INSANE..."
sa "https://www.youtube.com/watch?v=yOYJAOfZJFk" --language en

#date: 2024-12-27 - length:    32:46 - title: ""Christmas Hauls" are Here and They’re OUT OF CONTROL…"
sa "https://www.youtube.com/watch?v=5DatWHffZt8" --language en

#date: 2024-12-26 - length:    28:25 - title: "Rich Kid “Christmas Hauls” are OUT OF CONTROL…"
sa "https://www.youtube.com/watch?v=ZAgpXoKakAY" --language en

#date: 2024-12-23 - length:    33:22 - title: "Amazon Christmas “Must Haves” are OUT OF CONTROL in 2024…"
sa "https://www.youtube.com/watch?v=PwZIGV7YWzo" --language en

#date: 2024-12-19 - length:    32:24 - title: ""Christmas Hauls" are Already Here and They’re OUT OF CONTROL…"
sa "https://www.youtube.com/watch?v=AikNDtv2WBE" --language en

#date: 2024-12-17 - length:    32:54 - title: "People Are DESTROYING Their Finances This Holiday Season…"
sa "https://www.youtube.com/watch?v=43lLSDz87Mo" --language en

#date: 2024-12-13 - length:    32:36 - title: "“Restock” Influencers are Back for the Holidays and DESTROYING Your Finances…"
sa "https://www.youtube.com/watch?v=JA4jAk6oAXE" --language en

#date: 2024-12-12 - length:    31:15 - title: "Health Insurance in 2024 is Out of Control and MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=48YjX7KWd04" --language en

#date: 2024-12-10 - length:    32:04 - title: "Holiday Consumerism Has Debt EXPLODING in 2024…."
sa "https://www.youtube.com/watch?v=j0pcW8MR7tU" --language en

#date: 2024-12-05 - length:    28:58 - title: "Holidays Are a MASSIVE SCAM to Keep You POOR and in Debt!"
sa "https://www.youtube.com/watch?v=Usuxw7Ic2xM" --language en

#date: 2024-12-03 - length:    32:08 - title: "Black Friday Has Become a MASSIVE Scam in 2024!"
sa "https://www.youtube.com/watch?v=-DvcsVM7URM" --language en

#date: 2024-11-30 - length:    32:12 - title: "People Have NO IDEA How to Invest in 2024…"
sa "https://www.youtube.com/watch?v=97ZEkuVdYM0" --language en

#date: 2024-11-26 - length:    32:28 - title: "New Construction Homes are Built HORRIBLE in 2025..."
sa "https://www.youtube.com/watch?v=bgG_v6ZmZQk" --language en

echo " \\" > add_fix.txt
echo '	--tags="trump" \' >> add_fix.txt
echo '	--tags="united nations" \' >> add_fix.txt
echo '	--tags="2025"' >> add_fix.txt

saa "https://x.com/MonicaCrowley/status/1970558882528325962" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt

#date: 2024-11-21 - length:    32:41 - title: "The Cost of Weddings is HORRIBLE in 2024…"
sa "https://www.youtube.com/watch?v=q9QX6xpzVKQ" --language en

#date: 2024-11-19 - length:    29:33 - title: "The Younger Generation is SCREWED Financially…"
sa "https://www.youtube.com/watch?v=wOCvXvHMkHs" --language en

#date: 2024-11-14 - length:    33:00 - title: "Car Payments are Out of Control and DESTROYING Your Finances…"
sa "https://www.youtube.com/watch?v=LwtvnksiIao" --language en

#date: 2024-11-12 - length:    32:28 - title: "How The “Commute to Work” Keeps You Poor"
sa "https://www.youtube.com/watch?v=DsNt7yvVKHU" --language en

#date: 2024-11-08 - length:    29:21 - title: "Grocery Prices in 2024 Are Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=ZgkZL34dOHI" --language en

#date: 2024-11-06 - length:    31:28 - title: "Hyperconsumerism Has DEBT EXPLODING in 2025…."
sa "https://www.youtube.com/watch?v=CAzUnrCY4Rk" --language en

#date: 2024-11-04 - length:    30:24 - title: "“Restock” Influencers are Out of Control in 2025 - REACTION"
sa "https://www.youtube.com/watch?v=eapElkbl0uU" --language en

#date: 2024-10-31 - length:    33:17 - title: "People Are REFUSING to Pay Off Their Debt in 2025…"
sa "https://www.youtube.com/watch?v=0Ai6M5SfeeI" --language en

#date: 2024-10-28 - length:    29:55 - title: "“Underconsumption Core” in 2025 is A TRAP…"
sa "https://www.youtube.com/watch?v=Ii1xdzHF8vk" --language en

#date: 2024-10-24 - length:    34:55 - title: "Overconsumption in 2025 is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=mVx4fuNVOVE" --language en

#date: 2024-10-22 - length:    29:11 - title: "Doom Spending in 2025 is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=qAIdARjydeU" --language en

#date: 2024-10-19 - length:    25:39 - title: "The Food Stamp System in America is COMPLETELY Broken…."
sa "https://www.youtube.com/watch?v=BhFHgEX5U5k" --language en

#date: 2024-10-17 - length:    26:36 - title: "The Younger Generation is Completely Broke….."
sa "https://www.youtube.com/watch?v=gD0z5szneYo" --language en

#date: 2024-10-15 - length:    26:58 - title: "People Are REFUSING to Save Money in 2025…."
sa "https://www.youtube.com/watch?v=w_0Wfgty6gI" --language en

#date: 2024-10-10 - length:    23:57 - title: "People Are Giving Up Because The Cost of Living is OUT OF CONTROL!"
sa "https://www.youtube.com/watch?v=_IbCKfpG0DI" --language en

#date: 2024-10-08 - length:    29:20 - title: "Hurricane Prices in 2024 Are OUT OF CONTROL..."
sa "https://www.youtube.com/watch?v=RMC9s9rsx5g" --language en

#date: 2024-10-07 - length:    31:35 - title: "The Cost of Living in 2024 is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=f2ErZSSF9Uk" --language en

#date: 2024-10-04 - length:    25:12 - title: "Women in 2024 Are Living In Fantasy Land..."
sa "https://www.youtube.com/watch?v=lIGcfW4Xst0" --language en

#date: 2024-10-01 - length:    29:21 - title: "I Caught Influencers LYING About Their Wealth & Lifestyle! | IT'S ALL A SCAM!"
sa "https://www.youtube.com/watch?v=UjQVz3iHtgY" --language en

#date: 2024-09-26 - length:    41:16 - title: "Rent Prices in 2024 Are Out of Control and it MUST BE STOPPED! | PT2"
sa "https://www.youtube.com/watch?v=bBG7BwtLUO0" --language en

#date: 2024-09-23 - length:    29:53 - title: "Car Repo’s Are OUT OF CONTROL in 2024 and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=X0pnUwIcyoE" --language en

#date: 2024-09-18 - length:    31:47 - title: "Car Insurance Prices in 2024 Are Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=5QAvdMiYD10" --language en

#date: 2024-09-17 - length:    33:16 - title: "The Job Market in 2024 is TERRIBLE and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=vMlUw5i4NG8" --language en

#date: 2024-09-13 - length:    29:42 - title: "Barbershop Prices in 2024 Are Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=Baoduj9CYvs" --language en

#date: 2024-09-11 - length:    26:45 - title: "Tipping Culture in 2024 is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=kEi1s9USDHA" --language en

#date: 2024-09-10 - length:    28:49 - title: "28 Minutes of HORRIBLE Credit Card Debt in 2024..."
sa "https://www.youtube.com/watch?v=c039qLZTPkU" --language en

#date: 2024-09-06 - length:    31:02 - title: "31 Minutes of INSANE Car Payments in 2024..."
sa "https://www.youtube.com/watch?v=ZiuE--x5_0Q" --language en

#date: 2024-09-05 - length:    26:39 - title: "The Cost of Having Kids In 2024 is INSANE!"
sa "https://www.youtube.com/watch?v=NRKqoXStU4I" --language en

#date: 2024-09-03 - length:    32:27 - title: "Student Loan Debt in 2024 is OUT OF CONTROL!"
sa "https://www.youtube.com/watch?v=0-9-Wwenzvk" --language en

#date: 2024-08-30 - length:    31:42 - title: "The Cost of College Tuition in 2024 is OUT OF CONTROL!"
sa "https://www.youtube.com/watch?v=ElWpesobRWk" --language en

#date: 2024-08-29 - length:    27:50 - title: "Girl Math in 2024 is Out of Control and it MUST BE STOPPED! | Broke Girl Mindset"
sa "https://www.youtube.com/watch?v=uT0LlYInVQU" --language en

#date: 2024-08-27 - length:    34:23 - title: "Buying a House in 2024 Is INSANE! This is Why You're Broke & HOUSE POOR!"
sa "https://www.youtube.com/watch?v=b1-UU84O27c" --language en

#date: 2024-08-23 - length:    30:03 - title: "Rent Prices in 2025 Are Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=nsao9qWeBvY" --language en

#date: 2024-08-17 - length:    23:52 - title: "Work From Home in 2024 Is Out of Control!  THIS IS WHY IT’S GETTING CANCELLED!"
sa "https://www.youtube.com/watch?v=6tVWJqZTa24" --language en

#date: 2024-08-15 - length:    27:21 - title: "Living at Home in Your Late 20's IS OUT OF CONTROL! Failure or Financial Freedom?"
sa "https://www.youtube.com/watch?v=75ZG4QzUonA" --language en

#date: 2024-08-08 - length:    28:23 - title: "Gen Z Doesn’t Want to Work Anymore..."
sa "https://www.youtube.com/watch?v=1nTgYzQbzto" --language en

#date: 2024-08-06 - length:    26:44 - title: "Fast Food Prices in 2024 Are Out Of Control! THIS IS WHY YOU'RE BROKE!"
sa "https://www.youtube.com/watch?v=74uzDNvSeBE" --language en

#date: 2024-08-05 - length:    25:04 - title: "Credit Card Debt in 2024 is OUT OF CONTROL! THIS IS WHY YOU'RE BROKE!"
sa "https://www.youtube.com/watch?v=IEnTe4AqzZo" --language en

echo " \\" > add_fix.txt
echo '	--tags="Ursula von der Leyen" \' >> add_fix.txt
echo '	--tags="EU"' >> add_fix.txt

sa2 "https://x.com/Fidias0/status/1971213103950971023" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt


#date: 2024-08-02 - length:    16:52 - title: "Shrinkflation in 2024 is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=9PQEXDgTq5w" --language en

#date: 2024-08-01 - length:    27:42 - title: "The Cost of Living in 2024 is INSANE!"
sa "https://www.youtube.com/watch?v=YzBZiGSuFOk" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=65oWQN6jY0E" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="Stew Peters"' >> add_fix.txt

sa "https://rumble.com/v6z0e6u-gop-blocks-epstein-files-release-while-general-public-is-distracted-by-kirk.html?e9s=src_v1_ucp_a" --language en

exit

saa "https://www.youtube.com/watch?v=owootTAuxic"  --language en

echo " \\" > add_fix.txt
echo '	--tags="ramble_rants"' >> add_fix.txt

sa "https://x.com/ramble_rants/status/1967562961633092029" --language en

#saa "https://odysee.com/@AuronMacIntyre:f/zelenskyy-unmasked-guest-ben-swann-4-17:3"  --language en
#saa "https://odysee.com/@alltheworldsastage:0/Zelenskyy-Unmasked---Who-is-Volodymyr-Zelenskyy-truthinmedia-sovrenmedia:a"  --language en
#saa "https://odysee.com/@montysthinkingoutsidethebox:2/Zelenskyy-Unmasked---Who-is-Volodymyr-Zelenskyy-truthinmedia-sovrenmedia:5"  --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="Jeanius" \' >> add_fix.txt
echo '	--tags="X"' >> add_fix.txt

sa "https://x.com/jeanerus/status/1938603868918817097" --language en


sa "https://x.com/drtomcowan/status/1893358436437385656" --language en

sa "https://x.com/springfield1952/status/1753409217065529805" --language en

sa "https://odysee.com/@januszkowalskii1979:e/Twelve-Truths-Everyone-Should-Know-But-No-one-Else-Will-Tell-You-%28Dr.-Vernon-Coleman%29:9" --language en

sa "https://x.com/john1rudio/status/1650304520323227648" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=ubPyEerik_I" --language nl

exit

echo " \\" > add_fix.txt
echo '	--tags="Giorgia Melon" \' >> add_fix.txt
echo '	--tags="UDC"' >> add_fix.txt

saa "https://x.com/GiorgiaMeloni/status/1966816552516206887" --language it

echo " \\" > add_fix.txt
echo '	--tags="Poland" \' >> add_fix.txt
echo '	--tags="drones"' >> add_fix.txt

sa "https://x.com/gewoonmerels/status/1965650488751522225" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="Aaron Siri" \' >> add_fix.txt
echo '	--tags="vaccine" \' >> add_fix.txt
echo '	--tags="covid19"' >> add_fix.txt

saa "https://twitter.com/i/status/1965520139132256554" --language en

echo " \\" > add_fix.txt
echo '	--tags="De Nieuwe Wereld" \' >> add_fix.txt
echo '	--tags="Charlie Kirk" \' >> add_fix.txt
echo '	--tags="Wierd Duk"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=IX4it5LD6Xo" --language nl

exit

sa2 "https://x.com/dendolly1/status/1816473355345678696" --language nl 
sa2 "https://x.com/dendolly1/status/1964619290625339692" --language nl 
sa2 "https://x.com/dendolly1/status/1964994600336228690" --language nl 
sa2 "https://x.com/dendolly1/status/1964253380823462160" --language nl 
sa2 "https://x.com/dendolly1/status/1905315016686944634" --language nl 
sa2 "https://x.com/dendolly1/status/1916152815409336470" --language nl 
sa2 "https://x.com/dendolly1/status/1830925586719482056" --language nl 
sa2 "https://x.com/dendolly1/status/1965385035781152971" --language nl 
sa2 "https://x.com/dendolly1/status/1815655750380724372" --language nl 

exit

echo " \\" > add_fix.txt
echo '	--tags="The Cutting Edge" \' >> add_fix.txt
echo '	--tags="AI" \' >> add_fix.txt
echo '	--tags="robots"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=m8wyoYGdOQk" --language nl

exit

# echo " \\" > add_fix.txt
# echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
# echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
# echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt
# 
# saa "https://www.youtube.com/watch?v=5lifYcsUJlA" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="AI Revolution" \' >> add_fix.txt
## echo '	--tags="OpenAI" \' >> add_fix.txt
## echo '	--tags="ChatGPT"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=2sxFhGJ1P3o" --language en

echo " \\" > add_fix.txt
echo '	--tags="AIn" \' >> add_fix.txt
echo '	--tags="Hacking" \' >> add_fix.txt
echo '	--tags="NetworkChuck"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=Qvx2sVgQ-u0" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="David Icke" \' >> add_fix.txt
echo '	--tags="1996"' >> add_fix.txt

sa2 "https://x.com/deSunShineBand/status/1964239114959569257" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="LP" \' >> add_fix.txt
echo '	--tags="Dutch Libertarian Party" \' >> add_fix.txt
echo '	--tags="Libertaire Partij"' >> add_fix.txt

### saa "https://www.youtube.com/watch?v=Z-ycPdEmXBs" --language nl
### #date: 2020-06-20 - length:     1:54 - title: "Introductie Immigratiebeleid LP"
### 
### saa "https://www.youtube.com/watch?v=6-TrzbEPwQ0" --language nl
### #date: 2020-06-23 - length:     1:04 - title: "Robert Valentine over het voorwaardelijk basisinkomen - LP"
### 
### saa "https://www.youtube.com/watch?v=V_ByFOyNm_k" --language nl
### #date: 2020-07-02 - length:     3:14 - title: "De Nieuwe Kieswet"
### 
### saa "https://www.youtube.com/watch?v=B5NsmBhYFyo" --language nl
### #date: 2020-07-04 - length:       36 - title: "Oplossing voor de Woningmarkt Crisis - LP"
### 
### saa "https://www.youtube.com/watch?v=7p10BH158o8" --language nl
### #date: 2020-10-14 - length:     2:23 - title: "Nieuwe Coronamaatregels"
### 
### saa "https://www.youtube.com/watch?v=VokFElWAQWM" --language nl
### #date: 2020-10-19 - length:     2:37 - title: "Woonzekerheid"
### 
### saa "https://www.youtube.com/watch?v=OR_TRbQTe0s" --language nl
### #date: 2020-10-24 - length:       39 - title: "Waar staat de LP voor?"
### 
### saa "https://www.youtube.com/watch?v=IK1RcVGvDtA" --language nl
### #date: 2020-10-27 - length:     1:45 - title: "Corona"
### 
### saa "https://www.youtube.com/watch?v=w01udYNOPiA" --language nl
### #date: 2020-10-31 - length:     2:20 - title: "Barstmaar"
### 
### saa "https://www.youtube.com/watch?v=c_LNL3fjOjY" --language nl
### #date: 2020-11-04 - length:     2:19 - title: "Overheidsbemoeienis"
### 
### saa "https://www.youtube.com/watch?v=TL8ltX4OgZ4" --language nl
### #date: 2020-11-08 - length:     1:54 - title: "LP terugblik FAILLIET actie"
### 
### saa "https://www.youtube.com/watch?v=U1VAiW60XwA" --language nl
### #date: 2021-01-16 - length:     2:00 - title: "Politieke Poppenkast"
### 
### saa "https://www.youtube.com/watch?v=s9KAxJjaG2w" --language nl
### #date: 2021-01-19 - length:     1:48 - title: "Toeslagenaffaire"

### saa "https://www.youtube.com/watch?v=pwxsEFrIJ0U" --language nl
### #date: 2021-01-27 - length:       35 - title: "Hoe het wel moet: natuurlijk, energie!"
### 
### saa "https://www.youtube.com/watch?v=zx-7kToLeXM" --language nl
### #date: 2021-01-31 - length:       37 - title: "Hoe het wel moet: Digitale rechten"
### 
### saa "https://www.youtube.com/watch?v=mi1yqEoq5o8" --language nl
### #date: 2021-02-15 - length:     1:59 - title: "Achter de Schermen bij de LP"
### 
### saa "https://www.youtube.com/watch?v=78Iw-qMQExc" --language nl
### #date: 2021-02-26 - length:     1:36 - title: "Kleinere overheid: LP"
### 
### saa "https://www.youtube.com/watch?v=dBun5Wttkuw" --language nl
### #date: 2021-03-01 - length:     2:12 - title: "Ondernemers en de Overheid"
### 
### saa "https://www.youtube.com/watch?v=DfljswF9aB0" --language nl
### #date: 2021-03-01 - length:     3:13 - title: "Bitcoin als Verzetsmiddel"
### 
### saa "https://www.youtube.com/watch?v=1VoTVSMyGd8" --language nl
### #date: 2021-03-07 - length:     4:24 - title: "Corona"
### 
### saa "https://www.youtube.com/watch?v=3fdEY7W-Z5s" --language nl
### #date: 2021-03-08 - length:       36 - title: "Ondernemerschap"
### 
### saa "https://www.youtube.com/watch?v=t79ua0BdzVU" --language nl
### #date: 2021-03-09 - length:    19:28 - title: "Arno Wellens Vertelt Waarom Hij Lijstduwer van de Libertaire  Partij Is Geworden"
### 
### saa "https://www.youtube.com/watch?v=ib65Hy3PHxc" --language nl
### #date: 2021-03-09 - length:     2:44 - title: "Milieu, Europa, Immigratie & Economie"
### 
### saa "https://www.youtube.com/watch?v=ReXcZCxI0Do" --language nl
### #date: 2021-03-16 - length:     1:09 - title: "Ambtenarenapparaat"
### 
### saa "https://www.youtube.com/watch?v=DOCzIDR7QTM" --language nl
### #date: 2021-03-16 - length:     1:20 - title: "Minderheidskabinet"
### 
### saa "https://www.youtube.com/watch?v=HYwfK-nqA5E" --language nl
### #date: 2021-03-16 - length:       34 - title: "Politici, Verantwoordelijkheid en Expertise"
### 
### saa "https://www.youtube.com/watch?v=lKAL7U3Uuh0" --language nl
### #date: 2021-09-05 - length:     3:20 - title: "V for Valentine: Chaos in het Midden-Oosten"
### 
### saa "https://www.youtube.com/watch?v=Wf31RzjlhRE" --language nl
### #date: 2021-10-03 - length:  1:22:01 - title: "Gastlezing Toine Manders aan de TU Eindhoven"
### 
### saa "https://www.youtube.com/watch?v=Ws6vo1TkUDA" --language nl
### #date: 2022-10-09 - length:  1:09:49 - title: "Toine Manders - Het Libertarisme"
### 
### saa "https://www.youtube.com/watch?v=M8e5CffxpaA" --language nl
### #date: 2023-07-14 - length:     5:06 - title: "Wat willen Libertariërs?"
### 
### saa "https://www.youtube.com/watch?v=XBfZq1QOI1Q" --language nl
### #date: 2023-09-11 - length:    58:43 - title: "Economie, geld en belasting"
### 
### saa "https://www.youtube.com/watch?v=iyrCDy4Fss4" --language nl
### #date: 2023-09-12 - length:     1:12 - title: "Is iedereen een libertariër?"
### 
### saa "https://www.youtube.com/watch?v=LfT7F4myHPA" --language nl
### #date: 2023-09-12 - length:       42 - title: "Waarom dwang nooit OK is"
### 
### saa "https://www.youtube.com/watch?v=I-zyQRJZe54" --language nl
### #date: 2023-09-12 - length:       45 - title: "Inflatie is verborgen belasting"
### 
### saa "https://www.youtube.com/watch?v=AE35v4_GYVg" --language nl
### #date: 2023-09-12 - length:       46 - title: "Voorkeursbehandeling van grote bedrijven"
### 
### saa "https://www.youtube.com/watch?v=d_p6vWp8mgE" --language nl
### #date: 2023-09-19 - length:  1:04:23 - title: "Vrij onderwijs volgens Peter Hartkamp"
### 
### saa "https://www.youtube.com/watch?v=G3ohnQileIg" --language nl
### #date: 2023-09-19 - length:       17 - title: "Is het leerplicht of schoolplicht?"
### 
### saa "https://www.youtube.com/watch?v=IYaLTAIgBGs" --language nl
### #date: 2023-09-19 - length:       32 - title: "Alle scholen in ons land zijn hetzelfde"
### 
### saa "https://www.youtube.com/watch?v=FmH1SK0mT5Q" --language nl
### #date: 2023-09-19 - length:       46 - title: "Kinderen leren alleen met motivatie"
### 
### saa "https://www.youtube.com/watch?v=J_Ml-s-TWeU" --language nl
### #date: 2023-09-22 - length:       31 - title: "De codetaal van de politiek"
### 
### saa "https://www.youtube.com/watch?v=gsX_PTctGFQ" --language nl
### #date: 2023-10-02 - length:     1:00 - title: "90% minder belasting"
### 
### saa "https://www.youtube.com/watch?v=xihu7TDWcTE" --language nl
### #date: 2023-10-02 - length:  1:18:15 - title: "Is belasting diefstal?"
### 
### mv add_fix.txt add_fix.backup.txt
### 
### echo " \\" > add_fix.txt
### echo '	--tags="Thomas Massie" \' >> add_fix.txt
### echo '	--tags="America First" \' >> add_fix.txt
### echo '	--tags="Dissident Media"' >> add_fix.txt
### saa "https://x.com/DissidentMedia/status/1963315630137839873" --language en
### 
### echo " \\" > add_fix.txt
### echo '	--tags="Chris Rock" \' >> add_fix.txt
### echo '	--tags="Oboy the Law"' >> add_fix.txt
### sa "https://x.com/EnriqueLichten4/status/1963325375183995285" --language en
### 
### mv add_fix.backup.txt add_fix.txt
### 
### saa "https://www.youtube.com/watch?v=6qKNHOmyQ6M" --language nl
### #date: 2023-10-02 - length:       47 - title: "Belastingen op belastingen"
### 
### saa "https://www.youtube.com/watch?v=nvtmDy5IwUo" --language nl
### #date: 2023-10-02 - length:       51 - title: "Inflatie en belasting als diefstal?"
### 
### saa "https://www.youtube.com/watch?v=k1h4T2I0FFU" --language nl
### #date: 2023-10-02 - length:       52 - title: "Belastingen werken vaak contraproductief"
### 
### saa "https://www.youtube.com/watch?v=iQDnzBuYfoQ" --language nl
### #date: 2023-10-06 - length:     1:08 - title: "Waarom steunt Arno Wellens de LP?"
### 
### saa "https://www.youtube.com/watch?v=drg87yyAaLc" --language nl
### #date: 2023-10-06 - length:       32 - title: "Écht vrij onderwijs"
### 
### saa "https://www.youtube.com/watch?v=k6hgaSJZm8I" --language nl
### #date: 2023-10-06 - length:       35 - title: "Een transparante overheid"
### 
### saa "https://www.youtube.com/watch?v=D5SmeLbibi0" --language nl
### #date: 2023-10-06 - length:       38 - title: "The Great Moderation is een wonder?"
### 
### saa "https://www.youtube.com/watch?v=qPwGiunhe9k" --language nl
### #date: 2023-10-06 - length:       41 - title: "Het grootste probleem is het geldsysteem"
### 
### saa "https://www.youtube.com/watch?v=afXWsuT-H5M" --language nl
### #date: 2023-10-06 - length:       41 - title: "Het probleem met onderwijs"
### 
### saa "https://www.youtube.com/watch?v=60KChuFAeuk" --language nl
### #date: 2023-10-20 - length:  1:06:45 - title: "De rot in het bankenstelsel met Hester Bais"
### 
### saa "https://www.youtube.com/watch?v=RAcVOtYsE1I" --language nl
### #date: 2023-10-20 - length:       37 - title: "Het vervangen van poppetjes lost niets op"
### 
### saa "https://www.youtube.com/watch?v=cyXdoMLw3_A" --language nl
### #date: 2023-10-20 - length:       46 - title: "De Tweede Kamer negeert het"
### 
### saa "https://www.youtube.com/watch?v=ntsULpSjAtg" --language nl
### #date: 2023-10-20 - length:       47 - title: "In de praktijk is er geen vermogensscheiding"
### 
### saa "https://www.youtube.com/watch?v=WoDh1QJQBMA" --language nl
### #date: 2023-10-20 - length:       53 - title: "Een systeem met perverse prikkels"
### 
### saa "https://www.youtube.com/watch?v=qHcsSc_4Xbc" --language nl
### #date: 2023-10-20 - length:       58 - title: "Onze kinderen zijn het onderpand"
### 
### saa "https://www.youtube.com/watch?v=mPoDXFPdc1k" --language nl
### #date: 2023-10-31 - length:     1:35 - title: "Libertaire Partij - Politieke Zendtijd 2023"
### 
### saa "https://www.youtube.com/watch?v=TA81xnMvERY" --language nl
### #date: 2023-11-15 - length:     1:07 - title: "Waarom de LP belangrijk is volgens George van Houts"
### 
### saa "https://www.youtube.com/watch?v=PCdJWnc2Bvk" --language nl
### #date: 2023-11-15 - length:  1:12:50 - title: ""Als stemmen iets kon veranderen, zou het verboden zijn" met George van Houts"
### 
### 
### mv add_fix.txt add_fix.backup.txt
### 
### echo " \\" > add_fix.txt
### echo '	--tags="Naomi Wolf" \' >> add_fix.txt
### echo '	--tags="European Parliament" \' >> add_fix.txt
### echo '	--tags="Pfizer Papers"' >> add_fix.txt
### sa "https://x.com/i/broadcasts/1lPKqvQNwvmGb" --language en
### 
### mv add_fix.backup.txt add_fix.txt
### 
### saa "https://www.youtube.com/watch?v=9F7vn0b1NnQ" --language nl
### #date: 2023-11-15 - length:       48 - title: "De politiek kan je nooit vertrouwen"
### 
### saa "https://www.youtube.com/watch?v=z8SBOTP-JNU" --language nl
### #date: 2023-11-15 - length:       50 - title: "Voor bureaucraten zijn wij nummers op een spreadsheet"
### 
### saa "https://www.youtube.com/watch?v=VLFUz41CoY8" --language nl
### #date: 2023-11-15 - length:       55 - title: "Het systeem is prima voor de 0.01% zegt George van Houts"
### 
### saa "https://www.youtube.com/watch?v=sNaaU1MzsWk" --language nl
#date: 2023-11-18 - length:  1:05:20 - title: "Ondernemers en de politiek met Pancras Pouw"

#################### 			echo " \\" > add_fix.txt
#################### 			echo '	--tags="mk-ultra" \' >> add_fix.txt
#################### 			echo '	--tags="mind control" \' >> add_fix.txt
#################### 			echo '	--tags="ABC"' >> add_fix.txt
#################### 			
#################### 			sa "https://x.com/CarineKnapen/status/1963543888620122232" --language en

echo " \\" > add_fix.txt
echo '	--tags="LP" \' >> add_fix.txt
echo '	--tags="Dutch Libertarian Party" \' >> add_fix.txt
echo '	--tags="Libertaire Partij"' >> add_fix.txt

## saa "https://www.youtube.com/watch?v=czXxPKNdj1I" --language nl
## #date: 2023-11-18 - length:     1:14 - title: "Wie neemt het op voor de ondernemers?"
## 
## saa "https://www.youtube.com/watch?v=l4MkRh-VyYM" --language nl
## #date: 2024-01-09 - length:  1:17:02 - title: "De weg naar een staatloze samenleving met Olaf Weller"
## 
## saa "https://www.youtube.com/watch?v=kMjMy6Dk_og" --language nl
## #date: 2024-03-19 - length:  1:09:41 - title: ""De grote verbouwing van Nederland" met Elze van Hamelen"
## 
## saa "https://www.youtube.com/watch?v=FOctccSWR7s" --language nl
## #date: 2024-03-20 - length:     1:27 - title: "Een puzzelopdracht voor herverdeling"
## 
## 
## saa "https://www.youtube.com/watch?v=4FYzdQpLhuo" --language nl
## #date: 2024-03-22 - length:     1:57 - title: "Het fundament is zelfbeschikking"

saa "https://www.youtube.com/watch?v=BtGEcQAgets" --language nl
#date: 2024-03-22 - length:     2:20 - title: "Driekwart van ons land ging op de schop"

saa "https://www.youtube.com/watch?v=w00M3N9z95I" --language nl
#date: 2024-03-24 - length:     1:37 - title: "Ruilverkaveling was mogelijk door een 'crisis'"

saa "https://www.youtube.com/watch?v=hYWQaiR6kIQ" --language nl
#date: 2024-03-24 - length:     2:32 - title: ""Privébezit is dan het probleem""

saa "https://www.youtube.com/watch?v=H6_WHUiu_Hw" --language nl
#date: 2025-04-19 - length:     1:01 - title: "Bassie (Bas van Toor) over kunstsubsidies"

saa "https://www.youtube.com/watch?v=Y5XA_KwdirU" --language nl
#date: 2025-04-24 - length:       58 - title: "Mensen weten niet hoeveel belasting ze eigenlijk betalen"

saa "https://www.youtube.com/watch?v=35FUt5d7P1w" --language nl
#date: 2025-06-13 - length:     1:24 - title: "Tom van Lamoen over het probleem in het onderwijs"

saa "https://www.youtube.com/watch?v=-Ro8Ffbu_fI" --language nl
#date: 2025-08-13 - length:     3:45 - title: "Toine Manders ondervraagd door Renske Leijten"

saa "https://www.youtube.com/watch?v=sZ5qbsLLh3Q" --language nl
#date: 2025-08-17 - length:     2:07 - title: "NOS journaal 16 augustus 2025 - LP"

saa "https://www.youtube.com/watch?v=0gcA0ExIPK8" --language nl
#date: 2025-08-19 - length:    15:17 - title: "LightHouseTV #33: Tom van Lamoen | ‘Moestuinpolitie’"

saa "https://www.youtube.com/watch?v=58ymx16erLU" --language nl
#date: 2025-08-20 - length:    25:21 - title: "Doorzagen met John Medley, Hester Bais, Rico Brouwer en Tom van Lamoen"

saa "https://www.youtube.com/watch?v=MyTbymrbk1U" --language nl
#date: 2025-08-20 - length:    28:08 - title: "politiedocument radicalisering - Doorzagen met Dennis Spaanstra en Tom van Lamoen"

saa "https://www.youtube.com/watch?v=cw5ZYP7snEc" --language nl
#date: 2025-08-22 - length:    26:53 - title: "Doorzagen met lijsttrekker Tom van Lamoen - het ministerie van onderwijs; schaffen we af"

saa "https://www.youtube.com/watch?v=N_T8rnFHYw4" --language nl
#date: 2025-08-26 - length:    52:04 - title: "Het financiële stelsel is de kern van alle kwaad - Doorzagen met Hester Bais"

saa "https://www.youtube.com/watch?v=H7sHh4A6YGQ" --language nl
#date: 2025-08-27 - length:    34:36 - title: "de bank en de overheid - Doorzagen met Hester Bais en Tom van Lamoen"

saa "https://www.youtube.com/watch?v=9gMf3StqhWk" --language nl
#date: 2025-08-28 - length:    35:38 - title: "het klimaatverhaal wordt in stand gehouden om monetaire redenen - Marcel Crok verkiesbaar voor de LP"

saa "https://www.youtube.com/watch?v=O4HXSO1PGUo" --language nl
#date: 2025-08-29 - length:     1:36 - title: "Ondersteuningsverklaringen nodig"

exit

echo " \\" > add_fix.txt
echo '	--tags="media" \' >> add_fix.txt
echo '	--tags="Konstantin Kisin" \' >> add_fix.txt
echo '	--tags="Triggernometry"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=nfr-WjiTehM" --language en

echo " \\" > add_fix.txt
echo '	--tags="Monsanto" \' >> add_fix.txt
echo '	--tags="Veritasium"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=CxVXvFOPIyQ" --language en

echo " \\" > add_fix.txt
echo '	--tags="Monsanto" \' >> add_fix.txt
echo '	--tags="Full Documentary"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=4NQ6Tw7KXUk" --language en

exit 

echo " \\" > add_fix.txt
echo '	--tags="David Martin" \' >> add_fix.txt
echo '	--tags="DATA REQUEST" \' >> add_fix.txt
echo '	--tags="Warp speed"' >> add_fix.txt

saa "https://x.com/i/broadcasts/1yoKMPbaYrzxQ" --language en

echo " \\" > add_fix.txt
echo '	--tags="AI"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=aQnzxVk-qGY" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=QvH8A3Tp4gA" --language nl

echo " \\" > add_fix.txt
echo '	--tags="FVD" \' >> add_fix.txt
echo '	--tags="Thierry Baudet"' >> add_fix.txt

saa "https://x.com/Symphony_res/status/1961799457160200445" --language nl

exit 

echo " \\" > add_fix.txt
echo '	--tags="De Nieuwe Wereld" \' >> add_fix.txt
echo '	--tags="Andrea Speyerbach"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=xZIVrN-T7Zs" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="Wybren van Haga" \' >> add_fix.txt
## echo '	--tags="BVNL" \' >> add_fix.txt
## echo '	--tags="Haarlem105"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=RwLlCUtLQ7s" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=QXhHAlHvuw0" --language nl # 2025-04-02 -     6:54 - Afscheid Flavio Pasquino van Blckbx
## sa "https://www.youtube.com/watch?v=wvh1LK3jOIg" --language nl # 2025-04-16 -     1:26 - Steun LightHouseTV en bouw mee!
## sa "https://www.youtube.com/watch?v=XQAzfI7kQ-0" --language nl # 2025-04-17 -    20:09 - Flavio Pasquino lanceert LightHouseTV op MVO2025 en zoekt ondernemers met LEF!
## sa "https://www.youtube.com/watch?v=J3zia_lMLT0" --language nl # 2025-04-18 -     3:06 - Dít is LightHouseTV- Steun onze lancering op 5 mei!
## sa "https://www.youtube.com/watch?v=6M3S_gVvyOw" --language nl # 2025-04-25 -     4:14 - Crowdfund uitgelegd: dit doet LightHouseTV met je donaties
## sa "https://www.youtube.com/watch?v=wXg7jgQ2phY" --language nl # 2025-05-02 -     1:01 - We Zijn er (Bijna) Klaar Voor!
## sa "https://www.youtube.com/watch?v=t5dW-X5UpUE" --language nl # 2025-05-05 -    52:05 - LightHouseTV #1: Bevrijdingsdag | Nigel Farage wint met Reform UK | Trumps plan achter handelsoorlog
## sa "https://www.youtube.com/watch?v=_X3b7xFvkug" --language nl # 2025-05-06 -    12:34 - Zijn Bevrijdingsdag en dodenherdenking te verenigen met oorlogen van ons kabinet?
## sa "https://www.youtube.com/watch?v=zXNjo0qZkt8" --language nl # 2025-05-06 -    13:07 - Het economische spel achter Trumps invoerheffingen
## sa "https://www.youtube.com/watch?v=mGaWrdR6FPU" --language nl # 2025-05-07 -  1:02:57 - LightHouseTV #2: Stikstofultimatum Wiersma | Blackrocks bondskanselier | PFAS eieren gevaarlijk?
## sa "https://www.youtube.com/watch?v=nC6HDcSfcCQ" --language nl # 2025-05-07 -    14:26 - Reform UK van Nigel Farage - de man achter Brexit - wint opnieuw in Verenigd Koninkrijk
## sa "https://www.youtube.com/watch?v=-NxrJe2LgK0" --language nl # 2025-05-08 -    15:48 - RIVM adviseert geen particuliere eieren meer te eten. Wijs advies of nieuwe angstcampagne?
## sa "https://www.youtube.com/watch?v=TEXJQA9EIXU" --language nl # 2025-05-08 -    16:15 - Stikstofultimatum en dreigende rechtszaken voor Minister Wiersma als koers niet verandert
## sa "https://www.youtube.com/watch?v=DHi9xYHt5BI" --language nl # 2025-05-08 -    17:20 - Van Blackrock naar Duitse bondskanselier: Friedrich Merz
## sa "https://www.youtube.com/watch?v=T3zXtJAmaGc" --language nl # 2025-05-09 -  1:17:08 - LightHouseTV #3: EU-coronafonds gefileerd | 'Wanhoopsoffensief' CBDC | Toekomst Zaanse Schans
## sa "https://www.youtube.com/watch?v=S4SQ48AXf8M" --language nl # 2025-05-10 -    13:17 - Cultureel erfgoed in gevaar na nieuwe plannen voor Zaanse Schans
## sa "https://www.youtube.com/watch?v=8iEAuyy4XJY" --language nl # 2025-05-10 -    28:00 - ECB versnelt uitrol CBDC – Wat zit er achter deze haast?
## sa "https://www.youtube.com/watch?v=XdrXtqy2PSg" --language nl # 2025-05-11 -    20:45 - Coronaherstelfonds van 800 miljard gefileerd door Europese Rekenkamer
## sa "https://www.youtube.com/watch?v=bwJxPLtt1jQ" --language nl # 2025-05-12 -  1:16:30 - LightHouseTV #4: De aanhoudende oversterfte in Nederland doorgelicht - Wat weten we nu?
## sa "https://www.youtube.com/watch?v=JiRiGi99PHU" --language nl # 2025-05-13 -    21:16 - Duizenden missende doodsoorzaakverklaringen per jaar — CBS registratie faalt
## sa "https://www.youtube.com/watch?v=gMVcq9sr1sg" --language nl # 2025-05-13 -    26:50 - Oversterfte-onderzoek Meester vraagt om antwoorden - waarom blijft actie uit?
## sa "https://www.youtube.com/watch?v=5VD2jW-gakM" --language nl # 2025-05-14 -  1:00:05 - LightHouseTV #5: Dreiging zzp-rechtszaken | Pensioenen onder vuur | Megadeals Trump in Saoedi-Arabië
## sa "https://www.youtube.com/watch?v=i0UphLVUBYo" --language nl # 2025-05-14 -    17:46 - Huisarts onthult hoe Nederlanders vertrouwen kwijtraken in de medische wetenschap
## sa "https://www.youtube.com/watch?v=49Gxpa6K4mo" --language nl # 2025-05-15 -    13:51 - Zzp'ers klagen opdrachtgevers aan voor schijnzelfstandigheid, opdrachtgevers betalen tienduizenden
## sa "https://www.youtube.com/watch?v=S3I4W0im_j4" --language nl # 2025-05-15 -    16:10 - Welke deal van 600 miljard dollar sloot Trump met Saoedi-Arabië?
## sa "https://www.youtube.com/watch?v=XrOPsf-6Q8I" --language nl # 2025-05-16 -  1:09:01 - LightHouseTV #6: BVNL wint WHO-rechtszaak | Politie aan huis demonstranten | 'No-show' Poetin
## 
## echo " \\" > add_fix.txt
## echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
## echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
## echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=Ew5SQaavB_g" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="RichardDWolff" \' >> add_fix.txt
## echo '	--tags="Wolff Responds" \' >> add_fix.txt
## echo '	--tags="globalising"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=QpY4xQk9_8I"  --language en

## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=U-1K9VkKZb4" --language nl # 2025-05-16 -    16:27 - Pensioenwet: Hoe Nederland de controle over 1500 miljard pensioengeld dreigt te verliezen
## sa "https://www.youtube.com/watch?v=HVgrjhxusOQ" --language nl # 2025-05-17 -    14:06 - BVNL wint van overheid in rechtszaak en clasht met minister Agema over pandemieverdrag!
## sa "https://www.youtube.com/watch?v=z4ET8VvQJB0" --language nl # 2025-05-17 -    19:45 - Inspectiedienst tikt politie op de vingers over intimiderend huisbezoek
## sa "https://www.youtube.com/watch?v=q4EwGVovSg4" --language nl # 2025-05-18 -    20:32 - Rutte noemt Poetins 'no show' bij het vredesoverleg een grote fout: "He is in trouble"
## sa "https://www.youtube.com/watch?v=VX9e2qQE2nU" --language nl # 2025-05-19 -  1:20:14 - LightHouseTV #7: Blackouts in Nederland? | Pandemieverdrag en autonomie | Dreigt er een watertekort?
## sa "https://www.youtube.com/watch?v=vEY9aqFBRaA" --language nl # 2025-05-20 -    21:55 - Pandemieverdrag bij WHO-vergadering in Genève: Wat staat Nederland te wachten?
## sa "https://www.youtube.com/watch?v=yTO5rSYsCnE" --language nl # 2025-05-20 -    24:18 - Nederland op weg naar een black-out door energietransitie?

## sa "https://www.youtube.com/watch?v=zSRpdpOtdwg" --language nl # 2025-05-21 -  1:10:36 - LightHouseTV #8: Pandemieverdrag akkoord | Politie negeert Woo | Einde wolfbescherming?
## sa "https://www.youtube.com/watch?v=8YF3GzB4P_c" --language nl # 2025-05-21 -    24:30 - Dreigt er na 2030 een watertekort in Nederland en wat is er nodig?
## sa "https://www.youtube.com/watch?v=vh_VL2AkGwg" --language nl # 2025-05-22 -    17:28 - WHO akkoord over pandemieverdrag: wat zijn de gevolgen?
## sa "https://www.youtube.com/watch?v=CzVFrcbO_T0" --language nl # 2025-05-21 -  1:08:57 - LightHouseTV #8: Pandemieverdrag akkoord | Politie negeert Woo | Einde wolfbescherming?
## sa "https://www.youtube.com/watch?v=QaM_1JvDWl0" --language nl # 2025-05-22 -    20:27 - Wat verandert het EU-besluit nu voor de Nederlandse wolf?
## sa "https://www.youtube.com/watch?v=Q8LzRQflyQo" --language nl # 2025-05-23 -  1:03:52 - LightHouseTV #9: Censuuroorlog EU | Wiersma vs Woo privégegevens boeren | 'Miljardenzwendel' kabinet
## sa "https://www.youtube.com/watch?v=4i5rMx5ozoA" --language nl # 2025-05-23 -    21:21 - Politie negeert Woo én rechterlijk bevel in openbaren van geheime burgerdata
## sa "https://www.youtube.com/watch?v=cDKWxnUTXRo" --language nl # 2025-05-25 -    13:27 - Ontmaskerd: EU's propagandaoorlog van 650 miljoen tegen de vrijheid van meningsuiting
## sa "https://www.youtube.com/watch?v=mtS7R8KtWzM" --language nl # 2025-05-25 -    19:30 - 16 miljard euro ‘verdwenen’ bij Buitenlandse Zaken – Verantwoordingsdag 2025
## sa "https://www.youtube.com/watch?v=qINuzrkK3yA" --language nl # 2025-05-26 -  1:08:53 - LighthouseTV #10: Defensie vs. burger | 'Stikstofdoorbraak' afgeschoten | Geopolitiek voor jongeren
## sa "https://www.youtube.com/watch?v=u129-D5sjZI" --language nl # 2025-05-26 -    21:34 - Minister Wiersma negeert Woo-verzoek voor privacy van boeren
## sa "https://www.youtube.com/watch?v=Zrc9N4htYQI" --language nl # 2025-05-27 -    20:36 - Defensie onthult 57 locaties voor uitbreiding van de krijgsmacht in Nederland
## sa "https://www.youtube.com/watch?v=f79tP_2cAGY" --language nl # 2025-05-27 -    21:20 - Raad van State torpedeert ‘stikstofdoorbraak’ kabinet: FVD komt met meetbaar alternatief
## sa "https://www.youtube.com/watch?v=lKlNO5wpvNo" --language nl # 2025-05-28 -  1:05:15 - LightHouseTV #11: Klimaatexamen | FVD uit coronacommissie | ‘Blanke genocide’: complottheorie?
## sa "https://www.youtube.com/watch?v=n6qEOR2FRM0" --language nl # 2025-05-28 -    15:42 - Mees Wijnants over Kajsa Ollongren, netwerkcorruptie en de nieuwe generatie
## sa "https://www.youtube.com/watch?v=bRZk2JMhFCk" --language nl # 2025-05-29 -    13:14 - Hoe objectief is het Klimaatexamen? Journaliste Danielle van Wallinga deed onderzoek
## sa "https://www.youtube.com/watch?v=bexJ4jp76Uo" --language nl # 2025-05-29 -    14:41 - Waarom de NOS en MSM het geweld op blanke boeren in Zuid-Afrika verzwijgen
## sa "https://www.youtube.com/watch?v=w4Ee80RFgg8" --language nl # 2025-05-29 -    21:45 - Mini docu: "Kill the Boer”. Genocide – ja of nee?
## sa "https://www.youtube.com/watch?v=U0qEBOmzq3M" --language nl # 2025-05-29 -    24:14 - Waarom Gideon van Meijeren uit de parlementaire enquêtecommissie corona stapte
## sa "https://www.youtube.com/watch?v=mnP1D1SxsoA" --language nl # 2025-05-30 -  1:43:12 - LightHouseTV #12: Trumps Golden Dome | RFK Jr. onder vuur! | Moskou dreigt na wapensteun
## 
## echo " \\" > add_fix.txt
## echo '	--tags="🐇" \' >> add_fix.txt
## echo '	--tags="The White Rabbit Podcast"' >> add_fix.txt
## 
## saa "https://x.com/AllBiteNoBark88/status/1973204968401412501" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="RadioGenoa" \' >> add_fix.txt
## echo '	--tags="UK" \' >> add_fix.txt
## echo '	--tags="censorship"' >> add_fix.txt
## 
## sa "https://x.com/nogulagsagain/status/1972645818768519567" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=7PyE0eis0UY" --language nl # 2025-05-31 -    20:22 - Kennedy’s MAHA-rapport onder vuur - Spiegelbeeld Magazine over alternatieve kijk op gezondheid
## sa "https://www.youtube.com/watch?v=uYUHWA8X5I0" --language nl # 2025-05-31 -    31:55 - Felle Russische reactie op Duitse steun bij productie Taurus-raketten voor Oekraïne
## 
## echo " \\" > add_fix.txt
## echo '	--tags="blckbx" \' >> add_fix.txt
## echo '	--tags="Piratenpartij" \' >> add_fix.txt
## echo '	--tags="Matthijs Pontie"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=5FxGADJiz-s" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Carl Jung" \' >> add_fix.txt
## echo '	--tags="The Silent War"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=uOa7SR6o_hI" --language en
## 
## echo '	--tags="Jordan Peterson" \' >> add_fix.txt
## echo '	--tags="Empaths"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=iQ8oTXlhfcw" --language en
## 
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=OdQBVn6AC8I" --language nl # 2025-06-01 -    23:34 - Start Trump met zijn 'Golden Dome' een wapenwedloop in de ruimte?
## sa "https://www.youtube.com/watch?v=aRuwgfmvYHo" --language nl # 2025-06-02 -  1:14:36 - LightHouseTV #13: Einde kabinet? | Oversterfte: NL vs Bulgarije | Oekraïne toch bij de NAVO?
## sa "https://www.youtube.com/watch?v=g_ShcLs6MW8" --language nl # 2025-06-03 -    18:52 - Einde kabinet? Wilders zinspeelt op vertrek na crisisoverleg
## sa "https://www.youtube.com/watch?v=FLMNU1q6ZNc" --language nl # 2025-06-03 -    19:16 - Ondersterfte in Bulgarije vs oversterfte in Nederland - hoe kan dit?
## sa "https://www.youtube.com/watch?v=cKrSo4Frg-M" --language nl # 2025-06-04 -  1:18:28 - LightHouseTV #14: Val kabinet: hoe nu verder? | Monetaire 'big reset' | 'Ruslands Pearl Harbor'
## sa "https://www.youtube.com/watch?v=ydb6MfVuym0" --language nl # 2025-06-04 -    19:01 - Waarom komen de nieuwe media in België zo traag op gang?
## sa "https://www.youtube.com/watch?v=hcO9FPWwzDQ" --language nl # 2025-06-05 -    15:04 - Wie zit er achter de drone-aanval die 'Ruslands Pearl Harbor' wordt genoemd?
## sa "https://www.youtube.com/watch?v=ePl3WZ2O5bo" --language nl # 2025-06-05 -    38:00 - 29 oktober verkiezingen! Hoe komt NL uit impasse na val kabinet?
## sa "https://www.youtube.com/watch?v=NyzP86q_BK8" --language nl # 2025-06-06 -  1:21:26 - LightHouseTV #15: Breuk Trump & Musk | Bespioneerd door META | Landbouw vogelvrij na val kabinet?
## sa "https://www.youtube.com/watch?v=LwPkih6-hSw" --language nl # 2025-06-06 -    15:12 - Dedollarisatie, afkalvende middenklasse en ‘de grote reset’ met monetair econoom Brecht Arnaert
## sa "https://www.youtube.com/watch?v=TsVVyShYj-g" --language nl # 2025-06-07 -    18:23 - Ongelooflijke ruzie Musk en Trump: wat speelt er écht?
## sa "https://www.youtube.com/watch?v=5SY-YZc4FXI" --language nl # 2025-06-07 -    20:11 - Facebook en Instagram bespioneren Android-gebruikers via achterdeur
## sa "https://www.youtube.com/watch?v=oAR_ZnD4b30" --language nl # 2025-06-08 -    28:50 - Val kabinet luidt dramatische periode in voor Wiersma en de boeren
## sa "https://www.youtube.com/watch?v=_ZRYI3tRu8Q" --language nl # 2025-06-09 -  1:32:38 - LightHouseTV #16: Burgers houden grenscontroles Ter Apel | Noodwet Defensie | 'Asielcrisis in beeld'
## sa "https://www.youtube.com/watch?v=T6fsc5nqbEQ" --language nl # 2025-06-09 -  2:24:45 - Livestream Demonstratie AZC Dordrecht
## sa "https://www.youtube.com/watch?v=H4JX_xS-oz8" --language nl # 2025-06-10 -    23:05 - Burgercontrole bij grens Ter Apel: actievoerder sluit nieuwe acties niet uit
## sa "https://www.youtube.com/watch?v=ZSV8ctryI2o" --language nl # 2025-06-10 -    34:44 - ‘Noodwet’ in de maak: Defensie wil uitzonderlijke bevoegdheden
## sa "https://www.youtube.com/watch?v=lrumaOaUvKo" --language nl # 2025-06-11 -  1:24:49 - LightHouseTV #17: Weigert Kiev dodenruil? | Wilders grootste na uitsluiting! | Preppen in crisistijd
## sa "https://www.youtube.com/watch?v=YvmHzOSGdTE" --language nl # 2025-06-11 -    26:43 - Docu: 'De Nederlandse asielcrisis in beeld’ over extra AZC’s in Brabant
## sa "https://www.youtube.com/watch?v=j_C-_7gdj6Q" --language nl # 2025-06-12 -    15:53 - Koelwagens vol gesneuvelde soldaten aan de Oekraïense grens 'geweigerd' door Zelensky
## sa "https://www.youtube.com/watch?v=rWgUGmqyX-I" --language nl # 2025-06-12 -    28:00 - Wilders wéér de grootste, maar mag niet regeren — Kan ons politieke systeem nog functioneren?
## sa "https://www.youtube.com/watch?v=tT89Xlyyyrw" --language nl # 2025-06-13 -  1:03:09 - LightHouseTV #18: Arrestatie 'soevereinen' | Bilderberg | WOIII Iran vs Israël? | Machtsspel China
## sa "https://www.youtube.com/watch?v=KAYU_-zNo28" --language nl # 2025-06-13 -    21:07 - Preppen voor noodscenario's. Paniekzaaierij of gezonde zelfredzaamheid?
## sa "https://www.youtube.com/watch?v=G_DuS0NSDVs" --language nl # 2025-06-14 -    17:25 - Israël slaat toe in Iran: dreigt een nucleaire escalatie?
## sa "https://www.youtube.com/watch?v=vf7MPF0TALg" --language nl # 2025-06-14 -     9:43 - Arno van Kessel, advocaat die tegen Rutte en Gates procedeert, zelf gearresteerd
## sa "https://www.youtube.com/watch?v=adBPPp1gk_I" --language nl # 2025-06-15 -    15:51 - EU’s afhankelijkheid pijnlijk blootgelegd na grondstoffendeal VS & China
## sa "https://www.youtube.com/watch?v=N5BMmf6LzMg" --language nl # 2025-06-16 -  1:31:37 - LightHouseTV #19: Iran vs Israël | Wie draait op voor NAVO-norm? | Rode Lijn demonstratie Den Haag
## sa "https://www.youtube.com/watch?v=5btj17R_7CY" --language nl # 2025-06-17 -    24:40 - Iran slaat terug: raketaanvallen raken Israëlische steden
## sa "https://www.youtube.com/watch?v=HVPHfGIVO_o" --language nl # 2025-06-17 -    29:26 - Demissionair kabinet wil 5% van de economie naar Defensie - wie draait hiervoor op?
## sa "https://www.youtube.com/watch?v=CD3e9kB1s2U" --language nl # 2025-06-18 -  1:34:34 - LightHouseTV #20: Valt Trump Iran aan? | Gevreesde rellen bij NAVO-top | Partijverbod op de loer?
## sa "https://www.youtube.com/watch?v=-coLRhTBlRM" --language nl # 2025-06-18 -    23:54 - ‘Rode Lijn-protest’ met 150.000 Gaza-demonstranten roept vragen op
## sa "https://www.youtube.com/watch?v=_V0CO2R54ic" --language nl # 2025-06-19 -    23:29 - Nieuw wetsvoorstel geeft ruimte aan verbod op politieke partijen
## sa "https://www.youtube.com/watch?v=_syUExogh8c" --language nl # 2025-06-19 -    27:31 - Valt Amerika Iran aan en breekt Trump zijn belofte?
## sa "https://www.youtube.com/watch?v=jAEqhks_5g4" --language nl # 2025-06-20 -  1:07:46 - LightHouseTV #21: 'Absurde' Israël-motie GL-PvdA | NAVO-top vs parlement | Klimaatdoelen 2050
## 
## echo " \\" > add_fix.txt
## echo '	--tags="planned obsolescence"' >> add_fix.txt
## 
## saa "https://x.com/itsme_urstruly/status/1974074980926415206" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Reiner Fuellmich" \' >> add_fix.txt
## echo '	--tags="Arno van Kessel"' >> add_fix.txt
## 
## saa "https://x.com/FreeFuellmich/status/1970923486114988254" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=cY3XmC4ClBs" --language nl # 2025-06-20 -    24:51 - NAVO-top ‘vreest’ voor rellen na groots aangekondigde demonstraties!
## 
## echo " \\" > add_fix.txt
## echo '	--tags="mandatory" \' >> add_fix.txt
## echo '	--tags="consent"' >> add_fix.txt
## 
## saa "https://www.facebook.com/100069189664601/videos/1266740845138269" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=UUT1LZEgKvY" --language nl # 2025-06-21 -    19:48 - Klimaatneutraal in 2050: Europese ‘Net Zero-droom’ dreigt nachtmerrie te worden
## sa "https://www.youtube.com/watch?v=kHCaP4RLCCw" --language nl # 2025-06-21 -    20:36 - Timmermans wil Iron Dome schrappen: ‘Israëlische burgers zijn hier zelf verantwoordelijk voor’
## sa "https://www.youtube.com/watch?v=D2aEHzuSG9c" --language nl # 2025-06-22 -    15:37 - Waarom Eerste Kamerlid Eric Kemperman brak met BBB
## sa "https://www.youtube.com/watch?v=38Byx5oEMkE" --language nl # 2025-06-23 -  1:15:28 - LightHouseTV #22: Aanval VS-Iran | Vooruitblik NAVO-top & 'Russische dreiging' | Opstand AZC De Bilt
## sa "https://www.youtube.com/watch?v=-GYFqtGQ_fc" --language nl # 2025-06-24 -    18:39 - Trump slaat toe met gewaagde 'Top Gun'-operatie in Iran
## sa "https://www.youtube.com/watch?v=15wI-f6Z7bU" --language nl # 2025-06-24 -    22:10 - NAVO-top van start: overschatten we 'de Russische dreiging'?
## sa "https://www.youtube.com/watch?v=7_2Jwp4fF6M" --language nl # 2025-06-25 -  1:24:15 - LightHouseTV #23: VS-aanval Iran 'mislukt' | Nepnieuws-claim tegen NOS | NAVO-top voorbij: en nu?
## sa "https://www.youtube.com/watch?v=DlbjG-AiX54" --language nl # 2025-06-25 -    23:49 - AZC De Bilt slaat in als een bom: ‘Honderden jonge mannen uit Eritrea en Syrië op komst!’
## sa "https://www.youtube.com/watch?v=IpGCe81NwOM" --language nl # 2025-06-26 -    21:25 - NAVO-top ten einde: lidstaten moeten verantwoording gaan afleggen aan de NAVO over 5%-norm
## sa "https://www.youtube.com/watch?v=0amoV8arkUo" --language nl # 2025-06-26 -    22:08 - Plottwist na Iran-aanval: Pentagon-lek stelt dat ‘uranium grotendeels intact’ bleef - Trump ontkent
## sa "https://www.youtube.com/watch?v=IbyoC5nsIaM" --language nl # 2025-06-27 -  1:27:40 - LightHouseTV #24: Bijensterfte door 5G? | Zelensky & Ursula's "full-scale war" | Analyse NAVO-top
## sa "https://www.youtube.com/watch?v=nEctK-HBf68" --language nl # 2025-06-27 -    22:25 - NOS weigert rectificatie na 'nepnieuws' over migratiepolitiek in Italië
## sa "https://www.youtube.com/watch?v=gHGTmsZFciU" --language nl # 2025-06-28 -    23:42 - Wat als Nederland de NAVO verlaat? Een alternatief plan
## sa "https://www.youtube.com/watch?v=lMsIRnCJw20" --language nl # 2025-06-28 -    25:40 - Wat doodt onze bijen? 5G, pesticiden en andere factoren onder de loep
## sa "https://www.youtube.com/watch?v=BYJbvnNGLiw" --language nl # 2025-06-29 -    18:59 - Zelensky en Ursula von der Leyens "full-scale war"
## sa "https://www.youtube.com/watch?v=hs_q_GgPMss" --language nl # 2025-06-30 -  1:22:11 - LightHouseTV #25: prof. kraakt coronamaatregelen | AZC-demo Haarlem | Parkeerverbod eigen oprit?
## sa "https://www.youtube.com/watch?v=knTyrFZ8-1s" --language nl # 2025-07-01 -    13:26 - 'Ze kunnen de pleuris krijgen!' - AZC-demo in Haarlem zet demonstranten lijnrecht tegenover elkaar
## sa "https://www.youtube.com/watch?v=erMQQh1q8QE" --language nl # 2025-07-01 -    19:49 - Parkeren op je eigen oprit op de tocht
## sa "https://www.youtube.com/watch?v=IMUOME_LHvE" --language nl # 2025-07-01 -    25:30 - Prof. Schippers en 36 wetenschappers publiceren vernietigend onderzoek naar coronabeleid
## sa "https://www.youtube.com/watch?v=y6mCvLMz5LQ" --language nl # 2025-07-02 -  1:20:51 - LightHouseTV #26: Defensie onteigent boeren | 'stop hypotheekrenteaftrek' | Dienstplicht offensief
## sa "https://www.youtube.com/watch?v=kKFRG_rgwUY" --language nl # 2025-07-02 -    19:14 - AZC in Haarlem? Buurtbewoners sterk verdeeld over plannen
## sa "https://www.youtube.com/watch?v=yRvlDIOYdBI" --language nl # 2025-07-03 -    22:05 - Herinvoering dienstplicht voor onder andere asielzoekers?
## sa "https://www.youtube.com/watch?v=A9-be6ACdYA" --language nl # 2025-07-03 -    28:28 - Defensie onteigent: boeren raken land, bedrijf en huis kwijt
## sa "https://www.youtube.com/watch?v=jlIn0i5nyvg" --language nl # 2025-07-04 -  1:12:01 - LightHouseTV #27: AI, financiële vrijheid en gezondheid - Hoe willen we het dan wél?
## sa "https://www.youtube.com/watch?v=Dd6FzgeOoc4" --language nl # 2025-07-04 -    16:05 - Ambtenaren willen hypotheekrenteaftrek schrappen - huizenmarkt op kantelpunt?
## sa "https://www.youtube.com/watch?v=KIdajkqgDdI" --language nl # 2025-07-05 -    16:25 - Trumps AI-plan geblokkeerd! Hoeveel controle willen wij op AI?
## sa "https://www.youtube.com/watch?v=DxJ11oPOheM" --language nl # 2025-07-05 -    22:02 - FBI ontdekt grootste medische fraude ooit in VS: 15 miljard aan valse zorgclaims
## sa "https://www.youtube.com/watch?v=Pk5SKs9g9WA" --language nl # 2025-07-06 -    20:34 - Hoe ontsnap je uit ‘de financiële piramide van de elite?’
## sa "https://www.youtube.com/watch?v=wcbBy0pdWV8" --language nl # 2025-07-07 -  1:16:08 - LightHouseTV #28: BRICS-top: Global South vs. het Westen: wie wint de strijd om werelddominantie?
## sa "https://www.youtube.com/watch?v=G-Zj7w9-vrU" --language nl # 2025-07-08 -    14:45 - Hoe Europa zichzelf buiten spel zet
## sa "https://www.youtube.com/watch?v=Miw1UN-OCLg" --language nl # 2025-07-08 -    26:20 - BRICS-top rekent af met Westerse ‘Golden Billion’ en bouwt nieuwe veiligheidsorde
## sa "https://www.youtube.com/watch?v=Ti2e2GS9KLU" --language nl # 2025-07-09 -  1:39:13 - LightHouseTV #29: Baudet over NEXIT | Verslag rechtszaak Bill Gates | Sanering garnalenvissers
## sa "https://www.youtube.com/watch?v=RbP6H0H3rEU" --language nl # 2025-07-09 -    21:42 - Waarom Iran bij de BRICS Amerika grote zorgen baart
## sa "https://www.youtube.com/watch?v=q5bdH5iP9Jo" --language nl # 2025-07-10 -    19:12 - Demissionair kabinet ‘draait visserij de nek om’
## sa "https://www.youtube.com/watch?v=XBg9KskDL7I" --language nl # 2025-07-10 -    21:05 - Verslag van de rechtszaak in Leeuwarden tegen Bill Gates, Rutte, Koopmans en andere hoofdrolspelers
## sa "https://www.youtube.com/watch?v=3jFcMdDH1tQ" --language nl # 2025-07-11 -  1:48:40 - LightHouseTV #30: Seizoensafsluiter! – De rol van nieuwe media: wat kunnen we en wat móeten we doen?
## sa "https://www.youtube.com/watch?v=2NjYeN5y8aQ" --language nl # 2025-07-11 -    36:27 - Thierry Baudet presenteert plan voor een succesvolle Nexit
## sa "https://www.youtube.com/watch?v=OAUw9AvNH8E" --language nl # 2025-07-12 -    22:49 - DPG vergroot 'mediamonopolie' na overname RTL: vrije pers verder onder druk?
## sa "https://www.youtube.com/watch?v=y6YL2b2DOg0" --language nl # 2025-07-13 -    15:32 - Wat staat ons te doen als je de agenda's doorziet?
## sa "https://www.youtube.com/watch?v=PAnX8CuR0RE" --language nl # 2025-07-13 -    25:18 - Waarom alternatieve media zijn begonnen naast MSM
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Doug Macgregor" \' >> add_fix.txt
## echo '	--tags="Daniel Davis" \' >> add_fix.txt
## echo '	--tags="Deep Dive"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=aqkUlZH-c0E" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=zNhSvjRXo8c" --language nl # 2025-07-14 -    59:11 - Coen Vermeeren: 'Het TU Delft- & 9/11-dossier', #1
## sa "https://www.youtube.com/watch?v=s_Dc0ZNCrTk" --language nl # 2025-07-16 -    53:08 - Documentaire 'The Agenda' - Deel 1  (Nederlands ondertiteld)
## sa "https://www.youtube.com/watch?v=0A5zE5EYGt0" --language nl # 2025-07-18 -  1:05:20 - Documentaire 'The Agenda' - Deel 2 (Nederlands ondertiteld)
## sa "https://www.youtube.com/watch?v=4oz7xIq-x4Q" --language nl # 2025-07-21 -    54:11 - Coen Vermeeren: 'Ufo's bestaan gewoon', #2
## sa "https://www.youtube.com/watch?v=yh2bD3gAAa4" --language nl # 2025-07-23 -    34:23 - Kees Faasse, het eerste corona-interview in 2020
## sa "https://www.youtube.com/watch?v=Kje3T9qOGQA" --language nl # 2025-07-25 -    25:06 - Kees Faasse 5 jaar later
## sa "https://www.youtube.com/watch?v=z023sEM4yh4" --language nl # 2025-07-28 -    45:26 - Coen Vermeeren: 'Elites & Valse Goden', #3
## 
## echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## ## 
## echo " \\" > add_fix.txt
## echo '	--tags="MORAL CORRUPTION" \' >> add_fix.txt
## echo '	--tags="LHBTQ" \' >> add_fix.txt
## echo '	--tags="SEXUALIZATION"' >> add_fix.txt
## 
## saa "https://rumble.com/v5hscwi-a-history-of-sexualization-and-moral-corruption-of-twentieth-century-german.html" --language en
## 
## rm BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=NppChX2Wh3U" --language nl # 2025-07-30 -    20:40 - Wendy Kroeze, alias 'Het Bloemenmeisje', 5 jaar geleden
## sa "https://www.youtube.com/watch?v=hRla9Z5Ehkw" --language nl # 2025-08-01 -    26:57 - Wendy Kroeze,  Het Bloemenmeisje, vijf jaar later
## sa "https://www.youtube.com/watch?v=zHwctu23o3I" --language nl # 2025-08-04 -    55:19 - Coen Vermeeren: 'De Chemtrailagenda', #4
## sa "https://www.youtube.com/watch?v=jZVtRwHK01g" --language nl # 2025-08-06 -    19:52 - Anja Brokken, vijf jaar geleden
## sa "https://www.youtube.com/watch?v=Ahyfp9D9OBA" --language nl # 2025-08-08 -    19:41 - Anja Brokken, 5 jaar later
## sa "https://www.youtube.com/watch?v=cMesX-2uJvE" --language nl # 2025-08-11 -    34:44 - Klinisch ethicus dr. Erwin Kompanje, vijf jaar geleden
## sa "https://www.youtube.com/watch?v=HnpLnuS6vdc" --language nl # 2025-08-13 -  1:25:15 - LightHouseTV #31: Trump clasht met EU & Zelensky | Einde open internet | EU-handelsakkoord

## echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="MORAL CORRUPTION" \' >> add_fix.txt
## echo '	--tags="LHBTQ" \' >> add_fix.txt
## echo '	--tags="SEXUALIZATION"' >> add_fix.txt
## 
## saa "https://rumble.com/v5hscwi-a-history-of-sexualization-and-moral-corruption-of-twentieth-century-german.html" --language en
## 
## rm BURN_VIDEO2.TXT
## 
## echo " \\" > add_fix.txt
## echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=ztimyYvypGE" --language nl # 2025-08-14 -    19:51 - De 'nederlaag' van von der Leyen in 'the biggest deal ever' met Trump
## sa "https://www.youtube.com/watch?v=rQDbD-1S6lI" --language nl # 2025-08-14 -    23:10 - Zelensky en EU buitenspel bij Trumps vredesgesprek met Poetin: ‘EU is toeschouwer!’
## sa "https://www.youtube.com/watch?v=NkERHujOwRg" --language nl # 2025-08-15 -  1:40:40 - LightHouseTV #32: Voorbeschouwing en analyse historische vredesbespreking van Trump-Poetin in Alaska
## sa "https://www.youtube.com/watch?v=JUjc3Th6QE8" --language nl # 2025-08-15 -    18:15 - Einde open internet door 'Online Safety Act' in Verenigd Koninkrijk

echo "BURN_VIDEO2.TXT" > BURN_VIDEO2.TXT

echo " \\" > add_fix.txt
echo '	--tags="911"' >> add_fix.txt

# saf_911 "102 Minutes That Changed America 15th Anniversary Edition.mkv" --language en
# saf_911 "102 Minutes That Changed America.avi" --language en
# saf_911 "15 Septembers Later 2016.mkv" --language en
# saf_911 "15 Years Later 2016.mkv" --language en
saf_911 "16 Acres The Struggle to Rebuild Ground Zero.mkv" --language en
saf_911 "1st hit 2002 cbs version.avi" --language en
saf_911 "1st hit 2006 version.avi" --language en
saf_911 "1st hit dvd version.avi" --language en
saf_911 "2002 cbs version.avi" --language en
saf_911 "2006 extra content.avi" --language en
saf_911 "2006 version.avi" --language en
saf_911 "2nd hit 2002 cbs version.avi" --language en
saf_911 "2nd hit 2006 version.avi" --language en
saf_911 "2nd hit dvd version.avi" --language en
saf_911 "910 The Final Hours.mkv" --language en
saf_911 "911 After the Towers Fell.avi" --language en
saf_911 "911 - Control the Skies 2019.mkv" --language en
saf_911 "911 Crime Scene Investigators.avi" --language en
saf_911 "9 11 Emergency Room.mp4" --language en
saf_911 "911 Firehouse Ground Zero.avi" --language en
saf_911 "9-11 Inside Air Force One 2019.mkv" --language en
saf_911 "911 Inside the Pentagon 2016 (2).mkv" --language en
saf_911 "911 Inside the Pentagon 2016.mkv" --language en
saf_911 "911 Remembered  A Day of Infamy.mp4" --language en
saf_911 "911 Rescue Cops.mp4" --language en
saf_911 "911 Science and Conspiracy.mkv" --language en
saf_911 "9 11 State of Emergency 2010.mkv" --language en
saf_911 "9-11 The Final Minutes of Flight 93 2020.mkv" --language en
saf_911 "911 The Heartland Tapes.mkv" --language en
saf_911 "911 The Lost Tapes.avi" --language en
saf_911 "911 The Woman Who Wasn't There.mkv" --language en
saf_911 "9-11 Timeline Of Terror.avi" --language en
saf_911 "911 Washington Under Attack.avi" --language en
saf_911 "911 Where Were You.mp4" --language en
saf_911 "Air Crash Investigation S16E02 911 The Pentagon Attack.avi" --language en
saf_911 "Americas 911 Flag Rise From The Ashes 2016.mkv" --language en
saf_911 "BBC That September Day 2011.mkv" --language en
saf_911 "Beyond 911 Portraits of Resilience.mp4" --language en
saf_911 "Boatlift - An Untold Tale of 9 11.mp4" --language en
saf_911 "Brothers on Holy Ground 911.mp4" --language en
saf_911 "Ch4 Children of 911 Our Story.mkv" --language en
saf_911 "Days That Shaped America 911.mkv" --language en
saf_911 "Giuliani  Commanding 911.mp4" --language en
saf_911 "Ground Zero - Shockin 911.mp4" --language en
saf_911 "Heroes of 9 11.mp4" --language en
saf_911 "History Channel  911 the Days After 1.mp4" --language en
saf_911 "History Channel  911 the Days After 2.mp4" --language en
saf_911 "History Channel  911 the Days After 3.mp4" --language en
saf_911 "History Channel  911 the Days After 4.mp4" --language en
saf_911 "History Channel  911 the Days After 5.mp4" --language en
saf_911 "History Channel  911 the Days After 6.mp4" --language en
saf_911 "hoppa" --language en
saf_911 "In Memoriam New York City  911 2002.mp4" --language en
saf_911 "I Survived.. 9 11.mp4" --language en
saf_911 "ITV 911 Life Under Attack.mkv" --language en
saf_911 "itv - 911 The Day That Changed The World [MP4-AAC](oan).mp4" --language en
saf_911 "National Geographic Inside 9-11 Witness DC 9-11.mkv" --language en
saf_911 "NG 9 11 One Day in America 1of6 First Response.mkv" --language en
saf_911 "NG 9 11 One Day in America 2of6 The South Tower.mkv" --language en
saf_911 "NG 9 11 One Day in America 3of6 Collapse.mkv" --language en
saf_911 "NG 9 11 One Day in America 4of6 The Cloud.mkv" --language en
saf_911 "NG 9 11 One Day in America 5of6 I'm Coming for You Brother.mkv" --language en
saf_911 "NG 9 11 One Day in America 6of6 It's All Gone Kid.mkv" --language en
saf_911 "PBS 9-11 Emergency Room.mkv" --language en
saf_911 "PBS 911 Escape from the Impact Zone.mkv" --language en
saf_911 "President George W. Bush  The 911 Interview.mp4" --language en
saf_911 "Rising Rebuilding Ground Zero 1of6 Reclaiming the Skyline 1.avi" --language en
saf_911 "Rising Rebuilding Ground Zero 2of6 Reclaiming the Skyline 2.avi" --language en
saf_911 "Rising Rebuilding Ground Zero 3of6 A Gateway to New York.avi" --language en
saf_911 "Rising Rebuilding Ground Zero 4of6 A New City.avi" --language en
saf_911 "Rising Rebuilding Ground Zero 5of6 Stories from the Pile.avi" --language en
saf_911 "Rising Rebuilding Ground Zero 6of6 A Place to Mourn.avi" --language en
saf_911 "Seconds From Disaster S01E13 Pentagon 911.avi" --language en
saf_911 "Seconds from Disaster S04E01 911.avi" --language en
saf_911 "September 11 2001 Tribute (15 years later).mp4" --language en
saf_911 "September 11th As It Happened  The Definitive Live News Montage.mp4" --language en
saf_911 "Smithsonian 911 Stories In Fragments.mkv" --language en
saf_911 "The 911 Surfer.mp4" --language en
saf_911 "The Air Traffic Controllers of 911.mp4" --language en
saf_911 "The Day that Shook the World.mp4" --language en
saf_911 "The Last Hour of Flight 11.mp4" --language en
saf_911 "The Last Secrets of 911.mp4" --language en
saf_911 "the Miracle of Stairwell B.mp4" --language en
saf_911 "Voices From Inside the Towers 2011.mkv" --language en
saf_911 "VTS_01_1.VOB" --language en
saf_911 "VTS_01_2.VOB" --language en
saf_911 "VTS_01_4.VOB" --language en
saf_911 "VTS_01_5.VOB" --language en
saf_911 "World Trade Center Anatomy of the Collapse.mkv" --language en

rm BURN_VIDEO2.TXT

exit

echo " \\" > add_fix.txt
echo '	--tags="LIGHTHOUSETV"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=KguBGXYudQg" --language nl # 2025-08-16 -    18:59 - Hoe de wereld eruit kan zien na een Trump/Poetin-deal: vrede of Koude Oorlog?
sa "https://www.youtube.com/watch?v=2_VAhchMUYU" --language nl # 2025-08-16 -    21:56 - Trump & Poetin ontmoeten elkaar in Alaska
sa "https://www.youtube.com/watch?v=6yGke2EIvPI" --language nl # 2025-08-18 -  1:36:13 - LightHouseTV #33: Slikt Zelensky Trumps voorstel? | ‘Moestuinpolitie’ | Update Arno van Kessel
sa "https://www.youtube.com/watch?v=--XE1Iuyexk" --language nl # 2025-08-18 -    28:32 - Van Haga (BVNL): ‘Nederland en Europa buiten spel bij Trump/Poetin onderhandelingen’
sa "https://www.youtube.com/watch?v=MOPKHbB4ak0" --language nl # 2025-08-19 -    24:53 - ‘Krim opgeven en geen NAVO’: accepteert Oekraïne de deal van Trump en Poetin?
sa "https://www.youtube.com/watch?v=r7NV1liDXrc" --language nl # 2025-08-19 -    29:55 - Vraagtekens bij nieuwe informatie rond opgepakte advocaat Arno van Kessel
sa "https://www.youtube.com/watch?v=YI098qxVzAk" --language nl # 2025-08-20 -  1:34:00 - LightHouseTV #34: "EU bedreigt pers" | Gesprek Poetin & Zelensky? | Verkiezingsupdate Bert Brandsma
sa "https://www.youtube.com/watch?v=938fQ1GND7s" --language nl # 2025-08-20 -    15:31 - Moestuin? Gelekt politie-document toont 'verdachte' complotdenkers
sa "https://www.youtube.com/watch?v=nfCTpu6w8lo" --language nl # 2025-08-21 -    19:17 - Eerste partijprogramma’s onthuld: met deze standpunten begint de strijd om jouw stem
sa "https://www.youtube.com/watch?v=WhnO5I3hR-I" --language nl # 2025-08-21 -    29:26 - Sietske Bergsma vs. Thomas Bruning (NVJ) over 'bedreigende' European Media Freedom Act
sa "https://www.youtube.com/watch?v=9AGhodaG5GI" --language nl # 2025-08-22 -  1:17:51 - LightHouseTV #35: Defensiespecial – Militaire wervingscampagnes & 'schaduwzijde' Nederlandse missies
sa "https://www.youtube.com/watch?v=6q0NJObaK_M" --language nl # 2025-08-22 -    20:25 - Wat bespraken Trump, Zelensky en de EU-leiders in Het Witte Huis?
sa "https://www.youtube.com/watch?v=KRQkKobYf4c" --language nl # 2025-08-23 -    19:08 - Zó verleidt Defensie jongeren om het leger in te gaan
sa "https://www.youtube.com/watch?v=0390WGuFpRg" --language nl # 2025-08-23 -    22:36 - Austin Fitts & Dekker: Waarom ondanks potentiële vredesdeal tientallen miljarden naar Defensie gaan
sa "https://www.youtube.com/watch?v=P4QY5TsYn8Q" --language nl # 2025-08-24 -    21:50 - Veteranen delen schaduwzijde buitenlandse missies Nederland
sa "https://www.youtube.com/watch?v=QRVA4X5JiRY" --language nl # 2025-08-25 -  1:46:54 - Van moord tot campagne | NAVO-taks en dienstplicht CDA | Nederlandse democratie muurvast?
sa "https://www.youtube.com/watch?v=Q1PlBF-q74A" --language nl # 2025-08-26 -    28:49 - Henk Vermeer (BBB) vs. Bob de Wit – zit Nederland democratisch muurvast?
sa "https://www.youtube.com/watch?v=rmxlm-kVrUI" --language nl # 2025-08-26 -    34:03 - Nederland in shock door tragische moord op Lisa (17)
sa "https://www.youtube.com/watch?v=eerJ0FEt9nE" --language nl # 2025-08-27 -  1:15:41 - CDA: "Veiligheid is niet gratis" | Geheime aanschaf Palantir? | Massale deportaties VK | LHTV#37
sa "https://www.youtube.com/watch?v=IILYK6Zwfhs" --language nl # 2025-08-27 -    25:19 - Vrijheidsbijdrage en 'dienstplicht' in verkiezingsprogramma CDA
sa "https://www.youtube.com/watch?v=V0dm1_f-XHE" --language nl # 2025-08-28 -    16:46 - Waarom doet de Nederlandse overheid sinds 2011 geheimzinnig over data-analyse Palantir?
sa "https://www.youtube.com/watch?v=Cz13CTTuPCg" --language nl # 2025-08-28 -    19:21 - Hoogleraren leggen partijprogramma’s onder het mes: maken ze de economie beter of kapot?
sa "https://www.youtube.com/watch?v=dAirEQ8jZ6o" --language nl # 2025-08-29 -  1:08:15 - Gevaar nieuwe prikrondes | Mona Keijzer belt Flavio | Blies Oekraïne Nord Stream op? – LHTV #38
sa "https://www.youtube.com/watch?v=A-G9BHdXhMs" --language nl # 2025-08-29 -    19:05 - Nigel Farage (Reform UK)  kondigt massale deportaties aan
sa "https://www.youtube.com/watch?v=G6zoyP61T18" --language nl # 2025-08-30 -    13:05 - Gevaren van nieuwe coronaprikrondes
sa "https://www.youtube.com/watch?v=MlrwIa36PsQ" --language nl # 2025-08-30 -    21:04 - Mona Keijzer aan de tand gevoeld door Tom de Nooijer over explosieve migratieweek
sa "https://www.youtube.com/watch?v=OmEgsUy_0jU" --language nl # 2025-08-31 -    17:08 - Zit Oekraïne achter opblazen Nord Stream?
sa "https://www.youtube.com/watch?v=TJUXGQySjCw" --language nl # 2025-09-01 -  1:24:46 - Shanghai-top nieuwe wereldorde | Trump dreigt Brusselse top | Defensie wil 200.000 mensen - LHTV#39
sa "https://www.youtube.com/watch?v=kOebfGSRqJM" --language nl # 2025-09-02 -    17:18 - Xi, Poetin en Modi zetten zich af van het Westen tijdens SCO-top
sa "https://www.youtube.com/watch?v=IqwdtKuwLfA" --language nl # 2025-09-02 -    19:00 - Trump dreigt EU-functionarissen met persoonlijke straffen om Big Tech-wetten
sa "https://www.youtube.com/watch?v=q1NYkt6zLiE" --language nl # 2025-09-03 -    20:01 - Hoe gaat Defensie aan 200.000 man komen?
sa "https://www.youtube.com/watch?v=YLCJjB_MxUg" --language nl # 2025-09-03 -    56:08 - "Sluipmoordenaar" inflatie raakt NL | Inspectie fileert fiscus | 42% mist energietransitie - LHTV#40
sa "https://www.youtube.com/watch?v=P-7-Wa4dwRc" --language nl # 2025-09-04 -    12:26 - Inspectie: de menselijke maat is zoek bij de Belastingdienst
sa "https://www.youtube.com/watch?v=0lro1DQWDKM" --language nl # 2025-09-04 -    18:47 - 50% koopkrachtverlies in 20 jaar - inflatie in NL blijkt 'sluipmoordenaar' spaargeld & pensioen
sa "https://www.youtube.com/watch?v=x8eVr3GOQjI" --language nl # 2025-09-05 -    13:20 - Onderzoek: klimaatdoelen 2035 onhaalbaar - 42% kan simpelweg niet meedoen
sa "https://www.youtube.com/watch?v=I19D5pD2DEk" --language nl # 2025-09-05 -    59:20 - 7 AfD'ers dood | Pim fileert rapport Baarsma | Chinees machtsvertoon op parade? | LHTV#41
sa "https://www.youtube.com/watch?v=Re6Ri3Fsni0" --language nl # 2025-09-06 -    12:07 - 7 AfD'ers overleden in twee weken tijd vlak voor Duitse verkiezingen
sa "https://www.youtube.com/watch?v=dJ-nAM5-BkA" --language nl # 2025-09-07 -    10:46 - Chinees machtsvertoon op militaire parade brengt Westen in verlegenheid
sa "https://www.youtube.com/watch?v=xb2voJK2kRs" --language nl # 2025-09-07 -    19:09 - ‘Flauwekulrapport’ Barbara Baarsma stuurt aan op verplaatsen van Nederlandse bedrijven
sa "https://www.youtube.com/watch?v=HX_md8GqpRU" --language nl # 2025-09-08 -  1:15:02 - Vaccins verontreinigd | Bert voorspelt kabinet |  Leeftijdsslot internet via Digital ID | LHTV#42
sa "https://www.youtube.com/watch?v=ZMrqU9LMVrc" --language nl # 2025-09-09 -    18:16 - Alle onderzochte mRNA-vaccins verontreinigd: ‘Wanneer stopt Nederland met deze prikken?’
sa "https://www.youtube.com/watch?v=OsFkibPdFJg" --language nl # 2025-09-09 -    21:25 - Is het komende kabinet al beslist? - ‘er gaat niets veranderen’
sa "https://www.youtube.com/watch?v=0VsYZe0-GlI" --language nl # 2025-09-10 -    17:01 - EU introduceert 'toegangspoortje' voor internet: verplichte leeftijdscontrole
sa "https://www.youtube.com/watch?v=7Ufadh8wm5I" --language nl # 2025-09-11 -    13:23 - NAVO-artikel 4 na ‘Russische drones boven Polen’ – escalatie of politiek frame?
sa "https://www.youtube.com/watch?v=jH2TsiC6gUU" --language nl # 2025-09-11 -    31:50 - Arno van Kessel blijft vastzitten tot 4 december
sa "https://www.youtube.com/watch?v=DgwDDKTjkEs" --language nl # 2025-09-12 -  1:29:40 - Arno van Kessel BLIJFT VASTZITTEN! | NAVO-artikel 4 drones Polen | nieuwe stikstofwending | LHTV#43
sa "https://www.youtube.com/watch?v=FFHSel03aNI" --language nl # 2025-09-12 -    20:58 - Waarom politici het deze verkiezingen niet over stikstof willen hebben
sa "https://www.youtube.com/watch?v=8SKhbxk7IqY" --language nl # 2025-09-12 -    59:54 - Verdeling om Charlie Kirk | Goudprijs kanarie in kolenmijn? | Uitspraak Arno van Kessel | LHTV#44
sa "https://www.youtube.com/watch?v=JnZwtJkzRhw" --language nl # 2025-09-14 -    16:22 - Waarom de moord op Charlie Kirk ons niet uit elkaar moet spelen
sa "https://www.youtube.com/watch?v=WUCNpwDgmgM" --language nl # 2025-09-14 -    16:29 - Waarom blijft Arno van Kessel vastzitten?
sa "https://www.youtube.com/watch?v=T75lXjjno3E" --language nl # 2025-09-15 -  1:39:25 - Bob Vylan: moet kunnen? | Massale demo Londen | Was Kirk té kritisch voor Israël? | LHTV#45
sa "https://www.youtube.com/watch?v=UxzLSZxc1ak" --language nl # 2025-09-15 -    14:14 - Wat zeggen de recordstanden van goud- en beurskoersen ons?
sa "https://www.youtube.com/watch?v=-y8RpAbXbPE" --language nl # 2025-09-16 -    20:58 - Tommy Robinsons massale demo in Londen met Eva en Elon: "Fight back or die"
sa "https://www.youtube.com/watch?v=nH3xcEFhGKs" --language nl # 2025-09-16 -    25:23 - Bob Vylan ontleed: wordt politiek geweld genormaliseerd?
sa "https://www.youtube.com/watch?v=MWszOwsAGEU" --language nl # 2025-09-17 -  1:14:42 - Miljoenennota-special: Dit schuilt er achter de rooskleurige cijfers van Den Haag | LHTV#46
sa "https://www.youtube.com/watch?v=z_Jp2zKpp2Q" --language nl # 2025-09-17 -    24:57 - Scenario’s rond Israëlische Mossad en Charlie Kirk zwellen aan: waar gaat dit precies over?
sa "https://www.youtube.com/watch?v=TC6CDUFhcDg" --language nl # 2025-09-18 -    16:30 - Miljoenennota blijkt miljardennota van 500mld: hoe lang gaat dit nog goed?
sa "https://www.youtube.com/watch?v=FYyZwP-vO5w" --language nl # 2025-09-18 -    22:12 - Dit is waar het bij de politieke beschouwingen NIET over gaat
sa "https://www.youtube.com/watch?v=B9LMqqAJiz0" --language nl # 2025-09-19 -  1:07:32 - Antifa verboden na FVD-motie? | ‘Operation Eastern Sentry’ |'Kleuterklas' bij APB 2025 | LHTV#47
sa "https://www.youtube.com/watch?v=jTehuSzOC1A" --language nl # 2025-09-19 -    22:59 - De ware cijfers en het verhaal achter faillissementen in Nederland
sa "https://www.youtube.com/watch?v=lk-NGUsIW3A" --language nl # 2025-09-20 -    16:46 - Algemene Politieke Beschouwingen: theater voor de bühne of serieuze koers voor de toekomst?
sa "https://www.youtube.com/watch?v=Xrbv5_GrfEA" --language nl # 2025-09-20 -    18:36 - FVD-motie om Antifa als terroristische organisatie aan te merken aangenomen
sa "https://www.youtube.com/watch?v=pDjjVEZalF0" --language nl # 2025-09-21 -    18:17 - NAVO ‘Operation Eastern Sentry’ en EU ‘Defence Union’: verdediging of routekaart naar oorlog?
sa "https://www.youtube.com/watch?v=oFQdCLLtVgY" --language nl # 2025-09-22 -  1:35:26 - Wybren over ‘Elsfest’ & nieuwe politieke partijen over de problemen van Nederland | LHTV#48
#sa "https://www.youtube.com/watch?v=__Ot7LZnLhI" --language nl # 2025-09-22 -    21:55 - Romeo's, Antifa, hooligans? Wie zat er achter de escalatie van Malieveld-demo 'Elsfest'?
sa "https://www.youtube.com/watch?v=jVu3Xf7mQM8" --language nl # 2025-09-23 -    17:43 - Partij voor de Rechtstaat in de bres tegen ‘onbetrouwbare’ overheid
sa "https://www.youtube.com/watch?v=7a7eWPlfAoA" --language nl # 2025-09-23 -    20:40 - De Linie van ex-50PLUS-leider wil afrekenen met ‘bureaucratische’ wooncrisis
sa "https://www.youtube.com/watch?v=fNJyT3uhz9g" --language nl # 2025-09-24 -  1:35:49 - Oud-NOS-baas grilt framing | Digitale euro: juni 2026 | Trump bij VN: EU-landen gaan eraan |LHTV#49
sa "https://www.youtube.com/watch?v=LVrtwSNqCNo" --language nl # 2025-09-24 -    20:27 - Nieuwe partij Vrede voor Dieren: ‘STOP oorlogsmiljarden van NAVO en EU!’
sa "https://www.youtube.com/watch?v=HEgZkqIbkC8" --language nl # 2025-09-25 -    20:32 - Biolabs, verdwenen kinderen onder Biden, VN-invasies, de 'green energy scam' en meer
sa "https://www.youtube.com/watch?v=cXzHjT7ne5s" --language nl # 2025-09-25 -    27:16 - Haagse rellen: ex-NOS-baas fileert Jetten, Schimmelpenninck & AIVD over ‘Wilders-frame’
sa "https://www.youtube.com/watch?v=pKyB-5PaqrI" --language nl # 2025-09-26 -    33:50 - Digitale euro start in 2026: zullen Europeanen deze massaal adopteren? *
sa "https://www.youtube.com/watch?v=2qUaS-Rt5h0" --language nl # 2025-09-26 -    56:30 - Haagse rellen ‘misbruikt’ | ChatControl EU zet door | Probleemjeugd in azc’s | LHTV #50
sa "https://www.youtube.com/watch?v=XSUktXxQmjU" --language nl # 2025-09-27 -    13:46 - EU wil meekijken op je telefoon en zet door met ChatControl-wet
sa "https://www.youtube.com/watch?v=dHsC3rNnF6Q" --language nl # 2025-09-27 -    14:59 - Ex-COA-medewerker onthult ‘wanpraktijken’ binnen AZC’s
sa "https://www.youtube.com/watch?v=VxJopOVtmp8" --language nl # 2025-09-28 -    17:19 - Haagse rellen aangegrepen voor gezichtsherkenning, chat-toegang en verbod anonieme social accounts
exit

exit

## echo " \\" > add_fix.txt
## echo '	--tags="Ben Knapen" \' >> add_fix.txt
## echo '	--tags="Het Grote Complot" \' >> add_fix.txt
## echo '	--tags="The Great Conspiracy"' >> add_fix.txt
## 
## sa2 "https://www.youtube.com/watch?v=0Axr1LjIzyg" --language nl # 2008-08-02 -     8:25 - De Moraalridders - Het grote complot 1-1
## sa2 "https://www.youtube.com/watch?v=kinzO1gddEE" --language nl # 2008-08-02 -     9:13 - De Moraalridders - Het grote complot 1-2
## sa2 "https://www.youtube.com/watch?v=_lzm4v05ibs" --language nl # 2008-08-02 -     6:09 - De Moraalridders - Het grote complot 1-3
## sa2 "https://www.youtube.com/watch?v=wAHkdltmrsI" --language nl # 2008-08-02 -     5:54 - De Moraalridders - Het grote complot 2-1
## sa2 "https://www.youtube.com/watch?v=ZgLRLZy47g4" --language nl # 2008-08-02 -     7:23 - De Moraalridders - Het grote complot 2-2
## sa2 "https://www.youtube.com/watch?v=uqOptXXlzK8" --language nl # 2008-08-02 -     9:33 - De Moraalridders - Het grote complot 2-3
## sa2 "https://www.youtube.com/watch?v=rDkN2FsP47c" --language nl # 2008-08-02 -     8:25 - De Moraalridders - Het grote complot 3-1
## sa2 "https://www.youtube.com/watch?v=mAqaC2iMuBU" --language nl # 2008-08-02 -     6:50 - De Moraalridders - Het grote complot 3-2
## sa2 "https://www.youtube.com/watch?v=4QJmi-eoWGM" --language nl # 2008-08-02 -     7:59 - De Moraalridders - Het grote complot 3-3
## sa2 "https://www.youtube.com/watch?v=5xerKPszNV0" --language nl # 2008-08-02 -     6:51 - De Moraalridders - Het grote complot 4-1
## sa2 "https://www.youtube.com/watch?v=ipdz5im4Yds" --language nl # 2008-08-02 -     7:34 - De Moraalridders - Het grote complot 4-2
## sa2 "https://www.youtube.com/watch?v=n4Sf4HKe3TU" --language nl # 2008-08-02 -     8:22 - De Moraalridders - Het grote complot 4-3
## sa2 "https://www.youtube.com/watch?v=BkZRrCGGJNs" --language nl # 2008-08-02 -     7:46 - De Moraalridders - Het grote complot 5-1
## sa2 "https://www.youtube.com/watch?v=cDgQAJ6NkOU" --language nl # 2008-08-02 -     7:54 - De Moraalridders - Het grote complot 5-2
## sa2 "https://www.youtube.com/watch?v=B9Ai49eVY-I" --language nl # 2008-08-02 -     7:56 - De Moraalridders - Het grote complot 5-3
## sa2 "https://www.youtube.com/watch?v=FPXzuNiInhs" --language nl # 2008-08-02 -     8:27 - De Moraalridders - Het grote complot 6-1
## sa2 "https://www.youtube.com/watch?v=XCPkTImRSo8" --language nl # 2008-08-02 -     7:27 - De Moraalridders - Het grote complot 6-2
## sa2 "https://www.youtube.com/watch?v=Q-ta_XH7WS8" --language nl # 2008-08-02 -     7:43 - De Moraalridders - Het grote complot 6-3

echo " \\" > add_fix.txt
echo '	--tags="The Zeitgeist Movement" \' >> add_fix.txt
echo '	--tags="Occupy"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=dkinHuvLEaU"
saa "https://www.youtube.com/watch?v=DYH57Cw644k" --language en
saa "https://www.youtube.com/watch?v=4mkRFCtl2MI" --language en

echo " \\" > add_fix.txt
echo '	--tags="Doug Stanhope" \' >> add_fix.txt
echo '	--tags="Voice of America"' >> add_fix.txt


sa2 "https://www.youtube.com/watch?v=ooWailmzEoQ" --language en
sa2 "https://www.youtube.com/watch?v=YkgDhDa4HHo" --language en
sa2 "https://www.youtube.com/watch?v=9Oww4Ap3YZA" --language en

echo " \\" > add_fix.txt
echo '	--tags="Christopher Hitchens"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=mQorzOS-F6w"


echo " \\" > add_fix.txt
echo '	--tags="TED" \' >> add_fix.txt
echo '	--tags="Sam Harris" \' >> add_fix.txt
echo '	--tags="morals" \' >> add_fix.txt

saa "https://www.youtube.com/watch?v=Hj9oB4zpHww"


echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt

#date: 2024-07-30 - length:    27:59 - title: "The Car Payment Pandemic Is Out Of Control.. THIS IS KEEPING YOU BROKE!"
sa "https://www.youtube.com/watch?v=Qp86yWPDJyw" --language en

echo " \\" > add_fix.txt
echo '	--tags="Jim Gray" \' >> add_fix.txt
echo '	--tags="Drug Prohibition" \' >> add_fix.txt
echo '	--tags="War on Drugs"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=b6t1EM4Onao" --language en

echo " \\" > add_fix.txt
echo '	--tags="Pat Condell" \' >> add_fix.txt
echo '	--tags="Children Of A Stupid God"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=rEtfdzNAE74"

echo " \\" > add_fix.txt
echo '	--tags="Aspirational tv" \' >> add_fix.txt
echo '	--tags="Charlie Brooker"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=59OJ17raqWw" --language en

exit


### echo " \\" > add_fix.txt
### echo '	--tags="Jews" \' >> add_fix.txt
### echo '	--tags="Israel"' >> add_fix.txt
### 
### # saa "https://x.com/jovany1124/status/1967961512989077679" --language en
### saa "https://odysee.com/@VerumQuaerimus:2/2022-09-21-09-32-09_Trim:f" --language en
### # saa "https://x.com/Girlpatriot1974/status/1967822336704516592" --language en
### # saa "https://odysee.com/@Thor'sHammer:5/The-Other-Israel,-Ted-Pike---1987:e" --language en
### # saa "https://odysee.com/@WhitestGoyUKnow:2/Rev.-Ted-Pike---The-Insane-Religion-Of-Kabbalistic:c" --language en
### # saa "https://odysee.com/@thisworldworks:1/Ted-Pike---Hate-Laws-Making-Criminals-of-Christians-2001.mp4:d" --language en
### 
### exit

## echo " \\" > add_fix.txt
## echo '	--tags="planned obsolescence" \' >> add_fix.txt
## echo '	--tags="climate change" \' >> add_fix.txt
## echo '	--tags="Hayden Schreier"' >> add_fix.txt
## 
## ## 
## #date: 2025-09-16 - length:    36:49 - title: "Everything You Own Is DESIGNED TO BREAK in 2025…"
## ## sa "https://www.youtube.com/watch?v=65oWQN6jY0E" --language en
## 
## #date: 2025-09-11 - length:    40:42 - title: "I Caught Even CRAZIER Influencer LIES! | IT'S ALL A SCAM! PART 4"
## sa "https://www.youtube.com/watch?v=jV5I2RL9y-U" --language en
## 
## #date: 2025-09-09 - length:    40:18 - title: "Fall Decorating is OUT OF CONTROL (and COSTING You Thousands)"
## sa "https://www.youtube.com/watch?v=9Y7AR_B9RKg" --language en
## 
## 
## echo "BURN_VIDEO2.TXT" > "BURN_VIDEO2.TXT"
## 
## echo " \\" > add_fix.txt
## echo '	--tags="covid" \' >> add_fix.txt
## echo '	--tags="mRNA" \' >> add_fix.txt
## echo '	--tags="vaccines"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=BZrJraN2nOQ" --language en
## 
## rm "BURN_VIDEO2.TXT"
## 
## echo " \\" > add_fix.txt
## echo '	--tags="humanoid" \' >> add_fix.txt
## echo '	--tags="robots"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=Eys5oQabMF8" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="planned obsolescence" \' >> add_fix.txt
## echo '	--tags="climate change" \' >> add_fix.txt
## echo '	--tags="Hayden Schreier"' >> add_fix.txt
## 
## #date: 2025-09-04 - length:    43:49 - title: "Your Car Payment is Why You’ll NEVER GET AHEAD in 2025…"
## sa "https://www.youtube.com/watch?v=KOxzuU2Fd2o" --language en
## 
## #date: 2025-09-02 - length:    33:02 - title: ""Restock" Influencers Have OFFICIALLY RUINED FALL!"
## sa "https://www.youtube.com/watch?v=2zdbqsowBjc" --language en
## 
## #date: 2025-08-28 - length:    42:58 - title: "Used Cars Don’t Suck… PEOPLE DO! (at maintaining them)"
## sa "https://www.youtube.com/watch?v=A-xC4A3uR7I" --language en
## 
## #date: 2025-08-26 - length:    28:30 - title: ""Restock" Influencers Are Already RUINING Halloween!"
## sa "https://www.youtube.com/watch?v=TGT9qKn7TQY" --language en
## 
## #date: 2025-08-21 - length:    39:30 - title: "New Construction Homes Are a Total SCAM in 2025…"
## sa "https://www.youtube.com/watch?v=ATKHBkeKBI4" --language en
## 
## #date: 2025-08-19 - length:    45:00 - title: "New Cars are DESIGNED TO FAIL in 2025…"
## sa "https://www.youtube.com/watch?v=hGU9hqXpk0Q" --language en
## 
## #date: 2025-08-14 - length:    36:12 - title: "Your Collections Are Making You BROKE in 2025!"
## sa "https://www.youtube.com/watch?v=3PdSEG3adwU" --language en
## 
## #date: 2025-08-12 - length:    34:13 - title: "“Restock” Influencers are DESTROYING Your Finances…"
## sa "https://www.youtube.com/watch?v=3f4jWwTnuFA" --language en
## 
## #date: 2025-08-07 - length:    38:11 - title: "People Are Posting Their Net Worth Online and it’s INSANE!"
## sa "https://www.youtube.com/watch?v=DgVQOvkXlYY" --language en
## 
## #date: 2025-08-05 - length:    36:23 - title: "Mass Layoffs Are OUT OF CONTROL in 2025… (Don’t QUIT Your Job Yet)"
## sa "https://www.youtube.com/watch?v=Eazic8lZflY" --language en
## 
## #date: 2025-08-01 - length:    42:12 - title: "People Are Posting Their Salaries Online and it’s INSANE! PART 2"
## sa "https://www.youtube.com/watch?v=v_okMKPq9Oc" --language en
## 
## #date: 2025-07-30 - length:    25:42 - title: "I Bought a Brand New Car… and It Was a NIGHTMARE!"
## sa "https://www.youtube.com/watch?v=uGLBIeRHPtg" --language en
## 
## #date: 2025-07-24 - length:    30:09 - title: "Identity Theft in 2025 is OUT OF CONTROL…"
## sa "https://www.youtube.com/watch?v=Ch5jEkGwQ6w" --language en
## 
## #date: 2025-07-22 - length:    33:48 - title: "I Caught Companies LYING About Their Products! | Shrinkflation 2025"
## sa "https://www.youtube.com/watch?v=UACfTu6w1Yg" --language en
## 
## #date: 2025-07-17 - length:    39:55 - title: "Consumerism Has DEBT EXPLODING in 2025…."
## sa "https://www.youtube.com/watch?v=e4jtJw6GOQY" --language en
## 
## #date: 2025-07-15 - length:    37:31 - title: "People Are Posting Their Salaries Online and it’s INSANE!"
## sa "https://www.youtube.com/watch?v=-a6iT8fV-5A" --language en
## 
## #date: 2025-07-10 - length:    35:52 - title: "Used Cars Aren’t the Problem… YOU ARE! - PART 2"
## sa "https://www.youtube.com/watch?v=NtlIMF_JNrk" --language en
## 
## #date: 2025-07-08 - length:    39:16 - title: "Why The Cost of Living in 2025 is a COMPLETE DISASTER…"
## sa "https://www.youtube.com/watch?v=B83tSZJLS7Q" --language en
## 
## #date: 2025-07-03 - length:    32:00 - title: "Taxes Are COMPLETELY Out of Control in 2025…"
## sa "https://www.youtube.com/watch?v=0PjLWxhlr1Y" --language en
## 
## #date: 2025-07-01 - length:    33:04 - title: "I Caught Even MORE Influencers LYING About Their Lifestyle! | IT'S ALL A SCAM! PART 3"
## sa "https://www.youtube.com/watch?v=1y9Sl_OUK_Y" --language en
## 
## #date: 2025-06-26 - length:    40:31 - title: "You're BROKE Because of Your Spending Addiction! (How to Save Money)"
## sa "https://www.youtube.com/watch?v=Rm2d1oFltR8" --language en
## 
## #date: 2025-06-24 - length:    37:07 - title: "Electric Cars in 2025 are a COMPLETE DISASTER…"
## sa "https://www.youtube.com/watch?v=vsk0OQj8Je4" --language en
## 
## #date: 2025-06-19 - length:    40:47 - title: "New Cars in 2025 are a COMPLETE DISASTER…"
## sa "https://www.youtube.com/watch?v=waRnGHq1Pk8" --language en
## 
## mv add_fix.txt add_fix.txt.backup
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Soros" \' >> add_fix.txt
## echo '	--tags="terrorism" \' >> add_fix.txt
## echo '	--tags="ngo"' >> add_fix.txt
## 
## sa "https://x.com/ryanmauro/status/1968478985072804302" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Mike Benz" \' >> add_fix.txt
## echo '	--tags="NGO" \' >> add_fix.txt
## echo '	--tags="CIA"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=33vwRTrSmv8" --language en
## 
### echo " \\" > add_fix.txt
### echo '	--tags="USAID" \' >> add_fix.txt
### echo '	--tags="Foreign Affairs" \' >> add_fix.txt
### echo '	--tags="NGO"' >> add_fix.txt
### 
### saa "https://www.youtube.com/watch?v=s5Rsw0n30sk" --language en
### 
### echo '	--tags="planned obsolescence" \' >> add_fix.txt
### echo '	--tags="climate change" \' >> add_fix.txt
### echo '	--tags="Hayden Schreier"' >> add_fix.txt
### 
### 
### #date: 2025-06-17 - length:    13:46 - title: "I Tried Dumpster Diving… You Won’t Believe What I Found!"
### sa "https://www.youtube.com/watch?v=MQGPNk4HySg" --language en
### 
### echo '	--tags="charlie kirk" \' >> add_fix.txt
### echo '	--tags="oktober 7" \' >> add_fix.txt
### echo '	--tags="border"' >> add_fix.txt
### 
### saa "https://www.youtube.com/live/fQ9VOlaBBeo" --language en
### 
### echo '	--tags="planned obsolescence" \' >> add_fix.txt
### echo '	--tags="climate change" \' >> add_fix.txt
### echo '	--tags="Hayden Schreier"' >> add_fix.txt
### 
### #date: 2025-06-12 - length:    30:17 - title: "Why You Should NEVER Co-Sign a Car… - Reddit AITA"
### sa "https://www.youtube.com/watch?v=0FoDbx7JOVQ" --language en
### 
### #date: 2025-06-10 - length:    39:20 - title: "People are REFUSING to Pay Off Their Student Loan Debt in 2025…"
### sa "https://www.youtube.com/watch?v=MAMmxCQlTjg" --language en
### 
### #date: 2025-06-06 - length:    38:47 - title: "Credit Card Debt is CRUSHING People in 2025…"
### sa "https://www.youtube.com/watch?v=vkiWPweEe54" --language en
### 
### #date: 2025-06-03 - length:    30:10 - title: "These Amazon ‘Must-Haves’ Influencers Are Getting EMBARRASSING..."
### sa "https://www.youtube.com/watch?v=qqdtnpzIOOg" --language en
### 
### echo " \\" > add_fix.txt
### echo '	--tags="North Stream" \' >> add_fix.txt
### echo '	--tags="warmongers"' >> add_fix.txt
### 
### saa "https://x.com/NiemandsKnegt/status/1958612852803346469" --language nl

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt

### #date: 2025-05-29 - length:    42:04 - title: "Car Payments are Literally DESTROYING People in 2025…"
### sa "https://www.youtube.com/watch?v=fxeLpD0KYy4" --language en
### 
### #date: 2025-05-27 - length:    31:15 - title: "Scams in 2025 Are Getting INSANE – No One Is Safe…"
### sa "https://www.youtube.com/watch?v=5xpFi72hSk0" --language en
### 
### #date: 2025-05-22 - length:    31:50 - title: "New Homes are Literally FALLING APART in 2025…"
### sa "https://www.youtube.com/watch?v=BdAJXp0AA4E" --language en
### 
### #date: 2025-05-20 - length:    30:31 - title: "“Restock” Influencers Are Turning Spring Into a SPENDING NIGHTMARE!"
### sa "https://www.youtube.com/watch?v=dK_P_HM7xoc" --language en
### 
### #date: 2025-05-15 - length:    31:03 - title: "Dumpster Diving in 2025 is Absolutely INSANE…"
### sa "https://www.youtube.com/watch?v=vOKjmIE0Csw" --language en
### 
### #date: 2025-05-13 - length:    28:41 - title: "YOU REALLY KLARNA’D INTO COACHELLA FOR THIS?!"
### sa "https://www.youtube.com/watch?v=fEbU3jKV40g" --language en
### 
### #date: 2025-05-08 - length:    32:11 - title: "32 Minutes of People Making HORRIBLE Money Decisions in 2025..."
### sa "https://www.youtube.com/watch?v=WLs_FH4NlpU" --language en
### 
### #date: 2025-05-06 - length:    40:32 - title: "Used Cars Aren’t the Problem… YOU ARE!!!"
### sa "https://www.youtube.com/watch?v=AHpd22BEleA" --language en
### 
### #date: 2025-05-01 - length:    44:35 - title: "New Cars are Literally FALLING APART in 2025…"
### sa "https://www.youtube.com/watch?v=Wg-DyG5XA-8" --language en
### 
### #date: 2025-04-29 - length:    33:34 - title: "Subscription Culture is OUT OF CONTROL in 2025…"
### sa "https://www.youtube.com/watch?v=xmzjvBOseF8" --language en
### 
### #date: 2025-04-24 - length:    27:26 - title: "“Restock” Influencers are Back for Easter and DESTROYING Your Finances…"
### sa "https://www.youtube.com/watch?v=vTY4ci8-4Eo" --language en
### 
### #date: 2025-04-22 - length:    31:52 - title: "Let’s Expose the ‘Buy Now Pay Later’ Trap."
### sa "https://www.youtube.com/watch?v=ZRCq7ruEuyw" --language en
### 
### #date: 2025-04-17 - length:    30:35 - title: "How Gen Z Will Own Nothing and be Broke Forever…"
### sa "https://www.youtube.com/watch?v=VVVX2UHiuTA" --language en


#date: 2025-04-15 - length:    27:16 - title: "“Restock” Influencers are LYING to You About Your Car…"
## sa "https://www.youtube.com/watch?v=f4I0PlY4Uyg" --language en

## echo " \\" > add_fix.txt
## echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
## echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
## echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=OM6WNS3Ia3Q" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="Elon Musk" \' >> add_fix.txt
## echo '	--tags="Unite The Kingdom" \' >> add_fix.txt
## echo '	--tags="protest"' >> add_fix.txt
## 
## saa "https://www.youtube.com/watch?v=sSETb5QRLW0" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt


#date: 2025-04-10 - length:    33:55 - title: "Peoples Mortgages Are SKYROCKETING in 2025..."
sa "https://www.youtube.com/watch?v=UI29rOXUxXo" --language en

#date: 2025-04-08 - length:    35:47 - title: "How ‘Buy Now Pay Later’ is DESTROYING Your Finances in 2025…"
sa "https://www.youtube.com/watch?v=CjbqPGZZLrI" --language en

#date: 2025-04-03 - length:    30:58 - title: "“Fake Designer Hauls” Are INSANE CONSUMERISM in 2025..."
sa "https://www.youtube.com/watch?v=dl_j3mO96SQ" --language en

#date: 2025-04-01 - length:    37:05 - title: "I Found The WORST Financial Advice on The Internet…"
sa "https://www.youtube.com/watch?v=TtfVR6cercs" --language en

#date: 2025-03-28 - length:    35:22 - title: "You're BROKE Because You’re High Maintenance!"
sa "https://www.youtube.com/watch?v=00q5bZIAOv8" --language en

#date: 2025-03-26 - length:    38:23 - title: "New Cars are Still HORRIBLE in 2025…"
sa "https://www.youtube.com/watch?v=n07x1Z2uk4I" --language en

#date: 2025-03-20 - length:    34:45 - title: "CATCHING BEAUTY INFLUENCERS LYING! They’re RUINING Your Skin & Your Finances…"
sa "https://www.youtube.com/watch?v=HMvlO6lmK9Q" --language en

#date: 2025-03-18 - length:    34:48 - title: "New Cars are HORRIBLE in 2025…"
sa "https://www.youtube.com/watch?v=Awg5kffgqss" --language en

#date: 2025-03-13 - length:    41:06 - title: "Stop WASTING MONEY on Skincare — Here's Why You're Broke!"
sa "https://www.youtube.com/watch?v=1bnOxdxhsY8" --language en

echo " \\" > add_fix.txt
echo '	--tags="chemtrails" \' >> add_fix.txt
echo '	--tags="bill gates" \' >> add_fix.txt
echo '	--tags="tpvsean"' >> add_fix.txt

saa "https://x.com/thehealthb0t/status/1969898121296781340" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt

#date: 2025-03-11 - length:    28:03 - title: "Skincare Consumerism is OUT OF CONTROL in 2025…"
sa "https://www.youtube.com/watch?v=fhtoRdWQg_E" --language en

#date: 2025-03-06 - length:    32:18 - title: "Amazon "Must-Haves" Influencers Are OUT OF CONTROL..."
sa "https://www.youtube.com/watch?v=-PCrUO9pJWw" --language en

#date: 2025-03-04 - length:    41:15 - title: "7 Things Influencers Have Brainwashed Us Into Thinking Are Normal (But They’re Not)"
sa "https://www.youtube.com/watch?v=K5vP4ArkI1E" --language en

#date: 2025-02-27 - length:    31:38 - title: "PET OWNERS ARE GOING BROKE IN 2025..."
sa "https://www.youtube.com/watch?v=c2lGTNJ2iXg" --language en

#date: 2025-02-25 - length:    33:02 - title: "“Restock” Influencers Have RUINED Valentine’s Day…"
sa "https://www.youtube.com/watch?v=sNfcgUGMwm8" --language en

#date: 2025-02-20 - length:    32:07 - title: "How to Become Successful In 2025 | Only 7 Rules"
sa "https://www.youtube.com/watch?v=PVuqdBCwMiM" --language en

#date: 2025-02-18 - length:    31:09 - title: "New Construction Homes are STILL HORRIBLE in 2025…"
sa "https://www.youtube.com/watch?v=lEEoedXSMhM" --language en

#date: 2025-02-13 - length:    34:28 - title: "Valentine’s Day Consumerism is a SCAM! (Stop WASTING Your Money!)"
sa "https://www.youtube.com/watch?v=xE69CRVAE3g" --language en

#date: 2025-02-11 - length:    32:32 - title: "I Caught Influencers LYING About Their Wealth & Lifestyle! | IT'S ALL A FAKE! PART 2"
sa "https://www.youtube.com/watch?v=pmgrJX9ZU9w" --language en

#date: 2025-02-07 - length:    32:12 - title: "32 Minutes of TERRIBLE Credit Card Debt in 2025…"
sa "https://www.youtube.com/watch?v=ga4lfxtdloU" --language en

#date: 2025-02-05 - length:    35:32 - title: "35 Minutes of HORRIBLE Car Payments in 2025…"
sa "https://www.youtube.com/watch?v=XrjsOWdH4SI" --language en

echo " \\" > add_fix.txt
echo '	--tags="Tucker Carlson" \' >> add_fix.txt
echo '	--tags="Kirk Moore" \' >> add_fix.txt
echo '	--tags="covid"' >> add_fix.txt

saa "https://x.com/TuckerCarlson/status/1965097804365234399" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt

#date: 2025-02-03 - length:    26:02 - title: "The "Fridgescaping" Trend is Making You BROKE and MISERABLE!"
sa "https://www.youtube.com/watch?v=yuuBMItTR9c" --language en

#date: 2025-01-30 - length:    33:06 - title: "You're BROKE Because of Your Shopping Addiction! - REACTION"
sa "https://www.youtube.com/watch?v=khKjV7sN-Hs" --language en

#date: 2025-01-28 - length:    33:30 - title: "I Exposed Influencers LYING About Their Wealth and Lifestyle Again! | IT’S ALL FAKE!"
sa "https://www.youtube.com/watch?v=y3JxVkSzQ8g" --language en

#date: 2025-01-24 - length:    29:12 - title: "“Restock” Influencers are DESTROYING Your Fridge and Your Finances…"
sa "https://www.youtube.com/watch?v=0K23I-qUnL0" --language en

#date: 2025-01-22 - length:    34:18 - title: "Crumbl Cookie Overconsumption is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=kf30FAKwvtg" --language en

#date: 2025-01-20 - length:    33:20 - title: "The BIGGEST Job Layoff Just Happened in 2025… TikTok Banned"
sa "https://www.youtube.com/watch?v=7qfaSEhrWjc" --language en

#date: 2025-01-17 - length:    31:36 - title: "The 2024 “Spending Wrapped” TikTok Trend is OUT OF CONTROL…"
sa "https://www.youtube.com/watch?v=fPwHKVaXKgI" --language en

#date: 2025-01-15 - length:    35:34 - title: "This TikTok Influencers Spending is OUT OF CONTROL…(Dougherty Dozen)"
sa "https://www.youtube.com/watch?v=5ddHY7qyYYk" --language en

#date: 2025-01-13 - length:    34:36 - title: "Renovating Your “Rental” Apartment in 2025 is INSANE…"
sa "https://www.youtube.com/watch?v=3nxiZ1bHcYw" --language en

#date: 2025-01-09 - length:    32:51 - title: "“No Buy 2025” The GENIUS Trend That Could Make You Rich…"
sa "https://www.youtube.com/watch?v=InVqjY5NuQE" --language en

#date: 2025-01-07 - length:    33:17 - title: "Christmas “Clearance Sales” are OUT OF CONTROL. 90% OFF?!?…"
sa "https://www.youtube.com/watch?v=w94rS39dueo" --language en

#date: 2025-01-02 - length:    34:33 - title: "Rich Kid “Christmas Hauls” are OUT OF CONTROL… PT2"
sa "https://www.youtube.com/watch?v=GtYguZgeiKs" --language en

#date: 2024-12-30 - length:    28:58 - title: "The “Burr Basket” Tiktok Trend is INSANE..."
sa "https://www.youtube.com/watch?v=yOYJAOfZJFk" --language en

#date: 2024-12-27 - length:    32:46 - title: ""Christmas Hauls" are Here and They’re OUT OF CONTROL…"
sa "https://www.youtube.com/watch?v=5DatWHffZt8" --language en

#date: 2024-12-26 - length:    28:25 - title: "Rich Kid “Christmas Hauls” are OUT OF CONTROL…"
sa "https://www.youtube.com/watch?v=ZAgpXoKakAY" --language en

#date: 2024-12-23 - length:    33:22 - title: "Amazon Christmas “Must Haves” are OUT OF CONTROL in 2024…"
sa "https://www.youtube.com/watch?v=PwZIGV7YWzo" --language en

#date: 2024-12-19 - length:    32:24 - title: ""Christmas Hauls" are Already Here and They’re OUT OF CONTROL…"
sa "https://www.youtube.com/watch?v=AikNDtv2WBE" --language en

#date: 2024-12-17 - length:    32:54 - title: "People Are DESTROYING Their Finances This Holiday Season…"
sa "https://www.youtube.com/watch?v=43lLSDz87Mo" --language en

#date: 2024-12-13 - length:    32:36 - title: "“Restock” Influencers are Back for the Holidays and DESTROYING Your Finances…"
sa "https://www.youtube.com/watch?v=JA4jAk6oAXE" --language en

#date: 2024-12-12 - length:    31:15 - title: "Health Insurance in 2024 is Out of Control and MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=48YjX7KWd04" --language en

#date: 2024-12-10 - length:    32:04 - title: "Holiday Consumerism Has Debt EXPLODING in 2024…."
sa "https://www.youtube.com/watch?v=j0pcW8MR7tU" --language en

#date: 2024-12-05 - length:    28:58 - title: "Holidays Are a MASSIVE SCAM to Keep You POOR and in Debt!"
sa "https://www.youtube.com/watch?v=Usuxw7Ic2xM" --language en

#date: 2024-12-03 - length:    32:08 - title: "Black Friday Has Become a MASSIVE Scam in 2024!"
sa "https://www.youtube.com/watch?v=-DvcsVM7URM" --language en

#date: 2024-11-30 - length:    32:12 - title: "People Have NO IDEA How to Invest in 2024…"
sa "https://www.youtube.com/watch?v=97ZEkuVdYM0" --language en

#date: 2024-11-26 - length:    32:28 - title: "New Construction Homes are Built HORRIBLE in 2025..."
sa "https://www.youtube.com/watch?v=bgG_v6ZmZQk" --language en

echo " \\" > add_fix.txt
echo '	--tags="trump" \' >> add_fix.txt
echo '	--tags="united nations" \' >> add_fix.txt
echo '	--tags="2025"' >> add_fix.txt

saa "https://x.com/MonicaCrowley/status/1970558882528325962" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt

#date: 2024-11-21 - length:    32:41 - title: "The Cost of Weddings is HORRIBLE in 2024…"
sa "https://www.youtube.com/watch?v=q9QX6xpzVKQ" --language en

#date: 2024-11-19 - length:    29:33 - title: "The Younger Generation is SCREWED Financially…"
sa "https://www.youtube.com/watch?v=wOCvXvHMkHs" --language en

#date: 2024-11-14 - length:    33:00 - title: "Car Payments are Out of Control and DESTROYING Your Finances…"
sa "https://www.youtube.com/watch?v=LwtvnksiIao" --language en

#date: 2024-11-12 - length:    32:28 - title: "How The “Commute to Work” Keeps You Poor"
sa "https://www.youtube.com/watch?v=DsNt7yvVKHU" --language en

#date: 2024-11-08 - length:    29:21 - title: "Grocery Prices in 2024 Are Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=ZgkZL34dOHI" --language en

#date: 2024-11-06 - length:    31:28 - title: "Hyperconsumerism Has DEBT EXPLODING in 2025…."
sa "https://www.youtube.com/watch?v=CAzUnrCY4Rk" --language en

#date: 2024-11-04 - length:    30:24 - title: "“Restock” Influencers are Out of Control in 2025 - REACTION"
sa "https://www.youtube.com/watch?v=eapElkbl0uU" --language en

#date: 2024-10-31 - length:    33:17 - title: "People Are REFUSING to Pay Off Their Debt in 2025…"
sa "https://www.youtube.com/watch?v=0Ai6M5SfeeI" --language en

#date: 2024-10-28 - length:    29:55 - title: "“Underconsumption Core” in 2025 is A TRAP…"
sa "https://www.youtube.com/watch?v=Ii1xdzHF8vk" --language en

#date: 2024-10-24 - length:    34:55 - title: "Overconsumption in 2025 is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=mVx4fuNVOVE" --language en

#date: 2024-10-22 - length:    29:11 - title: "Doom Spending in 2025 is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=qAIdARjydeU" --language en

#date: 2024-10-19 - length:    25:39 - title: "The Food Stamp System in America is COMPLETELY Broken…."
sa "https://www.youtube.com/watch?v=BhFHgEX5U5k" --language en

#date: 2024-10-17 - length:    26:36 - title: "The Younger Generation is Completely Broke….."
sa "https://www.youtube.com/watch?v=gD0z5szneYo" --language en

#date: 2024-10-15 - length:    26:58 - title: "People Are REFUSING to Save Money in 2025…."
sa "https://www.youtube.com/watch?v=w_0Wfgty6gI" --language en

#date: 2024-10-10 - length:    23:57 - title: "People Are Giving Up Because The Cost of Living is OUT OF CONTROL!"
sa "https://www.youtube.com/watch?v=_IbCKfpG0DI" --language en

#date: 2024-10-08 - length:    29:20 - title: "Hurricane Prices in 2024 Are OUT OF CONTROL..."
sa "https://www.youtube.com/watch?v=RMC9s9rsx5g" --language en

#date: 2024-10-07 - length:    31:35 - title: "The Cost of Living in 2024 is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=f2ErZSSF9Uk" --language en

#date: 2024-10-04 - length:    25:12 - title: "Women in 2024 Are Living In Fantasy Land..."
sa "https://www.youtube.com/watch?v=lIGcfW4Xst0" --language en

#date: 2024-10-01 - length:    29:21 - title: "I Caught Influencers LYING About Their Wealth & Lifestyle! | IT'S ALL A SCAM!"
sa "https://www.youtube.com/watch?v=UjQVz3iHtgY" --language en

#date: 2024-09-26 - length:    41:16 - title: "Rent Prices in 2024 Are Out of Control and it MUST BE STOPPED! | PT2"
sa "https://www.youtube.com/watch?v=bBG7BwtLUO0" --language en

#date: 2024-09-23 - length:    29:53 - title: "Car Repo’s Are OUT OF CONTROL in 2024 and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=X0pnUwIcyoE" --language en

#date: 2024-09-18 - length:    31:47 - title: "Car Insurance Prices in 2024 Are Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=5QAvdMiYD10" --language en

#date: 2024-09-17 - length:    33:16 - title: "The Job Market in 2024 is TERRIBLE and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=vMlUw5i4NG8" --language en

#date: 2024-09-13 - length:    29:42 - title: "Barbershop Prices in 2024 Are Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=Baoduj9CYvs" --language en

#date: 2024-09-11 - length:    26:45 - title: "Tipping Culture in 2024 is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=kEi1s9USDHA" --language en

#date: 2024-09-10 - length:    28:49 - title: "28 Minutes of HORRIBLE Credit Card Debt in 2024..."
sa "https://www.youtube.com/watch?v=c039qLZTPkU" --language en

#date: 2024-09-06 - length:    31:02 - title: "31 Minutes of INSANE Car Payments in 2024..."
sa "https://www.youtube.com/watch?v=ZiuE--x5_0Q" --language en

#date: 2024-09-05 - length:    26:39 - title: "The Cost of Having Kids In 2024 is INSANE!"
sa "https://www.youtube.com/watch?v=NRKqoXStU4I" --language en

#date: 2024-09-03 - length:    32:27 - title: "Student Loan Debt in 2024 is OUT OF CONTROL!"
sa "https://www.youtube.com/watch?v=0-9-Wwenzvk" --language en

#date: 2024-08-30 - length:    31:42 - title: "The Cost of College Tuition in 2024 is OUT OF CONTROL!"
sa "https://www.youtube.com/watch?v=ElWpesobRWk" --language en

#date: 2024-08-29 - length:    27:50 - title: "Girl Math in 2024 is Out of Control and it MUST BE STOPPED! | Broke Girl Mindset"
sa "https://www.youtube.com/watch?v=uT0LlYInVQU" --language en

#date: 2024-08-27 - length:    34:23 - title: "Buying a House in 2024 Is INSANE! This is Why You're Broke & HOUSE POOR!"
sa "https://www.youtube.com/watch?v=b1-UU84O27c" --language en

#date: 2024-08-23 - length:    30:03 - title: "Rent Prices in 2025 Are Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=nsao9qWeBvY" --language en

#date: 2024-08-17 - length:    23:52 - title: "Work From Home in 2024 Is Out of Control!  THIS IS WHY IT’S GETTING CANCELLED!"
sa "https://www.youtube.com/watch?v=6tVWJqZTa24" --language en

#date: 2024-08-15 - length:    27:21 - title: "Living at Home in Your Late 20's IS OUT OF CONTROL! Failure or Financial Freedom?"
sa "https://www.youtube.com/watch?v=75ZG4QzUonA" --language en

#date: 2024-08-08 - length:    28:23 - title: "Gen Z Doesn’t Want to Work Anymore..."
sa "https://www.youtube.com/watch?v=1nTgYzQbzto" --language en

#date: 2024-08-06 - length:    26:44 - title: "Fast Food Prices in 2024 Are Out Of Control! THIS IS WHY YOU'RE BROKE!"
sa "https://www.youtube.com/watch?v=74uzDNvSeBE" --language en

#date: 2024-08-05 - length:    25:04 - title: "Credit Card Debt in 2024 is OUT OF CONTROL! THIS IS WHY YOU'RE BROKE!"
sa "https://www.youtube.com/watch?v=IEnTe4AqzZo" --language en

echo " \\" > add_fix.txt
echo '	--tags="Ursula von der Leyen" \' >> add_fix.txt
echo '	--tags="EU"' >> add_fix.txt

sa2 "https://x.com/Fidias0/status/1971213103950971023" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change" \' >> add_fix.txt
echo '	--tags="Hayden Schreier"' >> add_fix.txt


#date: 2024-08-02 - length:    16:52 - title: "Shrinkflation in 2024 is Out of Control and it MUST BE STOPPED!"
sa "https://www.youtube.com/watch?v=9PQEXDgTq5w" --language en

#date: 2024-08-01 - length:    27:42 - title: "The Cost of Living in 2024 is INSANE!"
sa "https://www.youtube.com/watch?v=YzBZiGSuFOk" --language en

echo " \\" > add_fix.txt
echo '	--tags="planned obsolescence" \' >> add_fix.txt
echo '	--tags="climate change"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=65oWQN6jY0E" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="Stew Peters"' >> add_fix.txt

sa "https://rumble.com/v6z0e6u-gop-blocks-epstein-files-release-while-general-public-is-distracted-by-kirk.html?e9s=src_v1_ucp_a" --language en

exit

saa "https://www.youtube.com/watch?v=owootTAuxic"  --language en

echo " \\" > add_fix.txt
echo '	--tags="ramble_rants"' >> add_fix.txt

sa "https://x.com/ramble_rants/status/1967562961633092029" --language en

#saa "https://odysee.com/@AuronMacIntyre:f/zelenskyy-unmasked-guest-ben-swann-4-17:3"  --language en
#saa "https://odysee.com/@alltheworldsastage:0/Zelenskyy-Unmasked---Who-is-Volodymyr-Zelenskyy-truthinmedia-sovrenmedia:a"  --language en
#saa "https://odysee.com/@montysthinkingoutsidethebox:2/Zelenskyy-Unmasked---Who-is-Volodymyr-Zelenskyy-truthinmedia-sovrenmedia:5"  --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="Jeanius" \' >> add_fix.txt
echo '	--tags="X"' >> add_fix.txt

sa "https://x.com/jeanerus/status/1938603868918817097" --language en


sa "https://x.com/drtomcowan/status/1893358436437385656" --language en

sa "https://x.com/springfield1952/status/1753409217065529805" --language en

sa "https://odysee.com/@januszkowalskii1979:e/Twelve-Truths-Everyone-Should-Know-But-No-one-Else-Will-Tell-You-%28Dr.-Vernon-Coleman%29:9" --language en

sa "https://x.com/john1rudio/status/1650304520323227648" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=ubPyEerik_I" --language nl

exit

echo " \\" > add_fix.txt
echo '	--tags="Giorgia Melon" \' >> add_fix.txt
echo '	--tags="UDC"' >> add_fix.txt

saa "https://x.com/GiorgiaMeloni/status/1966816552516206887" --language it

echo " \\" > add_fix.txt
echo '	--tags="Poland" \' >> add_fix.txt
echo '	--tags="drones"' >> add_fix.txt

sa "https://x.com/gewoonmerels/status/1965650488751522225" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="Aaron Siri" \' >> add_fix.txt
echo '	--tags="vaccine" \' >> add_fix.txt
echo '	--tags="covid19"' >> add_fix.txt

saa "https://twitter.com/i/status/1965520139132256554" --language en

echo " \\" > add_fix.txt
echo '	--tags="De Nieuwe Wereld" \' >> add_fix.txt
echo '	--tags="Charlie Kirk" \' >> add_fix.txt
echo '	--tags="Wierd Duk"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=IX4it5LD6Xo" --language nl

exit

sa2 "https://x.com/dendolly1/status/1816473355345678696" --language nl 
sa2 "https://x.com/dendolly1/status/1964619290625339692" --language nl 
sa2 "https://x.com/dendolly1/status/1964994600336228690" --language nl 
sa2 "https://x.com/dendolly1/status/1964253380823462160" --language nl 
sa2 "https://x.com/dendolly1/status/1905315016686944634" --language nl 
sa2 "https://x.com/dendolly1/status/1916152815409336470" --language nl 
sa2 "https://x.com/dendolly1/status/1830925586719482056" --language nl 
sa2 "https://x.com/dendolly1/status/1965385035781152971" --language nl 
sa2 "https://x.com/dendolly1/status/1815655750380724372" --language nl 

exit

echo " \\" > add_fix.txt
echo '	--tags="The Cutting Edge" \' >> add_fix.txt
echo '	--tags="AI" \' >> add_fix.txt
echo '	--tags="robots"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=m8wyoYGdOQk" --language nl

exit

# echo " \\" > add_fix.txt
# echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
# echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
# echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt
# 
# saa "https://www.youtube.com/watch?v=5lifYcsUJlA" --language nl

## echo " \\" > add_fix.txt
## echo '	--tags="AI Revolution" \' >> add_fix.txt
## echo '	--tags="OpenAI" \' >> add_fix.txt
## echo '	--tags="ChatGPT"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=2sxFhGJ1P3o" --language en

echo " \\" > add_fix.txt
echo '	--tags="AIn" \' >> add_fix.txt
echo '	--tags="Hacking" \' >> add_fix.txt
echo '	--tags="NetworkChuck"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=Qvx2sVgQ-u0" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="David Icke" \' >> add_fix.txt
echo '	--tags="1996"' >> add_fix.txt

sa2 "https://x.com/deSunShineBand/status/1964239114959569257" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="LP" \' >> add_fix.txt
echo '	--tags="Dutch Libertarian Party" \' >> add_fix.txt
echo '	--tags="Libertaire Partij"' >> add_fix.txt

### saa "https://www.youtube.com/watch?v=Z-ycPdEmXBs" --language nl
### #date: 2020-06-20 - length:     1:54 - title: "Introductie Immigratiebeleid LP"
### 
### saa "https://www.youtube.com/watch?v=6-TrzbEPwQ0" --language nl
### #date: 2020-06-23 - length:     1:04 - title: "Robert Valentine over het voorwaardelijk basisinkomen - LP"
### 
### saa "https://www.youtube.com/watch?v=V_ByFOyNm_k" --language nl
### #date: 2020-07-02 - length:     3:14 - title: "De Nieuwe Kieswet"
### 
### saa "https://www.youtube.com/watch?v=B5NsmBhYFyo" --language nl
### #date: 2020-07-04 - length:       36 - title: "Oplossing voor de Woningmarkt Crisis - LP"
### 
### saa "https://www.youtube.com/watch?v=7p10BH158o8" --language nl
### #date: 2020-10-14 - length:     2:23 - title: "Nieuwe Coronamaatregels"
### 
### saa "https://www.youtube.com/watch?v=VokFElWAQWM" --language nl
### #date: 2020-10-19 - length:     2:37 - title: "Woonzekerheid"
### 
### saa "https://www.youtube.com/watch?v=OR_TRbQTe0s" --language nl
### #date: 2020-10-24 - length:       39 - title: "Waar staat de LP voor?"
### 
### saa "https://www.youtube.com/watch?v=IK1RcVGvDtA" --language nl
### #date: 2020-10-27 - length:     1:45 - title: "Corona"
### 
### saa "https://www.youtube.com/watch?v=w01udYNOPiA" --language nl
### #date: 2020-10-31 - length:     2:20 - title: "Barstmaar"
### 
### saa "https://www.youtube.com/watch?v=c_LNL3fjOjY" --language nl
### #date: 2020-11-04 - length:     2:19 - title: "Overheidsbemoeienis"
### 
### saa "https://www.youtube.com/watch?v=TL8ltX4OgZ4" --language nl
### #date: 2020-11-08 - length:     1:54 - title: "LP terugblik FAILLIET actie"
### 
### saa "https://www.youtube.com/watch?v=U1VAiW60XwA" --language nl
### #date: 2021-01-16 - length:     2:00 - title: "Politieke Poppenkast"
### 
### saa "https://www.youtube.com/watch?v=s9KAxJjaG2w" --language nl
### #date: 2021-01-19 - length:     1:48 - title: "Toeslagenaffaire"

### saa "https://www.youtube.com/watch?v=pwxsEFrIJ0U" --language nl
### #date: 2021-01-27 - length:       35 - title: "Hoe het wel moet: natuurlijk, energie!"
### 
### saa "https://www.youtube.com/watch?v=zx-7kToLeXM" --language nl
### #date: 2021-01-31 - length:       37 - title: "Hoe het wel moet: Digitale rechten"
### 
### saa "https://www.youtube.com/watch?v=mi1yqEoq5o8" --language nl
### #date: 2021-02-15 - length:     1:59 - title: "Achter de Schermen bij de LP"
### 
### saa "https://www.youtube.com/watch?v=78Iw-qMQExc" --language nl
### #date: 2021-02-26 - length:     1:36 - title: "Kleinere overheid: LP"
### 
### saa "https://www.youtube.com/watch?v=dBun5Wttkuw" --language nl
### #date: 2021-03-01 - length:     2:12 - title: "Ondernemers en de Overheid"
### 
### saa "https://www.youtube.com/watch?v=DfljswF9aB0" --language nl
### #date: 2021-03-01 - length:     3:13 - title: "Bitcoin als Verzetsmiddel"
### 
### saa "https://www.youtube.com/watch?v=1VoTVSMyGd8" --language nl
### #date: 2021-03-07 - length:     4:24 - title: "Corona"
### 
### saa "https://www.youtube.com/watch?v=3fdEY7W-Z5s" --language nl
### #date: 2021-03-08 - length:       36 - title: "Ondernemerschap"
### 
### saa "https://www.youtube.com/watch?v=t79ua0BdzVU" --language nl
### #date: 2021-03-09 - length:    19:28 - title: "Arno Wellens Vertelt Waarom Hij Lijstduwer van de Libertaire  Partij Is Geworden"
### 
### saa "https://www.youtube.com/watch?v=ib65Hy3PHxc" --language nl
### #date: 2021-03-09 - length:     2:44 - title: "Milieu, Europa, Immigratie & Economie"
### 
### saa "https://www.youtube.com/watch?v=ReXcZCxI0Do" --language nl
### #date: 2021-03-16 - length:     1:09 - title: "Ambtenarenapparaat"
### 
### saa "https://www.youtube.com/watch?v=DOCzIDR7QTM" --language nl
### #date: 2021-03-16 - length:     1:20 - title: "Minderheidskabinet"
### 
### saa "https://www.youtube.com/watch?v=HYwfK-nqA5E" --language nl
### #date: 2021-03-16 - length:       34 - title: "Politici, Verantwoordelijkheid en Expertise"
### 
### saa "https://www.youtube.com/watch?v=lKAL7U3Uuh0" --language nl
### #date: 2021-09-05 - length:     3:20 - title: "V for Valentine: Chaos in het Midden-Oosten"
### 
### saa "https://www.youtube.com/watch?v=Wf31RzjlhRE" --language nl
### #date: 2021-10-03 - length:  1:22:01 - title: "Gastlezing Toine Manders aan de TU Eindhoven"
### 
### saa "https://www.youtube.com/watch?v=Ws6vo1TkUDA" --language nl
### #date: 2022-10-09 - length:  1:09:49 - title: "Toine Manders - Het Libertarisme"
### 
### saa "https://www.youtube.com/watch?v=M8e5CffxpaA" --language nl
### #date: 2023-07-14 - length:     5:06 - title: "Wat willen Libertariërs?"
### 
### saa "https://www.youtube.com/watch?v=XBfZq1QOI1Q" --language nl
### #date: 2023-09-11 - length:    58:43 - title: "Economie, geld en belasting"
### 
### saa "https://www.youtube.com/watch?v=iyrCDy4Fss4" --language nl
### #date: 2023-09-12 - length:     1:12 - title: "Is iedereen een libertariër?"
### 
### saa "https://www.youtube.com/watch?v=LfT7F4myHPA" --language nl
### #date: 2023-09-12 - length:       42 - title: "Waarom dwang nooit OK is"
### 
### saa "https://www.youtube.com/watch?v=I-zyQRJZe54" --language nl
### #date: 2023-09-12 - length:       45 - title: "Inflatie is verborgen belasting"
### 
### saa "https://www.youtube.com/watch?v=AE35v4_GYVg" --language nl
### #date: 2023-09-12 - length:       46 - title: "Voorkeursbehandeling van grote bedrijven"
### 
### saa "https://www.youtube.com/watch?v=d_p6vWp8mgE" --language nl
### #date: 2023-09-19 - length:  1:04:23 - title: "Vrij onderwijs volgens Peter Hartkamp"
### 
### saa "https://www.youtube.com/watch?v=G3ohnQileIg" --language nl
### #date: 2023-09-19 - length:       17 - title: "Is het leerplicht of schoolplicht?"
### 
### saa "https://www.youtube.com/watch?v=IYaLTAIgBGs" --language nl
### #date: 2023-09-19 - length:       32 - title: "Alle scholen in ons land zijn hetzelfde"
### 
### saa "https://www.youtube.com/watch?v=FmH1SK0mT5Q" --language nl
### #date: 2023-09-19 - length:       46 - title: "Kinderen leren alleen met motivatie"
### 
### saa "https://www.youtube.com/watch?v=J_Ml-s-TWeU" --language nl
### #date: 2023-09-22 - length:       31 - title: "De codetaal van de politiek"
### 
### saa "https://www.youtube.com/watch?v=gsX_PTctGFQ" --language nl
### #date: 2023-10-02 - length:     1:00 - title: "90% minder belasting"
### 
### saa "https://www.youtube.com/watch?v=xihu7TDWcTE" --language nl
### #date: 2023-10-02 - length:  1:18:15 - title: "Is belasting diefstal?"
### 
### mv add_fix.txt add_fix.backup.txt
### 
### echo " \\" > add_fix.txt
### echo '	--tags="Thomas Massie" \' >> add_fix.txt
### echo '	--tags="America First" \' >> add_fix.txt
### echo '	--tags="Dissident Media"' >> add_fix.txt
### saa "https://x.com/DissidentMedia/status/1963315630137839873" --language en
### 
### echo " \\" > add_fix.txt
### echo '	--tags="Chris Rock" \' >> add_fix.txt
### echo '	--tags="Oboy the Law"' >> add_fix.txt
### sa "https://x.com/EnriqueLichten4/status/1963325375183995285" --language en
### 
### mv add_fix.backup.txt add_fix.txt
### 
### saa "https://www.youtube.com/watch?v=6qKNHOmyQ6M" --language nl
### #date: 2023-10-02 - length:       47 - title: "Belastingen op belastingen"
### 
### saa "https://www.youtube.com/watch?v=nvtmDy5IwUo" --language nl
### #date: 2023-10-02 - length:       51 - title: "Inflatie en belasting als diefstal?"
### 
### saa "https://www.youtube.com/watch?v=k1h4T2I0FFU" --language nl
### #date: 2023-10-02 - length:       52 - title: "Belastingen werken vaak contraproductief"
### 
### saa "https://www.youtube.com/watch?v=iQDnzBuYfoQ" --language nl
### #date: 2023-10-06 - length:     1:08 - title: "Waarom steunt Arno Wellens de LP?"
### 
### saa "https://www.youtube.com/watch?v=drg87yyAaLc" --language nl
### #date: 2023-10-06 - length:       32 - title: "Écht vrij onderwijs"
### 
### saa "https://www.youtube.com/watch?v=k6hgaSJZm8I" --language nl
### #date: 2023-10-06 - length:       35 - title: "Een transparante overheid"
### 
### saa "https://www.youtube.com/watch?v=D5SmeLbibi0" --language nl
### #date: 2023-10-06 - length:       38 - title: "The Great Moderation is een wonder?"
### 
### saa "https://www.youtube.com/watch?v=qPwGiunhe9k" --language nl
### #date: 2023-10-06 - length:       41 - title: "Het grootste probleem is het geldsysteem"
### 
### saa "https://www.youtube.com/watch?v=afXWsuT-H5M" --language nl
### #date: 2023-10-06 - length:       41 - title: "Het probleem met onderwijs"
### 
### saa "https://www.youtube.com/watch?v=60KChuFAeuk" --language nl
### #date: 2023-10-20 - length:  1:06:45 - title: "De rot in het bankenstelsel met Hester Bais"
### 
### saa "https://www.youtube.com/watch?v=RAcVOtYsE1I" --language nl
### #date: 2023-10-20 - length:       37 - title: "Het vervangen van poppetjes lost niets op"
### 
### saa "https://www.youtube.com/watch?v=cyXdoMLw3_A" --language nl
### #date: 2023-10-20 - length:       46 - title: "De Tweede Kamer negeert het"
### 
### saa "https://www.youtube.com/watch?v=ntsULpSjAtg" --language nl
### #date: 2023-10-20 - length:       47 - title: "In de praktijk is er geen vermogensscheiding"
### 
### saa "https://www.youtube.com/watch?v=WoDh1QJQBMA" --language nl
### #date: 2023-10-20 - length:       53 - title: "Een systeem met perverse prikkels"
### 
### saa "https://www.youtube.com/watch?v=qHcsSc_4Xbc" --language nl
### #date: 2023-10-20 - length:       58 - title: "Onze kinderen zijn het onderpand"
### 
### saa "https://www.youtube.com/watch?v=mPoDXFPdc1k" --language nl
### #date: 2023-10-31 - length:     1:35 - title: "Libertaire Partij - Politieke Zendtijd 2023"
### 
### saa "https://www.youtube.com/watch?v=TA81xnMvERY" --language nl
### #date: 2023-11-15 - length:     1:07 - title: "Waarom de LP belangrijk is volgens George van Houts"
### 
### saa "https://www.youtube.com/watch?v=PCdJWnc2Bvk" --language nl
### #date: 2023-11-15 - length:  1:12:50 - title: ""Als stemmen iets kon veranderen, zou het verboden zijn" met George van Houts"
### 
### 
### mv add_fix.txt add_fix.backup.txt
### 
### echo " \\" > add_fix.txt
### echo '	--tags="Naomi Wolf" \' >> add_fix.txt
### echo '	--tags="European Parliament" \' >> add_fix.txt
### echo '	--tags="Pfizer Papers"' >> add_fix.txt
### sa "https://x.com/i/broadcasts/1lPKqvQNwvmGb" --language en
### 
### mv add_fix.backup.txt add_fix.txt
### 
### saa "https://www.youtube.com/watch?v=9F7vn0b1NnQ" --language nl
### #date: 2023-11-15 - length:       48 - title: "De politiek kan je nooit vertrouwen"
### 
### saa "https://www.youtube.com/watch?v=z8SBOTP-JNU" --language nl
### #date: 2023-11-15 - length:       50 - title: "Voor bureaucraten zijn wij nummers op een spreadsheet"
### 
### saa "https://www.youtube.com/watch?v=VLFUz41CoY8" --language nl
### #date: 2023-11-15 - length:       55 - title: "Het systeem is prima voor de 0.01% zegt George van Houts"
### 
### saa "https://www.youtube.com/watch?v=sNaaU1MzsWk" --language nl
#date: 2023-11-18 - length:  1:05:20 - title: "Ondernemers en de politiek met Pancras Pouw"

#################### 			echo " \\" > add_fix.txt
#################### 			echo '	--tags="mk-ultra" \' >> add_fix.txt
#################### 			echo '	--tags="mind control" \' >> add_fix.txt
#################### 			echo '	--tags="ABC"' >> add_fix.txt
#################### 			
#################### 			sa "https://x.com/CarineKnapen/status/1963543888620122232" --language en

echo " \\" > add_fix.txt
echo '	--tags="LP" \' >> add_fix.txt
echo '	--tags="Dutch Libertarian Party" \' >> add_fix.txt
echo '	--tags="Libertaire Partij"' >> add_fix.txt

## saa "https://www.youtube.com/watch?v=czXxPKNdj1I" --language nl
## #date: 2023-11-18 - length:     1:14 - title: "Wie neemt het op voor de ondernemers?"
## 
## saa "https://www.youtube.com/watch?v=l4MkRh-VyYM" --language nl
## #date: 2024-01-09 - length:  1:17:02 - title: "De weg naar een staatloze samenleving met Olaf Weller"
## 
## saa "https://www.youtube.com/watch?v=kMjMy6Dk_og" --language nl
## #date: 2024-03-19 - length:  1:09:41 - title: ""De grote verbouwing van Nederland" met Elze van Hamelen"
## 
## saa "https://www.youtube.com/watch?v=FOctccSWR7s" --language nl
## #date: 2024-03-20 - length:     1:27 - title: "Een puzzelopdracht voor herverdeling"
## 
## 
## saa "https://www.youtube.com/watch?v=4FYzdQpLhuo" --language nl
## #date: 2024-03-22 - length:     1:57 - title: "Het fundament is zelfbeschikking"

saa "https://www.youtube.com/watch?v=BtGEcQAgets" --language nl
#date: 2024-03-22 - length:     2:20 - title: "Driekwart van ons land ging op de schop"

saa "https://www.youtube.com/watch?v=w00M3N9z95I" --language nl
#date: 2024-03-24 - length:     1:37 - title: "Ruilverkaveling was mogelijk door een 'crisis'"

saa "https://www.youtube.com/watch?v=hYWQaiR6kIQ" --language nl
#date: 2024-03-24 - length:     2:32 - title: ""Privébezit is dan het probleem""

saa "https://www.youtube.com/watch?v=H6_WHUiu_Hw" --language nl
#date: 2025-04-19 - length:     1:01 - title: "Bassie (Bas van Toor) over kunstsubsidies"

saa "https://www.youtube.com/watch?v=Y5XA_KwdirU" --language nl
#date: 2025-04-24 - length:       58 - title: "Mensen weten niet hoeveel belasting ze eigenlijk betalen"

saa "https://www.youtube.com/watch?v=35FUt5d7P1w" --language nl
#date: 2025-06-13 - length:     1:24 - title: "Tom van Lamoen over het probleem in het onderwijs"

saa "https://www.youtube.com/watch?v=-Ro8Ffbu_fI" --language nl
#date: 2025-08-13 - length:     3:45 - title: "Toine Manders ondervraagd door Renske Leijten"

saa "https://www.youtube.com/watch?v=sZ5qbsLLh3Q" --language nl
#date: 2025-08-17 - length:     2:07 - title: "NOS journaal 16 augustus 2025 - LP"

saa "https://www.youtube.com/watch?v=0gcA0ExIPK8" --language nl
#date: 2025-08-19 - length:    15:17 - title: "LightHouseTV #33: Tom van Lamoen | ‘Moestuinpolitie’"

saa "https://www.youtube.com/watch?v=58ymx16erLU" --language nl
#date: 2025-08-20 - length:    25:21 - title: "Doorzagen met John Medley, Hester Bais, Rico Brouwer en Tom van Lamoen"

saa "https://www.youtube.com/watch?v=MyTbymrbk1U" --language nl
#date: 2025-08-20 - length:    28:08 - title: "politiedocument radicalisering - Doorzagen met Dennis Spaanstra en Tom van Lamoen"

saa "https://www.youtube.com/watch?v=cw5ZYP7snEc" --language nl
#date: 2025-08-22 - length:    26:53 - title: "Doorzagen met lijsttrekker Tom van Lamoen - het ministerie van onderwijs; schaffen we af"

saa "https://www.youtube.com/watch?v=N_T8rnFHYw4" --language nl
#date: 2025-08-26 - length:    52:04 - title: "Het financiële stelsel is de kern van alle kwaad - Doorzagen met Hester Bais"

saa "https://www.youtube.com/watch?v=H7sHh4A6YGQ" --language nl
#date: 2025-08-27 - length:    34:36 - title: "de bank en de overheid - Doorzagen met Hester Bais en Tom van Lamoen"

saa "https://www.youtube.com/watch?v=9gMf3StqhWk" --language nl
#date: 2025-08-28 - length:    35:38 - title: "het klimaatverhaal wordt in stand gehouden om monetaire redenen - Marcel Crok verkiesbaar voor de LP"

saa "https://www.youtube.com/watch?v=O4HXSO1PGUo" --language nl
#date: 2025-08-29 - length:     1:36 - title: "Ondersteuningsverklaringen nodig"

exit

echo " \\" > add_fix.txt
echo '	--tags="media" \' >> add_fix.txt
echo '	--tags="Konstantin Kisin" \' >> add_fix.txt
echo '	--tags="Triggernometry"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=nfr-WjiTehM" --language en

echo " \\" > add_fix.txt
echo '	--tags="Monsanto" \' >> add_fix.txt
echo '	--tags="Veritasium"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=CxVXvFOPIyQ" --language en

echo " \\" > add_fix.txt
echo '	--tags="Monsanto" \' >> add_fix.txt
echo '	--tags="Full Documentary"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=4NQ6Tw7KXUk" --language en

exit 

echo " \\" > add_fix.txt
echo '	--tags="David Martin" \' >> add_fix.txt
echo '	--tags="DATA REQUEST" \' >> add_fix.txt
echo '	--tags="Warp speed"' >> add_fix.txt

saa "https://x.com/i/broadcasts/1yoKMPbaYrzxQ" --language en

echo " \\" > add_fix.txt
echo '	--tags="AI"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=aQnzxVk-qGY" --language en

exit

echo " \\" > add_fix.txt
echo '	--tags="De Gulden Middenweg" \' >> add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="NL35ABNA0563838523"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=QvH8A3Tp4gA" --language nl

echo " \\" > add_fix.txt
echo '	--tags="FVD" \' >> add_fix.txt
echo '	--tags="Thierry Baudet"' >> add_fix.txt

saa "https://x.com/Symphony_res/status/1961799457160200445" --language nl

exit 

echo " \\" > add_fix.txt
echo '	--tags="De Nieuwe Wereld" \' >> add_fix.txt
echo '	--tags="Andrea Speyerbach"' >> add_fix.txt

saa "https://www.youtube.com/watch?v=xZIVrN-T7Zs" --language nl
