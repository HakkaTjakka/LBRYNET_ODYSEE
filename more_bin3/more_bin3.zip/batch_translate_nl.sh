#!/bin/bash

FILENAME=$*
BASENAME="${FILENAME%.*}"

LANGUAGE="${FILENAME%.*}"
LANGUAGE="${LANGUAGE%.*}"
BASENAME2="${LANGUAGE%.*}"
LANGUAGE="${LANGUAGE##*.}"
echo $LANGUAGE

#exit
#LANGUAGE="en"

echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"

while IFS='' read -r line || [[ -n "$line" ]]; do
        if [[ "$line" != "" ]] ; then
                if [[ ! $line =~ [0-9] ]] ; then
                        echo ORIGINAL___$LANGUAGE: $line
                        VAR=$(echo "$line" | trans -brief $LANGUAGE:nl)
                        #VAR2=$(echo "$line" | trans -brief $LANGUAGE:en)
                        echo TRANSLATED_NL: $VAR
                        #echo TRANSLATED_EN: $VAR2
                else
                        VAR=$line
                        #VAR2=$line
                        echo NO TRANSLATE: $line
                fi
        else
                VAR=$line
                #VAR2=$line
                echo NO TRANSLATE: $line
        fi
#        echo original  $line
#        echo translate $VAR
        echo $VAR >> "$BASENAME2.nl.srt.double"
        #echo $VAR2 >> "$BASENAME2.en.srt.double"

done < "$FILENAME"

