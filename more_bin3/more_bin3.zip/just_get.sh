#!/bin/bash

echo -------------------------------------------------------------------------- >> error.log

echo Getting filename from URL: $*
echo Getting filename from URL: $* >> error.log

		## yt-dlp -i --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "ytsearch:$*" > filename.txt

yt-dlp -i --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" > filename.txt

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')
#echo "Basename: $BASENAME"

#yt-dlp --restrict-filenames --abort-on-error --no-mtime --sub-lang "nl,en,de" --write-subs --convert-subs srt --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "ytsearch:$*"
#--default-search "ytsearch"
COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "nl,en" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

# COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "en-us,en" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

#COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "nl-id" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""
#COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "nl-en-US" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

#COMMAND="yt-dlp  --restrict-filenames --abort-on-error --no-mtime --sub-langs all --write-subs --write-auto-subs --embed-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

echo "$COMMAND" >> COMMANDS.SH
echo "$COMMAND" > command.sh
chmod +x command.sh
./command.sh

if test -f "$FILENAME"; then
	echo "DOWNLOADED: $FILENAME"
else 
	if test -f "$BASENAME.mkv"; then
		FILENAME="$BASENAME.mkv"
		echo "$BASENAME.mkv exists. Changing filename."
		echo "$FILENAME" > filename.txt
	fi
fi

if [ ! -d "subs" ]; then
	mkdir "subs"
fi	
# convert .vtt to .srt. Can also be done by yt-dlp with --convert-subs srt but only after/when downloading. So when interrupted can be continued.
for line in $VAR.*.vtt
do
	LANGUAGE="${line%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	echo "Converting subtitle file to .srt and fixing: $line"
	echo "Converting subtitle file to .srt and fixing: $line" >> error.log
	ffmpeg -n -hide_banner -i $BASENAME.$LANGUAGE.vtt $BASENAME.$LANGUAGE.srt
#	rm -f $BASENAME.$LANGUAGE.vtt
	echo "sof/sof $BASENAME.$LANGUAGE.srt" >> COMMANDS.SH
	sof/sof $BASENAME.$LANGUAGE.srt
#	echo "Moving $BASENAME.$LANGUAGE.srt* to dir: subs/$LANGUAGE"
	if [ ! -d "subs/$BASENAME" ]; then
		mkdir "subs/$BASENAME"
	fi	

	if [ ! -d "subs/$BASENAME/$LANGUAGE" ]; then
		mkdir "subs/$BASENAME/$LANGUAGE"
	fi	
	mv "$BASENAME.$LANGUAGE.vtt" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt.single" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt.double" "subs/$BASENAME/$LANGUAGE"
done
