#!/bin/bash

NEXT=$(echo "($1+1)"| bc -l)
printf "%d\r" "$1"
$0 $NEXT &
