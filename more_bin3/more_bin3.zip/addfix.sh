echo " \\" > add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="De Gulden Middenweg"' >> add_fix.txt

