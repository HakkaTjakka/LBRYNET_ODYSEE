#!/bin/bash

LANGUAGE="unknown"
TRANSLATOR="en-us-0.42-gigaspeech"

echo -------------------------------------------------------------------------- >> error.log

echo Getting filename from URL: $*
echo Getting filename from URL: $* >> error.log

#yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --skip-unavailable-fragments --geo-bypass --get-filename "$*" -o "kut.mp4" > filename.txt
#yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --skip-unavailable-fragments --geo-bypass --get-filename "$*" > filename.txt
#yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt
#--list-thumbnails
yt-dlp -i --trim-filenames 40 --write-thumbnail --merge-output-format mp4 --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt

#yt-dlp -i --write-thumbnail --merge-output-format mp4 --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt
yt-dlp "$*" --restrict-filenames --list-thumbnails --cookies cookies/twitter.com_cookies.txt > thumbnails.txt

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log

# THUMBNAIL=$(tail -n 1 thumbnails.txt)
# echo "Thumbnail=$THUMBNAIL"
# 
# THUMBNAIL="$(echo $THUMBNAIL | cut -d' ' -f4)"
# 
# #echo $THUMBNAIL | read -d " " A1 A2 A3 A4
# echo "Thumbnail=$THUMBNAIL"

# FILENAME=$*
# echo $FILENAME > filename.txt

BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')

if test -f "out/$BASENAME.$LANGUAGE.mp4"; then
	echo "out/$BASENAME.$LANGUAGE.mp4 exists."
else

#	COMMAND="yt-dlp --write-info-json --merge-output-format mp4 --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass --cookies cookies/twitter.com_cookies.txt "$*""
	COMMAND="yt-dlp --write-info-json --merge-output-format mp4 --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass --cookies cookies/twitter.com_cookies.txt \"$*\" -o $FILENAME"
#	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass --cookies cookies/twitter.com_cookies.txt "$*""
#	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""
#	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*" -o "kut.mp4""

	rm COMMANDS.SH
	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
#exit
	./command.sh

	if test -f "$BASENAME.mkv"; then
		FILENAME="$BASENAME.mkv"
		echo "$BASENAME.mkv exists. Changing filename."
		echo "$FILENAME" > filename.txt
	fi

	mv "$BASENAME.description" "$BASENAME.backup.description"
	echo "================ End of Original Description ================" > "$BASENAME.description"
	echo "Video Source: $*" >> "$BASENAME.description"
	echo "Translation(s) by Pacman Graphics: https://odysee.com/@PMG:5?view=channels"  >> "$BASENAME.description"
	echo "Speech Recognition: Whisper, medium model" >> "$BASENAME.description"
	echo "Translation: Google" >> "$BASENAME.description"
	echo "Subtitles Archive: https://drive.google.com/drive/folders/14RMVjdIla_OZ4TagWQUIDIWnb9dPcjtN" >> "$BASENAME.description"
	echo "👊 Buy me a Coffee: Bitcoin (BTC): 14eueBv7NuDGMqv4mBWLDFmU2g76h8vkYS" >> "$BASENAME.description"

#	COMMAND="autosub -S $LANGUAGE -D $LANGUAGE \"$FILENAME\" -o \"$BASENAME.$LANGUAGE.srt\""

#	COMMAND="vosk-transcriber -l $LANGUAGE -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""

	#COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_width 40 --max_line_count 2"
	#COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_width 40 --max_line_count 2"
	#COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_count 1 --no_speech_threshold 0.5"
	COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_count 1 --language en"
	# --no_speech_threshold NO_SPEECH_THRESHOLD
	# --max_line_width 30
	# --max_line_width 80

# 	--language Dutch 
#	COMMAND="vosk-transcriber -l $TRANSLATOR -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""


	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	#./command.sh
	ln=1
	# for i in $("./command.sh"); do
    # 	echo "whisper: "$ln" = \"$i\""
    # 	ln=$ln+1
	# done
	#IFS=$'\r'
	#./command.sh | while read -r line ; do
	#| tr -d '\r'
	script -c ./command.sh -f | while read -r line1; do
    	#echo "$line"
    	BAR=$(printf "whisper: "$ln" = \"$line1\"" | tr -d '\r')
    	#echo $(printf "whisper: "$ln" = \"$line1\"" | tr -d '\r')
    	echo -n $BAR
    	printf "\r\n"
    	ln=$((ln+1))
    	#IFS=$' '
	    #echo "Unknown" > language.txt
    	echo $line1 | while read -r line_a line_b line_c; do
    		if [ "$line_a" = "Detected" ]; then  
	    		if [ "$line_b" = "language:" ]; then
	    			LANGUAGE=$(echo $line_c | tr -d '\r')
	    			echo $LANGUAGE > language.txt
	    			echo $LANGUAGE > language_full.txt
					read -r LANGUAGE_FULL < language.txt
    				echo "LANGUAGE="$line_c

					if [ "$LANGUAGE_FULL" == "Dutch"      ];           then LANGUAGE="nl" ; fi
					if [ "$LANGUAGE_FULL" == "English"    ];           then LANGUAGE="en" ; fi
					if [ "$LANGUAGE_FULL" == "French"     ];           then LANGUAGE="fr" ; fi
					if [ "$LANGUAGE_FULL" == "Italian"    ];           then LANGUAGE="it" ; fi
					if [ "$LANGUAGE_FULL" == "German"     ];           then LANGUAGE="de" ; fi
					if [ "$LANGUAGE_FULL" == "Turkish"    ];           then LANGUAGE="tr" ; fi
					if [ "$LANGUAGE_FULL" == "Portuguese" ];           then LANGUAGE="pt" ; fi
					if [ "$LANGUAGE_FULL" == "Russian"    ];           then LANGUAGE="ru" ; fi
					if [ "$LANGUAGE_FULL" == "Ukrainian"  ];           then LANGUAGE="uk" ; fi
					if [ "$LANGUAGE_FULL" == "Arabic"     ];           then LANGUAGE="ar" ; fi
					if [ "$LANGUAGE_FULL" == "Japanese"   ];           then LANGUAGE="ja" ; fi
					if [ "$LANGUAGE_FULL" == "Urdu"       ];           then LANGUAGE="ur" ; fi
					echo $LANGUAGE > language.txt
    				printf "LANGUAGE=$LANGUAGE\r\n"

	    		fi
    		fi
    		#printf "line_a="$line_a"  line_b="$line_b"\r\n"
    	done
	done

#exit
	echo English > language_full.txt
	echo en > language.txt

	read -r LANGUAGE < language.txt
	read -r LANGUAGE_FULL < language_full.txt

#	COMMAND="sof/sof "$BASENAME.$LANGUAGE.srt""
	COMMAND="ffmpeg -y -hide_banner -i \"$BASENAME.srt\" \"$BASENAME.$LANGUAGE.ass\""

	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	
	./command.sh

	cat "$BASENAME.$LANGUAGE.ass" | sed "s/\u1/c\&HFFFF\&/g" | sed "s/\u0/c\&HFFFFFF\&/g" > "$BASENAME.$LANGUAGE.ass.double"

	#batch_burn_video_ass.sh $LANGUAGE

	mv "$BASENAME.single" "$BASENAME.$LANGUAGE.srt.double"

	COMMAND="batch_translate_nl.sh \"$BASENAME.$LANGUAGE.srt.double\""
	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	
	./command.sh

	cp "$BASENAME.nl.srt.double" "$BASENAME.nl.srt"
	COMMAND="ffmpeg -y -hide_banner -i \"$BASENAME.nl.srt\" \"$BASENAME.nl.ass\""
	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	
	./command.sh

	batch_burn_video_ass.sh $LANGUAGE
	batch_burn_video.sh nl

	mkdir "$BASENAME"
	find -maxdepth 1 -type f -name "$VAR*" -exec mv {} "$BASENAME" ';'
	mv thumbnails.txt "$BASENAME"
	mv COMMANDS.SH "$BASENAME"
	mv command3.sh "$BASENAME"
#	"$THUMBNAIL"
fi
