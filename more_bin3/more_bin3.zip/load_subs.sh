yt-dlp -i "$1" \
	--merge-output-format mp4 \
	--restrict-filenames \
	--skip-unavailable-fragments \
	--geo-bypass \
	--get-filename \
	--no-playlist \
	--cookies cookies/twitter.com_cookies.txt > filename.txt

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log

yt-dlp --merge-output-format mp4 --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime \
--write-subs --write-auto-subs --sub-lang "nl,en,nl-NL,nl-en" --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass \"$*\" --cookies cookies/twitter.com_cookies.txt -o $FILENAME

BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')
echo "VAR: $VAR"

find . -maxdepth 1 -type f -name "$VAR.*.vtt" -print0 | sort -z | while IFS= read -r -d '' line; # do
do
	LANGUAGE="${line%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	echo "Converting subtitle file to .srt and fixing: $line"
	echo "Converting subtitle file to .srt and fixing: $line" >> error.log
	ffmpeg -n -hide_banner -i $BASENAME.$LANGUAGE.vtt $BASENAME.$LANGUAGE.srt

	sof/sof $BASENAME.$LANGUAGE.srt > shit.txt 2>&1

	mv "$BASENAME.$LANGUAGE.srt" "$BASENAME.$LANGUAGE.srt.double"
done
