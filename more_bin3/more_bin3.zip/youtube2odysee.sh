#!/bin/bash

LANGUAGE="unknown"
TRANSLATOR="en-us-0.42-gigaspeech"

echo -------------------------------------------------------------------------- >> error.log

echo Getting filename from URL: $*
echo Getting filename from URL: $* >> error.log

yt-dlp -i --merge-output-format mp4 --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename_odysee.txt
yt-dlp "$*" --restrict-filenames --list-thumbnails --cookies cookies/twitter.com_cookies.txt > thumbnails_odysee.txt

read -r FILENAME < filename_odysee.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log

BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')

if test -f "out/$FILENAME"; then
	echo "out/$FILENAME exists."
else
	COMMAND="yt-dlp --write-info-json --merge-output-format mp4 --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass --cookies cookies/twitter.com_cookies.txt \"$*\" -o $FILENAME"

	echo "$COMMAND" > upload_command.sh
	chmod +x upload_command.sh
	./upload_command.sh

	if test -f "$BASENAME.mkv"; then
		FILENAME="$BASENAME.mkv"
		echo "$BASENAME.mkv exists. Changing filename."
		echo "$FILENAME" > filename_odysee.txt
	fi

	#mv "$VAR.description" "$VAR.backup.description"
	echo -e "\nVideo Source: $*" > "$BASENAME.description"
	echo -e "\nGitHub Repositories: https://github.com/HakkaTjakka 👀" >> "$BASENAME.description"

	mv "$FILENAME" out

    COMMAND="~/movies/bin/video_to_odysee.sh \"$FILENAME\" \"$BASENAME\" "
    echo "$COMMAND" > upload_command.sh
    chmod +x upload_command.sh
    ./upload_command.sh

	mkdir "$BASENAME"
	mv upload_video.sh "$BASENAME"
   	find -maxdepth 1 -type f -name "$VAR*" -exec mv {} "$BASENAME" ';'
	mv thumbnails_odysee.txt "$BASENAME"
	mv filename_odysee.txt "$BASENAME"
fi
