#!/bin/bash
# wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-ubuntu2204.pin
# sudo mv cuda-ubuntu2204.pin /etc/apt/preferences.d/cuda-repository-pin-600
# wget https://developer.download.nvidia.com/compute/cuda/12.3.2/local_installers/cuda-repo-ubuntu2204-12-3-local_12.3.2-545.23.08-1_amd64.deb
# sudo dpkg -i cuda-repo-ubuntu2204-12-3-local_12.3.2-545.23.08-1_amd64.deb
# sudo cp /var/cuda-repo-ubuntu2204-12-3-local/cuda-*-keyring.gpg /usr/share/keyrings/
# sudo apt-get update
# sudo apt-get -y install cuda-toolkit-12-3
# 
# exit
# 
# #To install the legacy kernel module flavor:
# sudo apt-get install -y cuda-drivers
# 
# #To install the open kernel module flavor:
# sudo apt-get install -y nvidia-kernel-open-545
# sudo apt-get install -y cuda-drivers-545
# 
# 
# #To switch from legacy to open:
# sudo apt-get --purge remove nvidia-kernel-source-XXX
# sudo apt-get install --verbose-versions nvidia-kernel-open-XXX
# sudo apt-get install --verbose-versions cuda-drivers-XXX
# 
# #To switch from open to legacy:
# sudo apt-get remove --purge nvidia-kernel-open-XXX
# sudo apt-get install --verbose-versions cuda-drivers-XXX

#whisper "redpillbot_-_https_-_t.co_uaAtnlrDjp-[1762968430494244864].mp4" — model large-v2 — align_model WAV2VEC2_ASR_LARGE_LV60K_960H — batch_size 4 — highlight_words True — segment_resolution chunk — max_line_width 5
#whisper "redpillbot_-_https_-_t.co_uaAtnlrDjp-[1762968430494244864].mp4" — model large-v2 — align_model WAV2VEC2_ASR_LARGE_LV60K_960H — batch_size 4 — highlight_words True — segment_resolution chunk — max_line_width 5


#whisper "redpillbot_-_https_-_t.co_uaAtnlrDjp-[1762968430494244864].mp4" --model medium --language English --task translate --highlight_words True

#whisper "redpillbot_-_https_-_t.co_uaAtnlrDjp-[1762968430494244864].mp4" \
#	--model medium --highlight_words True --word_timestamps True
# whisper "redpillbot_-_https_-_t.co_uaAtnlrDjp-[1762968430494244864].mp4" \
# 	--model large-v2 --highlight_words True --word_timestamps True

#	--align_model WAV2VEC2_ASR_LARGE_LV60K_960H --batch_size 4 --highlight_words True --segment_resolution chunk --max_line_width 5



whisper "Tom_de_Nooijer_-_De_vieze_boekjes_die_Rutgers_op_dit_moment_aanprijst_voor_kinde.-[1763213116060413952].mp4" \
	--language Dutch --model medium --highlight_words True --word_timestamps True
