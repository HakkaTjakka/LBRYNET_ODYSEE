ffmpeg -y -loop 1 -i "KID1.png" -t 00:00:05 -c:v libx264 -tune stillimage -pix_fmt yuv420p "kid1.mp4"
