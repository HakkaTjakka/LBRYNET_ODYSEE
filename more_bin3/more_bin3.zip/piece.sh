ffmpeg -y -ss 56.0 -i American_News_Anchors_-_This_is_Extremel.mp4 -ss 1 -t 2.8 -c:v h264_nvenc -pix_fmt yuv420p out.mp4
