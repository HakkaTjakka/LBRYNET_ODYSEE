VIDEO_LINK="$*"

bin/yt-dlp --list-formats --cookies cookies/cookies3.txt "$VIDEO_LINK"

VIDEO_URL=$(bin/yt-dlp --cookies ~/movies/cookies/cookies.txt -g -f 137 "$VIDEO_LINK")
echo $VIDEO_URL

AUDIO_URL=$(bin/yt-dlp --cookies ~/movies/cookies/cookies.txt -g -f "250-2" "$VIDEO_LINK")
echo $AUDIO_URL

ffmpeg -hide_banner -progress url -nostdin -i "$VIDEO_URL" -i "$AUDIO_URL" -c:v copy -c:a copy -f matroska - | ffplay -fs -i -