FILENAME="$*"

BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')

for line in $VAR.*.vtt
do
	LANGUAGE="${line%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	echo "Converting subtitle file to .srt and fixing: $line"
	echo "Converting subtitle file to .srt and fixing: $line" >> error.log
	ffmpeg -n -hide_banner -i $BASENAME.$LANGUAGE.vtt $BASENAME.$LANGUAGE.srt
#	rm -f $BASENAME.$LANGUAGE.vtt
	echo "sof/sof $BASENAME.$LANGUAGE.srt" >> COMMANDS.SH
	sof/sof $BASENAME.$LANGUAGE.srt
done
