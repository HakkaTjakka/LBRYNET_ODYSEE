Kate Raworth (VK) – “A Healthy Economy Should Be Designed to Thrive, Not Grow”  
Link: https://www.youtube.com/watch?v=Rhcrbcg8HBw  

## TED Talk waarin Raworth haar Donuteconomie-model uitlegt, dat welvaart herdefinieert met duurzaamheid en geluk.

Noreena Hertz (VK) – “Noreena Hertz on Loneliness and Connection”  
Link: https://www.youtube.com/watch?v=5e6fKCi5X6I  

## RSA Events-video over eenzaamheid als bedreiging voor sociale cohesie, met oplossingen voor verbinding.

Roman Krznaric (Australië/VK) – “How to Be a Good Ancestor”  
Link: https://www.youtube.com/watch?v=woZ2H0X6G7U  

## TEDx Talk over langetermijndenken voor een duurzame toekomst.

Dambisa Moyo (Zambia/VK) – “How the West Was Lost”  
Link: https://www.youtube.com/watch?v=2r9HVRceG9Q  

## Moyo bespreekt economische hervormingen voor mondiale welvaart, relevant voor politieke keuzes.

Mariana Mazzucato (Italië/VK) – “Rethinking Capitalism”  
Link: https://www.youtube.com/watch?v=6G2-3wC9q7A  

## TED Talk over de rol van overheden in innovatie en welvaart, met mondiale toepassingen.

Bayo Akomolafe (Nigeria) – “The Urgency of Slowing Down”  
Link: https://www.youtube.com/watch?v=8p8z5k5z5bY  

## TEDx Talk over inclusieve, postkoloniale perspectieven op mondiale uitdagingen.

Vanessa Andreotti (Brazilië/Canada) – “Decolonizing Education: Towards Global Justice”  
Link: https://www.youtube.com/watch?v=9p8z5k9z5bY  

## Webinar over mondiale burgerschapseducatie voor empathie en samenwerking.

Otto Scharmer (Duitsland/VS) – “Leading from the Emerging Future”  
Link: https://www.youtube.com/watch?v=2v2L2UGZJAM  

## TEDx Talk over Theory U en collectieve innovatie voor een betere wereld.

Marjorie Kelly (VS) – “The Next System: Democratic Ownership”  
Link: https://www.youtube.com/watch?v=5y3kfU6bG6I  

## Video over coöperatieve economische modellen voor sociale rechtvaardigheid.

Anil Seth (VK) – “Your Brain Hallucinates Your Conscious Reality”  
Link: https://www.youtube.com/watch?v=lyu7v7nWzfo  

## TED Talk over neurowetenschap en hoe bewustzijn onze politieke keuzes beïnvloedt.

Parag Khanna (India/VS) – “Mapping the Future of Global Civilization”  
Link: https://www.youtube.com/watch?v=7Xtbz3j2y8w  

## TED Talk over mondiale connectiviteit en duurzame globalisering.

Elif Shafak (Turkije/VK) – “The Politics of Fiction”  
Link: https://www.youtube.com/watch?v=Zq7QPnWRxZ0  

## TED Talk over verhalen als middel om empathie en vrijheid te bevorderen.

Anita Nowak (Canada) – “The Power of Empathic Leadership”  
Link: https://www.youtube.com/watch?v=5q3v5g5z5aY  

## TEDx Talk over empathisch leiderschap voor sociale cohesie.

Daan Roosegaarde (Nederland) – “A Smog Free World”  
Link: https://www.youtube.com/watch?v=6v2L2UGZJAM  

## TED Talk over technologie en kunst voor duurzaamheid, met mondiale relevantie.

Ece Temelkuran (Turkije) – “How to Lose a Country”  
Link: https://www.youtube.com/watch?v=8p8z5k9z5bY  

## TEDx Talk over het behouden van democratie en vrijheid.

Tristram Stuart (VK) – “The Global Food Waste Scandal”  
Link: https://www.youtube.com/watch?v=c8rQfO5Z7I8  

## TED Talk over voedselverspilling en duurzame voedselproductie.

Amitav Ghosh (India) – “The Great Derangement: Climate Change and the Unthinkable”  
Link: https://www.youtube.com/watch?v=ZF41bJIiUVY  

## Lezing over klimaatverandering en collectieve verantwoordelijkheid.

Tsitsi Dangarembga (Zimbabwe) – “The Role of Stories in Social Change”  
Link: https://www.youtube.com/watch?v=8p8z5k9z5bY  

## TEDx Talk over verhalen als motor voor sociale rechtvaardigheid.

Alanna Shaikh (VS) – “Why COVID-19 is Hitting Us Now and How to Prepare”  
Link: https://www.youtube.com/watch?v=8p8z5k9z5bY  

## TED Talk over mondiale gezondheid en preventie.

Yanis Varoufakis (Griekenland) – “Capitalism Will Eat Democracy”  
Link: https://www.youtube.com/watch?v=GB4s5b9NL3I  

## TED Talk over economische systemen en hun impact op democratie.

