#!/bin/bash

upload() {

	LANGUAGE="${FILENAME%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	
	echo LANGUAGE=$LANGUAGE
	
	FILENAME="/home/pacman/movies/out/$FILENAME"
	
	THUMBNAIL_URL="$THUMBNAIL"
	
	CHANNEL_ID="9a9e290f87160e29c4c9dbc1cbe80a811072e0a0"
	
	BID_AMT="0.001"
	
	COMMAND='lbrynet publish \
	--name="'${NAME}'" \
	--title='${TITLE}' \
	--description='${DESCRIPTION}'
	--file_path="'${FILENAME}'" \
	--tags="English" \
	--tags="Subtitles" \
	--thumbnail_url="'${THUMBNAIL_URL}'" \
	--channel_id="'${CHANNEL_ID}'" \
	--bid="'${BID_AMT}'"'
	
	echo "STR=$'\n\n'" > command3.sh
	echo "STR1=$'\n'" >> command3.sh
	echo -n "$COMMAND" >> command3.sh 

	if test -f "add_fix.txt"; then
		echo "Adding:"
		cat add_fix.txt
		cat add_fix.txt >> command3.sh
	fi
	
	chmod +x command3.sh
	
	echo UPLOADING LANGUAGE=$LANGUAGE
	sleep 1

#	echo NOT!!! UPLOADING LANGUAGE=$LANGUAGE
#	return #(remove this for executing the bash script)
	./command3.sh
	echo UPLOADED LANGUAGE=$LANGUAGE
	sleep 2
}

echo "======"

read -r THUMBNAIL < thumburl.txt
#THUMBNAIL=$(jq -r .thumbnail $2.info.json)
echo "Thumbnail=$THUMBNAIL"
echo "======"

UPLOAD_DATE=$(jq --raw-output .upload_date "$2.info.json")
UPLOAD_DATE=$(echo "$UPLOAD_DATE" | sed -E 's/(....)(..)(..)/\1\-\2\-\3/')
echo "Upload_date=$UPLOAD_DATE"

read -r TITLE < basename.txt

# TITLE=$(jq -r .title $2.info.json)
# TITLE=$(echo -n $TITLE | sed "s|\"|\\\\\\\"|g"  )
TITLE="\"(🇬🇧EN 911) "$TITLE"\""
echo "Title=$TITLE"
echo "======"

DESCRIPTION2=$(cat $2.description)
DESCRIPTION=$(jq -r .description $2.info.json; echo -n "$DESCRIPTION2")

DESCRIPTION=$(echo -n "$DESCRIPTION" | sed "s|Show more |\\n|g"  )
DESCRIPTION=$(echo -n "$DESCRIPTION" | sed "s| Show less||g"  )

DESCRIPTION=$(echo -n "$DESCRIPTION" | sed "s|\"|\\\\\\\"|g"  )

DESCRIPTION=$(echo -n "$DESCRIPTION" | sed "s|$|\"\"\$STR\"\"\\\|g"  )

#DESCRIPTION3=$(cat COMMANDS.SH) # add more
#DESCRIPTION3=$(echo -n "$DESCRIPTION3" | sed "s|\"|\\\\\\\"|g"  )
#DESCRIPTION3=$(echo -n "$DESCRIPTION3" | sed "s|\\\\$|\\\\\\\\|g"  )
#DESCRIPTION3=$(echo -n "$DESCRIPTION3" | sed "s|$|\"\"\$STR1\"\"\\\|g"  )
#DESCRIPTION=$(echo -n "$DESCRIPTION" ; echo ; echo -n "$DESCRIPTION3"  )

STR=$'\n'

DESCRIPTION="\""$DESCRIPTION""$STR"\" \\"

echo "Description=$DESCRIPTION"
echo "======"

FILENAME="$1"
NAME="${FILENAME%.*}"
echo "Name=$NAME"
NAME=$(echo $NAME | sed 's/\[//g' | sed 's/\]//g')
echo "Name=$NAME"
upload
