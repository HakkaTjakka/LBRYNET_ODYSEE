#!/bin/bash

echo -------------------------------------------------------------------------- >> error.log

echo Getting filename from URL: $*
echo Getting filename from URL: $* >> error.log

		## yt-dlp -i --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "ytsearch:$*" > filename.txt

yt-dlp -i --merge-output-format mp4 --trim-filenames 50 --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')
echo "VAR: $VAR"

#yt-dlp --restrict-filenames --abort-on-error --no-mtime --sub-lang "nl,en,de" --write-subs --convert-subs srt --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "ytsearch:$*"
#--default-search "ytsearch"
## COMMAND="yt-dlp --merge-output-format mp4 -S "height:720" --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime \
## --sub-lang "nl,en,nl-en-US,en-US" \
## --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass \"$*\" --cookies cookies/twitter.com_cookies.txt -o $FILENAME"
COMMAND="yt-dlp --sleep-subtitles 10 --merge-output-format mp4 --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime \
--sub-langs "all" \
--write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass \"$*\" --cookies cookies/twitter.com_cookies.txt -o $FILENAME"
# --sub-langs "en,ru,uk,de,fr,es,pt,nl,iw,ar,ja,zh-CN,it,tr" \

#--sub-lang "nl-en-nP7-2PuUl7o,nl-en-GB,en-GB,nl,en,nl-en-US,en-US" \
#--sub-lang "nl,en,de,fr,es,it,tr,pt,ru,uk,ar,ja,zh-CN" \

# COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "en-us,en" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

#COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "nl-id" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""
#COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "nl-en-US" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

#COMMAND="yt-dlp  --restrict-filenames --abort-on-error --no-mtime --sub-langs all --write-subs --write-auto-subs --embed-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

echo "$COMMAND" >> COMMANDS.SH
echo "$COMMAND" > command.sh
chmod +x command.sh
./command.sh

if test -f "$FILENAME"; then
	echo "DOWNLOADED: $FILENAME"
else 
	if test -f "$BASENAME.mkv"; then
		FILENAME="$BASENAME.mkv"
		echo "$BASENAME.mkv exists. Changing filename."
		echo "$FILENAME" > filename.txt
	fi
fi

if [ ! -d "subs" ]; then
	mkdir "subs"
fi	

# convert .vtt to .srt. Can also be done by yt-dlp with --convert-subs srt but only after/when downloading. So when interrupted can be continued.

ONE="1.0"

echo "" > map.txt
echo " \\" > in.txt

echo " -map 0:v:0 -map 0:a:0 \\" >> map.txt
MAP_COUNT=0
#if [ -f "in.txt" ]; then
#	rm in.txt
#fi	

echo " -i \"$FILENAME\" \\" >> in.txt

#for line in $VAR.*.vtt

find . -maxdepth 1 -type f -name "$VAR.*.vtt" -print0 | sort -z | while IFS= read -r -d '' line; # do
do
	LANGUAGE="${line%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	echo "Converting subtitle file to .srt and fixing: $line"
	echo "Converting subtitle file to .srt and fixing: $line" >> error.log
	ffmpeg -n -hide_banner -i $BASENAME.$LANGUAGE.vtt $BASENAME.$LANGUAGE.srt
#	rm -f $BASENAME.$LANGUAGE.vtt
	echo "sof/sof $BASENAME.$LANGUAGE.srt" >> COMMANDS.SH
	sof/sof $BASENAME.$LANGUAGE.srt &>> shit.txt
#	echo "Moving $BASENAME.$LANGUAGE.srt* to dir: subs/$LANGUAGE"
	if [ ! -d "subs/$BASENAME" ]; then
		mkdir "subs/$BASENAME"
	fi	

	if [ ! -d "subs/$BASENAME/$LANGUAGE" ]; then
		mkdir "subs/$BASENAME/$LANGUAGE"
	fi	
	mv "$BASENAME.$LANGUAGE.vtt" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt.single" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt.double" "subs/$BASENAME/$LANGUAGE"

     if [ "$LANGUAGE" == "he"        ];     then LANGUAGE_FULL="Hebrew" ; fi
     if [ "$LANGUAGE" == "iw"        ];     then LANGUAGE_FULL="Hebrew" ; fi
 	 if [ "$LANGUAGE" == "af"        ]; 	then LANGUAGE_FULL="Afrikaans" ; fi
     if [ "$LANGUAGE" == "he"        ]; 	then LANGUAGE_FULL="Hebrew" ; fi
     if [ "$LANGUAGE" == "pt"        ]; 	then LANGUAGE_FULL="Portuguese" ; fi
     if [ "$LANGUAGE" == "sq"        ]; 	then LANGUAGE_FULL="Albanian" ; fi
     if [ "$LANGUAGE" == "mrj"       ]; 	then LANGUAGE_FULL="Hill Mari" ; fi
     if [ "$LANGUAGE" == "pa"        ]; 	then LANGUAGE_FULL="Punjabi" ; fi
     if [ "$LANGUAGE" == "am"        ]; 	then LANGUAGE_FULL="Amharic" ; fi
     if [ "$LANGUAGE" == "hi"        ]; 	then LANGUAGE_FULL="Hindi" ; fi
     if [ "$LANGUAGE" == "otq"       ]; 	then LANGUAGE_FULL="Querétaro Otomi" ; fi
     if [ "$LANGUAGE" == "ar"        ]; 	then LANGUAGE_FULL="Arabic" ; fi
     if [ "$LANGUAGE" == "hmn"       ]; 	then LANGUAGE_FULL="Hmong" ; fi
     if [ "$LANGUAGE" == "ro"        ]; 	then LANGUAGE_FULL="Romanian" ; fi
     if [ "$LANGUAGE" == "hy"        ]; 	then LANGUAGE_FULL="Armenian" ; fi
     if [ "$LANGUAGE" == "mww"       ]; 	then LANGUAGE_FULL="Hmong Daw" ; fi
     if [ "$LANGUAGE" == "ru"        ]; 	then LANGUAGE_FULL="Russian" ; fi
     if [ "$LANGUAGE" == "az"        ]; 	then LANGUAGE_FULL="Azerbaijani" ; fi
     if [ "$LANGUAGE" == "hu"        ]; 	then LANGUAGE_FULL="Hungarian" ; fi
     if [ "$LANGUAGE" == "sm"        ]; 	then LANGUAGE_FULL="Samoan" ; fi
     if [ "$LANGUAGE" == "ba"        ]; 	then LANGUAGE_FULL="Bashkir" ; fi
     if [ "$LANGUAGE" == "is"        ]; 	then LANGUAGE_FULL="Icelandic" ; fi
     if [ "$LANGUAGE" == "gd"        ]; 	then LANGUAGE_FULL="Scots Gaelic" ; fi
     if [ "$LANGUAGE" == "eu"        ]; 	then LANGUAGE_FULL="Basque" ; fi
     if [ "$LANGUAGE" == "ig"        ]; 	then LANGUAGE_FULL="Igbo" ; fi
     if [ "$LANGUAGE" == "sr-Cyrl"   ]; 	then LANGUAGE_FULL="Serbian" ; fi
     if [ "$LANGUAGE" == "be"        ]; 	then LANGUAGE_FULL="Belarusian" ; fi
     if [ "$LANGUAGE" == "id"        ]; 	then LANGUAGE_FULL="Indonesian" ; fi
     if [ "$LANGUAGE" == "sr-Latn"   ]; 	then LANGUAGE_FULL="Serbian (Latin)" ; fi
     if [ "$LANGUAGE" == "bn"        ]; 	then LANGUAGE_FULL="Bengali" ; fi
     if [ "$LANGUAGE" == "ga"        ]; 	then LANGUAGE_FULL="Irish" ; fi
     if [ "$LANGUAGE" == "st"        ]; 	then LANGUAGE_FULL="Sesotho" ; fi
     if [ "$LANGUAGE" == "bs"        ]; 	then LANGUAGE_FULL="Bosnian" ; fi
     if [ "$LANGUAGE" == "it"        ]; 	then LANGUAGE_FULL="Italian" ; fi
     if [ "$LANGUAGE" == "sn"        ]; 	then LANGUAGE_FULL="Shona" ; fi
     if [ "$LANGUAGE" == "bg"        ]; 	then LANGUAGE_FULL="Bulgarian" ; fi
     if [ "$LANGUAGE" == "ja"        ]; 	then LANGUAGE_FULL="Japanese" ; fi
     if [ "$LANGUAGE" == "sd"        ]; 	then LANGUAGE_FULL="Sindhi" ; fi
     if [ "$LANGUAGE" == "yue"       ]; 	then LANGUAGE_FULL="Cantonese" ; fi
     if [ "$LANGUAGE" == "jv"        ]; 	then LANGUAGE_FULL="Javanese" ; fi
     if [ "$LANGUAGE" == "si"        ]; 	then LANGUAGE_FULL="Sinhala" ; fi
     if [ "$LANGUAGE" == "ca"        ]; 	then LANGUAGE_FULL="Catalan" ; fi
     if [ "$LANGUAGE" == "kn"        ]; 	then LANGUAGE_FULL="Kannada" ; fi
     if [ "$LANGUAGE" == "sk"        ]; 	then LANGUAGE_FULL="Slovak" ; fi
     if [ "$LANGUAGE" == "ceb"       ]; 	then LANGUAGE_FULL="Cebuano" ; fi
     if [ "$LANGUAGE" == "kk"        ]; 	then LANGUAGE_FULL="Kazakh" ; fi
     if [ "$LANGUAGE" == "sl"        ]; 	then LANGUAGE_FULL="Slovenian" ; fi
     if [ "$LANGUAGE" == "ny"        ]; 	then LANGUAGE_FULL="Chichewa" ; fi
     if [ "$LANGUAGE" == "km"        ]; 	then LANGUAGE_FULL="Khmer" ; fi
     if [ "$LANGUAGE" == "so"        ]; 	then LANGUAGE_FULL="Somali" ; fi
     if [ "$LANGUAGE" == "zh-CN"     ];     then LANGUAGE_FULL="Chinese Simple" ; fi
     if [ "$LANGUAGE" == "zh-Hans"   ];     then LANGUAGE_FULL="Chinese Simple" ; fi
     if [ "$LANGUAGE" == "tlh"       ]; 	then LANGUAGE_FULL="Klingon" ; fi
     if [ "$LANGUAGE" == "es"        ]; 	then LANGUAGE_FULL="Spanish" ; fi
     if [ "$LANGUAGE" == "zh-TW"     ]; 	then LANGUAGE_FULL="Chinese Tradit" ; fi
     if [ "$LANGUAGE" == "tlh-Qaak"  ]; 	then LANGUAGE_FULL="Klingon (pIqaD)" ; fi
     if [ "$LANGUAGE" == "su"        ]; 	then LANGUAGE_FULL="Sundanese" ; fi
     if [ "$LANGUAGE" == "co"        ]; 	then LANGUAGE_FULL="Corsican" ; fi
     if [ "$LANGUAGE" == "ko"        ]; 	then LANGUAGE_FULL="Korean" ; fi
     if [ "$LANGUAGE" == "sw"        ]; 	then LANGUAGE_FULL="Swahili" ; fi
     if [ "$LANGUAGE" == "hr"        ]; 	then LANGUAGE_FULL="Croatian" ; fi
     if [ "$LANGUAGE" == "ku"        ]; 	then LANGUAGE_FULL="Kurdish" ; fi
     if [ "$LANGUAGE" == "sv"        ]; 	then LANGUAGE_FULL="Swedish" ; fi
     if [ "$LANGUAGE" == "cs"        ]; 	then LANGUAGE_FULL="Czech" ; fi
     if [ "$LANGUAGE" == "ky"        ]; 	then LANGUAGE_FULL="Kyrgyz" ; fi
     if [ "$LANGUAGE" == "ty"        ]; 	then LANGUAGE_FULL="Tahitian" ; fi
     if [ "$LANGUAGE" == "da"        ]; 	then LANGUAGE_FULL="Danish" ; fi
     if [ "$LANGUAGE" == "lo"        ]; 	then LANGUAGE_FULL="Lao" ; fi
     if [ "$LANGUAGE" == "tg"        ]; 	then LANGUAGE_FULL="Tajik" ; fi
     if [ "$LANGUAGE" == "nl"        ]; 	then LANGUAGE_FULL="Dutch" ; fi
     if [ "$LANGUAGE" == "la"        ]; 	then LANGUAGE_FULL="Latin" ; fi
     if [ "$LANGUAGE" == "ta"        ]; 	then LANGUAGE_FULL="Tamil" ; fi
     if [ "$LANGUAGE" == "mhr"       ]; 	then LANGUAGE_FULL="Eastern Mari" ; fi
     if [ "$LANGUAGE" == "lv"        ]; 	then LANGUAGE_FULL="Latvian" ; fi
     if [ "$LANGUAGE" == "tt"        ]; 	then LANGUAGE_FULL="Tatar" ; fi
     if [ "$LANGUAGE" == "emj"       ]; 	then LANGUAGE_FULL="Emoji" ; fi
     if [ "$LANGUAGE" == "lt"        ]; 	then LANGUAGE_FULL="Lithuanian" ; fi
     if [ "$LANGUAGE" == "te"        ]; 	then LANGUAGE_FULL="Telugu" ; fi
     if [ "$LANGUAGE" == "en"        ]; 	then LANGUAGE_FULL="English" ; fi
     if [ "$LANGUAGE" == "lb"        ]; 	then LANGUAGE_FULL="Luxembourgish" ; fi
     if [ "$LANGUAGE" == "th"        ]; 	then LANGUAGE_FULL="Thai" ; fi
     if [ "$LANGUAGE" == "eo"        ]; 	then LANGUAGE_FULL="Esperanto" ; fi
     if [ "$LANGUAGE" == "mk"        ]; 	then LANGUAGE_FULL="Macedonian" ; fi
     if [ "$LANGUAGE" == "to"        ]; 	then LANGUAGE_FULL="Tongan" ; fi
     if [ "$LANGUAGE" == "et"        ]; 	then LANGUAGE_FULL="Estonian" ; fi
     if [ "$LANGUAGE" == "mg"        ]; 	then LANGUAGE_FULL="Malagasy" ; fi
     if [ "$LANGUAGE" == "tr"        ]; 	then LANGUAGE_FULL="Turkish" ; fi
     if [ "$LANGUAGE" == "fj"        ]; 	then LANGUAGE_FULL="Fijian" ; fi
     if [ "$LANGUAGE" == "ms"        ]; 	then LANGUAGE_FULL="Malay" ; fi
     if [ "$LANGUAGE" == "udm"       ]; 	then LANGUAGE_FULL="Udmurt" ; fi
     if [ "$LANGUAGE" == "tl"        ]; 	then LANGUAGE_FULL="Filipino" ; fi
     if [ "$LANGUAGE" == "ml"        ]; 	then LANGUAGE_FULL="Malayalam" ; fi
     if [ "$LANGUAGE" == "uk"        ]; 	then LANGUAGE_FULL="Ukrainian" ; fi
     if [ "$LANGUAGE" == "fi"        ]; 	then LANGUAGE_FULL="Finnish" ; fi
     if [ "$LANGUAGE" == "mt"        ]; 	then LANGUAGE_FULL="Maltese" ; fi
     if [ "$LANGUAGE" == "ur"        ]; 	then LANGUAGE_FULL="Urdu" ; fi
     if [ "$LANGUAGE" == "fr"        ]; 	then LANGUAGE_FULL="French" ; fi
     if [ "$LANGUAGE" == "mi"        ]; 	then LANGUAGE_FULL="Maori" ; fi
     if [ "$LANGUAGE" == "uz"        ]; 	then LANGUAGE_FULL="Uzbek" ; fi
     if [ "$LANGUAGE" == "fy"        ]; 	then LANGUAGE_FULL="Frisian" ; fi
     if [ "$LANGUAGE" == "mr"        ]; 	then LANGUAGE_FULL="Marathi" ; fi
     if [ "$LANGUAGE" == "vi"        ]; 	then LANGUAGE_FULL="Vietnamese" ; fi
     if [ "$LANGUAGE" == "gl"        ]; 	then LANGUAGE_FULL="Galician" ; fi
     if [ "$LANGUAGE" == "mn"        ]; 	then LANGUAGE_FULL="Mongolian" ; fi
     if [ "$LANGUAGE" == "cy"        ]; 	then LANGUAGE_FULL="Welsh" ; fi
     if [ "$LANGUAGE" == "ka"        ]; 	then LANGUAGE_FULL="Georgian" ; fi
     if [ "$LANGUAGE" == "my"        ]; 	then LANGUAGE_FULL="Myanmar" ; fi
     if [ "$LANGUAGE" == "xh"        ]; 	then LANGUAGE_FULL="Xhosa" ; fi
     if [ "$LANGUAGE" == "de"        ]; 	then LANGUAGE_FULL="German" ; fi
     if [ "$LANGUAGE" == "ne"        ]; 	then LANGUAGE_FULL="Nepali" ; fi
     if [ "$LANGUAGE" == "yi"        ]; 	then LANGUAGE_FULL="Yiddish" ; fi
     if [ "$LANGUAGE" == "el"        ]; 	then LANGUAGE_FULL="Greek" ; fi
     if [ "$LANGUAGE" == "no"        ]; 	then LANGUAGE_FULL="Norwegian" ; fi
     if [ "$LANGUAGE" == "yo"        ]; 	then LANGUAGE_FULL="Yoruba" ; fi
     if [ "$LANGUAGE" == "gu"        ]; 	then LANGUAGE_FULL="Gujarati" ; fi
     if [ "$LANGUAGE" == "pap"       ]; 	then LANGUAGE_FULL="Papiamento" ; fi
     if [ "$LANGUAGE" == "yua"       ]; 	then LANGUAGE_FULL="Yucatec Maya" ; fi
     if [ "$LANGUAGE" == "ht"        ]; 	then LANGUAGE_FULL="Haitian Creole" ; fi
     if [ "$LANGUAGE" == "ps"        ]; 	then LANGUAGE_FULL="Pashto" ; fi
     if [ "$LANGUAGE" == "zu"        ]; 	then LANGUAGE_FULL="Zulu" ; fi
     if [ "$LANGUAGE" == "ha"        ]; 	then LANGUAGE_FULL="Hausa" ; fi
     if [ "$LANGUAGE" == "fa"        ]; 	then LANGUAGE_FULL="Persian" ; fi
     if [ "$LANGUAGE" == "haw"       ]; 	then LANGUAGE_FULL="Hawaiian" ; fi
     if [ "$LANGUAGE" == "pl"        ]; 	then LANGUAGE_FULL="Polish" ; fi

    if [ "$LANGUAGE" == "en" ]; 	then LANGUAGE_FULL="English"; fi
    if [ "$LANGUAGE" == "es" ]; 	then LANGUAGE_FULL="Spanish"; fi
    if [ "$LANGUAGE" == "nl" ]; 	then LANGUAGE_FULL="Dutch"; fi
#nl-en-GB
#en-GB
    if [ "$LANGUAGE" == "nl-en-GB" ]; 	then LANGUAGE_FULL="Dutch"; fi
    if [ "$LANGUAGE" == "en-GB" ];     then LANGUAGE_FULL="English"; fi

    if [ "$LANGUAGE" == "fr" ]; 	then LANGUAGE_FULL="French"; fi
    if [ "$LANGUAGE" == "it" ]; 	then LANGUAGE_FULL="Italian"; fi
    if [ "$LANGUAGE" == "de" ]; 	then LANGUAGE_FULL="German"; fi
    if [ "$LANGUAGE" == "tr" ]; 	then LANGUAGE_FULL="Turkish"; fi
    if [ "$LANGUAGE" == "pt" ]; 	then LANGUAGE_FULL="Portuguese"; fi
    if [ "$LANGUAGE" == "ru" ]; 	then LANGUAGE_FULL="Russian"; fi
    if [ "$LANGUAGE" == "uk" ]; 	then LANGUAGE_FULL="Ukrainian"; fi
    if [ "$LANGUAGE" == "ar" ]; 	then LANGUAGE_FULL="Arabic"; fi
    if [ "$LANGUAGE" == "ja" ]; 	then LANGUAGE_FULL="Japanese"; fi
    if [ "$LANGUAGE" == "zh-CN" ]; 	then LANGUAGE_FULL="Chinese (Simplified)"; fi

	MAP_COUNT_NEXT=$(echo "($MAP_COUNT+$ONE)"| bc -l);  
    MAP_COUNT_NEXT="${MAP_COUNT_NEXT%.*}"
	echo -n " -map $MAP_COUNT_NEXT" >> map.txt
	echo " -metadata:s:s:$MAP_COUNT language=$LANGUAGE -metadata:s:s:$MAP_COUNT title=$LANGUAGE_FULL \\" >> map.txt
	MAP_COUNT=$MAP_COUNT_NEXT

	echo " -i \"subs/$BASENAME/$LANGUAGE/$BASENAME.$LANGUAGE.srt.double\" \\" >> in.txt
done
echo " " >> map.txt
MAP=$(cat map.txt)
IN=$(cat in.txt)

# select wanted languages
#LANG="nl"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Dutch	nl
#LANG="nl-vUrwgfI32b8";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Dutch nl
#LANG="nl-en-nP7-2PuUl7o";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Dutch nl

#LANG="zh-CN";   cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Chinese   zh-Hans
LANG="zh-Hans"; cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Chinese   zh-Hans
LANG="en";		cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# English	en
LANG="ru";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Chinese   zh-Hans
LANG="uk";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Chinese   zh-Hans
LANG="de"; 		cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# German	de
LANG="fr"; 		cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# French	fr
LANG="es";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Chinese   zh-Hans
LANG="pt";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Chinese   zh-Hans
LANG="nl";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Dutch nl
LANG="iw";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Chinese   zh-Hans
LANG="ar";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Arabic    ar
LANG="ja";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Arabic    ar
LANG="it";      cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .  # Chinese   zh-Hans
LANG="tr"; 		cp "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Turkish	tr

#--sub-langs "en,ru,uk,de,fr,es,pt,nl,iw,ar,ja,zh-CN,it,tr" \

if [ ! -d "out" ]; then
	mkdir "out"
fi	

exit

#for line in $VAR.*.srt.single
#for line in $VAR.*.srt.double
find . -maxdepth 1 -type f -name "$VAR".*.srt.double -print0 | sort -z | while IFS= read -r -d '' line; # do
do
	echo "Subtitle fixed: $line"
	echo "Subtitle fixed: $line" >> error.log
	
	LANGUAGE="${line%.*}"
	LANGUAGE="${LANGUAGE%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	echo "Language: $LANGUAGE"

	if test -f "out/$BASENAME.$LANGUAGE.mp4"; then
		echo "out/$BASENAME.$LANGUAGE.mp4 exists."
	else
		if test -f "out/DOING/$BASENAME.$LANGUAGE.mp4"; then
			echo "out/DOING/$BASENAME.$LANGUAGE.mp4 exists."
		else
			if test -f "out/DOING/DONE/$BASENAME.$LANGUAGE.mp4"; then
				echo "out/DOING/DONE/$BASENAME.$LANGUAGE.mp4 exists."
			else

#				# FONTNAME="Simply Rounded Bold"
#				FONTNAME="AdobeCorpID-MyriadBl"
#				# FONTNAME="Akkordeon-Ten"
#				# FONTNAME="BMWHelvetica-BlackCond"
#
#				FONTSIZE="28"
#				OUTLINE="1"
#				FORCE_STYLE="'Fontname=$FONTNAME,FontSize=$FONTSIZE,Outline=$OUTLINE'"
#				# echo $FORCE_STYLE
#
#				COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style=$FORCE_STYLE\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""

				# FONTNAME="Simply Rounded Bold"
				# FONTNAME="AdobeCorpID-MyriadBl"
				# FONTNAME="Akkordeon-Ten"
				#FONTNAME="BMWHelvetica-BlackCond"
                FONTNAME="CHUTEROLK Free"



#    COLOR="60900000"
#    COLOR="6060ff60"
#    OUTLINE_COLOR="00FFFFFF"

    COLOR="00FFFFFF"
    OUTLINE_COLOR="00000000"
    FONTSIZE="34"
    OUTLINE="1.2"
    BACK_COLOR="80000000"
    BORDERSTYLE="0"
    SHADOW="1.2"
    ANGLE="0.0"
    ALIGNMENT="2"

#        ALIGNMENT="6"


				FORCE_STYLE="'MarginV=20,Fontname=$FONTNAME,FontSize=$FONTSIZE,Outline=$OUTLINE,PrimaryColour=&H$COLOR,OutlineColour=&H$OUTLINE_COLOR,BackColour=&H$BACK_COLOR,Shadow=$SHADOW,Angle=$ANGLE,BorderStyle=$BORDERSTYLE,Alignment=$ALIGNMENT'"
				SUBTITLES="subtitles=f='$line':force_style=$FORCE_STYLE"

#NOSUBS
#				PARMS_OUT="-strict -2 -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy"
				PARMS_OUT="-strict -2 -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a aac -ac 2 -b:a 128k"

#				PARMS_OUT="-strict -2 -c:s mov_text -c:v copy -c:a copy"

				PARMS_IN="-y -hide_banner -progress url -nostdin"

#				MAP="-map 0:v:0 -map 0:a:0"
#				IN="-i \"$FILENAME\""

				SCALE="scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:-1:-1:color=black"
#				FILTER="-filter_complex \"[0:v]$SCALE,$SUBTITLES\""
				FILTER="-filter_complex \"[0:v]$SCALE,$SUBTITLES;[0:a]aresample=44100\""

#				SCALE="scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black"

#NOSUBS
#				FILTER="-filter_complex \"[0:v]$SUBTITLES\""

#				FILTER="-filter_complex \"[0:v]$SCALE,tblend=all_expr='if(eq(mod(X,2),mod(Y,2)),A,B)',$SUBTITLES\""
				OUT="\"out/$BASENAME.$LANGUAGE.PART.mp4\""
				echo $OUT > out.txt

				FFMPEG="ffmpeg"
				# echo $FORCE_STYLE

				COMMAND="$FFMPEG $PARMS_IN $IN$MAP$FILTER $PARMS_OUT $OUT"

				echo "$COMMAND" >> COMMANDS.SH
				echo "$COMMAND" > command.sh
				chmod +x command.sh
				./command.sh

				if [ -f out/"$BASENAME".$LANGUAGE.PART.mp4 ]; then
					COMMAND="mv \"out/$BASENAME.$LANGUAGE.PART.mp4\" \"out/$BASENAME.$LANGUAGE.mp4\""
					echo "$COMMAND" >> COMMANDS.SH
					echo "$COMMAND" > command.sh
					chmod +x command.sh
					# burn *(&'r burn
					./command.sh
				fi	
			fi
		fi
	fi
	mv "$BASENAME.$LANGUAGE.srt.double" "subs/$BASENAME/$LANGUAGE"
done


#		COMMAND="~/ffmpeg-n4.4-latest-linux64-gpl-4.4/bin/ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -i \"$line\" -map 0:v:0 -map 0:a:0 -map 1:s:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		~/nvidia/ffmpeg/ffmpeg -y -hide_banner -progress url -nostdin -i "$FILENAME" -strict -2 -filter_complex "[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -preset slow -c:a copy "out/$BASENAME.$LANGUAGE.PART.mp4"
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""

### ach	Acoli	Acoli
### af	Afrikaans	Afrikaans
### ak	Akan	Akan
### ay	Aymara	Aymara
### az	Azerbaijani	azərbaycan
### ban	Balinese	Balinese
### su	Sundanese	Basa Sunda
### bho	Bhojpuri	Bhojpuri
### ceb	Cebuano	Binisaya
### x-bork	Bork, bork, bork!	Bork, bork, bork!
### bs	Bosnian	bosanski
### br	Breton	brezhoneg
### ca	Catalan	català
### cs	Czech	Čeština
### sn	Shona	chiShona
### co	Corsican	Corsican
### cy	Welsh	Cymraeg
### da	Danish	Dansk
### de	German	Deutsch
### yo	Yoruba	Èdè Yorùbá
### et	Estonian	eesti
### en	English	English
### es	Spanish	Español
### eo	Esperanto	esperanto
### eu	Basque	euskara
### ee	Ewe	Eʋegbe
### x-elmer	Ewmew Fudd	Ewmew Fudd
### fil	Filipino	Filipino
### fo	Faroese	føroyskt
### fr	French	Français
### fy	Western Frisian	Frysk
### gaa	Ga	Ga
### ga	Irish	Gaeilge
### gd	Scottish Gaelic	Gàidhlig
### gl	Galician	galego
### gn	Guarani	Guarani
### ht	Haitian Creole	Haitian Creole
### ha	Hausa	Hausa
### hr	Croatian	Hrvatski
### haw	Hawaiian	ʻŌlelo Hawaiʻi
### bem	Bemba	Ichibemba
### ig	Igbo	Igbo
### rn	Rundi	Ikirundi
### id	Indonesian	Indonesia
### ia	Interlingua	interlingua
### xh	Xhosa	isiXhosa
### zu	Zulu	isiZulu
### is	Icelandic	íslenska
### it	Italian	Italiano
### jv	Javanese	Jawa
### rw	Kinyarwanda	Kinyarwanda
### sw	Swahili	Kiswahili
### tlh	Klingon	Klingon
### kg	Kongo	Kongo
### mfe	Morisyen	kreol morisien
### kri	Krio	Krio
### ku	Kurdish	kurdî
### la	Latin	Latin
### lv	Latvian	latviešu
### to	Tongan	lea fakatonga
### lt	Lithuanian	lietuvių
### ln	Lingala	lingála
### loz	Lozi	Lozi
### lua	Luba-Lulua	Luba-Lulua
### lg	Ganda	Luganda
### hu	Hungarian	magyar
### mg	Malagasy	Malagasy
### mt	Maltese	Malti
### ms	Malay	Melayu
### pcm	Nigerian Pidgin	Naijíriá Píjin
### nl	Dutch	Nederlands
### no	Norwegian	norsk
### nn	Norwegian Nynorsk	norsk nynorsk
### nso	Northern Sotho	Northern Sotho
### ny	Nyanja	Nyanja
### uz	Uzbek	o‘zbek
### oc	Occitan	Occitan
### om	Oromo	Oromoo
### x-pirate	Pirate	Pirate
### pl	Polish	polski
### pt	Portuguese	Português
### ro	Romanian	română
### rm	Romansh	rumantsch
### qu	Quechua	Runasimi
### nyn	Nyankole	Runyankore
### crs	Seselwa Creole French	Seselwa Creole French
### sq	Albanian	shqip
### sk	Slovak	Slovenčina
### sl	Slovenian	slovenščina
### so	Somali	Soomaali
### st	Southern Sotho	Southern Sotho
### sr-Latn	Serbian (Latin)	srpski (latinica)
### fi	Finnish	Suomi
### sv	Swedish	Svenska
### mi	Māori	te reo Māori
### vi	Vietnamese	Tiếng Việt
### tn	Tswana	Tswana
### tum	Tumbuka	Tumbuka
### tr	Turkish	Türkçe
### tk	Turkmen	türkmen dili
### wo	Wolof	Wolof
### el	Greek	Ελληνικά
### be	Belarusian	беларуская
### bg	Bulgarian	български
### ky	Kyrgyz	кыргызча
### kk	Kazakh	қазақ тілі
### mk	Macedonian	македонски
### mn	Mongolian	монгол
### ru	Russian	Русский
### sr	Serbian	српски
### tt	Tatar	татар
### tg	Tajik	тоҷикӣ
### uk	Ukrainian	Українська
### ka	Georgian	ქართული
### hy	Armenian	հայերեն
### yi	Yiddish	ייִדיש
### iw	Hebrew	עברית
### ug	Uyghur	ئۇيغۇرچە
### ur	Urdu	اردو
### ar	Arabic	العربية
### ps	Pashto	پښتو
### sd	Sindhi	سنڌي
### fa	Persian	فارسی
### ckb	Central Kurdish	کوردیی ناوەندی
### ti	Tigrinya	ትግርኛ
### am	Amharic	አማርኛ
### ne	Nepali	नेपाली
### mr	Marathi	मराठी
### sa	Sanskrit	संस्कृत भाषा
### hi	Hindi	हिन्दी
### as	Assamese	অসমীয়া
### bn	Bangla	বাংলা
### pa	Punjabi	ਪੰਜਾਬੀ
### gu	Gujarati	ગુજરાતી
### or	Odia	ଓଡ଼ିଆ
### ta	Tamil	தமிழ்
### te	Telugu	తెలుగు
### kn	Kannada	ಕನ್ನಡ
### ml	Malayalam	മലയാളം
### si	Sinhala	සිංහල
### th	Thai	ไทย
### lo	Lao	ລາວ
### my	Burmese	မြန်မာ
### km	Khmer	ខ្មែរ
### chr	Cherokee	ᏣᎳᎩ
### ko	Korean	한국어
### ja	Japanese	日本語
### zh-CN	Chinese (Simplified)	简体中文
### yue	Cantonese	粵語
### zh-TW	Chinese (Traditional)	繁體中文
