# for i in $(ffmpeg -i Nr_24_2024.mkv 2>&1 | grep 'Stream.*Subtitle' | awk -F: '{print $2}' | awk '{print $1}'); do 
#     echo "-map 0:s:$i output$i.srt"
# # ffmpeg -i Nr_24_2024.mkv -map 0:s:$i output$i.srt
# done
# exit

# mappings="`ffmpeg -i \"${filein}\" |& awk 'BEGIN { i = 1 }; /Stream.*Audio/ {gsub(/^ *Stream #/, \"-map \"); gsub(/\(.*$/, \" -acodec mp3 audio\"i\".mp3\"); print; i +=1}'`"
# ffmpeg -i "${input_file}" ${mappings}

# mappings="`ffmpeg -i \"${filein}\" |& awk 'BEGIN { i = 1 }; /Stream.*Subtitle/ {gsub(/^ *Stream #/, \"-map \"); gsub(/\(.*$/, \" -acodec mp3 audio\"i\".mp3\"); print; i +=1}'`"
# echo $mappings
# #ffmpeg -i "${input_file}" ${mappings}

function subs() {
    movie="${1}"
    filename="${1%.*}"
    mappings=`ffprobe -loglevel error -select_streams s -show_entries stream=index:stream_tags=language -of csv=p=0 "${movie}"`
    OLDIFS=$IFS
    IFS=,
    ( while read idx lang
    do
        echo "Exctracting ${lang} subtitle #${idx} from ${movie}"
        ffmpeg -nostdin -hide_banner -loglevel quiet -i "${movie}" -map 0:"$idx" "${filename}_${lang}_${idx}.srt"
    done <<< "${mappings}" )
    IFS=$OLDIFS
}

filein="Nr_24_2024.mkv"
subs "$filein"
#subs "${1}"