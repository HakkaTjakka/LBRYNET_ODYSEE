LANGUAGE="en"

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"

BASENAME="${FILENAME%.*}"

COMMAND="ffmpeg -y -hide_banner -i \"$BASENAME.srt\" \"$BASENAME.$LANGUAGE.ass\""

#echo "$COMMAND" >> COMMANDS.SH
echo "$COMMAND" > command.sh
chmod +x command.sh

./command.sh
    
cat "$BASENAME.$LANGUAGE.ass" | sed "s/{\\\u1}//g" | sed "s/,,0,0,0,,/,,0,0,0,,{\\\c\&HFFFF\&}/g" | sed "s/\u0/c\&HFFFFFF\&/g" > "$BASENAME.$LANGUAGE.ass.double"
