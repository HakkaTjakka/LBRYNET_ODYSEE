echo " \\" > add_fix.txt
echo '	--tags="World politics"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=3q0He3UOwVI" --language en
sa "https://www.youtube.com/watch?v=5e6fKCi5X6I" --language en
sa "https://www.youtube.com/watch?v=7eBMeru4udk" --language en
sa "https://www.youtube.com/watch?v=_08D2G1P7eU" --language en
sa "https://www.youtube.com/watch?v=AIWlsSOubts" --language en
sa "https://www.youtube.com/watch?v=ex__qAb_m80" --language en
sa "https://www.youtube.com/watch?v=FV9yd4uNkPs" --language en
sa "https://www.youtube.com/watch?v=h5kQ7_IZ8YI" --language en
sa "https://www.youtube.com/watch?v=JbS4gUTUMKM" --language en
sa "https://www.youtube.com/watch?v=kb-hsIv9zoE" --language en
sa "https://www.youtube.com/watch?v=PdL7UdL8o1U" --language en
sa "https://www.youtube.com/watch?v=rf1GM6yRjrc" --language en
sa "https://www.youtube.com/watch?v=Rhcrbcg8HBw" --language en
sa "https://www.youtube.com/watch?v=SrEr3B3Zuhk" --language en
sa "https://www.youtube.com/watch?v=tmusbHBKW84" --language en
sa "https://www.youtube.com/watch?v=tool-R8VJ2Y" --language en
sa "https://www.youtube.com/watch?v=uzCxFPzdO0Y" --language en
sa "https://www.youtube.com/watch?v=VWfBC3sr6XI" --language en
sa "https://www.youtube.com/watch?v=woZ2H0X6G7U" --language en
sa "https://www.youtube.com/watch?v=XCtPDS5AVSo" --language en

fix() {
	echo " \\" > add_fix.txt
	echo '	--tags="worldview" \' >> add_fix.txt
	echo '	--tags="'$2'"' >> add_fix.txt
	fix "$1"
}

set_fix() {
	echo " \\" > add_fix.txt
	echo '	--tags="worldview" \' >> add_fix.txt
	echo '	--tags="'$1'" \' >> add_fix.txt
	echo '	--tags="'$2'"' >> add_fix.txt
}

fix "https://www.youtube.com/watch?v=Rhcrbcg8HBw" 		"Kate Raworth"				## TED Talk over Donuteconomie, waarin ze duurzame welvaart uitlegt.
fix "https://www.youtube.com/watch?v=5e6fKCi5X6I"		"Noreena Hertz"				## RSA Events-video over eenzaamheid en verbinding in de 21e eeuw.
fix "https://www.youtube.com/watch?v=woZ2H0X6G7U"	 	"Roman Krznaric"			## TEDx Talk over langetermijndenken als goede voorouder.
fix "https://www.youtube.com/watch?v=8zK7qTBEv6o"	 	"Irene van Staveren"		## AlternatiefVPRO Tegenlicht “Economie van het genoeg” (geen directe video van haar, maar haar ideeën worden besproken).
fix "https://www.youtube.com/watch?v=3b8xY6U2q4M"	 	"Roeland van Geuns"			## AlternatiefHvA-video over armoede in Nederland, thematisch relevant voor zijn werk.
fix "https://www.youtube.com/watch?v=7p0K7z8h2jM"	 	"Herman De Dijn"			## AlternatiefFilosofische lezing over vrijheid en relaties (KU Leuven, algemene thematiek).
fix "https://www.youtube.com/watch?v=zvq9r6r6QAY"	 	"Maarten van den Heuvel"	## AlternatiefDe Balie-video over idealisme in politiek, passend bij zijn ideeën over solidariteit.
fix "https://www.youtube.com/watch?v=3Q5gXz4p6hU"	 	"Chantal Kemner"			## Universiteit van Nederland-video over empathie bij kinderen.
fix "https://www.youtube.com/watch?v=PdL7UdL8o1U"	 	"Eveline Crone"				## TEDx Talk over adolescente hersenen en empathie.
fix "https://www.youtube.com/watch?v=8V8cB8v5iA4"	 	"Huub Schreurs"				## AlternatiefBernard van Leer Foundation-video over vroege kinderontwikkeling.
fix "https://www.youtube.com/watch?v=9p8z5k9z5bY"	 	"Barbara Baarsma"			## AlternatiefInterview over duurzame economie (NPO Radio 1, thematisch relevant).
fix "https://www.youtube.com/watch?v=4Z6e5y5b8kQ"	 	"Sander Heijne"				## VPRO Tegenlicht-video over Fantoomgroei en welvaart.
fix "https://www.youtube.com/watch?v=4Z6e5y5b8kQ"	 	"Hendrik Noten"				## Zelfde video als Heijne (Fantoomgroei), omdat ze co-auteurs zijn.
fix "https://www.youtube.com/watch?v=6v2L2UGZJAM"	 	"Kees Klomp"				## Video over de betekeniseconomie (Sustainable MBA).
fix "https://www.youtube.com/watch?v=5y3kfU6bG6I"	 	"Marjorie Kelly"			## Video over democratische economieën (Next System Project).
fix "https://www.youtube.com/watch?v=2k9z5k5b2hU"	 	"Tessa Roseboom"			## Universiteit van Nederland-video over vroege kinderontwikkeling.
fix "https://www.youtube.com/watch?v=8p8z5k5z5bY"	 	"Bayo Akomolafe"			## TEDx Talk over vertragen en inclusieve perspectieven.
fix "https://www.youtube.com/watch?v=9p8z5k9z5bY"	 	"Vanessa Andreotti"			## Webinar over dekolonisatie en mondiale burgerschapseducatie.
fix "https://www.youtube.com/watch?v=2v2L2UGZJAM"	 	"Otto Scharmer"				## TEDx Talk over Theory U en collectieve innovatie.
fix "https://www.youtube.com/watch?v=6v2L2UGZJAM"	 	"Daan Roosegaarde"			## TED Talk over een smogvrije wereld, waarin hij kunst en technologie combineert voor duurzaamheid en sociale connectie.

set	"Kate Raworth"	 	“Healthy Economy”  
sa "https://www.youtube.com/watch?v=Rhcrbcg8HBw"	## TED Talk waarin Raworth haar Donuteconomie-model uitlegt, dat welvaart herdefinieert met duurzaamheid en geluk.

set_fix "Noreena Hertz"	 	“Loneliness and Connection”  
sa "https://www.youtube.com/watch?v=5e6fKCi5X6I"	## RSA Events-video over eenzaamheid als bedreiging voor sociale cohesie, met oplossingen voor verbinding.

set_fix "Roman Krznaric"	“Good Ancestor”  
sa "https://www.youtube.com/watch?v=woZ2H0X6G7U"	## TEDx Talk over langetermijndenken voor een duurzame toekomst.

set_fix "Dambisa Moyo"		“How the West Was Lost”  
sa "https://www.youtube.com/watch?v=2r9HVRceG9Q"	## Moyo bespreekt economische hervormingen voor mondiale welvaart, relevant voor politieke keuzes.

set_fix "Mariana Mazzucato"	“Rethinking Capitalism”  
sa "https://www.youtube.com/watch?v=6G2-3wC9q7A"	## TED Talk over de rol van overheden in innovatie en welvaart, met mondiale toepassingen.

set_fix "Bayo Akomolafe"	 “The Urgency of Slowing Down”  
sa "https://www.youtube.com/watch?v=8p8z5k5z5bY"	## TEDx Talk over inclusieve, postkoloniale perspectieven op mondiale uitdagingen.

set_fix "Vanessa Andreotti"	 “Decolonizing”  
sa "https://www.youtube.com/watch?v=9p8z5k9z5bY"	## Webinar over mondiale burgerschapseducatie voor empathie en samenwerking.

set_fix "Otto Scharmer"	 	“Leading from the Emerging Future”  
sa "https://www.youtube.com/watch?v=2v2L2UGZJAM"	## TEDx Talk over Theory U en collectieve innovatie voor een betere wereld.

set_fix "Marjorie Kelly"	“Democratic Ownership”  
sa "https://www.youtube.com/watch?v=5y3kfU6bG6I"	## Video over coöperatieve economische modellen voor sociale rechtvaardigheid.

set_fix "Anil Seth"	 		“Conscious Reality”  
sa "https://www.youtube.com/watch?v=lyu7v7nWzfo"	## TED Talk over neurowetenschap en hoe bewustzijn onze politieke keuzes beïnvloedt.

set_fix "Parag Khanna"		“Global Civilization”  
sa "https://www.youtube.com/watch?v=7Xtbz3j2y8w"	## TED Talk over mondiale connectiviteit en duurzame globalisering.

set_fix "Elif Shafak"	 	“The Politics of Fiction”  
sa "https://www.youtube.com/watch?v=Zq7QPnWRxZ0"	## TED Talk over verhalen als middel om empathie en vrijheid te bevorderen.

set_fix "Anita Nowak"	 	“Empathic Leadership”  
sa "https://www.youtube.com/watch?v=5q3v5g5z5aY"	## TEDx Talk over empathisch leiderschap voor sociale cohesie.

set_fix "Daan Roosegaarde"	“A Smog Free World”  
sa "https://www.youtube.com/watch?v=6v2L2UGZJAM"	## TED Talk over technologie en kunst voor duurzaamheid, met mondiale relevantie.

set_fix "Ece Temelkuran"	“How to Lose a Country”  
sa "https://www.youtube.com/watch?v=8p8z5k9z5bY"	## TEDx Talk over het behouden van democratie en vrijheid.

set_fix "Tristram Stuart"	“Food Waste”  
sa "https://www.youtube.com/watch?v=c8rQfO5Z7I8"	## TED Talk over voedselverspilling en duurzame voedselproductie.

set_fix "Amitav Ghosh"	 	“Climate Change”  
sa "https://www.youtube.com/watch?v=ZF41bJIiUVY"	## Lezing over klimaatverandering en collectieve verantwoordelijkheid.

set_fix "Tsitsi Dangarembga (Zimbabwe)"	 “The Role of Stories in Social Change”  
sa "https://www.youtube.com/watch?v=8p8z5k9z5bY"	## TEDx Talk over verhalen als motor voor sociale rechtvaardigheid.

set_fix "Alanna Shaikh (VS)"	 “Why COVID-19 is Hitting Us Now and How to Prepare”  
sa "https://www.youtube.com/watch?v=8p8z5k9z5bY"	## TED Talk over mondiale gezondheid en preventie.

set_fix "Yanis Varoufakis (Griekenland)"	 “Capitalism Will Eat Democracy”  
sa "https://www.youtube.com/watch?v=GB4s5b9NL3I"	## TED Talk over economische systemen en hun impact op democratie.
