#!/bin/bash

# Path to your thumbnail image
THUMB_PATH="/home/pacman/movies/out/thumbnail.jpg"  # Example path
THUMB_NAME="1st_hit_2002_thumbnail"  # A unique name for the image claim (no extension needed)

# Upload thumbnail to spee.ch via API (costs ~0.0001 LBC, adjust --form if needed)
THUMB_RESPONSE=$(curl -s -X POST \
  -F "name=${THUMB_NAME}" \
  -F "file=@${THUMB_PATH}" \
  https://spee.ch/api/claim/publish)

# Extract the thumbnail URL from JSON response (use "url" for the direct image link)
THUMB_URL=$(echo "${THUMB_RESPONSE}" | jq -r '.data.url // empty')

if [ -z "${THUMB_URL}" ]; then
  echo "Error: Thumbnail upload failed. Check response: ${THUMB_RESPONSE}"
  exit 1
fi

echo "Thumbnail uploaded: ${THUMB_URL}"

# Now your existing video publish command, with --thumbnail_url="${THUMB_URL}"
STR=$'\n\n'
STR1=$'\n'
lbrynet publish \
    --name="1st_hit_2002_cbs_version.English" \
    --title="(🇬🇧EN ) " \
    --description="===================== End of Original Description =====================""$STR""\
Video Source: 1st hit 2002 cbs version.avi""$STR""\
Translation(s) by Pacman Graphics: https://odysee.com/@PMG:5?view=channels""$STR""\
Speech Recognition & Translation (to English): Whisper, medium/turbo model""$STR""\
Or https://github.com/Aegisub/Aegisub""$STR""\
Subtitles Archive: https://drive.google.com/drive/folders/14RMVjdIla_OZ4TagWQUIDIWnb9dPcjtN""$STR""\
👊 Buy me a Coffee: Bitcoin (BTC): 14eueBv7NuDGMqv4mBWLDFmU2g76h8vkYS""$STR""\
==============================================================""$STR""\
Other Channels 👉 https://odysee.com/@TheLastBattle:3?view=channels""$STR""\
""$STR""\
Featuring: (Click the 'Playlists' tab for selections)""$STR""\
Europe: The Last Battle (2017) 👉 https://odysee.com/@TheLastBattle:3""$STR""\
English Subtitles 👉 https://odysee.com/@English_Subtitles:b""$STR""\
Actuele Video's Nederlands Ondertiteld. 👉 https://odysee.com/@Nederlands_Ondertiteld:0""$STR""\
Unheard of 👉 https://odysee.com/@Unheard:5""$STR""\
Fall of the Cabal 👉 https://odysee.com/@FalloftheCabal:0""$STR""\
(DELETED/CENSORED BY ODYSEE.COM) Vladimir Putin interview by Tucker Carlson 👉 https://odysee.com/@Putin_interview_by_Tucker_Carlson:f""$STR""\
Pacman Graphics 👉 https://odysee.com/@PMG:5""$STR""\
(🇬🇧EN) Ongehoord Nederland (English Subtitles) 👉 https://odysee.com/@Reserve3:c""$STR""\
PDF DOCUMENTS 👉 https://odysee.com/@Reserve1:8""$STR""\
==============================================================""$STR""\
" \
    --file_path="/home/pacman/movies/out/1st_hit_2002_cbs_version.English.mp4" \
    --tags="English" \
    --tags="Subtitles" \
    --thumbnail_url="${THUMB_URL}" \
    --channel_id="9a9e290f87160e29c4c9dbc1cbe80a811072e0a0" \
    --bid="0.001" \
    --tags="911"