FILENAME1="$1"
BASENAME1="${FILENAME1%.*}"

FILENAME2="$2"
BASENAME2="${FILENAME2%.*}"

# ffmpeg -y -i "$FILENAME" -vf "fps=11,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse"   "$BASENAME.gif"

DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$FILENAME1")
echo "DURATION1=$DURATION"

read -d " " XX YY 	<<< $(ffprobe -v error -show_entries stream=width,height -of default=noprint_wrappers=1:nokey=1 "$FILENAME2")
XX2=$((XX/2))
YY2=$((YY/2))
SCALE2="$XX2:$YY2"
echo "SCALE2=$SCALE2"

read FPS1			<<< $(ffprobe -v error -select_streams v -of default=noprint_wrappers=1:nokey=1 -show_entries stream=r_frame_rate "$FILENAME1")
echo "FPS1=$FPS1"


ffmpeg -y \
	-i "$FILENAME1" \
	-stream_loop -1 -i "$FILENAME2" \
	-filter_complex "[0:v]fps=$FPS1[v0];
	[1:v]scale=$SCALE2,fps=$FPS1[v1];
	[0:a]aresample=44100,volume=1.0[aa]; \
	[v0][v1]overlay=x='40':y='40'[vv]" \
	-map "[vv]" -map "[aa]" \
	-t $DURATION \
	-c:v h264_nvenc -pix_fmt yuv420p \
	"$BASENAME1.blend.mp4"
#	[1:v]scale=300:-1,fps=30[v1];

#	-filter_complex '[1:v][0:v]scale2ref[ckout][vid];[vid][ckout]blend=all_mode='multiply'[out]' \


#ffmpeg -i input.mov -i overlay.mov \
#-filter_complex "[1:v]setpts=PTS-10/TB[a]; \
#                 [0:v][a]overlay=enable=gte(t\,5):shortest=1[out]" \
#-map [out] -map 0:a \
#-c:v libx264 -crf 18 -pix_fmt yuv420p \
#-c:a copy \
#output.mov