#!/bin/bash

FILENAME_VIDEO=$1
FILENAME_AUDIO=$2
FILENAME_MUSIC=$3
#FILENAME="simplescreenrecorder-2023-02-17_08.52.56.mp4"
BASENAME="${FILENAME_VIDEO%.*}"

DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$FILENAME_AUDIO")
echo "DURATION=$DURATION"

#RATE=$(ffprobe -v error -show_entries stream=sample_rate -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
#echo $RATE 

#ffmpeg -hide_banner -i "lach1.m4a" -filter_complex "[0:a]aresample=$RATE[a]" -map "[a]" -c:a aac -ac 2 -b:a 128k "lach1.aac"
#ffmpeg -hide_banner -i "audience-laughing-6323.mp3" -t 15 -filter_complex "[0:a]aresample=$RATE[a]" -map "[a]" -c:a aac -ac 2 -b:a 128k "lach1.aac"


# ffmpeg -y -i "$FILENAME" -itsoffset 00:00:30 -i lach1.m4a -map 0:0 -map 1:0 -c:v copy -preset slow -async 1 $BASENAME.added.mp4
# ffmpeg -y -i "$FILENAME" -itsoffset 00:00:30 -i lach1.aac -filter_complex \
# 	"[0:a][1:a]amerge[a]" \
# 	-map 0:0 -map "[a]" \
# 	-c:v copy -preset slow -async 1 $BASENAME.added.mp4
#exit

ffmpeg -y -hide_banner \
	-ss 0 -i "$FILENAME_VIDEO" \
	-ss 0 -i "$FILENAME_AUDIO" \
	-ss 0 -i "$FILENAME_MUSIC" \
	-t $DURATION \
 	-filter_complex \
 	" \
 	[1:a]volume=2.0[1a]; \
 	[2:a]volume=0.5,atrim=start=120,asetpts=PTS-STARTPTS[2a]; \
 	[1a][2a]amix=inputs=2:duration=longest[a];
 	[0:v]trim=start=0,setpts=PTS-STARTPTS[v]
 	" \
 	-map [v] -map "[a]" \
	-c:v h264_nvenc -pix_fmt yuv420p -c:a aac -ac 2 -b:a 128k -b:v 10M -async 1 $BASENAME.sound.mp4	

#	[0:a]atrim=start=500,asetpts=PTS-STARTPTS[0a]

# [0:v]trim=start=30,setpts=PTS-STARTPTS[v];
# [0:a]atrim=start=30,asetpts=PTS-STARTPTS[a]" -map "[v]" -map "[a]" output.mp4
# 	-map 0:0 -map "[a]" \

##	-map 0:v:0 -map 1:a:0 \



## ffmpeg -y -hide_banner \
## 	-ss 00:15:17 -i "$FILENAME" \
## 	-itsoffset 00:00:13 -i "lach1.aac" \
## 	-itsoffset 00:00:20.5 -i "lach1.m4a" \
## 	-t 25 \
## 	-filter_complex \
## 	" \
## 	[0:a]volume=3.0[0a];
## 	[1:a]volume=1.1[1a];
## 	[2:a]volume=1.1[2a];
## 	[0a][1a][2a]amix=inputs=3:duration=longest[a]" \
## 	-map 0:0 -map "[a]" \
## 	-c:v copy -preset slow -async 1 $BASENAME.added.mp4

#aresample=async=1:min_hard_comp=0.100000:first_pts=0
#ffmpeg -i input0.mp3 -i input1.mp3 -filter_complex amix=inputs=2:duration=longest output.mp3
#ffmpeg -i sv.en.mp4 -i mst1.mp4 -filter_complex \
#"[1]scale=iw/4:ih/4 [pip]; [0][pip] overlay=main_w-overlay_w-10:main_h-overlay_h-10[v];[0:a][1:a]amerge[a]" -map "[v]" -map "[a]" -ac 2 -ar 44100 -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -b:v 10M -bufsize 20M -bf:v 3 -preset slow -rc:v vbr_hq -rc-lookahead 32 -acodec aac outstream.mp4
