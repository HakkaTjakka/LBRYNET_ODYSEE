#!/bin/bash

export LC_NUMERIC="en_US.UTF-8"

round() {
  printf "%.${2}f" "${1}"
}

echo $0 $1
# BASENAME="${0%.*}"
# echo BASENAME=$BASENAME
# exit

if [ "$1" == "" ]; then
	NEXT=1
else
	NEXT=$(echo "($1+1)"| bc -l)
fi
echo NEXT="$NEXT"
echo "$0 $NEXT" > "command.sh"
chmod +x "command.sh"
command.sh &
echo ENDING $1



#	echo "$COMMAND" > command.sh
#	chmod +x command.sh
#	./command.sh
