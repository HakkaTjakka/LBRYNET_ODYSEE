youtube-dl $* --cookies facebook.com_cookies.txt --restrict-filenames --merge-output-format mp4 --audio-format aac
