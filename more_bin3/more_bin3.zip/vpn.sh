yt-dlp -i "$1" \
	--merge-output-format mp4 \
	--restrict-filenames \
	--skip-unavailable-fragments \
	--geo-bypass \
	--cookies cookies/opera_vpn_cookies.txt
