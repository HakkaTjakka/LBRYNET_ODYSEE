in="$1"
out="$2"
splits=""
while read start end title; do
  splits="$splits -c copy -ss $start -to $end $out/$title.m4b"
done <<<$(ffprobe -i "$in" -print_format json -show_chapters \
  | jq -r '.chapters[] | .start_time + " " + .end_time + " " + (.tags.title | sub(" "; "_"))')

echo $splits

echo "ffmpeg -i "$in" "$splits > hoppa.txt
