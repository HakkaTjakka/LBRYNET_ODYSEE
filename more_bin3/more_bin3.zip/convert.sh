#!/bin/bash

# ffmpeg -y -i "$*" -acodec pcm_s16le -ac 1 -ar 16000 "$*.wav"

python3 ./test_srt.py "$*"


# ffmpeg -i "President_Biden_is_a_dead_man_walking-[cuhVW2Pf7nk].webp" -acodec pcm_s16le -ac 1 -ar 16000 "President_Biden_is_a_dead_man_walking-[cuhVW2Pf7nk].webp.wav"


