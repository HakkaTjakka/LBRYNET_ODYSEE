#lbrynet claim search --channel="@english_subtitles" --claim_type="stream" --any_tags="blue tiger studio" > bts.json
#lbrynet claim search --any_tags="tiger" > bts.json

lbrynet claim search --channel="@english_subtitles#b" --claim_type="stream" --any_tags="blue tiger studio" > bts.json

#lbrynet claim search --channel_ids="bVUmvi9nzZnpYGxCur64EMyyNDxjHmhvjF" --claim_type="stream" --any_tags="blue tiger studio" > bts.json

#bVUmvi9nzZnpYGxCur64EMyyNDxjHmhvjF
#jq .items.[].claim_id,.items.[].name bts.sh -c

jq "pick(.items.[] | .claim_id,.name)" bts.json
