yt-dlp $* --cookies cookies/facebook.com_cookies.txt --restrict-filenames --trim-filenames 100 --merge-output-format mp4
