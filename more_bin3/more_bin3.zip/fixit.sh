#!/bin/bash

echo Getting filename from URL: $*

yt-dlp -i --write-thumbnail --merge-output-format mp4 --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies ../cookies/twitter.com_cookies.txt > filename.txt
read -r FILENAME < filename.txt
echo "Filename: $FILENAME"

yt-dlp "$*" --restrict-filenames --list-thumbnails --cookies ../cookies/twitter.com_cookies.txt > thumbnails.txt

BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')

~/movies/bin/to_odysee.sh "$BASENAME.Dutch.mp4" "$BASENAME"
~/movies/bin/english_to_odysee.sh "$BASENAME.English.mp4" "$BASENAME"


