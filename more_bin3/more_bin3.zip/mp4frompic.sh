#!/bin/bash

round() {
  printf "%.${2}f" "${1}"
}

if [ ! -d "png" ]; then
  mkdir "png"
fi  

FILENAME="$*"
BASENAME="${FILENAME%.*}"
FRAMERATE=$(ffprobe -v 0 -of csv=p=0 -select_streams v:0 -show_entries stream=r_frame_rate "$FILENAME")
BITRATE=$(ffprobe -v quiet -select_streams v:0 -show_entries stream=bit_rate -of default=noprint_wrappers=1:nokey=1 "$FILENAME")

# echo FRAMERATE=$FRAMERATE
# echo BITRATE=$BITRATE

#exit

# ffmpeg -i "$FILENAME" "png/%04d.png"
# ffmpeg -framerate "$FRAMERATE" -pattern_type glob -i 'png/*.png' -c:v h264_nvenc -pix_fmt yuv420p -preset slow -b:v $BITRATE "$BASENAME.new.mp4"
#
do_make() {

for i in {0000..0499..2}
do
  random=$((40 + RANDOM % 500))
  #echo $random
  #echo $i
  count=$(echo $i | bc -l)
  #echo $count
  if (( $random < $count )); then
    #echo cp png/h.png png/$i.png
    random=$((1 + RANDOM % 2))
    if (( $random == 1 )); then
      #echo cp png/h.png png/$i.png
      cp png/h.png png/$i.png
    else 
      #echo cp png/s.png png/$i.png
      cp png/s.png png/$i.png
    fi
  else
    #echo cp png/k.png png/$i.png
    cp png/k.png png/$i.png
  fi
done

for i in {0500..0999..2}
do
  random=$((40 + RANDOM % 500))
  #echo $random
  #echo $i
  count=$(echo $i | bc -l)
  count="$((count-500))"
  #echo $count
  if (( $random > $count )); then
    #echo cp png/h.png png/$i.png
    random=$((1 + RANDOM % 2))
    if (( $random == 1 )); then
      #echo cp png/h.png png/$i.png
      cp png/h.png png/$i.png
    else 
      #echo cp png/s.png png/$i.png
      cp png/s.png png/$i.png
    fi
  else
    #echo cp png/k.png png/$i.png
    cp png/k.png png/$i.png
  fi
done
}

#exit
#do_make()

ffmpeg -y -framerate "30" -pattern_type glob -i 'png/0*.png' -c:v h264_nvenc -pix_fmt yuv420p -preset slow -b:v 2M "$BASENAME.new.mp4"
#ffmpeg -y -i "$BASENAME.new.mp4" -vf "fps=15,scale=400:-1:sws_dither=none:flags=lanczos[q];[q]split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse" "$BASENAME.new.gif"

#mp42gif.sh "$BASENAME.new"