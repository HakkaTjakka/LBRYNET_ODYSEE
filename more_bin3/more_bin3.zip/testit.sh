#!/bin/bash

#TRANSLATOR="en-us-0.42-gigaspeech"
TRANSLATOR="English"
LANGUAGE="en"
FILENAME="CS_-_Dr._Byrne_-_hersendood_is_een_uitvi.-[1759667998170718209].mp4"

BASENAME="${FILENAME%.*}"
#VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')

#COMMAND="vosk-transcriber -l $TRANSLATOR -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""
COMMAND="vosk-transcriber -l $TRANSLATOR -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""

if test -f "execute.sh"; then
	rm execute.sh
fi
echo "$COMMAND" > execute.sh
chmod +x execute.sh
./command.sh
