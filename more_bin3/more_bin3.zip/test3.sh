FILENAME=$*
BASENAME="${FILENAME%.*}"
#BASENAME="Peace_War_and_9_11-[v3e6pkc]"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')
mkdir "$BASENAME"
find -maxdepth 1 -type f -name "$VAR*" -exec mv {} "$BASENAME" ';'
