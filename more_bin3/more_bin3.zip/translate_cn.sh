#!/bin/bash

FILENAME=$*
BASENAME="${FILENAME%.*}"

LANGUAGE="${FILENAME%.*}"
LANGUAGE="${LANGUAGE%.*}"
BASENAME2="${LANGUAGE%.*}"
LANGUAGE="${LANGUAGE##*.}"
echo $LANGUAGE


echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"

while IFS='' read -r line || [[ -n "$line" ]]; do
 
#    if [[ $line = [\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uff66-\uff9f] ]] ; then
#    if [[ $line =~ [a-z] ]] ; then

        VAR=$(echo "$line" | trans -brief zh-CN:nl)
        echo $line
        echo translate $VAR
        echo $VAR >> "$BASENAME2.nl.srt.double"

        VAR=$(echo "$line" | trans -brief zh-CN:en)
        echo $line
        echo translate $VAR
        echo $VAR >> "$BASENAME2.en.srt.double"

        #echo translate
        #echo "$line" | trans -brief $LANGUAGE:en >> "$BASENAME2.en.srt.double"
#    else
#        echo no translate $line
#       echo no translate
#        echo $line >> "$BASENAME2.nl.srt.double"
#    fi
done < "$1"

#trans [OPTIONS] [SOURCES]:[TARGETS] [TEXT]...
