#!/bin/bash

# ffplay -f pulse -ac 2 -i default

FROM="nl"
TO="pl"

rm back.txt > /dev/null 2>&1

echo ------------------------
ffmpeg -y -hide_banner -progress url -nostdin -f pulse -ac 2 -i default input.mp3
vosk-transcriber -l $FROM -i input.mp3 -t txt -o "output.txt" > /dev/null 2>&1
while IFS='' read -r line || [[ -n "$line" ]]; do
	VAR=$(echo "$line" | trans -brief $FROM:$TO -download-audio-as output.mp3 )
    echo $line
    echo $VAR
    echo $VAR >> back.txt
	cvlc --play-and-exit output.mp3 > /dev/null 2>&1
	echo ------------------------
done < "output.txt"

# while IFS='' read -r line || [[ -n "$line" ]]; do
# 	VAR=$(echo "$line" | trans -brief $TO:$FROM -download-audio-as output.mp3 )
#     echo $line
#     echo $VAR
# 	cvlc --play-and-exit output.mp3 > /dev/null 2>&1
# 	echo ------------------------
# done < "back.txt"

### VAR=$(cat "output.txt" | trans -brief $FROM:$TO -download-audio-as output.mp3)
### echo $VAR
### cvlc --play-and-exit output.mp3
### 







#ffmpeg -y -f pulse -ac 2 -i default -f wav pipe: | ffplay -f wav -i pipe:

# ffmpeg -y -f pulse -ac 2 -i default -f wav pipe: | vosk-transcriber -l nl -t txt -o "output.txt"

#ffmpeg -i file.mp3  -c:a pcm_s16le -f s16le pipe: | ffmpeg -f mp3 -i pipe: -c:a pcm_s16le -f s16le encoded.mp3

#-download-audio-as FILENAME


# vosk-transcriber -l en -i output.mp3 -t txt -o "reversed.txt"
# VAR=$(cat "reversed.txt" | trans -brief en:nl -download-audio-as reversed.mp3)
# echo $VAR
# cvlc --play-and-exit reversed.mp3



#cat ikke.txt | trans -brief nl:pl -player vlc

# pactl list sources 

# sudo docker run -it -p 2700:2700 alphacep/kaldi-en:latest /bin/bash

#ffmpeg -f pulse -ac 2 -i default -f wav pipe:1 | vosk-transcriber -l nl 

#	COMMAND="vosk-transcriber -l $LANGUAGE -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""
#	COMMAND="vosk-transcriber -l $LANGUAGE -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""

#### ffmpeg -f alsa -i hw:0 -f video4linux2 -i /dev/video0 hoppa.mp4
#### 
#### ffplay  -ac 2 -i default -f v4l2 -i /dev/video0
#### 
#### ffplay  -f v4l2 -i /dev/video0
#### 
#### ffplay -f pulse -i /dev/audio0 -ac 2  -f video4linux2 -i /dev/video0
#### ffmpeg -y -f alsa -i default -f v4l2 -i /dev/video0 -acodec aac -strict -2 -ac 1 -b:a 64k -vcodec libx264 -b:v 300k -r 30 -g 30 prueba1.mp4
#### 
#### 
#### 
#### ffplay -f pulse -ac 2 -i default
#### 
#### ffplay -f video4linux2 -i /dev/video0 
#### 
#### 
#### 
#### ffmpeg -f alsa -ac 2 -i hw:1,0 -f video4linux2 -i /dev/video0 -acodec ac3 -ab 128k -f matroska -s 1280x720 -vcodec libx264 -preset ultrafast -qp 16 testsize.mkv
#### 
#### ffplay -f video4linux2 -i /dev/video0
#### 
#### ffmpeg -f video4linux2 -i /dev/video0 -vcodec libx264 -preset ultrafast hoppa.mp4