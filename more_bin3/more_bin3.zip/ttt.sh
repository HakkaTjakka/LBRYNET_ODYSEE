whisper "$1" --task translate --model medium --language nl 

