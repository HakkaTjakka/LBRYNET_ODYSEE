#!/bin/bash
# Usage: ./cut_video.sh input.mp4 00:01:23 00:02:34
# Cuts from start_time to end_time and re-encodes video/audio/subtitles with h264_nvenc

if [ "$#" -ne 3 ]; then
    echo "Usage: $0 <inputfile> <start_time> <end_time>"
    echo "Example: $0 video.mp4 00:01:00 00:02:30"
    exit 1
fi

INPUT="$1"
START="$2"
END="$3"

# Get filename without extension
BASENAME="$(basename "$INPUT")"
NAME="${BASENAME%.*}"
EXT="${BASENAME##*.}"

# Calculate duration in seconds
DURATION=$(ffmpeg -nostdin -hide_banner -v error -ss "$START" -to "$END" -i "$INPUT" -map 0 -f null - 2>&1 | \
           grep "time=" | tail -n1 | sed -E 's/.*time=([0-9:.]+).*/\1/' || true)

if [ -z "$DURATION" ]; then
    # fallback to direct math (using ffprobe)
    DURATION=$(ffprobe -v error -show_entries format=duration \
               -of default=noprint_wrappers=1:nokey=1 "$INPUT")
    DURATION=$(awk -v s="$START" -v e="$END" 'BEGIN {
        split(s, a, ":"); split(e, b, ":");
        st = a[1]*3600 + a[2]*60 + a[3];
        et = b[1]*3600 + b[2]*60 + b[3];
        print et - st
    }')
fi

OUTPUT="${NAME}_${START//:/-}_${END//:/-}.${EXT}"

echo "Cutting from $START to $END ($DURATION s) ..."
echo "Output: $OUTPUT"

# Perform the cut and re-encode
# -c:v h264_nvenc
# -b:a 192k \
ffmpeg -y -ss "$START" -to "$END" -i "$INPUT" \
  -map 0 \
  -c:v h264_nvenc -preset p7 -rc:v vbr -cq:v 19 \
  -c:a aac \
  -c:s copy \
  "$OUTPUT"

echo "Done."
