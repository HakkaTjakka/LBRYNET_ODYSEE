#!/bin/bash

FILENAME=$*
BASENAME="${FILENAME%.*}"

LANGUAGE="${FILENAME%.*}"
LANGUAGE="${LANGUAGE%.*}"
BASENAME2="${LANGUAGE%.*}"
LANGUAGE="${LANGUAGE##*.}"
echo $LANGUAGE

#exit
#LANGUAGE="en"

echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"

VAR=$(cat "$1" | trans -brief $LANGUAGE:nl)

#echo $line
echo $VAR
echo $VAR >> "$BASENAME2.nl.srt.double"

### while IFS='' read -r line || [[ -n "$line" ]]; do
###     if [[ $line =~ [a-z] ]] ; then
### 
###         VAR=$(echo "$line" | trans -brief $LANGUAGE:nl)
###         echo $line
###         echo $VAR
###         echo $VAR >> "$BASENAME2.nl.srt.double"
### 
### 
### #    echo translate
### #    echo "$line" | trans -brief $LANGUAGE:nl >> "$BASENAME2.nl.srt.double"
###     else
###         echo $line
### #        echo no translate
###        echo $line >> "$BASENAME2.nl.srt.double"
###     fi
### done < "$1"

#trans [OPTIONS] [SOURCES]:[TARGETS] [TEXT]...