#!/bin/bash

round() {
  printf "%.${2}f" "${1}"
}

FILENAME=$1
echo FILENAME=$FILENAME
BASENAME="${FILENAME%.*}"


#BIT_RATE=$(ffprobe -v error -show_entries format=bit_rate -of default=noprint_wrappers=1:nokey=1 "fucked.mp4") 

BIT_RATE=$(ffprobe -v error -show_entries format=bit_rate -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
echo BIT_RATE=$BIT_RATE

FILELENGTH=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
RATE=$(ffprobe -v error -show_entries stream=sample_rate -of default=noprint_wrappers=1:nokey=1 "$FILENAME")

PITCH="$2"
SPEED=1.0
ATEMPO=$(echo "(1.0/($SPEED/$PITCH))"| bc -l)
ATEMPO=$(round ${ATEMPO} 2)
ASETRATE=$(echo "($RATE/$PITCH)"| bc -l)
ASETRATE=$(round ${ASETRATE} 0)

L=$(echo "($FILELENGTH * $SPEED)"| bc -l)
L=$(round ${L} 2)

echo $FILELENGTH
echo $L
echo $FILENAME
echo $BASENAME
echo $RATE
echo $SPEED
echo $ATEMPO
echo $ASETRATE
### 
###  ffmpeg -hide_banner -i "$FILENAME" -filter_complex " \
###  	[0:v] scale=1280:720:force_original_aspect_ratio=decrease, \
###  	pad=1280:720:-1:-1:color=black, \
###  	setpts=$SPEED*PTS, \
###  	fps=fps=60[v]; \
###  	[0:a] asetrate=$ASETRATE, \
###  	aresample=44100, \
###  	atempo=$ATEMPO[a]
###  	" \
###  	-map "[v]" -map "[a]" -c:v h264_nvenc -pix_fmt yuv420p -preset slow -c:a aac -ac 2 -b:a 128k -b:v 4000k "$BASENAME.TWITTER.MP4"
### 
	setpts=$SPEED*PTS,fps=50[v]; \
ffmpeg -hide_banner -i "$FILENAME" \
	-filter_complex " \
	[0:v] \
	setpts=$SPEED*PTS[v]; \
	[0:a]atempo=$ATEMPO,asetpts=PTS[a] \
	" \
	-map "[a]" \
	-map "[v]" -c:v h264_nvenc -pix_fmt yuv420p "$BASENAME.TWITTER.mp4"
#	-t $L \

#	fps=fps=60[v]; \

#ffmpeg -hwaccel cuda -hide_banner -i "$FILENAME" -filter_complex " \
#	[0:v] scale=1280:720:force_original_aspect_ratio=decrease, \
#	pad=1280:720:-1:-1:color=black, \
#	setpts=$SPEED*PTS, \
#	fps=fps=60[v1]; \
#	[0:a] asetrate=$ASETRATE, \
#	aresample=44100, \
#	atempo=$ATEMPO[a1];
#	[v1]setpts=$SPEED*PTS[v]; \
#	[a1]atempo=$ATEMPO[a] \
#	" \
#	-map "[v]" -map "[a]" -c:v h264_nvenc -pix_fmt yuv420p -preset slow -c:a aac -ac 2 -b:a 128k -b:v 4000k "$BASENAME.TWITTER.MP4"

