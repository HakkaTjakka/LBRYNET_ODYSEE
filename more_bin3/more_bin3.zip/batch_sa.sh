
# batch_san "https://rumble.com/v4ktf2q-march-22-2024.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4ma2si-bombshell-rki-files-liggen-op-straat.-je-hebt-de-tijd-voor-de-rki-files-en-.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4cf0gf-weekoverzicht-06-2024.html?e9s=src_v1_upp"
# exit
# batch_san "https://rumble.com/v4dszj3-weekoverzicht-07-2024.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4f7j6l-weekoverzicht-08-2024.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4gluer-weekoverzicht-9-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4hzk43-wo-10.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4jf1z9-weekoverzicht-11-2024-jeroen-pols-en-willem-engel.html?e9s=src_v1_upp"

# batch_san "https://rumble.com/v4mfsk0-weekoverzicht-13-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4nljd9-weekoverzicht-14-2024.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4p1p1x-weekoverzicht-15-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4qd1pf-weekoverzicht-16-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"

# batch_san "https://rumble.com/v4rouux-weekoverzicht-17.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4t0ga0-weekoverzicht-18-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4uaat0-weekoverzicht-19-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"

# batch_sae "https://x.com/MTGrepp/status/1829998820731863070"
# batch_sae "https://x.com/its_The_Dr/status/1830045903912161629"
# batch_san "https://youtu.be/yhRGniGW-Ng"
# batch_san "https://youtu.be/-Lp8HuG_zhk"
# batch_sae "https://x.com/Wordsarewordz/status/1813672918557315450"
# exit

# batch_san "https://rumble.com/v4vrmbb-weekoverzicht-20-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"

# batch_sae "https://rumble.com/v3gs3u0-peace-war-and-911.html"

# batch_san "https://rumble.com/v4x5ms6-weekoverzicht-21-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v4yo2zw-weekoverzicht-22-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v5062p6-weekoverzicht-23-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v51qoeq-weekoverzicht-24-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v52wv7e-weekoverzicht-25-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v54bpui-weekoverzicht-26-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v55poaa-weekoverzicht-27-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v56naph-weekoverzicht-28-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v57kqp9-weekoverzicht-29-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v58jeh1-weekoverzicht-30-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v59fps5-weekoverzicht-31-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v5aau3x-weekoverzicht-32-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v5b58el-weekoverzicht-33-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v5c2b3o-weekoverzicht-33-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
# batch_san "https://rumble.com/v5cye0y-weekoverzicht-35-2024-willem-engel-en-jeroen-pols.html?e9s=src_v1_upp"
#!/bin/bash

# 91e90fa08647c561	7b081cc97cb81cd7
# 7425529e120ee998	a3ab89ba37d5fcfd
# 2159d601093191ea	5bf51ee3672cb39d
# d32b536071e2c130	2c84d001fd62a8cc
# 1c8da2832bfc9626	7ffe6adeab2ae74d

# batch_san "https://www.youtube.com/watch?v=5mNobbIi9uc"
# batch_san "https://www.youtube.com/watch?v=oBYlEmyf4po"
# batch_san "https://www.youtube.com/watch?v=SMZkXwPjLgE"
# batch_san "https://www.youtube.com/watch?v=6gbyKOOzLdA"
# batch_san "https://www.youtube.com/watch?v=44NyQNBWyG4"
# batch_san "https://www.youtube.com/watch?v=ikEt_FiAi4I"
# 	batch_sae "https://www.youtube.com/watch?v=8uNgfFwbziU"
# 	batch_sae "https://www.youtube.com/watch?v=7y9M_Wle2hE"
# batch_san "https://www.youtube.com/watch?v=tWxh2oS7Ays"
# batch_san "https://www.youtube.com/watch?v=h5bYjbeZsl0"
# 	batch_sae "https://www.youtube.com/watch?v=AdUNz3x3re0"
# batch_san "https://www.youtube.com/watch?v=CfKjFAFB1eM"
# batch_sa "https://www.youtube.com/watch?v=lfFjJf_4jW8"

#  batch_sa "https://www.youtube.com/watch?v=AIGGpTP1zPs"
#  batch_sa "https://www.youtube.com/watch?v=oSsjH0zWKe8"

### batch_sa "https://www.youtube.com/watch?v=t4EJQPWjFj8"
### batch_sa "https://www.youtube.com/watch?v=GqoqUs_Z-_4"
### batch_sa "https://www.youtube.com/watch?v=opkS85cxZ8E"
### batch_sa "https://www.youtube.com/watch?v=awuFYqq4z_o"
### batch_sa "https://www.youtube.com/watch?v=zY_0jdFBhBA"
### batch_sa "https://www.youtube.com/watch?v=kxonyXZew5o"
### batch_sa "https://www.youtube.com/watch?v=-v6wTuJFmPY"
### batch_sa "https://www.youtube.com/watch?v=bbH13sBHvDI"
### batch_sa "https://www.youtube.com/watch?v=tOkrujW8s_g"
### batch_sa "https://www.youtube.com/watch?v=SknnBjwRsvw"
### batch_sa "https://www.youtube.com/watch?v=5REii_WxWfM"

# batch_sa "https://x.com/KimKimetje/status/1831335224091058581"
# batch_sa "https://x.com/VanEmmerickKris/status/1831196360818770251"
# batch_sa "https://x.com/fvdemocratie/status/1831345665944744422"
# batch_sa "https://www.youtube.com/watch?v=DuidG6hNCrk"
# exit

# batch_sa "https://www.youtube.com/watch?v=8KVzm6QoyL8"
# batch_sa "https://www.youtube.com/watch?v=1VR7gHcvXN8"
# batch_sa "https://www.youtube.com/watch?v=1nOoKtawa68"
# batch_sa "https://www.youtube.com/watch?v=bA4a1rT9U2k"
# batch_sa "https://www.youtube.com/watch?v=KnuNNox2gf0"
# batch_sa "https://www.youtube.com/watch?v=-7jKTrxE3mA"
# batch_sa "https://www.youtube.com/watch?v=taVuGG0dmjA"
# batch_sa "https://www.youtube.com/watch?v=PDPez9qc0uE"
# batch_sa "https://www.youtube.com/watch?v=ImI7OoyBLJo"
# batch_sa "https://www.youtube.com/watch?v=pqyqkafRGbg"
# batch_sa "https://www.youtube.com/watch?v=S93WkXQK8b4"
# batch_sa "https://www.youtube.com/watch?v=iocmYFapOAo"
# batch_sa "https://www.youtube.com/watch?v=-CbUKYb0VnM"
# batch_sa "https://www.youtube.com/watch?v=4HLAWZXuFM8"
# batch_sa "https://www.youtube.com/watch?v=fp-NMGB9KTc"
# batch_sa "https://www.youtube.com/watch?v=w9qBpy62Ivc"
# batch_sa "https://www.youtube.com/watch?v=C78xyhERm1o"
# batch_sa "https://www.youtube.com/watch?v=L0drHqG9sao"
# batch_sa "https://www.youtube.com/watch?v=yYmc1ocJYO8"
# batch_sa "https://www.youtube.com/watch?v=CJfN3kOYjaY"
# batch_sa "https://www.youtube.com/watch?v=M1IMjzmsrdw"
# batch_sa "https://www.youtube.com/watch?v=8c5BauKdZGg"
# batch_sa "https://www.youtube.com/watch?v=KSNWJ2Xp84k"
# batch_sa "https://www.youtube.com/watch?v=HRj_xPwlpzs"
# batch_sa "https://www.youtube.com/watch?v=I7qmnJiNzOs"
# batch_sa "https://www.youtube.com/watch?v=vmmTrTMtZRE"
# batch_sa "https://www.youtube.com/watch?v=SPT_e8LOe3s"
# batch_sa "https://www.youtube.com/watch?v=XKXZct_MjWQ"
# batch_sa "https://www.youtube.com/watch?v=tVNYFruw1GU"
# batch_sa "https://www.youtube.com/watch?v=W5ARy18nKNA"
# batch_sa "https://www.youtube.com/watch?v=tNoeFfb6GyU"
# batch_sa "https://www.youtube.com/watch?v=X9w-zLLtmpM"
# batch_sa "https://www.youtube.com/watch?v=4hjUVq_S7h4"
# batch_sa "https://www.youtube.com/watch?v=-Lp8HuG_zhk"

# batch_sa "https://www.youtube.com/watch?v=sPB6jrh3R1s"
# batch_sa "https://www.youtube.com/watch?v=b1m7Cp7xBwk"
# batch_sa "https://www.youtube.com/watch?v=oTfnleTn_ZU"

# batch_sa "https://www.youtube.com/watch?v=ILXH2GDFb84"
# batch_sa "https://www.youtube.com/watch?v=onBpfOS6Ick"
# batch_sa "https://www.youtube.com/watch?v=WyAwTe9Z53w"
# batch_sa "https://www.youtube.com/watch?v=XzE6jRB7sw8"
# batch_sa "https://www.youtube.com/watch?v=8SE-dhyksj8"
# batch_sa "https://www.youtube.com/watch?v=xE_QFHFj40g"
# batch_sa "https://www.youtube.com/watch?v=FbCcy8j2GbE"
# batch_sa "https://www.youtube.com/watch?v=yhRGniGW-Ng"
# batch_sa "https://www.youtube.com/watch?v=MJbjql94eg8"
# batch_sa "https://www.youtube.com/watch?v=KX2S0bxmH6Q"
# batch_sa "https://www.youtube.com/watch?v=TkwalwjqTLg"
# batch_sa "https://www.youtube.com/watch?v=rHV4-YzaCEo"
# batch_sa "https://www.youtube.com/watch?v=30qH6gG3iE4"
# batch_sa "https://www.youtube.com/watch?v=xyTR6rukhTw"
# batch_sa "https://www.youtube.com/watch?v=RGpnIorrDkc"
# batch_sa "https://www.youtube.com/watch?v=Lo7I5OGqCk8"
# batch_sa "https://www.youtube.com/watch?v=4BLPByteU50"
# batch_sa "https://www.youtube.com/watch?v=7jPArwkONjk"
# batch_sa "https://www.youtube.com/watch?v=qj_lCfbEVPc"
# batch_sa "https://www.youtube.com/watch?v=D7Lzu3sfHlY"
# batch_sa "https://www.youtube.com/watch?v=j0dfOgF6Gtc"
# batch_sa "https://www.youtube.com/watch?v=j_fZCp100cw"
# batch_sa "https://www.youtube.com/watch?v=Za4JkXkMLJE"
# batch_sa "https://www.youtube.com/watch?v=mGgaA_dfBes"
# batch_sa "https://www.youtube.com/watch?v=M7xYTH40lHg"
# batch_sa "https://www.youtube.com/watch?v=4iFunETbnrI"
# batch_san "https://www.youtube.com/watch?v=-Lp8HuG_zhk"


# batch_sa "https://www.youtube.com/watch?v=54iEmvso3us"
# batch_sa "https://www.youtube.com/watch?v=84_pH1YqoUI"
# batch_sa "https://www.youtube.com/watch?v=wAYHuQvXuVw"
# batch_sa "https://www.youtube.com/watch?v=0TBbcrIfSMU"

#batch_sa "https://www.youtube.com/watch?v=OOsGVR7uvDY" --language nl
batch_sa "https://www.youtube.com/watch?v=JuKXrbNIZyY" --language nl
batch_sa "https://www.youtube.com/watch?v=-67RiAjKR44" --language nl
batch_sa "https://www.youtube.com/watch?v=wvndHF_iJYI" --language nl
batch_sa "https://www.youtube.com/watch?v=8wv453QswAk" --language nl
batch_sa "https://www.youtube.com/watch?v=9wPBgKW8A0E" --language nl
batch_sa "https://www.youtube.com/watch?v=v5yMwXaUnSU" --language nl
batch_sa "https://www.youtube.com/watch?v=2alWptNN4Kg" --language nl
batch_sa "https://www.youtube.com/watch?v=s2w2iAO5XLk" --language nl
batch_sa "https://www.youtube.com/watch?v=LKYvMui0-xg" --language nl
batch_sa "https://www.youtube.com/watch?v=DP9lTD3KKtA" --language nl
batch_sa "https://www.youtube.com/watch?v=-pzid2kgYa0" --language nl
batch_sa "https://www.youtube.com/watch?v=y5DQrIhVFoI" --language nl
batch_sa "https://www.youtube.com/watch?v=8D0-7d-sb8o" --language nl
batch_sa "https://www.youtube.com/watch?v=vesrW-upd8I" --language nl
batch_sa "https://www.youtube.com/watch?v=YKS7YU8EAnk" --language nl
batch_sa "https://www.youtube.com/watch?v=Bob-BRauU6w" --language nl
batch_sa "https://www.youtube.com/watch?v=BuLUQeEB9Uw" --language nl
batch_sa "https://www.youtube.com/watch?v=PZMKIEdoq2I" --language nl
batch_sa "https://www.youtube.com/watch?v=bKUFTHQy3BM" --language nl
batch_sa "https://www.youtube.com/watch?v=GU60l40k-So" --language nl
batch_sa "https://www.youtube.com/watch?v=i211HXKwlSI" --language nl
batch_sa "https://www.youtube.com/watch?v=W7nj_0QMR8s" --language nl
batch_sa "https://www.youtube.com/watch?v=MZ9oyhYgxmY" --language nl
batch_sa "https://www.youtube.com/watch?v=I5KyHhJQpq4" --language nl
batch_sa "https://www.youtube.com/watch?v=DYm-bK5Y8Kg" --language nl
batch_sa "https://www.youtube.com/watch?v=1kEMeSHK-Wg" --language nl
batch_sa "https://www.youtube.com/watch?v=G5JDl1bB358" --language nl
batch_sa "https://www.youtube.com/watch?v=IlVfV7pQeZU" --language nl
batch_sa "https://www.youtube.com/watch?v=LkKTqw3JXQY" --language nl
batch_sa "https://www.youtube.com/watch?v=X2YoXBtMjQ4" --language nl
batch_sa "https://www.youtube.com/watch?v=plZdd53mROY" --language nl
batch_sa "https://www.youtube.com/watch?v=knoh0n3XCcY" --language nl
batch_sa "https://www.youtube.com/watch?v=KAk6nNazyLY" --language nl
batch_sa "https://www.youtube.com/watch?v=Srfzw00I5oo" --language nl
batch_sa "https://www.youtube.com/watch?v=g6F6xGVQ1NQ" --language nl
batch_sa "https://www.youtube.com/watch?v=Y1j14YxBWnU" --language nl
batch_sa "https://www.youtube.com/watch?v=sBOPJsRNMj4" --language nl
batch_sa "https://www.youtube.com/watch?v=waeI1jZo7CM" --language nl
batch_sa "https://www.youtube.com/watch?v=DkZM5fz1HUU" --language nl
batch_sa "https://www.youtube.com/watch?v=L7YihjB_Qkk" --language nl
batch_sa "https://www.youtube.com/watch?v=6MQVcYO59Uo" --language nl
batch_sa "https://www.youtube.com/watch?v=9DcpqAHNExw" --language nl
batch_sa "https://www.youtube.com/watch?v=r104Yxss21U" --language nl
batch_sa "https://www.youtube.com/watch?v=NmTM79C7ctE" --language nl
batch_sa "https://www.youtube.com/watch?v=zpTrML16ZvI" --language nl
batch_sa "https://www.youtube.com/watch?v=oKe4mdfVUzY" --language nl
batch_sa "https://www.youtube.com/watch?v=UOfF2XSQsaU" --language nl
batch_sa "https://www.youtube.com/watch?v=x80J-vEyxwk" --language nl
batch_sa "https://www.youtube.com/watch?v=eeNS04JUyCc" --language nl
batch_sa "https://www.youtube.com/watch?v=ut42qs_C_I0" --language nl
batch_sa "https://www.youtube.com/watch?v=qm5oO7pg1uA" --language nl
batch_sa "https://www.youtube.com/watch?v=0u2OYnAK6Pc" --language nl
batch_sa "https://www.youtube.com/watch?v=80d-7-JuVaM" --language nl
batch_sa "https://www.youtube.com/watch?v=RVn1RXABigE" --language nl
batch_sa "https://www.youtube.com/watch?v=yr9comDWlrM" --language nl
batch_sa "https://www.youtube.com/watch?v=FUDR7hirICc" --language nl
batch_sa "https://www.youtube.com/watch?v=eN-uwVqy828" --language nl
batch_sa "https://www.youtube.com/watch?v=rcF8O3L2ZGM" --language nl
batch_sa "https://www.youtube.com/watch?v=40E4-aO3bYA" --language nl
batch_sa "https://www.youtube.com/watch?v=KVzDSvrYFIo" --language nl
batch_sa "https://www.youtube.com/watch?v=v1How-yTCVI" --language nl
batch_sa "https://www.youtube.com/watch?v=wlwOTWwVAQk" --language nl
batch_sa "https://www.youtube.com/watch?v=Vjw9swXYBCs" --language nl
batch_sa "https://www.youtube.com/watch?v=5Bc5_Fyxvdc" --language nl
 