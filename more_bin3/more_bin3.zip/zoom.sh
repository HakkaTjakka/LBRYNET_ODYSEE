#!/bin/bash

FILENAME=$1
BASENAME="${FILENAME%.*}"

read -d " " XX YY <<< $(ffprobe -v error -show_entries stream=width,height -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
SCALE="$XX":"$YY"
echo SCALE=$XX:$YY

ffmpeg -y -hide_banner \
	-loop 1 -i "$FILENAME" \
	-vf " \
	scale=iw*4:ih*4, \
	zoompan= \
	z='if(lte(mod(on*2,50),25),zoom+sin(on/25)/100,zoom+sin(on/25)/100)': \
	x='iw/2-(iw/zoom)/2': \
	y='ih/2-(ih/zoom)/2': \
	d=25*25" -c:v h264_nvenc -pix_fmt yuv420p -preset slow -t 25 -s "$XX"x"$YY" $BASENAME.zoom.mp4

#	z='zoom+sin(on/25)/100': \
#	z='if(lte(mod(on*2,60),30),zoom+0.02,zoom-0.02)': \

#	ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:v]setpts=$SPEED*PTS,fps=fps=60[v];[0:a]asetrate=$RATE/$PITCH,aresample=44100,atempo=(1.0/($SPEED/$PITCH))[a]" \
#	-map "[v]" -map "[a]" -c:v h264_nvenc -pix_fmt yuv420p -preset slow -c:a aac -ac 2 -b:a 64k "$BASENAME.TWITTER.MP4"
#ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:v]setpts=$SPEED*PTS,scale=1280:720:force_original_aspect_ratio=increase[v];[0:a]asetrate=$RATE/$PITCH,aresample=44100,atempo=(1.0/($SPEED/$PITCH))[a]" -map "[v]" -map "[a]" -c:v h264_nvenc -pix_fmt yuv420p -preset slow -c:a aac -ac 2 -b:a 64k "$BASENAME.TWITTER.MP4"
