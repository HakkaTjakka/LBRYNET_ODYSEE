#!/bin/bash

FILENAME1=$1
FILENAME2=$2
BASENAME="${FILENAME1%.*}"

ffmpeg -i "$1" -i "$2" -filter_complex "[0:v] [0:a] [1:v] [1:a] concat=n=2:v=1:a=1 [v] [a]" \
	-c:v h264_nvenc -pix_fmt yuv420p -preset slow \
	-map [v] -map [a] output.mp4
	

