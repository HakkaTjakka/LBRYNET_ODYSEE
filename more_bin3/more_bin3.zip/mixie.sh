#!/bin/bash

round() {
  printf "%.${2}f" "${1}"
}


FILENAME=$1
BASENAME="${FILENAME%.*}"
FILENAME2=$2
BASENAME2="${FILENAME2%.*}"

## ffmpeg -y -hide_banner \
##   -i $FILENAME -i $FILENAME2 -filter_complex \
##   "[1]adelay=33800|33800[aud];[0][aud]amix" \
##   -c:a aac -ac 2 -c:v copy $BASENAME.mixie.mp4

DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
echo "DURATION=$DURATION"

ffmpeg -y -hide_banner \
  -i $FILENAME -i "bin/koekoek.cut.aac" -i "bin/koekoek.cut.hp.aac" -ss 17 -i "bin/monkey_sound.aac" -filter_complex \
  "[1]adelay=33800|33800,volume=2[aud1]; \
   [2]adelay=34400|34400,volume=2[aud2]; \
   [3]adelay=48000|48000,volume=2[aud3]; \
   [0][aud1]amix[aud_mix1]; \
   [aud_mix1][aud2]amix[aud_mix2]; \
   [aud_mix2][aud3]amix" \
   -t $DURATION \
  -c:a aac -ac 2 -c:v copy $BASENAME.mixie.mp4



#### FILENAME="bin/koekoek.cut.aac"
#### PITCH="0.7"
#### SPEED=0.8
#### ATEMPO=$(echo "(1.0/($SPEED/$PITCH))"| bc -l)
#### ATEMPO=$(round ${ATEMPO} 2)
#### 
#### RATE=$(ffprobe -v error -show_entries stream=sample_rate -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
#### echo $RATE
#### 
#### ASETRATE=$(echo "($RATE/$PITCH)"| bc -l)
#### ASETRATE=$(round ${ASETRATE} 0)
#### 
#### echo $FILENAME
#### echo $SPEED
#### echo $ATEMPO
#### echo $ASETRATE
#### 
#### ffmpeg -hide_banner -i "$FILENAME" \
####   -filter_complex " \
####   [0:a]atempo=$ATEMPO,asetpts=PTS,asetrate=$ASETRATE,aresample=44100[a] \
####   " \
####   -map "[a]" \
####   "bin/koekoek.cut.hp.aac"

#  "[1]adelay=11700|11700,volume=4.0[aud];[0][aud]amix" \

#ffmpeg -y -hide_banner \
#  -i earth.mp4 
#  -i 1.wav -i 2.wav -i 3.wav -filter_complex "[1]adelay=delays=5s:all=1[r1]; [2]adelay=delays=8000S:all=1[r2]; [3]adelay=delays=15s:all=1[r3]; [r1][r2][r3]amix=inputs=3[a]"  -map 0:v -map "[a]" -codec:v copy output.mp4

## #ffmpeg -y -stream_loop -1 -i bin/thug_life.mp3 -i "$FILENAME" -shortest -c copy "$BASENAME.SOUND.MP4"
## 
## # ffmpeg -y -hide_banner \
## #  	-i "$FILENAME" \
## # 	-filter_complex \
## #   	" \
## #   	[0:a]aresample=44100[a] \
## #    	" \
## #    	-map 0:v:0 -map "[a]" \
## #   	-c:v copy -c:a aac -ac 2 -b:a 64k output.mp4
## 
## 
## # ffmpeg -y -hide_banner -i "$FILENAME2" -filter_complex "[0:a]aresample=44100[a]" -map "[a]" "$BASENAME.mp3"
## 
## #ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:a]aresample=44100[a]" -map "[a]" -c:a aac -ac 2 -b:a 128k "$BASENAME.aac"
## #ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:a]aresample=44100[a]" -map "[a]" -c:a aac -ac 2 -b:a 128k "$BASENAME.aac"
## 
## #DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "video-1659865497.mp4")
## 
## DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$FILENAME2")
## #DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$BASENAME.mp3")
## DURATION=$(round ${DURATION} 2)
## FADE=$(echo "($DURATION-3-2)"| bc -l)
## echo DURATION=$DURATION
## 
## ffmpeg -hide_banner -ss 00:00:02 -i "$FILENAME2" -t $DURATION \
##   -filter_complex "[0:a]aresample=44100,afade=type=out:duration=3:start_time=$FADE[a]" -map "[a]" -c:a aac -ac 2 -b:a 128k "$BASENAME2.aac"
## 
## ffmpeg -hide_banner -loop 1 -i "$FILENAME" -t $DURATION -c:v h264_nvenc -pix_fmt yuv420p "$BASENAME.mix.mp4"
## 
## #ffmpeg -y -hide_banner -loop 1 -i "$FILENAME2" -t $DURATION -c:v h264_nvenc -pix_fmt yuv420p -preset slow "$BASENAME2.mp4"
## 
## ffmpeg -y -hide_banner -i "$BASENAME2.aac" -i "$BASENAME.mix.mp4" -c copy output.mp4
## 
## # ffmpeg -y -hide_banner \
## #    -i hoppa.mp3 \
## #    -stream_loop -1 -i "$FILENAME" \
## #    -map 1:v:0 -map 0:a:0 \
## #    -c:v copy \
## #    -shortest \
## #    -c:a aac -ac 2 \
## #    output.mp4
## 
## # ffmpeg -y -hide_banner \
## #     -stream_loop -1 -i hoeba.opus \
## #     -i "$FILENAME" \
## #     -filter_complex \
## #     " \
## #     [0:a]volume=3[a0]; \
## #     [1:a]volume=0.5[a1]; \
## #     [a0][a1]amerge=inputs=2[a] \
## #     " \
## #     -map 1:v:0 -map "[a]" \
## #     -shortest -c:v copy \
## #     -c:a aac -ac 2 \
## #     output.mp4
## 
## # ffmpeg -y -hide_banner \
## #    -i "$FILENAME" \
## #    -i "$BASENAME2.aac" \
## #    -t $DURATION \
## #    -filter_complex " \
## #     [0:a]volume=1.5[a0]; \
## #     [1:a]volume=0.25[a11]; \
## #     [a0][a11]amerge=inputs=2[a] \
## #     " \
## #    -map 0:v:0 -map "[a]" \
## #    -c:v h264_nvenc -pix_fmt yuv420p \
## #    -b:v 500k \
## #    -c:a aac -ac 2 \
## #    "$BASENAME.mixed2.mp4"
## 
## # ffmpeg -y -hide_banner \
## #      -stream_loop -1 -i "$BASENAME2.mp4" -t $DURATION \
## #      -i "$BASENAME.mp3" \
## #      -shortest -c:v copy \
## #      -c:a copy \
## #      "output.mp4"
## 
## #     -map 1:v:0 -map "[a]" \
## #     -filter_complex \
## #     " \
## #     [0:a]volume=12[a0]; \
## #     [1:a]volume=0.5[a1]; \
## #     [a0][a1]amerge=inputs=2[a] \
## #     " \
## 
## #  	-map "[v]" 
## # h264_nvenc -pix_fmt yuv420p 
## #   	-preset slow \
## 