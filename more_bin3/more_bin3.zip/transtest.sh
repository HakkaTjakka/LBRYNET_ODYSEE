# source ~/git/argos-translate/env/bin/activate

cat "$1" | argos-translate --from en --to nl > trans.txt
