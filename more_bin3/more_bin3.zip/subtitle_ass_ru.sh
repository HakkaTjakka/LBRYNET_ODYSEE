#!/bin/bash

LANGUAGE="unknown"
TRANSLATOR="en-us-0.42-gigaspeech"

echo -------------------------------------------------------------------------- >> error.log

echo Getting filename from URL: $*
echo Getting filename from URL: $* >> error.log

#yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --skip-unavailable-fragments --geo-bypass --get-filename "$*" -o "kut.mp4" > filename.txt
#yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --skip-unavailable-fragments --geo-bypass --get-filename "$*" > filename.txt
yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log

# FILENAME=$*
# echo $FILENAME > filename.txt

BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')

if test -f "out/$BASENAME.$LANGUAGE.mp4"; then
	echo "out/$BASENAME.$LANGUAGE.mp4 exists."
else

	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass --cookies cookies/twitter.com_cookies.txt "$*""
#	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""
#	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*" -o "kut.mp4""

	rm COMMANDS.SH
	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	./command.sh

	if test -f "$BASENAME.mkv"; then
		FILENAME="$BASENAME.mkv"
		echo "$BASENAME.mkv exists. Changing filename."
		echo "$FILENAME" > filename.txt
	fi

#	COMMAND="autosub -S $LANGUAGE -D $LANGUAGE \"$FILENAME\" -o \"$BASENAME.$LANGUAGE.srt\""

#	COMMAND="vosk-transcriber -l $LANGUAGE -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""

	#COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_width 40 --max_line_count 2"
	#COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_width 40 --max_line_count 2"
	#COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_count 1 --no_speech_threshold 0.5"
	COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_count 1"
	# --no_speech_threshold NO_SPEECH_THRESHOLD
	# --max_line_width 30
	# --max_line_width 80

# 	--language Dutch 
#	COMMAND="vosk-transcriber -l $TRANSLATOR -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""


	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	#./command.sh
	ln=1
	# for i in $("./command.sh"); do
    # 	echo "whisper: "$ln" = \"$i\""
    # 	ln=$ln+1
	# done
	#IFS=$'\r'
	#./command.sh | while read -r line ; do
	#| tr -d '\r'
	script -c ./command.sh -f | while read -r line1; do
    	#echo "$line"
    	BAR=$(printf "whisper: "$ln" = \"$line1\"" | tr -d '\r')
    	#echo $(printf "whisper: "$ln" = \"$line1\"" | tr -d '\r')
    	echo -n $BAR
    	printf "\r\n"
    	ln=$((ln+1))
    	#IFS=$' '
	    #echo "Unknown" > language.txt
    	echo $line1 | while read -r line_a line_b line_c; do
    		if [ "$line_a" = "Detected" ]; then  
	    		if [ "$line_b" = "language:" ]; then
	    			LANGUAGE=$(echo $line_c | tr -d '\r')
	    			echo $LANGUAGE > language.txt
	    			echo $LANGUAGE > language_full.txt
					read -r LANGUAGE_FULL < language.txt
    				echo "LANGUAGE="$line_c

					if [ "$LANGUAGE_FULL" == "Dutch"      ];           then LANGUAGE="nl" ; fi
					if [ "$LANGUAGE_FULL" == "English"    ];           then LANGUAGE="en" ; fi
					if [ "$LANGUAGE_FULL" == "French"     ];           then LANGUAGE="fr" ; fi
					if [ "$LANGUAGE_FULL" == "Italian"    ];           then LANGUAGE="it" ; fi
					if [ "$LANGUAGE_FULL" == "German"     ];           then LANGUAGE="de" ; fi
					if [ "$LANGUAGE_FULL" == "Turkish"    ];           then LANGUAGE="tr" ; fi
					if [ "$LANGUAGE_FULL" == "Portuguese" ];           then LANGUAGE="pt" ; fi
					if [ "$LANGUAGE_FULL" == "Russian"    ];           then LANGUAGE="ru" ; fi
					if [ "$LANGUAGE_FULL" == "Ukrainian"  ];           then LANGUAGE="uk" ; fi
					if [ "$LANGUAGE_FULL" == "Arabic"     ];           then LANGUAGE="ar" ; fi
					if [ "$LANGUAGE_FULL" == "Japanese"   ];           then LANGUAGE="ja" ; fi
					if [ "$LANGUAGE_FULL" == "Urdu"       ];           then LANGUAGE="ur" ; fi
					echo $LANGUAGE > language.txt
    				printf "LANGUAGE=$LANGUAGE\r\n"

	    		fi
    		fi
    		#printf "line_a="$line_a"  line_b="$line_b"\r\n"
    	done
	done

#exit
#	read -r LANGUAGE < language.txt
#	read -r LANGUAGE_FULL < language_full.txt

#	COMMAND="sof/sof "$BASENAME.$LANGUAGE.srt""
	COMMAND="ffmpeg -y -hide_banner -i \"$BASENAME.srt\" \"$BASENAME.$LANGUAGE.ass\""

	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	
	./command.sh

	cat "$BASENAME.$LANGUAGE.ass" | sed "s/\u1/c\&HFFFF\&/g" | sed "s/\u0/c\&HFFFFFF\&/g" > "$BASENAME.$LANGUAGE.ass.double"

	burn_video_ass.sh $LANGUAGE

	mv "$BASENAME.single" "$BASENAME.$LANGUAGE.srt.double"

	COMMAND="translate_ru.sh \"$BASENAME.$LANGUAGE.srt.double\""

	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	
	./command.sh

	burn_video2.sh nl
	burn_video2.sh en
	burn_video2.sh uk

	#cp "$BASENAME.nl.srt.double" "$BASENAME.$LANGUAGE_FULL.nl.srt.double" 
	#cp "$BASENAME.en.srt.double" "$BASENAME.$LANGUAGE_FULL.en.srt.double"

	#cp "out/$BASENAME.$LANGUAGE_FULL.mp4" "$BASENAME.$LANGUAGE_FULL.mp4"

	#echo "$BASENAME.$LANGUAGE_FULL.mp4" > filename.txt
	#burn_video2.sh nl
	#burn_video2.sh en

fi

## if test -f "out/$BASENAME.nl.mp4"; then
## 	echo "out/$BASENAME.nl.mp4 exists."
## else
## 	if test -f "$BASENAME.nl.srt.double"; then
## 		rm "$BASENAME.nl.srt.double"
## 	fi
## 
## 	COMMAND="translate.sh "$BASENAME.$LANGUAGE.srt.double""
## 
## 	echo "$COMMAND" >> COMMANDS.SH
## 	echo "$COMMAND" > command.sh
## 	chmod +x command.sh
## 	./command.sh
## 
## 	burn_video.sh nl
## fi