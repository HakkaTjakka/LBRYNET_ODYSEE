#!/bin/bash

round() {
  printf "%.${2}f" "${1}"
}


FILENAME=$1
BASENAME="${FILENAME%.*}"
FILENAME2=$2
BASENAME2="${FILENAME2%.*}"

#ffmpeg -y -stream_loop -1 -i bin/thug_life.mp3 -i "$FILENAME" -shortest -c copy "$BASENAME.SOUND.MP4"

# ffmpeg -y -hide_banner \
#  	-i "$FILENAME" \
# 	-filter_complex \
#   	" \
#   	[0:a]aresample=44100[a] \
#    	" \
#    	-map 0:v:0 -map "[a]" \
#   	-c:v copy -c:a aac -ac 2 -b:a 64k output.mp4


# ffmpeg -y -hide_banner -i "$FILENAME2" -filter_complex "[0:a]aresample=44100[a]" -map "[a]" "$BASENAME.mp3"

#ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:a]aresample=44100[a]" -map "[a]" -c:a aac -ac 2 -b:a 128k "$BASENAME.aac"
#ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:a]aresample=44100[a]" -map "[a]" -c:a aac -ac 2 -b:a 128k "$BASENAME.aac"

#DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "video-1659865497.mp4")

DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
#DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$BASENAME.mp3")
DURATION=$(round ${DURATION} 2)
FADE=$(echo "($DURATION-5)"| bc -l)
echo DURATION=$DURATION

ffmpeg -y -hide_banner -ss 00:00:16 -i "$FILENAME2"  -t $DURATION \
  -filter_complex "[0:a]aresample=44100,afade=type=in:duration=8:start_time=0,afade=type=out:duration=3:start_time=$FADE[a]" -map "[a]" -c:a aac -ac 2 -b:a 128k "$BASENAME2.aac"

#ffmpeg -hide_banner -loop 1 -i "$FILENAME" -t $DURATION -c:v h264_nvenc -pix_fmt yuv420p "$BASENAME.mix.mp4"

#ffmpeg -y -hide_banner -loop 1 -i "$FILENAME2" -t $DURATION -c:v h264_nvenc -pix_fmt yuv420p -preset slow "$BASENAME2.mp4"

#ffmpeg -y -hide_banner -i "$BASENAME2.aac" -i "$BASENAME.mix.mp4" -c copy output.mp4
ffmpeg -y -hide_banner \
    -i "$BASENAME2.aac" \
    -i "$FILENAME" \
    -t $DURATION \
    -filter_complex " \
    [0:a]aresample=44100,volume=1.00,atempo=1.0[a0];
    [1:a]aresample=44100,volume=1.00,atempo=1.0[a1]; \
    [a1][a0]amix=inputs=2:shortest[a] \
    " \
    -map "[a]" \
    -map 1:v:0 \
    -c:v h264_nvenc -pix_fmt yuv420p \
    "$BASENAME.$BASENAME2.mp4"

###    [0:a]aresample=44100,volume=1.00,atempo=1.0,afade=type=out:duration=3:start_time=$FADE[a0];
###     [0:a]aresample=44100,volume=1.00[a0];
###     [1:a]aresample=44100,atempo=(1.0/($SPEED/$PITCH)), \
###     afade=type=out:duration=$FADE:start_time=10, \
###     afade=type=in:duration=10:start_time=0,volume=0.7[a1]; \
###     [a0][a1]amix=inputs=2:shortest[a] \
###   " \
###   -map "[v]" \
###   -map "[a]" \
###   -c:v h264_nvenc -pix_fmt yuv420p \


# ffmpeg -y -hide_banner \
#    -i hoppa.mp3 \
#    -stream_loop -1 -i "$FILENAME" \
#    -map 1:v:0 -map 0:a:0 \
#    -c:v copy \
#    -shortest \
#    -c:a aac -ac 2 \
#    output.mp4

# ffmpeg -y -hide_banner \
#     -stream_loop -1 -i hoeba.opus \
#     -i "$FILENAME" \
#     -filter_complex \
#     " \
#     [0:a]volume=3[a0]; \
#     [1:a]volume=0.5[a1]; \
#     [a0][a1]amerge=inputs=2[a] \
#     " \
#     -map 1:v:0 -map "[a]" \
#     -shortest -c:v copy \
#     -c:a aac -ac 2 \
#     output.mp4

# ffmpeg -y -hide_banner \
#    -i "$FILENAME" \
#    -i "$BASENAME2.aac" \
#    -t $DURATION \
#    -filter_complex " \
#     [0:a]volume=1.5[a0]; \
#     [1:a]volume=0.25[a11]; \
#     [a0][a11]amerge=inputs=2[a] \
#     " \
#    -map 0:v:0 -map "[a]" \
#    -c:v h264_nvenc -pix_fmt yuv420p \
#    -b:v 500k \
#    -c:a aac -ac 2 \
#    "$BASENAME.mixed2.mp4"

# ffmpeg -y -hide_banner \
#      -stream_loop -1 -i "$BASENAME2.mp4" -t $DURATION \
#      -i "$BASENAME.mp3" \
#      -shortest -c:v copy \
#      -c:a copy \
#      "output.mp4"

#     -map 1:v:0 -map "[a]" \
#     -filter_complex \
#     " \
#     [0:a]volume=12[a0]; \
#     [1:a]volume=0.5[a1]; \
#     [a0][a1]amerge=inputs=2[a] \
#     " \

#  	-map "[v]" 
# h264_nvenc -pix_fmt yuv420p 
#   	-preset slow \
