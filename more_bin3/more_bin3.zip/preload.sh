get_one() {
	echo "==============================="
	echo "===============================" >> get_errors.log
	echo "URL:  $1"
	echo "URL:  $1" >> get_errors.log

	yt-dlp -i "$1" \
		--merge-output-format mp4 \
		--restrict-filenames \
		--skip-unavailable-fragments \
		--geo-bypass \
		--get-filename \
		--no-playlist \
		--cookies cookies/twitter.com_cookies.txt > get_filename.txt

	read -r FILENAME < get_filename.txt

	echo "Filename: $FILENAME"
	echo "Filename: $FILENAME" >> get_errors.log

	yt-dlp -i "$1" \
		--downloader aria2c \
		-R 5 \
		--merge-output-format mp4 \
		-o "$FILENAME"

	ffmpeg -v error -i "$FILENAME" -f null - 2>get_error.log
	cat get_error.log
	cat get_error.log >> get_errors.log
}

get_one "https://x.com/PeterSweden7/status/1874898579208413557"
exit

# rm get_errors.log

## #date: 2022-05-01 - length:    47:40 - title: "Libertarisme als Trojaans Paard in de Truth Movement - Anthony Migchels"
## get_one "https://odysee.com/libertarisme-als-trojaans-paard-in-de-truth-movement---anthony-migchels:1871c350405bc29837a3e074dc299df11fee61f1" --language nl
## 
## #date: 2022-04-29 - length:  1:16:47 - title: "Jeroen en Willem nemen de week door"
## get_one "https://odysee.com/jeroen-en-willem-nemen-de-week-door:3b610361cb824c891c62ad609c91cdfb0e6726d2" --language nl
##
###date: 2022-04-28 - length:       59 - title: "Samen Voor Nederland - It ain't right"
##get_one "https://odysee.com/samen-voor-nederland---it-ain-t-right:da2f5bba86703bf92bf5705352081f0dd860b62c" --language nl
##
###date: 2022-04-26 - length:  1:21:35 - title: "Jeugdzorg & Coronabeleid: georganiseerde misdaad - Maria-Louise Genet en Hanno Wisse"
##get_one "https://odysee.com/jeugdzorg---coronabeleid--georganiseerde-misdaad---maria-louise-genet-en-hanno-wisse:5c2d0f0e59fc406a5a33de1a5876d71f3bb978e2" --language nl
##
###date: 2022-04-25 - length:    47:35 - title: "Tussen Hemel en Aarde - Peter den Haring en Willemijn Bessem"
##get_one "https://odysee.com/tussen-hemel-en-aarde---peter-den-haring-en-willemijn-bessem:adf33b32f495e782a9024816a5e53282d428d3d7" --language nl
##
###date: 2022-04-24 - length:    46:39 - title: "Verborgen kracht: De kracht van kwetsbaarheid - Shohreh Feshtali en Tuffie Vos"
##get_one "https://odysee.com/verborgen-kracht--de-kracht-van-kwetsbaarheid---shohreh-feshtali-en-tuffie-vos:223653bb6182c1e8a592537928edf156ccb20bf5" --language nl
##
###date: 2022-04-20 - length:    52:47 - title: "Wat is er mis met het financiële systeem (vervolg) - Anthony Migchels"
##get_one "https://odysee.com/wat-is-er-mis-met-het-financi-le-systeem--vervolg----anthony-migchels:ab1bdc0770c66a6328667712a69a7e34e426d8dc" --language nl
##
###date: 2022-04-20 - length:  1:00:10 - title: "Verborgen kracht: darmen en zelfgenezend vermogen - Shohreh Feshtali en Merel van der Weurf"
##get_one "https://odysee.com/verborgen-kracht--darmen-en-zelfgenezend-vermogen---shohreh-feshtali-en-merel-van-der-weurf:83968eb2119e843bc5c556ecf79601f50b841c84" --language nl

#date: 2022-04-19 - length:    27:32 - title: "Criminelen in Toga's - Maria-Louise Genet, Willem Engel, Jeroen Pols"
get_one "https://odysee.com/criminelen-in-toga-s---maria-louise-genet--willem-engel--jeroen-pols:216a5596d56bc9c1a53f7c13c1e4bea17dbaa5ce" --language nl

#date: 2022-04-19 - length:  1:09:04 - title: ""Op de rand van de afgrond" - Sid Lukkassen en Paul Cliteur"
get_one "https://odysee.com/-op-de-rand-van-de-afgrond----sid-lukkassen-en-paul-cliteur:651da50ed8cb2653522832e22ed85f8f2f5757c7" --language nl

#date: 2022-04-15 - length:     1:45 - title: "Oproep: Zorg voor Nederland - Max von Kreyfelt en Shohreh Feshtali"
get_one "https://odysee.com/oproep--zorg-voor-nederland---max-von-kreyfelt-en-shohreh-feshtali:30d2be530edabd928f6c697759f4cda7329162e5" --language nl

#date: 2022-04-15 - length:  1:12:32 - title: "Jeroen en Willem nemen de week door"
get_one "https://odysee.com/jeroen-en-willem-nemen-de-week-door:95f0dc07925907ede69ad4869c457b43756d3df8" --language nl

#date: 2022-04-14 - length:    47:55 - title: "Wat is er mis met het financiële systeem? - Anthony Migchels"
get_one "https://odysee.com/wat-is-er-mis-met-het-financi-le-systeem----anthony-migchels:1bc19bf461c4a36001b747a60180be6aee09b2e5" --language nl

#date: 2022-04-13 - length:    43:20 - title: "Drie pijlers voor een post-corona samenleving - Loek Dullart en Frans Lutters"
get_one "https://odysee.com/drie-pijlers-voor-een-post-corona-samenleving---loek-dullart-en-frans-lutters:75cb275a6df8ae693beb857b5188640cacb812da" --language nl

#date: 2022-04-12 - length:    55:36 - title: "Verborgen kracht: Trouw aan eigen keuze - Shohreh Feshtali en Evelien Stricker"
get_one "https://odysee.com/verborgen-kracht--trouw-aan-eigen-keuze---shohreh-feshtali-en-evelien-stricker:6325e22d3c95ccf392c4c62cfa1af68bf40b301d" --language nl

#date: 2022-04-12 - length:  1:02:43 - title: "Inkwartieren & Uitkleden - Hanno Wisse en Maria Louise Genet"
get_one "https://odysee.com/inkwartieren---uitkleden---hanno-wisse-en-maria-louise-genet:8098206044d575f180a8949e9915af8e5a97f9a6" --language nl

#date: 2022-04-10 - length:    47:43 - title: "Manipulatie in de financiële wereld - Kiki Scheepens en Jelena Postuma"
get_one "https://odysee.com/manipulatie-in-de-financi-le-wereld---kiki-scheepens-en-jelena-postuma:2e342a659da9bcc727230cb7900104d03b9505b7" --language nl

#date: 2022-04-09 - length:    15:34 - title: "Iedereen is een Willem - Ad Nuis"
get_one "https://odysee.com/iedereen-is-een-willem---ad-nuis:ab070d8b4faed84ba1dda11482386459faa4bc82" --language nl

#date: 2022-04-08 - length:    56:49 - title: "Ongecensureerd: Waarom intervenieert Rusland nu? - Kees van der Pijl en Aleksander Sjoelgin"
get_one "https://odysee.com/ongecensureerd--waarom-intervenieert-rusland-nu----kees-van-der-pijl-en-aleksander-sjoelgin:9a6ab09a4eb5524292bb1cc1b07ff29de5c747f2" --language nl

#date: 2022-04-08 - length:    47:43 - title: "Ex-politieagent: De waarheid was voor mij belangrijker - Heidi Gündel en Brian Geertshuis"
get_one "https://odysee.com/ex-politieagent--de-waarheid-was-voor-mij-belangrijker---heidi-g-ndel-en-brian-geertshuis:95b088e57ace8beeb9d83a0b490a239145052602" --language nl

#date: 2022-04-07 - length:    33:16 - title: "Comedy brengt licht en donker samen - Laila Mol en Jonathan Krispijn"
get_one "https://odysee.com/comedy-brengt-licht-en-donker-samen---laila-mol-en-jonathan-krispijn:e0c85aaf49879e2b8a4ea57f6cccad254e295f6c" --language nl

#date: 2022-04-06 - length:    43:57 - title: "De effecten van globalisering op Nederland - Denise Pellinkhof en Twan Houben"
get_one "https://odysee.com/de-effecten-van-globalisering-op-nederland---denise-pellinkhof-en-twan-houben:ee622e65a8c67b9a4d6b74ed10bfecb1d514c077" --language nl

#date: 2022-04-06 - length:  1:10:13 - title: "Geef niet op, spreek je uit! - Shohreh Feshtali en Mattias Desmet"
get_one "https://odysee.com/geef-niet-op--spreek-je-uit----shohreh-feshtali-en-mattias-desmet:e2349b8927208d4a8c637885fd15eff13ca6adcf" --language nl

#date: 2022-04-05 - length:    55:20 - title: "Lockdown als afleiding? - Patricia Mensink en Anthony Migchels"
get_one "https://odysee.com/lockdown-als-afleiding----patricia-mensink-en-anthony-migchels:c6828ddcc685de4c1ca109eed3a02a29314537de" --language nl

#date: 2022-04-05 - length:    20:11 - title: "BREAKING NEWS: Willem Engel is vrij!"
get_one "https://odysee.com/breaking-news--willem-engel-is-vrij-:c53fc28ed77bddbc99ca3f80f23ba71b94267f01" --language nl

#date: 2022-04-05 - length:  1:12:48 - title: "Luizen in de Pels - Hanno Wisse en Maria Louise Genet"
get_one "https://odysee.com/luizen-in-de-pels---hanno-wisse-en-maria-louise-genet:9a6c7f68eaa4e5d3a17ae56dea313b5d00ddc2fa" --language nl

#date: 2022-04-04 - length:    30:14 - title: "Willem Engel: wat is waar? Shohreh, Frank, Dorien, Jeroen en Max"
get_one "https://odysee.com/willem-engel--wat-is-waar--shohreh--frank--dorien--jeroen-en-max:28f864a352bba96c15ba2f784073959ba0912334" --language nl

#date: 2022-04-03 - length:    46:50 - title: "Bestaat reïncarnatie echt? - Peter Toonen en Peter den Haring"
get_one "https://odysee.com/bestaat-re-ncarnatie-echt----peter-toonen-en-peter-den-haring:a6c80a6378aebff552f2d5bdd362ad9f03aace34" --language nl

#date: 2022-04-02 - length:    35:52 - title: "He's back! - Shohreh Feshtali met Willem Engel en Jeroen Pols"
get_one "https://odysee.com/he-s-back----shohreh-feshtali-met-willem-engel-en-jeroen-pols:62db55fdfec3a049814c596ba3cae01e78800c72" --language nl

#date: 2022-04-01 - length:     2:13 - title: "Samen Voor Nederland - Nee tegen het digitaal ID"
get_one "https://odysee.com/samen-voor-nederland---nee-tegen-het-digitaal-id:015459b71a716fd73ba55e567e08bafa9427c2a6" --language nl

#date: 2022-04-01 - length:  1:20:47 - title: "Jeroen en Willem nemen de week door"
get_one "https://odysee.com/jeroen-en-willem-nemen-de-week-door:39565c390be0e0bd1ea099acafb9f144c14928b5" --language nl

#date: 2022-03-31 - length:    34:17 - title: "De geschiedenis van globalisering (deel 1) - Denise Pellinkhof en Twan Houben"
get_one "https://odysee.com/de-geschiedenis-van-globalisering--deel------denise-pellinkhof-en-twan-houben:afa302ca5d9baa6756ba295e283a030f612cd5cf" --language nl

#date: 2022-03-30 - length:    55:13 - title: "Crisis na crisis - Shohreh Feshtali en Wybren van Haga"
get_one "https://odysee.com/crisis-na-crisis---shohreh-feshtali-en-wybren-van-haga:2188dcd733294f94cef1f53022f467e2464ae555" --language nl

#date: 2022-03-30 - length:  1:45:12 - title: "Erik Boomsma in gesprek met Ronald Bernard"
get_one "https://odysee.com/erik-boomsma-in-gesprek-met-ronald-bernard:dbd686f5c49f9c7c2a0e3e8f460072b8b320b2e6" --language nl

#date: 2022-03-29 - length:    36:47 - title: "Het gevaar van Central Bank Digital Currency (CBDC) - Maria Louise Genet en Hanno Wisse"
get_one "https://odysee.com/het-gevaar-van-central-bank-digital-currency--cbdc----maria-louise-genet-en-hanno-wisse:d720067221c793222a4408493b0f108f81f55f72" --language nl

#date: 2022-03-29 - length:       27 - title: "Ben jij slachtoffer van misbruik of satanisch ritueel misbruik?"
get_one "https://odysee.com/ben-jij-slachtoffer-van-misbruik-of-satanisch-ritueel-misbruik-:f9c139efbd58277278605b8370368723fd067f20" --language nl

#date: 2022-03-29 - length:    14:35 - title: "Ad Nuis - Willem Engel"
get_one "https://odysee.com/ad-nuis---willem-engel:708178cff6749313775b24d7e130efc38f6aa01a" --language nl

exit

#date: 2022-03-26 - length:  1:06:18 - title: "Verborgen kracht #1 - Shohreh Feshtali en Max von Kreyfelt"
get_one "https://odysee.com/verborgen-kracht------shohreh-feshtali-en-max-von-kreyfelt:40867e3808032e68edd40ba92a72d8ac1e2a1932" --language nl

#date: 2022-03-25 - length:  1:05:50 - title: "Weekoverzicht met Jeroen Pols en een bericht van Willem Engel"
get_one "https://odysee.com/weekoverzicht-met-jeroen-pols-en-een-bericht-van-willem-engel:f3fcad1e6523ebdfecb5d7e9ace77fb8ad1c7e85" --language nl

#date: 2022-03-23 - length:    44:35 - title: "De tuchtklacht tegen de landsadvocaat - Maria Louise Genet en Hanno Wisse"
get_one "https://odysee.com/mario-louise-en-hanno-wisse:4282363f564b8c506998fe7019060ad7f6764271" --language nl

#date: 2022-03-21 - length:    47:25 - title: "We moeten menselijkheid weer de norm maken - Pieter Stuurman en Berber Pieksma"
get_one "https://odysee.com/we-moeten-menselijkheid-weer-de-norm-maken---pieter-stuurman-en-berber-pieksma:502158621ef33c7bd75517d19e05c928b1700a96" --language nl

#date: 2022-03-19 - length:    51:09 - title: "Toxic: Psychopathie en destructieve relaties (deel 2) - Kiki Scheepens en Jan Storms"
get_one "https://odysee.com/toxic--psychopathie-en-destructieve-relaties--deel------kiki-scheepens-en-jan-storms:2e1db7681e56effc2b2d4ed24a0242e93c491d44" --language nl

#date: 2022-03-19 - length:     4:08 - title: "#freewillemengel"
get_one "https://odysee.com/-freewillemengel:0c4915fa4354d424e849d7b8c4161a2b8c83f918" --language nl

#date: 2022-03-18 - length:    59:05 - title: "Weekoverzicht met Jeroen, zonder Willem"
get_one "https://odysee.com/weekoverzicht-met-jeroen--zonder-willem:035b81270e18dc9b54d150af65cc5dd9b7b4804e" --language nl

#date: 2022-03-18 - length:    36:51 - title: "Zondag 20 maart, mars van de verbinding een jaar na dato - Heidi Gündel en Dennis Spaanstra"
get_one "https://odysee.com/zondag----maart--mars-van-de-verbinding-een-jaar-na-dato---heidi-g-ndel-en-dennis-spaanstra:1477426e95a3a4e4c9ea2ddb187e3faec01453bc" --language nl

#date: 2022-03-17 - length:    22:19 - title: "Coma en de Russen - Ad Nuis"
get_one "https://odysee.com/coma-en-de-russen---ad-nuis:2ef2132e56b7c6b5c3843ddcd36983b5b9d506f7" --language nl

#date: 2022-03-16 - length:    19:17 - title: "Willem Engel gearresteerd - Pieter Stuurman, Jeroen Pols, Frank Stadermann en Max von Kreyfelt?"
get_one "https://odysee.com/willem-engel-gearresteerd---pieter-stuurman--jeroen-pols--frank-stadermann-en-max-von-kreyfelt-:9887016897c112208a757515fdb59c490d37df62" --language nl

#date: 2022-03-15 - length:    55:13 - title: "Juridisch Weekjournaal - Jeroen Pols en Willem Engel"
get_one "https://odysee.com/juridisch-weekjournaal---jeroen-pols-en-willem-engel:eb7eda4b7f74cc58c4bac7f4bfa24217df85fe73" --language nl

#date: 2022-03-14 - length:    26:45 - title: "Pathé saboteert documentaire "Gideon" - Max von Kreyfelt, Frank Stadermann en Jean-Jaques van Bemmel"
get_one "https://odysee.com/path--saboteert-documentaire--gideon----max-von-kreyfelt--frank-stadermann-en-jean-jaques-van-bemmel:80c932ea8e90b0be3a48debda9b0b83105fd38d9" --language nl

#date: 2022-03-12 - length:  1:02:48 - title: "Terugblik op 2 jaar pandemie - Kiki Scheepens en Kees van der Pijl"
get_one "https://odysee.com/terugblik-op---jaar-pandemie---kiki-scheepens-en-kees-van-der-pijl:f3fb318bf1dcaa0df1fff2547a3857195eb49e71" --language nl

#date: 2022-03-11 - length:    59:59 - title: "Viruswaarheid Weekjournaal - Willem Engel en Jeroen Pols"
get_one "https://odysee.com/viruswaarheid-weekjournaal---willem-engel-en-jeroen-pols:521a9e8998c50c7e3002553766361086b34ec08b" --language nl

#date: 2022-03-09 - length:  1:16:32 - title: "UAP officieel erkend - Peter Toonen en Bart Uyttenhaege"
get_one "https://odysee.com/uap-officieel-erkend---peter-toonen-en-bart-uyttenhaege:366a451e44254068cffcd206ad1ce8a16c094ca8" --language nl

#date: 2022-03-08 - length:    42:24 - title: "De kracht van water - Patricia Mensink en Harald Thiers"
get_one "https://odysee.com/de-kracht-van-water---patricia-mensink-en-harald-thiers:21c504bf3ea3ae528d4c65bd0ecd9c9a3eaf1eb0" --language nl

#date: 2022-03-07 - length:    26:14 - title: "Mindfuck - Max von Kreyfelt en Jack Tucker"
get_one "https://odysee.com/mindfuck---max-von-kreyfelt-en-jack-tucker:2d8ffd52c598351855fb86470f2133fb374eec9d" --language nl

#date: 2022-03-06 - length:    50:48 - title: "Rusland/Oekraïne - Pieter Stuurman en Thierry Baudet"
get_one "https://odysee.com/rusland-oekra-ne---pieter-stuurman-en-thierry-baudet:f4477dc7bf21b6d747fc1fec6b35f82a78a2da9e" --language nl

#date: 2022-03-05 - length:    54:03 - title: "Toxic: Psychopathie en destructieve relaties (deel 1) - Kiki Scheepens en Jan Storms"
get_one "https://odysee.com/toxic--psychopathie-en-destructieve-relaties--deel------kiki-scheepens-en-jan-storms:2f83814a147edbae51dbe3c3c8682a0b16ffd8e5" --language nl

#date: 2022-03-04 - length:    52:56 - title: "Het Coronabedrog - Pieter Stuurman en Thierry Baudet"
get_one "https://odysee.com/het-coronabedrog---pieter-stuurman-en-thierry-baudet:e538a125128c61093e3ba71791c527bd16385791" --language nl

#date: 2022-03-04 - length:  1:08:26 - title: "De Navo heeft de Russische inval in Oekraïne uitgelokt - Stan van Houcke en Kees van der Pijl"
get_one "https://odysee.com/de-navo-heeft-de-russische-inval-in-oekra-ne-uitgelokt---stan-van-houcke-en-kees-van-der-pijl:685db0a1781a0c6bf5685abf84943079e012a960" --language nl

#date: 2022-03-03 - length:    35:07 - title: "We mogen wat meer aan egoreductie doen - Heidi Gündel en Viola Holt"
get_one "https://odysee.com/we-mogen-wat-meer-aan-egoreductie-doen---heidi-g-ndel-en-viola-holt:a5f90300462e9d0b118db053b80fcb9e955a64eb" --language nl

#date: 2022-03-03 - length:  1:06:20 - title: "MH17, de onderste steen - Kees van der Pijl en Eric van de Beek"
get_one "https://odysee.com/mh----de-onderste-steen---kees-van-der-pijl-en-eric-van-de-beek:b048bdce0a1f664bb0d8dcd0d835571fcd28e36d" --language nl

#date: 2022-03-02 - length:    40:03 - title: "Suïcide - Kiki Scheepens en Johan de Korte"
get_one "https://odysee.com/su-cide---kiki-scheepens-en-johan-de-korte:7ede52c07c1abf401868d4e28987bb379006ee1c" --language nl

#date: 2022-03-02 - length:    38:09 - title: "Smartphone = surveillance - Max en Wesley Feijth"
get_one "https://odysee.com/smartphone---surveillance---max-en-wesley-feijth:1162095b0e36ce9e42dcd99c55022220ae4d3625" --language nl

#date: 2022-03-01 - length:     2:04 - title: "It's not me, it's You(Tube) - Laila Mol"
get_one "https://odysee.com/it-s-not-me--it-s-you-tube----laila-mol:826e35a5be0887377c24d1e08e9ab1f88fa074e4" --language nl

#date: 2022-02-27 - length:     5:02 - title: "Bevrijding in Donetsk?"
get_one "https://odysee.com/bevrijding-in-donetsk-:8de84b2af5be60267be8ca3b787f0c2c08d4e225" --language nl

#date: 2022-02-27 - length:    43:21 - title: "Vrijheid? Vergeet het maar! - Max von Kreyfelt en Marcel de Graaf"
get_one "https://odysee.com/vrijheid--vergeet-het-maar----max-von-kreyfelt-en-marcel-de-graaf:b0dfc01b3a32f962d2b7d4e793bf9f6b3728f412" --language nl

#date: 2022-02-27 - length:     3:41 - title: "Schapen naar de weide"
get_one "https://odysee.com/schapen-naar-de-weide:768a66bde1325c296d6b2b27a281dbbd0e8361b4" --language nl

#date: 2022-02-26 - length:  1:06:46 - title: "Toxic: Manipulatie in het onderwijs - Kiki Scheepens, Anton de Lange en René Woensdrecht"
get_one "https://odysee.com/toxic--manipulatie-in-het-onderwijs---kiki-scheepens--anton-de-lange-en-ren--woensdrecht:0f12205927ea5e6ab0dad934a2bb085e604c16b5" --language nl

#date: 2022-02-25 - length:  1:10:35 - title: "Willem en Jeroen nemen de week door"
get_one "https://odysee.com/willem-en-jeroen-nemen-de-week-door:e8102a64c31c6ea00e37aa36588cc9d28558cfb8" --language nl

#date: 2022-02-24 - length:    21:01 - title: "PraatVrijBijMij - Max von Kreyfelt, Tine Boeve en Olaf Weller"
get_one "https://odysee.com/praatvrijbijmij---max-von-kreyfelt--tine-boeve-en-olaf-weller:ca3ff6b04a7213bfa5fe5213cee709dea0564654" --language nl

#date: 2022-02-23 - length:    32:50 - title: "Toxic: Gaslighting - Kiki Scheepens en Daan van Deursen"
get_one "https://odysee.com/toxic--gaslighting---kiki-scheepens-en-daan-van-deursen:3a5482641c3f5466bae773aa74c60055a9a7698a" --language nl

#date: 2022-02-23 - length:  1:05:18 - title: "Hoe nu verder? - Ferdinand van der Neut en Sander Compagner"
get_one "https://odysee.com/hoe-nu-verder----ferdinand-van-der-neut-en-sander-compagner:ba234b3d273b011f20db99b7a366369fc6a111d2" --language nl

#date: 2022-02-22 - length:  1:02:43 - title: "Demonstreren is géén gunst, maar een grondrecht! - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/demonstreren-is-g--n-gunst--maar-een-grondrecht----jeroen-pols-en-maria-louise-genet:aa0bf3b842a6fce714377e158f2e574a5bd1d069" --language nl

#date: 2022-02-20 - length:    49:38 - title: "Samen terug naar normaal - Peter Toonen en Fred van 't End"
get_one "https://odysee.com/samen-terug-naar-normaal---peter-toonen-en-fred-van--t-end:88bdea58309147978b8b3fc5173938737066f265" --language nl

#date: 2022-02-20 - length:    49:38 - title: "Samen terug naar normaal - Peter Toonen en Fred van 't End"
get_one "https://odysee.com/samen-terug-naar-normaal---peter-toonen-en-fred-van--t-end:1d752aab754c347d502db35b1644cf62a9ec706e" --language nl

#date: 2022-02-19 - length:    37:15 - title: "Toxic: meester-manipulators - Kiki Scheepens en Johan de Korte"
get_one "https://odysee.com/toxic--meester-manipulators---kiki-scheepens-en-johan-de-korte:e7e13635cfb9d9b934f989395a4eecdeb6c640c8" --language nl

#date: 2022-02-17 - length:    57:37 - title: "Faalt het nieuwe pensioenstelsel? - Bas Huitink en Arno Eijgenraam"
get_one "https://odysee.com/faalt-het-nieuwe-pensioenstelsel----bas-huitink-en-arno-eijgenraam:682562feb244bac9da2823be6dd4561599b64b84" --language nl

#date: 2022-02-17 - length:    39:35 - title: "Janet Ossebaard: “Zij zijn satanisch en gaan over lijken!” - Duncan, Janet Ossebaard & Cyntha Koeter"
get_one "https://odysee.com/janet-ossebaard---zij-zijn-satanisch-en-gaan-over-lijken-----duncan--janet-ossebaard---cyntha-koeter:1e4432f621e2d95892f5265eb3861eb54d0840b7" --language nl

#date: 2022-02-15 - length:     2:01 - title: "Samen Voor Nederland #7"
get_one "https://odysee.com/samen-voor-nederland---:4ddc98f0d2b0ff2f51a82a8fd7bf44baa131612b" --language nl

#date: 2022-02-15 - length:  1:01:05 - title: "De Coronapas: Het paard van Troje! - mr. Jeroen Pols en mr. Hanno Wisse"
get_one "https://odysee.com/de-coronapas--het-paard-van-troje----mr--jeroen-pols-en-mr--hanno-wisse:299b11c1fcdcb3d6a57c6dca6e37a32bb169750a" --language nl

#date: 2022-02-13 - length:    45:16 - title: "Levenslast - Peter Toonen en Tommy Zwartjes"
get_one "https://odysee.com/levenslast---peter-toonen-en-tommy-zwartjes:59f0ba19d89b0cf50d67650d926e6b105476da4a" --language nl

#date: 2022-02-12 - length:  1:45:10 - title: "De strijd tussen Rusland en het Westen - Marie Therese ter Haar"
get_one "https://odysee.com/de-strijd-tussen-rusland-en-het-westen---marie-therese-ter-haar:8470fa54c3e19202fdff80b9679d34bdc27a1808" --language nl

#date: 2022-02-11 - length:  1:05:03 - title: "Jeroen en Willem nemen de week door"
get_one "https://odysee.com/jeroen-en-willem-nemen-de-week-door:e4690580b73e5848c33977954f0d490d97729ee1" --language nl

#date: 2022-02-10 - length:     3:14 - title: "Crisis Compilatie - Demissionair minister van misleiding"
get_one "https://odysee.com/crisis-compilatie---demissionair-minister-van-misleiding:7e3ce239cc83d95f9bba1391a0ebf78c329a5fee" --language nl

#date: 2022-02-09 - length:     2:35 - title: "Protests All Over The World"
get_one "https://odysee.com/protests-all-over-the-world:312ac41b2b483359552e9d385534e55f078cbfd1" --language nl

#date: 2022-02-08 - length:     5:27 - title: "Waarom is Café Weltschmerz gestopt met Poppencast.tv? - Tommy Zwartjes en Max von Kreyfelt"
get_one "https://odysee.com/waarom-is-caf--weltschmerz-gestopt-met-poppencast-tv----tommy-zwartjes-en-max-von-kreyfelt:f397037af51a93178416838263b2b7d7b7bd8565" --language nl

#date: 2022-02-08 - length:  1:10:04 - title: "Vooruitblik op de gezondheidsraad - Jeroen Pols en Willem Engel"
get_one "https://odysee.com/vooruitblik-op-de-gezondheidsraad---jeroen-pols-en-willem-engel:3ec0e68ddfaf1f1bd46324a11ad2fe977e78e50f" --language nl

#date: 2022-02-07 - length:    35:36 - title: "False flag attacks; the ultimate mix of lies and violence! - Daniele Ganser & Duncan Robles"
get_one "https://odysee.com/false-flag-attacks--the-ultimate-mix-of-lies-and-violence----daniele-ganser---duncan-robles:86d339ec9bc406960c9d30674b1d0e91ce10a106" --language nl

#date: 2022-02-07 - length:  1:13:29 - title: "Lucifer - Peter Toonen en Maurits Prins"
get_one "https://odysee.com/lucifer---peter-toonen-en-maurits-prins:c4280c98fe70e8475dd45da074d127a843689360" --language nl

#date: 2022-02-06 - length:    50:38 - title: "Apeldoorn, smart city? - Pieter Stuurman en Antoon Huigens"
get_one "https://odysee.com/apeldoorn--smart-city----pieter-stuurman-en-antoon-huigens:97109dae39c1c6531bb2d307bcd13c333c20d29c" --language nl

#date: 2022-02-04 - length:     5:35 - title: "Crisis Compilatie #7 - The Cyber Attack"
get_one "https://odysee.com/crisis-compilatie------the-cyber-attack:ffae38ed89d50dbe69cb5ffed4d569213b3edf34" --language nl

#date: 2022-02-04 - length:    20:41 - title: "Voordracht Karel van Wolferen nr. 34: "De machtsgreep die zich verstevigt""
get_one "https://odysee.com/voordracht-karel-van-wolferen-nr-------de-machtsgreep-die-zich-verstevigt-:6f308496a3232ebaf51bb8d7eab3bafc16219b75" --language nl

#date: 2022-02-02 - length:    52:11 - title: "Corona voorbij? Klimaat volgende stap naar het Social Credit System - Kees van Rengs & Marijn Poels"
get_one "https://odysee.com/corona-voorbij--klimaat-volgende-stap-naar-het-social-credit-system---kees-van-rengs---marijn-poels:c4a59c3a7720ea426d42f5020e883416b6116420" --language nl

#date: 2022-02-02 - length:    15:24 - title: "Cabal verliest terrein  Europa wordt wakker!   Duncan Robles & Laura Hos"
get_one "https://odysee.com/cabal-verliest-terrein--europa-wordt-wakker----duncan-robles---laura-hos:bc41900f91e03e046e02b6144bc2a835275b6635" --language nl

#date: 2022-02-02 - length:  1:13:50 - title: "“The cure” met Erik Boomsma"
get_one "https://odysee.com/-the-cure--met-erik-boomsma:afc7c239bd51c7aec7806b06386acf2fe60b14cb" --language nl

#date: 2022-02-01 - length:    59:55 - title: "Politieke gevangenen in Nederland anno 2022 - Jeroen Pols & Maria-Louise Genet"
get_one "https://odysee.com/politieke-gevangenen-in-nederland-anno--------jeroen-pols---maria-louise-genet:b5493ba50f814f4105ecb19929f425f7076d51b0" --language nl

#date: 2022-01-29 - length:  1:04:07 - title: "Oekraïne, oorlogsdreiging of bluf? - Marie Therese ter Haar en Kees van der Pijl"
get_one "https://odysee.com/oekra-ne--oorlogsdreiging-of-bluf----marie-therese-ter-haar-en-kees-van-der-pijl:cc30fcf54bed331caac22c5d6fd24bed2c702474" --language nl

#date: 2022-01-28 - length:    26:38 - title: "Europa in verzet - Max von Kreyvelt en Hilda Slofstra"
get_one "https://odysee.com/europa-in-verzet---max-von-kreyvelt-en-hilda-slofstra:0ee4e6288147a5ffa8acfd89aae89a3d19621ad5" --language nl

#date: 2022-01-28 - length:  1:06:32 - title: "Doen we het wel goed? - Ferdinand van der Neut en Mordechai Krispijn"
get_one "https://odysee.com/doen-we-het-wel-goed----ferdinand-van-der-neut-en-mordechai-krispijn:da7e27756bb29c472fbcb87927bf3976ebe11c2d" --language nl

#date: 2022-01-25 - length:     1:48 - title: "Massive protest Brussels: 23-01"
get_one "https://odysee.com/massive-protest-brussels-------:d4869b8f4a8c5911d9b546e0453249ef87c41dbd" --language nl

#date: 2022-01-25 - length:  1:07:50 - title: "Minister koos bewust voor catastrofaal beleid! - Jeroen Pols & Maria Louise"
get_one "https://odysee.com/minister-koos-bewust-voor-catastrofaal-beleid----jeroen-pols---maria-louise:5bfa53cdcc119d863bcf1ef427c8aa46013734c7" --language nl

#date: 2022-01-24 - length:    57:28 - title: "Ziek zijn is genezen - Patricia Mensink en Mies Kloos"
get_one "https://odysee.com/ziek-zijn-is-genezen---patricia-mensink-en-mies-kloos:551babc3fb590929cc2e989c0ec916a8cff56c2b" --language nl

#date: 2022-01-21 - length:     2:19 - title: "Samen Voor Nederland #6"
get_one "https://odysee.com/samen-voor-nederland---:cbe52d9fc5565f9703e518df328b5f9a49f01e34" --language nl

#date: 2021-11-03 - length:    24:20 - title: "Alle absurditeiten van het coronabeleid op een rijtje - Erik van der Horst en Thierry Baudet"
get_one "https://odysee.com/alle-absurditeiten-van-het-coronabeleid-op-een-rijtje---erik-van-der-horst-en-thierry-baudet:c8cd78872a34cfe397dd41b6581d530847cb39d4" --language nl

#date: 2021-10-17 - length:    47:20 - title: "De macht van de onzichtbare bankiers – Peter Toonen en Lucas Hollertt"
get_one "https://odysee.com/de-macht-van-de-onzichtbare-bankiers---peter-toonen-en-lucas-hollertt:ca3bf47f48a2063cffc40f10db33f2746f8c6b08" --language nl

#date: 2021-10-17 - length:    46:27 - title: "Contouren van een post-coronasamenleving #2 - Loek Dullaart en Harry Salman"
get_one "https://odysee.com/contouren-van-een-post-coronasamenleving------loek-dullaart-en-harry-salman:dbd01e99ed41fb635fc1af4b7e6e59512296bbe0" --language nl

#date: 2021-10-17 - length:    30:44 - title: "Deceptie of realiteit? Ontwaken uit de MATRIX! - Duncan Robles met Margreet Martini"
get_one "https://odysee.com/deceptie-of-realiteit--ontwaken-uit-de-matrix----duncan-robles-met-margreet-martini:3488d7d4710b0dd27976ecd8f49843fe28531d71" --language nl

#date: 2021-10-15 - length:    49:45 - title: "Artiesten over de coronacrisis, het verzet en gecontroleerde oppositie"
get_one "https://odysee.com/artiesten-over-de-coronacrisis--het-verzet-en-gecontroleerde-oppositie:d6ee06467b1e626fddfb64739809b1f24917c311" --language nl

#date: 2021-10-15 - length:    22:36 - title: "Poppencast.tv #01 - Ik gebruik gewoon een valse QR-code"
get_one "https://odysee.com/poppencast-tv-------ik-gebruik-gewoon-een-valse-qr-code:a34ebc9cafeb4403530704f52f545b1259b3b7d4" --language nl

#date: 2021-10-15 - length:    17:15 - title: "Actiejournaal week #41- Martina Groenveld en Michel Rijinga"
get_one "https://odysee.com/actiejournaal-week------martina-groenveld-en-michel-rijinga:5e5610d29ce6ee08366dd273448d0d42b8722992" --language nl

#date: 2021-10-14 - length:    13:45 - title: "Gaf rechter terecht toestemming voor vaccineren van kind? - Isa Kriens en Frank Stadermann"
get_one "https://odysee.com/gaf-rechter-terecht-toestemming-voor-vaccineren-van-kind----isa-kriens-en-frank-stadermann:e794d1a169038ebcbff6d43cd4d0ce2cffae0b82" --language nl

#date: 2021-10-13 - length:    35:31 - title: "Kinderen hebben bescherming nodig - Martina Groenveld, Deborah Veldwijk en Geert-Jan Balvert"
get_one "https://odysee.com/kinderen-hebben-bescherming-nodig---martina-groenveld--deborah-veldwijk-en-geert-jan-balvert:a41d5d8ebec9f1c14f8538332fa606a87e1c0b61" --language nl

#date: 2021-10-13 - length:  1:08:22 - title: "Wat is het werkelijke doel? - Max von Kreyfelt en Erik Boomsma"
get_one "https://odysee.com/Wat-is-het-werkelijke-doel---Max-von-Kreyfelt-en-Erik-Boomsma:b62cc5022cc740152660cd645980403cc9df7882" --language nl

#date: 2021-10-12 - length:     8:10 - title: "Boetekleed - Max van der Werff, Max von Kreyfeld en Erik van der Horst"
get_one "https://odysee.com/boetekleed---max-van-der-werff--max-von-kreyfeld-en-erik-van-der-horst:3b33ddc768cf85b4de2924c93defce75e5570463" --language nl

#date: 2021-10-12 - length:    51:06 - title: "Het collectieve immuunsysteem is verzwakt - Sven Hulleman en Max von Kreyfelt"
get_one "https://odysee.com/Het-collectieve-immuunsysteem-is-verzwakt---Sven-Hulleman-en-Max-von-Kreyfelt:eae725f5181c7edbfc59d8939483fbaed5af70e7" --language nl

#date: 2021-10-10 - length:    34:00 - title: "Olifant in De Kamer: Sadistisch, ritueel kindermisbruik - Erik van der Horst en Gideon van Meijeren"
get_one "https://odysee.com/olifant-in-de-kamer--sadistisch--ritueel-kindermisbruik---erik-van-der-horst-en-gideon-van-meijeren:4aaba27d1d05c782b15df873caf0e442686c6370" --language nl

#date: 2021-10-08 - length:    11:03 - title: "Diplomatieke paspoorten en andere oplossingen om uit het systeem stappen; fantasie of echt?"
get_one "https://odysee.com/diplomatieke-paspoorten-en-andere-oplossingen-om-uit-het-systeem-stappen--fantasie-of-echt-:16518af6c902a5e3a42cd7d2e4924e3907a3b448" --language nl

#date: 2021-10-06 - length:    40:53 - title: "Meer slachtoffers, meer leugens - Max von Kreyfelt en Erik Boomsma"
get_one "https://odysee.com/Meer-slachtoffers-meer-leugens---Max-von-Kreyfelt-en-Erik-Boomsma:180d72d6f7a54ba4e2dd253c9b2062311cccc3e4" --language nl

#date: 2021-10-06 - length:  1:06:39 - title: "Adviezen Gezondheidsraad: onrechtmatig, onethisch en immoreel - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/Adviezen-Gezondheidsraad-onrechtmatig-onethisch-en-immoreel---Jeroen-Pols-En-Maria-Louise-Genet:f5b35d30c029d6705850ad9e78b9c4c3fb6202de" --language nl

#date: 2021-10-05 - length:    22:38 - title: "Boer René: "Dreigend voedseltekort? NO FARMERS, NO FOOD!" - Laura Hos en René Staal"
get_one "https://odysee.com/boer-ren----dreigend-voedseltekort--no-farmers--no-food-----laura-hos-en-ren--staal:b989628c9205b3db3d10c663e2a8f4694e4eee69" --language nl

#date: 2021-10-05 - length:    14:23 - title: "De wekelijkse Andere Krant - Erik van der Horst en Sander Compagner"
get_one "https://odysee.com/de-wekelijkse-andere-krant---erik-van-der-horst-en-sander-compagner:b07603b12a35a7adf6d13d0b7f2cbf65317c972c" --language nl

#date: 2021-10-04 - length:    51:07 - title: ""The Great Reset is gedoemd te falen" - Willem Engel en Paul Frijters"
get_one "https://odysee.com/-the-great-reset-is-gedoemd-te-falen----willem-engel-en-paul-frijters:fae0e09e2f5eff1953c03fb56ee3c227356909eb" --language nl

#date: 2021-10-03 - length:    50:27 - title: "Verzonnen verhalen met een politieke doelstelling - Peter Toonen en Frank Smits"
get_one "https://odysee.com/Verzonnen-verhalen-met-een-politieke-doelstelling---Peter-Toonen-en-Frank-Smits:bb7a84183d41b6e059faf5eb875efc31d67aa4ca" --language nl

#date: 2021-10-02 - length:    46:48 - title: "Contouren van een post-coronasamenleving"
get_one "https://odysee.com/Contouren-van-een-post-coronasamenleving:1084b6009d12adbd5a7d166ccb5cf501ecc4ef44" --language nl

#date: 2021-10-02 - length:    41:01 - title: "Niets is wat het lijkt - Peter Toonen en Angelo Meijers"
get_one "https://odysee.com/Niets-is-wat-het-lijkt---Peter-Toonen-en-Angelo-Meijers:9a29c5c3aad161bc2e62eb9c70c0e52616923626" --language nl

#date: 2021-10-02 - length:    34:57 - title: "Ministerie van VWS haat wetenschap - Erik van der Horst, Pepijn van Houwelingen en Ralf Dekker"
get_one "https://odysee.com/Ministerie-van-VWS-haat-wetenschap---Erik-van-der-Horst-Pepijn-van-Houwelingen-en-Ralf-Dekker:be1279e8439e71f2059126ac7b5048b4221d2584" --language nl

#date: 2021-09-30 - length:  1:04:14 - title: "Achter ieder cijfer zit een mens - Max von Kreyfelt en Erik Boomsma"
get_one "https://odysee.com/Achter-ieder-cijfer-zit-een-mens---Max-von-Kreyfelt-en-Erik-Boomsma:369cc00cb0804caf8ffc4f64d9d5aa743b12ffa1" --language nl

#date: 2021-09-29 - length:    47:43 - title: "Dagvaarding Gezondheidsraad - Show me the 'Pandemie'!"
get_one "https://odysee.com/Show-me-the-pandemie:2108136359a84e01f2318191b5e06ed5e3e4306a" --language nl

#date: 2021-09-29 - length:  1:04:37 - title: "Hoe angst ons brein programmeert - Pieter Stuurman en Eddie Tjon Fo"
get_one "https://odysee.com/Hoe-angst-ons-brein-programmeert---Pieter-Stuurman-en-Eddie-Tjon-Fo:a2c0eebfb8c2495cafae2e4c5223541637d5b9db" --language nl

#date: 2021-09-28 - length:    35:39 - title: "Restaurant Waku Waku maakt de weg vrij voor de Nederlandse horeca - Max, Anna en Mordechaï"
get_one "https://odysee.com/Restaurant-Waku-Waku-maakt-de-weg-vrij-voor-de-Nederlandse-horeca---Max,-Anna-en-Mordechaï:846a79420c1175753d63874500299ad549113822" --language nl

#date: 2021-09-27 - length:  1:42:38 - title: "Coronabeleid: Imitatie Chinese repressie op basis van zeer twijfelachtige statistieken - Arno Wellens"
get_one "https://odysee.com/Coronabeleid-Imitatie-Chinese-repressie-op-basis-van-zeer-twijfelachtige-statistieken---Arno-Wellens:0cc8859b1302fe1516533af95626d7ac597340ed" --language nl

#date: 2021-09-25 - length:    38:41 - title: "Onzichtbare genocide - Max von Kreyfelt en Erik Boomsma"
get_one "https://odysee.com/Onzichtbare-genocide---Max-von-Kreyfelt-en-Erik-Boomsma:ac4e5786c612ba5e61769b0c930e4f67fbd3d39b" --language nl

#date: 2021-09-24 - length:    14:46 - title: "25/9: Winkels en horeca spreken zich uit voor keuzevrijheid - Erik van der Horst en Olaf Weller"
get_one "https://odysee.com/------winkels-en-horeca-spreken-zich-uit-voor-keuzevrijheid---erik-van-der-horst-en-olaf-weller:e02a0740cbab25dcb1a83017945ce03d2094327b" --language nl

#date: 2021-09-24 - length:    14:46 - title: "25/9: Winkels en horeca spreken zich uit voor keuzevrijheid - Erik van der Horst en Olaf Weller"
get_one "https://odysee.com/------winkels-en-horeca-spreken-zich-uit-voor-keuzevrijheid---erik-van-der-horst-en-olaf-weller:367f91064509278b50605eb6932eaf61ab5914e1" --language nl

#date: 2021-09-22 - length:    28:42 - title: "Corrupte machtssystemen: We worden voor de gek gehouden!"
get_one "https://odysee.com/corrupte-machtssystemen--we-worden-voor-de-gek-gehouden-:6142b242a55e8b6b5b616fb6129cbd55c67a74d9" --language nl

#date: 2021-09-22 - length:    28:42 - title: "Corrupte machtssystemen: We worden voor de gek gehouden!"
get_one "https://odysee.com/corrupte-machtssystemen--we-worden-voor-de-gek-gehouden-:3276f8a77e8363ba4376b3a516b2cbfa7c2c6130" --language nl

#date: 2021-09-22 - length:    28:42 - title: "Corrupte machtssystemen: We worden voor de gek gehouden!"
get_one "https://odysee.com/corrupte-machtssystemen--we-worden-voor-de-gek-gehouden-:29d62ec2e0c15e555d618234475c06ade69b5ad7" --language nl

#date: 2021-09-21 - length:    49:14 - title: "Gezondheidsraad gedagvaard - Aanvaardbaarheidstoets - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/gezondheidsraad-gedagvaard---aanvaardbaarheidstoets---jeroen-pols-en-maria-louise-genet:c825f8fb98622b036247bb0f9833cbdde0001c92" --language nl

#date: 2021-09-21 - length:    49:14 - title: "Gezondheidsraad gedagvaard - Aanvaardbaarheidstoets - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/gezondheidsraad-gedagvaard---aanvaardbaarheidstoets---jeroen-pols-en-maria-louise-genet:8b61b63d393958546b893014b8a841da7ad7995a" --language nl

#date: 2021-09-21 - length:    49:14 - title: "Gezondheidsraad gedagvaard - Aanvaardbaarheidstoets - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/gezondheidsraad-gedagvaard---aanvaardbaarheidstoets---jeroen-pols-en-maria-louise-genet:1fbc81b717bbbcc52bc8f04a8e90f16e687c218a" --language nl

#date: 2021-09-20 - length:    17:35 - title: "Ik ben bang dat mijn (ex)partner onze kinderen zal laten prikken - Isa Kriens en Frank Stadermann"
get_one "https://odysee.com/ik-ben-bang-dat-mijn--ex-partner-onze-kinderen-zal-laten-prikken---isa-kriens-en-frank-stadermann:161ead1ba963967f51b0658b919a63e97188fbf7" --language nl

#date: 2021-09-17 - length:    58:43 - title: "De échte reset is de Going Direct Reset - Elze van Hamelen en Catherine Austin Fitts"
get_one "https://odysee.com/de--chte-reset-is-de-going-direct-reset---elze-van-hamelen-en-catherine-austin-fitts:1dab718a4cd87f6e1594ab728253f9a8bf439e86" --language nl

#date: 2021-09-16 - length:    15:01 - title: "De baas eist een test of prik. Wat nu? - Isa Kriens en Frank Stadermann"
get_one "https://odysee.com/de-baas-eist-een-test-of-prik--wat-nu----isa-kriens-en-frank-stadermann:e373e217c779f8a8bc3776b3c0c4d0229ec29d40" --language nl

#date: 2021-09-16 - length:    15:01 - title: "De baas eist een test of prik. Wat nu? - Isa Kriens en Frank Stadermann"
get_one "https://odysee.com/de-baas-eist-een-test-of-prik--wat-nu----isa-kriens-en-frank-stadermann:e1be3b4fa2e7c80dc8d292b91827a43021d8a487" --language nl

#date: 2021-09-14 - length:  1:03:47 - title: "Gezondheidsraad gedagvaard - Veiligheid en ernstige bijwerkingen - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/gezondheidsraad-gedagvaard---veiligheid-en-ernstige-bijwerkingen---jeroen-pols-en-maria-louise-genet:f21ac6ee76f416bd295dbd5f719e3d04f618b472" --language nl

#date: 2021-09-14 - length:  1:03:47 - title: "Gezondheidsraad gedagvaard - Veiligheid en ernstige bijwerkingen - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/gezondheidsraad-gedagvaard---veiligheid-en-ernstige-bijwerkingen---jeroen-pols-en-maria-louise-genet:e506a54827e9dc7317f310160f28369e0f8930fc" --language nl

#date: 2021-09-13 - length:    18:36 - title: "TikTok-influencer Sara Dol: "Ik doe niet mee aan deze poppenkast""
get_one "https://odysee.com/tiktok-influencer-sara-dol---ik-doe-niet-mee-aan-deze-poppenkast-:f2caffe633c771e29d24036ef8bace14003e4098" --language nl

#date: 2021-09-13 - length:    18:36 - title: "TikTok-influencer Sara Dol: "Ik doe niet mee aan deze poppenkast""
get_one "https://odysee.com/tiktok-influencer-sara-dol---ik-doe-niet-mee-aan-deze-poppenkast-:e55c9062f9072c9facd46079ad899fd72118d0e7" --language nl

#date: 2021-09-13 - length:    18:36 - title: "TikTok-influencer Sara Dol: "Ik doe niet mee aan deze poppenkast""
get_one "https://odysee.com/tiktok-influencer-sara-dol---ik-doe-niet-mee-aan-deze-poppenkast-:3a5bb6bcc7afaea2ba856fa77202159525dee6a3" --language nl

#date: 2021-09-12 - length:    53:30 - title: "Rechteloze Werkelijkheid - Peter Toonen met Rients Hofstra"
get_one "https://odysee.com/rechteloze-werkelijkheid---peter-toonen-met-rients-hofstra:fce044f0f275ea779d7e5d50fd4a667b3e9ae2cf" --language nl

#date: 2021-09-12 - length:    53:30 - title: "Rechteloze Werkelijkheid - Peter Toonen met Rients Hofstra"
get_one "https://odysee.com/rechteloze-werkelijkheid---peter-toonen-met-rients-hofstra:b98034b3e9bddba787f42010d6d4247c4aeb8d61" --language nl

#date: 2021-09-09 - length:    37:33 - title: "Dwang, oplichting & technocratie. De natte droom van iedere dictator?"
get_one "https://odysee.com/dwang--oplichting---technocratie--de-natte-droom-van-iedere-dictator-:df1e49c65c17ce694de01743f0f13096b43aa335" --language nl

#date: 2021-09-09 - length:    30:02 - title: "Actiejournaal week #36 - Martina Groenveld met Michel Reijinga"
get_one "https://odysee.com/actiejournaal-week-------martina-groenveld-met-michel-reijinga:a6817cdefb4049924b12046e3328f1b1c728c45e" --language nl

#date: 2021-09-08 - length:    28:12 - title: "De Groene Amsterdammer en KRO-NCRV geven niet thuis - Karel Beckman en Cees Hamelink"
get_one "https://odysee.com/de-groene-amsterdammer-en-kro-ncrv-geven-niet-thuis---karel-beckman-en-cees-hamelink:570fdb8b5dc5d609ceb66817a28be3ed52a0159a" --language nl

#date: 2021-09-07 - length:    40:35 - title: "Dagvaarding tegen de Gezondheidsraad - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/dagvaarding-tegen-de-gezondheidsraad---jeroen-pols-en-maria-louise-genet:1535668768e8ac0646f69fb9bff2e022dfe76941" --language nl

#date: 2021-09-06 - length:     2:50 - title: "Weltschmerz Next - Biggest Freedom Rally Netherlands Ever!"
get_one "https://odysee.com/weltschmerz-next---biggest-freedom-rally-netherlands-ever-:3a9b98914a3587bc84287f39249287cec6034c4f" --language nl

#date: 2021-09-04 - length:    32:35 - title: "VWS: Een muur van onwil - Erik van der Horst met Pepijn van Houwelingen"
get_one "https://odysee.com/VWS-Een-muur-van-onwil---Erik-van-der-Horst-en-Pepijn-Van-Houwelingen:adfa78980347259616886f3a0be2cac5ad3d1518" --language nl

#date: 2021-09-02 - length:    52:59 - title: "Dit is mijn politie niet meer - Erik van der Horst, Peter Cirk, Alice Besselink & Dennis Spaanstra"
get_one "https://odysee.com/dit-is-mijn-politie-niet-meer---erik-van-der-horst--peter-cirk--alice-besselink---dennis-spaanstra:ef4c720642f730c6e747caf1fd251671c9627873" --language nl

#date: 2021-09-02 - length:    18:53 - title: "Actiejournaal #SPECIAL"
get_one "https://odysee.com/actiejournaal--special:b0e61d03f2444bfe9658aa84df747542e253ccc0" --language nl

#date: 2021-09-01 - length:    35:10 - title: "Actiejournaal week #35"
get_one "https://odysee.com/actiejournaal-week----:8dd0a05ffdb8629345427b2cd970031eebc71c47" --language nl

#date: 2021-08-31 - length:    24:44 - title: "Het ware gezicht - Ad Nuis"
get_one "https://odysee.com/Ad-Nuis---Het-ware-gezicht:2166461b21ea4881553a651b6138aacdb21775c7" --language nl

#date: 2021-08-29 - length:    53:43 - title: "De Hack van de Matrix - Peter Toonen en Dino Sarac"
get_one "https://odysee.com/de-hack-van-de-matrix---peter-toonen-en-dino-sarac:1e3a07e37909a2486327263d1a674734026652e1" --language nl

#date: 2021-08-25 - length:  1:14:07 - title: "Wees uw broeders hoeder - Peter Toonen en Gitta Sluijters"
get_one "https://odysee.com/wees-uw-broeders-hoeder---peter-toonen-en-gitta-sluijters:2e55ac47f4b8d9e1222015e0898b71b9c9fe32ee" --language nl

#date: 2021-08-22 - length:    45:45 - title: "We hoeven hier niet in mee te gaan - Erik van der Horst en Elke de Klerk"
get_one "https://odysee.com/we-hoeven-hier-niet-in-mee-te-gaan---erik-van-der-horst-en-elke-de-klerk:4066c4ef1b4ee8354f3790e6dadc997bf2f46527" --language nl

#date: 2021-08-22 - length:    36:54 - title: "The Truth is Out There - Peter Toonen en Jaron Harambam"
get_one "https://odysee.com/the-truth-is-out-there---peter-toonen-en-jaron-harambam:04285c0660818dfe8194b5d1a901f070da8bf610" --language nl

#date: 2021-08-19 - length:  1:07:03 - title: "Wat is erger, C19 of CO2? - Willem Engel met Marcel Crok"
get_one "https://odysee.com/wat-is-erger--c---of-co-----willem-engel-met-marcel-crok:72575dda633c8aed1f0b4fe935649a53cac25ace" --language nl

#date: 2021-08-17 - length:  1:02:50 - title: "De man die keer op keer gelijk bleek te hebben - Erik van der Horst met David Icke"
get_one "https://odysee.com/de-man-die-keer-op-keer-gelijk-bleek-te-hebben---erik-van-der-horst-met-david-icke:330c07ac9ccfca6539d0278fa2c5eb13dd4dd5da" --language nl

#date: 2021-08-15 - length:    48:01 - title: "Bestaansrecht - Peter Toonen met Maarten Oversier"
get_one "https://odysee.com/bestaansrecht---peter-toonen-met-maarten-oversier:1d58733fbfec3e7cd82cb64bfc0d0bbd56fbd77a" --language nl

#date: 2021-08-13 - length:    32:26 - title: "Oud-docente rechten (UVA): 'Dit riekt naar een dictatuur!’ Maria-Louise Genet & Laura Hos"
get_one "https://odysee.com/oud-docente-rechten--uva----dit-riekt-naar-een-dictatuur---maria-louise-genet---laura-hos:0c3441e8c501ffcbedd3bce91ab2efcf7c15a083" --language nl

#date: 2021-08-12 - length:    52:16 - title: "Groene woestijn? - Martina Groenveld met Caroline van der Plas"
get_one "https://odysee.com/groene-woestijn----martina-groenveld-met-caroline-van-der-plas:2b24e8350b1d692eda397107fe842cd2673517c2" --language nl

#date: 2021-08-08 - length:    40:26 - title: "Liefdevol Rebelleren – Peter Toonen met Bart van Tongerlo"
get_one "https://odysee.com/liefdevol-rebelleren---peter-toonen-met-bart-van-tongerlo:55387dbd86d638e19840020265b5d927fbff6cc4" --language nl

#date: 2021-08-07 - length:    26:51 - title: ""Something American" -  Ad Nuis"
get_one "https://odysee.com/-something-american-----ad-nuis:bd46b6e7bcfbee1d7743a20db9a6b23971898a30" --language nl

#date: 2021-08-06 - length:    33:10 - title: "Actiejournaal - Hugo de Jonge voor de rechter gedaagd - Martina Groenveld met Wij de Ouders"
get_one "https://odysee.com/actiejournaal---hugo-de-jonge-voor-de-rechter-gedaagd---martina-groenveld-met-wij-de-ouders:5f6272ca7f585150ae183fdf24cac37d2677303d" --language nl

#date: 2021-08-06 - length:    25:51 - title: ""De lamgelegde staat, een herhaling" - Karel van Wolferen"
get_one "https://odysee.com/-de-lamgelegde-staat--een-herhaling----karel-van-wolferen:f85645f6914cb89d10c47e719a150170f00893e8" --language nl

#date: 2021-08-05 - length:    17:01 - title: "Actiejournaal week #31 - Sanne van Beek met Michel Reijinga"
get_one "https://odysee.com/actiejournaal-week-------sanne-van-beek-met-michel-reijinga:1b82bdbd9c86ca85a85d1285e7fa362bb99faf31" --language nl

#date: 2021-08-01 - length:    52:34 - title: "De oogst van de Angst - Peter Toonen met Willem Erné"
get_one "https://odysee.com/de-oogst-van-de-angst---peter-toonen-met-willem-ern-:aec93c6f631189b93235fc67127aa6c9e13009a0" --language nl

#date: 2021-08-01 - length:    16:32 - title: "Een volgende troef? CYBERAANVAL? KLIMAATLOCKDOWN? - Duncan Robles en Laura Hos"
get_one "https://odysee.com/een-volgende-troef--cyberaanval--klimaatlockdown----duncan-robles-en-laura-hos:77223ace7eaedc71ab9b16e7f843a36294e4bc36" --language nl

#date: 2021-07-31 - length:    56:17 - title: "Nederland is géén democratie - Erik van der Horst met Gideon van Meijeren"
get_one "https://odysee.com/nederland-is-g--n-democratie---erik-van-der-horst-met-gideon-van-meijeren:93d20ffbce32269fa207f54683cc8870f80605ea" --language nl

#date: 2021-07-31 - length:    56:17 - title: "Nederland is géén democratie - Erik van der Horst met Gideon van Meijeren"
get_one "https://odysee.com/nederland-is-g--n-democratie---erik-van-der-horst-met-gideon-van-meijeren:7e50e65525bfab4e59e92ebf80312d570605c241" --language nl

#date: 2021-07-30 - length:    19:08 - title: "Uitsluiting uitgesloten -  Erik van der Horst met Olaf Weller"
get_one "https://odysee.com/uitsluiting-uitgesloten----erik-van-der-horst-met-olaf-weller:11973cdff23c264a1c93421687dd9303cc6833a6" --language nl

#date: 2021-07-30 - length:  1:05:07 - title: "De dictatuur is uitgeroepen - Erik van der Horst met Pieter Stuurman"
get_one "https://odysee.com/de-dictatuur-is-uitgeroepen---erik-van-der-horst-met-pieter-stuurman:719f767e606ddec1b77ca3bf120592077e98b61b" --language nl

#date: 2021-07-25 - length:  1:22:57 - title: "5G: Niemand luistert! - Jan van Gils met Rob Verboog en Vera Verhagen"
get_one "https://odysee.com/-g--niemand-luistert----jan-van-gils-met-rob-verboog-en-vera-verhagen:244e1b3b0a327a1750153cb5c8f8e03721e60d09" --language nl

#date: 2021-07-23 - length:    41:59 - title: "Gezondheid een geheim? Wat BIG PHARMA je niet vertelt!"
get_one "https://odysee.com/gezondheid-een-geheim--wat-big-pharma-je-niet-vertelt-:0a5adf7769c3bb3f4a7e7962e47b58e3d0cf17a1" --language nl

#date: 2021-07-23 - length:    15:09 - title: "Actiejournaal week 29 - Sanne van Beek met Michel van Reijinga"
get_one "https://odysee.com/actiejournaal-week------sanne-van-beek-met-michel-van-reijinga:ee37b843a494c8aa832115652f36028c9ab63a76" --language nl

#date: 2021-07-21 - length:     5:35 - title: "Crisis Compilatie #7 - The Cyberattack"
get_one "https://odysee.com/crisis-compilatie------the-cyberattack:9826d6e32714ad06c6462138d6822d6200c27e80" --language nl

#date: 2021-07-21 - length:    25:14 - title: "Ode aan de vrienden van Weltschmerz - Erik van der Horst met Max von Kreyfelt"
get_one "https://odysee.com/ode-aan-de-vrienden-van-weltschmerz---erik-van-der-horst-met-max-von-kreyfelt:656e636414aff0928bc4d5811ec8c9ee106e525a" --language nl

#date: 2021-07-20 - length:  1:19:22 - title: "Fascisme zonder fascisten - Pieter Stuurman met René ten Bos"
get_one "https://odysee.com/fascisme-zonder-fascisten---pieter-stuurman-met-ren--ten-bos:4a0717f3df7c582d1acddc08e61b33c089b99906" --language nl

#date: 2021-07-16 - length:    50:08 - title: "Buitenlandse media over Russische ontwikkelingen - Marie Thérèse en Max von Kreyfeld"
get_one "https://odysee.com/buitenlandse-media-over-russische-ontwikkelingen---marie-th-r-se-en-max-von-kreyfeld:2c8400b4fed658b33d65d0ca0446ed407a9762f9" --language nl

#date: 2021-07-15 - length:    12:55 - title: "Actiejournaal week 28 - Daan van den Berg met Michel Reijinga"
get_one "https://odysee.com/actiejournaal-week------daan-van-den-berg-met-michel-reijinga:2bfb0d9bced5030f80b802c5c7d30684c74f52ac" --language nl

#date: 2021-07-14 - length:    51:31 - title: "The Great Reset is een 'zot boekske' - Martina Groenveld met Michael Verstraete"
get_one "https://odysee.com/the-great-reset-is-een--zot-boekske----martina-groenveld-met-michael-verstraete:3866e9dc8a841f28c262f9fb536247bc8e4d4403" --language nl

#date: 2021-07-13 - length:    34:10 - title: "COVID-19 is géén ebola! - Erik van der Horst met Tjerk de Haan"
get_one "https://odysee.com/covid----is-g--n-ebola----erik-van-der-horst-met-tjerk-de-haan:7ea99812453f42e570bd5bee80ffb1578f9040a9" --language nl

#date: 2021-07-12 - length:  1:40:34 - title: "Deutsche Bank #5 - 'Shadow Banking" - Arno Wellens"
get_one "https://odysee.com/deutsche-bank-------shadow-banking----arno-wellens:169cad7f8d16c6c2dc8fa2f4b7a593c8ee54d6cf" --language nl

#date: 2021-07-10 - length:  1:09:53 - title: "Dit is het einde van een beschaving - Kees van der Pijl & Karel van Wolferen"
get_one "https://odysee.com/dit-is-het-einde-van-een-beschaving---kees-van-der-pijl---karel-van-wolferen:60353461bbb4a5019a544ce3b81df3c4ee1c20ea" --language nl

#date: 2021-07-09 - length:    14:33 - title: "Pech, helaas... -  Ad Nuis"
get_one "https://odysee.com/pech--helaas-------ad-nuis:b2200979ae7c55bc428ef3ab1aea1f5de1773e4e" --language nl

#date: 2021-07-08 - length:    31:19 - title: "Is ons onderwijssysteem toe aan een reset? - Laila & Kees"
get_one "https://odysee.com/is-ons-onderwijssysteem-toe-aan-een-reset----laila---kees:93d39ebb3ea982c4a38d8594fd66bc626765f828" --language nl

#date: 2021-07-08 - length:    14:11 - title: "Actiejournaal week #27 - Martina Groenveld met Michel Rijinga"
get_one "https://odysee.com/actiejournaal-week-------martina-groenveld-met-michel-rijinga:22ba6151b99e9c4307e3e34660eac1ff7a27af2f" --language nl

#date: 2021-07-07 - length:    18:36 - title: "Karel van Wolferen - Gekaapte instituties - Gezond Verstand #19"
get_one "https://odysee.com/karel-van-wolferen---gekaapte-instituties---gezond-verstand----:9321e6e28a9e0cc8adb2a67fdf0cca64a60c65c7" --language nl

#date: 2021-07-07 - length:  1:02:14 - title: ""Ik kijk het nog even aan" - Ad Nuis met Nippy Noya"
get_one "https://odysee.com/-ik-kijk-het-nog-even-aan----ad-nuis-met-nippy-noya:737702f971f6f90d7a914ebfaf9c0f50aa50f6a9" --language nl

#date: 2021-07-06 - length:    15:33 - title: ""Het zal je kind maar zijn" - Anne-Marie Kroes en Frank Ruesink"
get_one "https://odysee.com/-het-zal-je-kind-maar-zijn----anne-marie-kroes-en-frank-ruesink:d9fc60e4da2b15908451124748177816be2fcbcb" --language nl

#date: 2021-07-05 - length:  1:16:26 - title: "Corona als koevoet - George van der Leeden met Daan de Wit"
get_one "https://odysee.com/corona-als-koevoet---george-van-der-leeden-met-daan-de-wit:5412b0e450d16d6e9141d2fdf10f4af275a36e04" --language nl

#date: 2021-07-04 - length:     5:30 - title: "Bocheltje | Ate de Jong"
get_one "https://odysee.com/bocheltje---ate-de-jong:85ee6c42fd59c6a432580f4b5a163fd9fa5b1219" --language nl

#date: 2021-07-04 - length:     5:30 - title: "Bocheltje | Ate de Jong"
get_one "https://odysee.com/bocheltje---ate-de-jong:0608e43fe76b727c5b46305c899e6f5e4560bf11" --language nl

#date: 2021-07-03 - length:  2:19:00 - title: "Kinder-vaccinatie Awareness Day"
get_one "https://odysee.com/kinder-vaccinatie-awareness-day:3bf36311a68296d70f210738f3f08691b73fedde" --language nl

#date: 2021-07-02 - length:  1:12:58 - title: "Pandemie van de Angst - Erik van der Horst met Kees van der Pijl"
get_one "https://odysee.com/pandemie-van-de-angst---erik-van-der-horst-met-kees-van-der-pijl:87bb6ee89899d28c9371b7da6a20d1fa051b228e" --language nl

#date: 2021-07-01 - length:    29:29 - title: "Weltschmerz Next - Tracking-code Turkije voorloper Vaccinpaspoort? - Laura Hos & Duncan Robles"
get_one "https://odysee.com/weltschmerz-next---tracking-code-turkije-voorloper-vaccinpaspoort----laura-hos---duncan-robles:516a771dc749fc2854b199c84d6725c55f4a1c00" --language nl

#date: 2021-07-01 - length:    15:46 - title: "Actiejournaal week #26 - Martina Groenveld met Michel Reijinga"
get_one "https://odysee.com/actiejournaal-week-------martina-groenveld-met-michel-reijinga:1b78d00c6c260d0519ef491cc6cce0920dffef6b" --language nl

#date: 2021-06-30 - length:    16:54 - title: "Vrijheid is niet onderhandelbaar - Erik van der Horst met Ghislen Nysten"
get_one "https://odysee.com/vrijheid-is-niet-onderhandelbaar---erik-van-der-horst-met-ghislen-nysten:2304e72ab50e6de9dea8f782cbb3f663fae1c3df" --language nl

#date: 2021-06-30 - length:    13:17 - title: "Actiejournaal  Special - Handen af van onze kinderen!"
get_one "https://odysee.com/actiejournaal--special---handen-af-van-onze-kinderen-:451a078c96877f603ae74593213307857f06455b" --language nl

#date: 2021-06-27 - length:    54:32 - title: "Het Rusland van Poetin is géén gevaar - Marie Thérèse ter Haar en Max von Kreyfelt"
get_one "https://odysee.com/het-rusland-van-poetin-is-g--n-gevaar---marie-th-r-se-ter-haar-en-max-von-kreyfelt:994d542a7411c1202ca4d72a5691cec323dce27a" --language nl

#date: 2021-06-27 - length:     3:28 - title: "Crisis Compilatie #2 - Opdat wij niet vergeten"
get_one "https://odysee.com/crisis-compilatie------opdat-wij-niet-vergeten:96e7985c13f10263846494854f185efb5bc96737" --language nl

#date: 2021-06-26 - length:  1:13:31 - title: "Coronadebat:  Kritiek vs Mainstream. Ab Gietelink met Maarten Keulemans en John Jansen van Galen #62"
get_one "https://odysee.com/coronadebat---kritiek-vs-mainstream--ab-gietelink-met-maarten-keulemans-en-john-jansen-van-galen----:a1caeebc36c50a90c425213ec2e19faa9b640124" --language nl

#date: 2021-06-25 - length:     3:52 - title: "De overheid lost al uw problemen op! - Frank Karsten"
get_one "https://odysee.com/de-overheid-lost-al-uw-problemen-op----frank-karsten:0c4a4d147b8e3797b71eb44b09c508dc5177de0d" --language nl

#date: 2021-06-25 - length:  1:06:36 - title: "€600.000.000 verdwenen! - Erik van der Horst met Pepijn van Houwelingen en Thierry Baudet"
get_one "https://odysee.com/------------verdwenen----erik-van-der-horst-met-pepijn-van-houwelingen-en-thierry-baudet:52373b86715b129017958b5d3ef2075cb66b25b1" --language nl

#date: 2021-06-24 - length:    54:45 - title: "De Snelweg naar bevrijding - George van der Leeden met Erik Boomsma"
get_one "https://odysee.com/de-snelweg-naar-bevrijding---george-van-der-leeden-met-erik-boomsma:6bcacb6f562e8f924adfc7c0503b3a8b271d967d" --language nl

#date: 2021-06-24 - length:    30:29 - title: "Actiejournaal week #25 - Martina Groenveld met Michel Rijenga en Sascha Beentjes"
get_one "https://odysee.com/actiejournaal-week-------martina-groenveld-met-michel-rijenga-en-sascha-beentjes:11e3aa597ecd196a5f873b8815e43c1263983e3d" --language nl

#date: 2021-06-24 - length:    19:16 - title: "De schaduw van de Wuhan Lab-fout in het Post-Coronatijdperk  - Ab Gietelink #61"
get_one "https://odysee.com/de-schaduw-van-de-wuhan-lab-fout-in-het-post-coronatijdperk----ab-gietelink----:7d239c388577628e66021b249e7cc568b4a06be3" --language nl

#date: 2021-06-22 - length:    32:18 - title: "Ik ga niet zitten huilen - Martina Groenveld met ‎Patrick Poetjet Kromowidjojo"
get_one "https://odysee.com/-ik-ga-niet-zitten-huilen-:d2d5476d32c9c7978dec58662933a16681a1aa4b" --language nl

#date: 2021-06-21 - length:    39:44 - title: "Zenderstraling leidt tot fysieke klachten - Jan van Gils met Maarten Spaargaren"
get_one "https://odysee.com/zenderstraling-leidt-tot-fysieke-klachten---jan-van-gils-met-maarten-spaargaren:adae5291c8e125c8b8bd90a35af4df4c873ba46e" --language nl

#date: 2021-06-17 - length:     5:52 - title: "Crisis Compilatie # 1  - Eerlijkheid is de eerste stap naar bevrijding"
get_one "https://odysee.com/crisis-compilatie--------eerlijkheid-is-de-eerste-stap-naar-bevrijding:7c45c50e994a0e791a4b257c9323f58a349040a1" --language nl

#date: 2021-06-17 - length:     4:54 - title: "Weltschmertz Next - Wat mogen wij niet zien? En waarom niet?"
get_one "https://odysee.com/weltschmertz-next---wat-mogen-wij-niet-zien--en-waarom-niet-:2b22e826cb587fb31e1b52c383911dbc18610892" --language nl

#date: 2021-06-17 - length:    27:29 - title: "Actiejournaal week #24"
get_one "https://odysee.com/actiejournaal-week----:bf9ae4a3bfe17a1457720788a4b20bad6521d0a1" --language nl

#date: 2021-06-15 - length:    38:25 - title: "Alle grote ideologieën verzanden in tirannie"
get_one "https://odysee.com/alle-grote-ideologie-n-verzanden-in-tirannie:cf973a02bcf20055599fd535fdff083aa6513ea0" --language nl

#date: 2021-06-13 - length:  1:12:35 - title: ""Kijk met een blije blik de wereld in" - Ad Nuis en Harry Slinger"
get_one "https://odysee.com/-kijk-met-een-blije-blik-de-wereld-in----ad-nuis-en-harry-slinger:74161d6676c3172a10e9db97107b1b363417d2d3" --language nl

#date: 2021-06-12 - length:  1:02:00 - title: "Westerse waarden zijn verdwenen -  Kees van der Pijl en Stan van Houcke"
get_one "https://odysee.com/westerse-waarden-zijn-verdwenen----kees-van-der-pijl-en-stan-van-houcke:98394697a679b1880cc10d8c89175d573764e08f" --language nl

#date: 2021-06-11 - length:    39:42 - title: "MKB-debat "Faciliteert het MKB zijn eigen ondergang?" (deel 3)"
get_one "https://odysee.com/mkb-debat--faciliteert-het-mkb-zijn-eigen-ondergang----deel---:a95df14debc573ab9f168a848e10c7caa42bf87c" --language nl

#date: 2021-06-10 - length:     9:49 - title: "Actiejournaal week #23 - Martina Groenveld met Michel Reijinga"
get_one "https://odysee.com/actiejournaal-week-------martina-groenveld-met-michel-reijinga:d2895cd099a3206953f9172f7fe3a45b0ec13b5d" --language nl

#date: 2021-06-10 - length:    33:53 - title: "MKB-debat "Faciliteert het MKB zijn eigen ondergang?" (deel 2)"
get_one "https://odysee.com/mkb-debat--faciliteert-het-mkb-zijn-eigen-ondergang----deel---:5ad3962795790222ee6e9a5eb0a9e497a79c207b" --language nl

#date: 2021-06-09 - length:    36:47 - title: "MKB-debat Deel 1: Faciliteert het MKB zijn eigen ondergang?"
get_one "https://odysee.com/mkb-debat-deel----faciliteert-het-mkb-zijn-eigen-ondergang-:bff5ae87f1cfb48ec6a689108d6f24416fb1bd31" --language nl

#date: 2021-06-08 - length:    50:18 - title: "#60 Carola, Kantelmoment en Fuck up. Ab Gietelink interviewt Luc Sala"
get_one "https://odysee.com/----carola--kantelmoment-en-fuck-up--ab-gietelink-interviewt-luc-sala:515e98081fc6fca2ddc87b6fd856efd2b60f9c11" --language nl

#date: 2021-06-08 - length:    45:59 - title: "Het grote Carola-Vaccinatiedebat (deel 2): Burgers slecht geïnformeerd over vaccinatie"
get_one "https://odysee.com/het-grote-carola-vaccinatiedebat--deel-----burgers-slecht-ge-nformeerd-over-vaccinatie:38da0e6c5c1852391198c810a432436d0fc22257" --language nl

#date: 2021-06-05 - length:    50:42 - title: "#1 Het grote Corona-Vaccinatiedebat: Geen reden om door te gaan met vaccineren"
get_one "https://odysee.com/---het-grote-corona-vaccinatiedebat--geen-reden-om-door-te-gaan-met-vaccineren:dff48b4689b6d5afbf02c6ad92f571939b51cae5" --language nl

#date: 2021-06-05 - length:    15:16 - title: "Actiejournaal week #22. Martina Groeneveld met Michel Reijinga"
get_one "https://odysee.com/actiejournaal-week------martina-groeneveld-met-michel-reijinga:51b75993930b6abe824cc6f0b35547d7d8b0a1bb" --language nl

#date: 2021-06-04 - length:    37:03 - title: "Robin Hood of charlatan? - Erik van der Horst met Pieter Knabben"
get_one "https://odysee.com/robin-hood-of-charlatan----erik-van-der-horst-met-pieter-knabben:393217a77125702f9ca9e771366893be84419218" --language nl

#date: 2021-06-02 - length:    44:41 - title: "Complete media wereldwijd kan prullenbak in - Bryan Roy met George van der Leeden"
get_one "https://odysee.com/complete-media-wereldwijd-kan-prullenbak-in---bryan-roy-met-george-van-der-leeden:ab7bc8d701ede794047126dccc2ee028e44cc640" --language nl

#date: 2021-06-01 - length:    47:46 - title: "Agenda 2030: Gezondheid als dwangmiddel - Jorn Luka met Pieter Stuurman"
get_one "https://odysee.com/agenda-------gezondheid-als-dwangmiddel---jorn-luka-met-pieter-stuurman:5553be8a226fcd910232289e9b7825bd08b4a31b" --language nl

#date: 2021-05-31 - length:  1:12:54 - title: "Ecologisch schandaal van de eeuw - biomassa - Marcel Crok met Fenna Swart"
get_one "https://odysee.com/ecologisch-schandaal-van-de-eeuw---biomassa---marcel-crok-met-fenna-swart:ab7596777b13683db5c68a5b1de625cd8dea89e1" --language nl

#date: 2021-05-30 - length:    14:16 - title: "Toespraak Palestina demonstratie 16 mei door Jaap Hamburger"
get_one "https://odysee.com/toespraak-palestina-demonstratie----mei-door-jaap-hamburger:02173cced841f2126a39fe89bb036e8092a2d8a6" --language nl

#date: 2021-05-29 - length:    55:49 - title: "Dit is Willem Engel – oordeel zelf"
get_one "https://odysee.com/dit-is-willem-engel---oordeel-zelf:adafd85d8107780ce20c68ad81c7ebcbfb11e3d3" --language nl

#date: 2021-05-28 - length:    29:28 - title: "De Nationaal Coördinator Terrorismebestrijding liegt - Ad Nuis"
get_one "https://odysee.com/de-nationaal-co-rdinator-terrorismebestrijding-liegt---ad-nuis:dd1da2b409120121489fc8776c0b1f677fe38fda" --language nl

#date: 2021-05-28 - length:    18:20 - title: "Actiejournaal week #21. Max von Kreyfelt met Michel Reijinga"
get_one "https://odysee.com/actiejournaal-week------max-von-kreyfelt-met-michel-reijinga:2736d0b37a1d8438cd797f87e5c57caa3d59a378" --language nl

#date: 2021-05-27 - length:    52:51 - title: "Lokaal verzet tegen 5G neemt toe - Jan van Gils met Carlo Fiscalini en Ruud Lammers"
get_one "https://odysee.com/lokaal-verzet-tegen--g-neemt-toe---jan-van-gils-met-carlo-fiscalini-en-ruud-lammers:95377b64d7152c68497ba009cd14290d342697fa" --language nl

#date: 2021-05-26 - length:  1:03:46 - title: "Komt er een nieuwe wereldoorlog? Kees van der Pijl en Stan van Houcke"
get_one "https://odysee.com/komt-er-een-nieuwe-wereldoorlog--kees-van-der-pijl-en-stan-van-houcke:784d6082d636a71fa192632f7607f287cc000916" --language nl

#date: 2021-05-25 - length:    28:09 - title: "Het omzeilen van censuur - Karel Beckman met Marc van den Broek"
get_one "https://odysee.com/het-omzeilen-van-censuur---karel-beckman-met-marc-van-den-broek:f63ffe015f513703cba2e49dc6e632cf469f0396" --language nl

#date: 2021-05-24 - length:    15:32 - title: "Column #59Ab Gietelink – Was de 5 mei poster echt zo fout?"
get_one "https://odysee.com/column----ab-gietelink---was-de---mei-poster-echt-zo-fout-:a661b3addec30f803a785545efca93c1953e9687" --language nl

#date: 2021-05-23 - length:    27:12 - title: "Testwet: einde van onze privacy en vrijheid - Karel Beckman met Bas Filippini"
get_one "https://odysee.com/testwet--einde-van-onze-privacy-en-vrijheid---karel-beckman-met-bas-filippini:b084764f7b8c8c6809fa273edf5c544a4b8db5e1" --language nl

#date: 2021-05-22 - length:    21:02 - title: "Column Ad Nuis – Johan Derksen lakei van vaccin-minister De Jonge?"
get_one "https://odysee.com/column-ad-nuis---johan-derksen-lakei-van-vaccin-minister-de-jonge-:f5c5de020c26478a8986bc06752209b3444f4955" --language nl

#date: 2021-05-21 - length:    13:48 - title: "Aktiejournaal week 20 met Michel Reijinga"
get_one "https://odysee.com/aktiejournaal-week----met-michel-reijinga:dc65fe7f85a6491a82b3af54dadfffe845365162" --language nl

#date: 2021-05-21 - length:  1:21:31 - title: "De universiteit als propagandamachine - Elze van Hamelen met Mark Crispin Miller"
get_one "https://odysee.com/de-universiteit-als-propagandamachine---elze-van-hamelen-met-mark-crispin-miller:6864f2ec3c8c105b17b84b530d7c15b6f3f62655" --language nl

#date: 2021-05-19 - length:    46:24 - title: ""Het enige waar we bang voor hoeven te zijn, is de angst zelf.""
get_one "https://odysee.com/20210505-Erik-Van-Der-Horst-Met-Nick-Hudson_forLBRY:525d99d9e99633cc745e80e218bc83ba16bfc366" --language nl

#date: 2021-05-18 - length:    52:34 - title: "'Hoe blijf je weerbaar in een informatie-oorlog?' - Fiona Zwart met Laura Slot"
get_one "https://odysee.com/-hoe-blijf-je-weerbaar-in-een-informatie-oorlog-----fiona-zwart-met-laura-slot:59497754d8030b2f3b8dcfc92c4b47e7fde782c4" --language nl

#date: 2021-05-17 - length:  1:03:22 - title: "De staat als het kwaad - James Roolvink met Robert Valentine"
get_one "https://odysee.com/de-staat-als-het-kwaad---james-roolvink-met-robert-valentine:c987b61f215617a6e124eb8b574b94e92a88bf90" --language nl

#date: 2021-05-16 - length:    16:17 - title: "Brief aan Mark Rutte: zullen we ruilen? - Ab Gietelink #58"
get_one "https://odysee.com/brief-aan-mark-rutte--zullen-we-ruilen----ab-gietelink----:d6b3e017d518784b21e4fe3fa1e9cfc2186d593a" --language nl

#date: 2021-05-15 - length:    31:23 - title: "We mogen niet meer samenkomen? Dus wel - Karel Beckman met Dennis Spaanstra"
get_one "https://odysee.com/we-mogen-niet-meer-samenkomen--dus-wel---karel-beckman-met-dennis-spaanstra:5ef48ff218ecac70e588263402a1c5458032a486" --language nl

#date: 2021-05-14 - length:    45:27 - title: "Windmolens zijn te stoppen! - Marcel Crok met advocaat Peter de Lange"
get_one "https://odysee.com/windmolens-zijn-te-stoppen----marcel-crok-met-advocaat-peter-de-lange:7e4f9c8d57eee40178323a1ddb973a1ab9cfd9ee" --language nl

#date: 2021-05-14 - length:    21:56 - title: "Zijn demonstranten terroristen? Ad Nuis"
get_one "https://odysee.com/zijn-demonstranten-terroristen--ad-nuis:0527ef6b46202e48cfbfbf0f25a8544c2629430e" --language nl

#date: 2021-05-13 - length:    31:18 - title: "Chaos, prutswerk of complot? Het wederhoor van Filemon Wesselink door Max von Kreyfelt"
get_one "https://odysee.com/chaos--prutswerk-of-complot--het-wederhoor-van-filemon-wesselink-door-max-von-kreyfelt:14facf555f6a5c423f2ad66ef81c3ac9cd459b42" --language nl

#date: 2021-05-13 - length:    18:22 - title: "Het AktieJournaal week #19 met Michel Reijinga"
get_one "https://odysee.com/het-aktiejournaal-week-----met-michel-reijinga:06ae9fc84c4525df3b88dd339d1171d36343aac8" --language nl

#date: 2021-05-12 - length:  1:04:32 - title: "Leugens over Oekraïne en MH17 - Elze van Hamelen met Ray McGovern"
get_one "https://odysee.com/leugens-over-oekra-ne-en-mh-----elze-van-hamelen-met-ray-mcgovern:12454650e365ef8c07248743af25f7a1db72b66a" --language nl

#date: 2021-05-11 - length:    48:55 - title: "Het einde van geld - Pieter Stuurman met Jorn Luka"
get_one "https://odysee.com/het-einde-van-geld---pieter-stuurman-met-jorn-luka:7e567b3de260b5ebf5eacf02dba9f44a9f3e0d11" --language nl

#date: 2021-05-10 - length:    17:04 - title: "Waar blijft de rechterlijke macht? - Juridisch Coronajournaal #9"
get_one "https://odysee.com/waar-blijft-de-rechterlijke-macht----juridisch-coronajournaal---:3fc0c65bd727a713a869e7d1a124fbcf9f787075" --language nl

#date: 2021-05-09 - length:  1:11:37 - title: "Het is geen ebola! We moeten snel terug naar normaal! - George van der Leeden met Wybren van Haga"
get_one "https://odysee.com/het-is-geen-ebola--we-moeten-snel-terug-naar-normaal----george-van-der-leeden-met-wybren-van-haga:1e8a2fa04ee85e176446635b0968c51595970975" --language nl

#date: 2021-05-08 - length:    46:48 - title: "Windmolens komen uw landschap ontsieren - Karel Beckman met Willem Joustra en Cyril Wentzel"
get_one "https://odysee.com/windmolens-komen-uw-landschap-ontsieren---karel-beckman-met-willem-joustra-en-cyril-wentzel:ac730b7ef83c5eb5cae118948e8adc5bddadf4ae" --language nl

#date: 2021-05-07 - length:    17:56 - title: "Mag arts je weigeren als je niet getest bent of geen mondkapje draagt? - Juridisch Coronajournaal #8"
get_one "https://odysee.com/mag-arts-je-weigeren-als-je-niet-getest-bent-of-geen-mondkapje-draagt----juridisch-coronajournaal---:74df811a94a33bf741e29dfb24e0cfb21845921d" --language nl

#date: 2021-05-06 - length:    52:15 - title: "Wat kun je doen om je te wapenen tegen de aankomende crisis? - Fiona Zwart met Elmer Hogervorst"
get_one "https://odysee.com/wat-kun-je-doen-om-je-te-wapenen-tegen-de-aankomende-crisis----fiona-zwart-met-elmer-hogervorst:28d9e6ffb82c49fc46ed0b6518be7a32a041f932" --language nl

#date: 2021-05-05 - length:  1:21:59 - title: "Het Echte Vrijheidsconcert 2021 -  Organisatie en presentatie Frank Ruesink"
get_one "https://odysee.com/het-echte-vrijheidsconcert---------organisatie-en-presentatie-frank-ruesink:f29d9ac00e02fe990ef1759280676aac90bf60a2" --language nl

#date: 2021-05-04 - length:     8:26 - title: "Moeten zorgverleners prikken? - Juridisch coronajournaal #7"
get_one "https://odysee.com/moeten-zorgverleners-prikken----juridisch-coronajournaal---:44673d4518a9511341473257c240b32b2ce2dd68" --language nl

#date: 2021-05-03 - length:    26:11 - title: "Het ‘Complot’ van Filemon Wesselink BNN/VARA - Max von Kreyfelt, Laura Hos en Duncan Robles"
get_one "https://odysee.com/het--complot--van-filemon-wesselink-bnn-vara---max-von-kreyfelt--laura-hos-en-duncan-robles:fba1d9b296ce49b6c87967f7c6597b717a53ed90" --language nl

#date: 2021-05-02 - length:  1:05:26 - title: "Naar een wereldregering - Pieter Stuurman met Jorn Lukaszczyk"
get_one "https://odysee.com/naar-een-wereldregering---pieter-stuurman-met-jorn-lukaszczyk:ce8a1f5fae1c0ef14de3b5660d8a302c1afcbada" --language nl

#date: 2021-05-01 - length:     3:41 - title: "De voordelen van vooroordelen - Frank Karsten"
get_one "https://odysee.com/de-voordelen-van-vooroordelen---frank-karsten:9dd261ef7ae4242f78ceb3f44dbe892acafd3fb0" --language nl

#date: 2021-05-01 - length:    26:44 - title: "Zorgmedewerkers spreken zich uit - Erik van de Horst"
get_one "https://odysee.com/zorgmedewerkers-spreken-zich-uit---erik-van-de-horst:f4bfc897bfbdf4eaf909857d39d10089120c6f04" --language nl

#date: 2021-04-30 - length:    21:23 - title: "De media in coronatijd: eenzijdig, laf en manipulatief - Ab Gietelink #57"
get_one "https://odysee.com/de-media-in-coronatijd--eenzijdig--laf-en-manipulatief---ab-gietelink----:1a1972bdd820ac29fc844a746f463f5ec1e33edb" --language nl

#date: 2021-04-29 - length:    18:57 - title: "Moeten werknemers zich laten testen? Mondkapje opdoen? Vaccineren? - Juridisch coronajournaal #6"
get_one "https://odysee.com/moeten-werknemers-zich-laten-testen--mondkapje-opdoen--vaccineren----juridisch-coronajournaal---:5fcbe866194da6d6d4e49e5485dbfc789c3a41e5" --language nl

#date: 2021-04-28 - length:    14:56 - title: "De Europese groene droom en de waterstofhype - Karel Beckman"
get_one "https://odysee.com/de-europese-groene-droom-en-de-waterstofhype---karel-beckman:c59311d7f844364964741f2281ef2bef55bb57b7" --language nl

#date: 2021-04-26 - length:    34:34 - title: "Must-see: Bom onder testbeleid - Frank Stadermann met Jeroen Pols"
get_one "https://odysee.com/must-see--bom-onder-testbeleid---frank-stadermann-met-jeroen-pols:89063737e18c4e52c373798fa1d2aa93a4679af0" --language nl

#date: 2021-04-25 - length:    15:11 - title: "Beschermt de wet tegen verplichte vaccinatie? - Juridisch Coronajournaal #5"
get_one "https://odysee.com/beschermt-de-wet-tegen-verplichte-vaccinatie----juridisch-coronajournaal---:a780639dafba1e87d13cba113f41fbf53f5b92fe" --language nl

#date: 2021-04-24 - length:     3:22 - title: "Gratis Geld - Frank Karsten"
get_one "https://odysee.com/gratis-geld---frank-karsten:8eb4e461712ccab0132134a91c96967646a6fe11" --language nl

#date: 2021-04-23 - length:    46:14 - title: "Zou Jezus het vaccin hebben genomen? - James Roolvink met Jaap Dieleman"
get_one "https://odysee.com/zou-jezus-het-vaccin-hebben-genomen----james-roolvink-met-jaap-dieleman:3e7f6338a668bfc2b8cf9c5a39bc700f41ee1e7f" --language nl

#date: 2021-04-22 - length:    27:44 - title: "Niet-gevaccineerden welkom! - Karel Beckman met Olaf Weller"
get_one "https://odysee.com/niet-gevaccineerden-welkom----karel-beckman-met-olaf-weller:71334c965391b30cbc4573b2df3748040b4e9af2" --language nl

#date: 2021-04-21 - length:    42:54 - title: "Moeder, geboeid, in cel gegooid - George van der Leeden met Mascha Sponselee"
get_one "https://odysee.com/moeder--geboeid--in-cel-gegooid---george-van-der-leeden-met-mascha-sponselee:b1a7a037706e46ab42e54e5d3584dd72d1661af4" --language nl

#date: 2021-04-21 - length:    23:22 - title: "Worden we supermensen? - Ad Nuis"
get_one "https://odysee.com/worden-we-supermensen----ad-nuis:97ef9fe43fb988c1fe0d67dcda806ab161552644" --language nl

#date: 2021-04-19 - length:    55:13 - title: "Vaccinatiepaspoort opmaat naar controlemaatschappij – Elze van Hamelen met Vera Sharav"
get_one "https://odysee.com/-nazi-moorden-begonnen-als-medisch-programma----elze-van-hamelen-met-vera-sharav:d407c0a4287e277e62f77b0e333c21d429875907" --language nl

#date: 2021-04-18 - length:    49:18 - title: "Coronabeleid: weer faalt centrale planning - Karel Beckman met Willem Cornax"
get_one "https://odysee.com/coronabeleid--weer-faalt-centrale-planning---karel-beckman-met-willem-cornax:b9e20b2bc6d372ed54b2ef5d769deb7c7321298a" --language nl

#date: 2021-04-17 - length:     3:22 - title: "Is democratie vrijheid? - Frank Karsten"
get_one "https://odysee.com/is-democratie-vrijheid----frank-karsten:d0624c1a83695cf2adae605897bdb71b31da6d44" --language nl

#date: 2021-04-17 - length:    16:53 - title: "Open brief aan het OMT - Ab Gietelink #56"
get_one "https://odysee.com/open-brief-aan-het-omt---ab-gietelink----:28cf32f4becf4fdbd018cb9c4f35f08425746e95" --language nl

#date: 2021-04-16 - length:  1:02:03 - title: "De 2e Kamer slaapt ... doet niets aan 5G | Jan van Gils met Rob van de Boom en Rob Verboog"
get_one "https://odysee.com/de--e-kamer-slaapt-----doet-niets-aan--g---jan-van-gils-met-rob-van-de-boom-en-rob-verboog:535d10f82273d141cf4d25585dfd0eba6f1cff36" --language nl

#date: 2021-04-15 - length:    49:01 - title: "“Laat kinderen voelen:  ik ben al goed zoals ik ben” - Maame Joses met Evelien Deiters"
get_one "https://odysee.com/-laat-kinderen-voelen---ik-ben-al-goed-zoals-ik-ben----maame-joses-met-evelien-deiters:0fa34062deb31563e635e6adf91c981872fe2f3a" --language nl

#date: 2021-04-14 - length:    30:21 - title: "“Avondklok geldt niet in de auto!” - Juridisch coronajournaal #4"
get_one "https://odysee.com/-avondklok-geldt-niet-in-de-auto-----juridisch-coronajournaal---:c416a596a6cd9e9316b59dfe93f01911db5dee20" --language nl

#date: 2021-04-13 - length:  1:23:38 - title: "Politie escaleert bewust - George van der Leeden met advocaat Bart Maes"
get_one "https://odysee.com/politie-escaleert-bewust---george-van-der-leeden-met-advocaat-bart-maes:23b08184620e7d27ac1039d7e09cbf88e7463bae" --language nl

#date: 2021-04-11 - length:    22:32 - title: "Juridisch coronajournaal #3: “Basisschool niet verplicht maatregelen te volgen”"
get_one "https://odysee.com/juridisch-coronajournaal------basisschool-niet-verplicht-maatregelen-te-volgen-:1a1c693683f774cf65b04480ebfe6bc68b09b0b4" --language nl

#date: 2021-04-10 - length:    34:55 - title: "MKB terug naar lonen uit 19e eeuw - Richard Beune met Pancras Pouw"
get_one "https://odysee.com/mkb-terug-naar-lonen-uit---e-eeuw---richard-beune-met-pancras-pouw:676d50ffc6b3a3a7f10017ba4e1455c6a905ba1d" --language nl

#date: 2021-04-09 - length:    50:24 - title: "Wordt rechtszaak wietolie keerpunt? - Sander Compagner met Rinus Beintema"
get_one "https://odysee.com/wordt-rechtszaak-wietolie-keerpunt----sander-compagner-met-rinus-beintema:189010c88beee22ff4b22321c1acdb1097525f64" --language nl

#date: 2021-04-08 - length:    54:27 - title: "“Rutte is menselijkheid kwijt” - George van der Leeden met Ghislen Nysten"
get_one "https://odysee.com/-rutte-is-menselijkheid-kwijt----george-van-der-leeden-met-ghislen-nysten:a2b3df1fe47c007bbaa027af908d4453e986f3ea" --language nl

#date: 2021-04-06 - length:  1:06:55 - title: "Deskundigen luiden noodklok: onze kinderen moeten hun jeugd terugkrijgen!"
get_one "https://odysee.com/deskundigen-luiden-noodklok--onze-kinderen-moeten-hun-jeugd-terugkrijgen-:125a095c143488b3e449883519e9e365fa503df0" --language nl

#date: 2021-04-03 - length:    18:11 - title: "#55 Ab Gietelink Brief van het Museumplein aan Burgemeester Femke Lukashenko"
get_one "https://odysee.com/----ab-gietelink-brief-van-het-museumplein-aan-burgemeester-femke-lukashenko:74641219cfaaca5fe7cd6263fd1ea78334f42504" --language nl

#date: 2021-03-31 - length:    21:22 - title: "We zouden het niet meer moeten pikken - Ad Nuis"
get_one "https://odysee.com/we-zouden-het-niet-meer-moeten-pikken---ad-nuis:cfe07931e3dd0861ef85f757aa19756a31e8db64" --language nl

#date: 2021-03-31 - length:  1:11:22 - title: "Techno-fascisten voeren oorlog tegen het volk - Pieter Stuurman met Ullrich Mies"
get_one "https://odysee.com/techno-fascisten-voeren-oorlog-tegen-het-volk---pieter-stuurman-met-ullrich-mies:6a794d999daad711ff85829b86857c961287829c" --language nl

#date: 2021-03-28 - length:    46:18 - title: "Waakzaam en dienstbaar - voor wie? George van der Leeden met Dennis Spaanstra"
get_one "https://odysee.com/waakzaam-en-dienstbaar---voor-wie--george-van-der-leeden-met-dennis-spaanstra:ea56babe60c872d1bf861dc386263f1e7e5a730b" --language nl

#date: 2021-03-26 - length:  1:09:05 - title: "In het gelid voor vrijheid | James Roolvink met veteranen Ard Daniëls en Madhu Kasi"
get_one "https://odysee.com/in-het-gelid-voor-vrijheid---james-roolvink-met-veteranen-ard-dani-ls-en-madhu-kasi:1aad476c36f22d53dcf3157af1fe0e9c74bc633b" --language nl

#date: 2021-03-25 - length:  1:02:13 - title: "5G: einde van de privacy | Karel Beckman met Jan van Gils en Elze van Hamelen"
get_one "https://odysee.com/-g--einde-van-de-privacy---karel-beckman-met-jan-van-gils-en-elze-van-hamelen:75598632481ccda07cae500583a0925583fc085b" --language nl

#date: 2021-03-22 - length:    35:20 - title: "Dit loopt spaak! | Richard Beune met Lucas Hartong"
get_one "https://odysee.com/dit-loopt-spaak----richard-beune-met-lucas-hartong:54f6fe7dc7cafcf76e4cf3ba76b860ae661b6501" --language nl

#date: 2021-03-21 - length:    44:40 - title: "Gevangen in de klimaatfuik | Karel Beckman met Marcel Crok"
get_one "https://odysee.com/Gevangen-in-de-klimaatfuik-_-Karel-Beckman-met-Marcel-Crok:2a77250b3beb01279b0bac90f3b17992e7c3692a" --language nl

#date: 2021-03-19 - length:    17:10 - title: "De overheid als drugsdealer | Ad Nuis"
get_one "https://odysee.com/De-overheid-als-drugsdealer-_-Ad-Nuis:a84fcc38e037ab9bede47437bc3311c889ba2de9" --language nl

#date: 2021-03-18 - length:  1:25:54 - title: "Een andere weg uit de crisis (deel 3) | James Roolvink met Hans Siepel"
get_one "https://odysee.com/een-andere-weg-uit-de-crisis--deel------james-roolvink-met-hans-siepel:633c274e5e7298214f9d7d454fa9b89304df8b21" --language nl

#date: 2021-03-15 - length:  1:02:33 - title: "Crisis in de jeugdzorg | Rudie Kagie met Hélène van Beek"
get_one "https://odysee.com/crisis-in-de-jeugdzorg---rudie-kagie-met-h-l-ne-van-beek:06c1354f5e861400d607741ac20e24887a3d4ab2" --language nl

#date: 2021-03-14 - length:    17:35 - title: "Wilde Zwerfkatten | Ate de Jong"
get_one "https://odysee.com/Wilde-Zwerfkatten-_-Ate-de-Jong:2f811167ca880bc6e016319d6cace31637a4d031" --language nl

#date: 2021-03-13 - length:    24:37 - title: "Kritiek op corrupte WHO taboe | Karel Beckman met Cees Hamelink"
get_one "https://odysee.com/Kritiek-op-corrupte-WHO-taboe-_-Karel-Beckman-met-Cees-Hamelink:1e7716569b1846bc02afa55aa1ef579434ef8524" --language nl

#date: 2021-03-13 - length:  1:15:35 - title: "Een andere weg uit de crisis (2) | James Roolvink en Hans Siepel"
get_one "https://odysee.com/LZVPEUl6AqQ:70afa3b5027d2aac6bb024f9463a4ceee2b00c24" --language nl

#date: 2021-03-09 - length:    54:18 - title: "Falende media bij krakersrellen en coronacrisis | Ab Gietelink met Stan van Houcke"
get_one "https://odysee.com/falende-media-bij-krakersrellen-en:b14d52e138d870b3e545c597af3c8959e90fb144" --language nl

#date: 2021-03-07 - length:     7:29 - title: "Wachten | Ate de Jong"
get_one "https://odysee.com/wachten-ate-de-jong:9a91d76bceedf774e4ac35f7af737a5ad07c3e7f" --language nl

#date: 2021-03-06 - length:  1:01:03 - title: "Rappen voor het FVD | James Roolvink met Duncan van Wijk en Lars de Vries"
get_one "https://odysee.com/rappen-voor-het-fvd-james-roolvink-met:72ab918408a241f8c72e1e7f458d4bec94ad3489" --language nl

#date: 2021-03-05 - length:    36:31 - title: "Misleiding over mondkapjes | James Roolvink met Karel Beckman en Daniel Pardoen"
get_one "https://odysee.com/misleiding-over-mondkapjes-james:c98a801e6d705597219542ad866bed1207cc99f2" --language nl

#date: 2021-03-03 - length:    41:40 - title: "Stop verval democratische rechtsstaat | Karel Beckman met Guus Berkhout"
get_one "https://odysee.com/karel-beckman-met-guus-berkhout-stop:c9c7cb66319697dfd295bf3d6a4cb1a23e06bcc8" --language nl

#date: 2021-03-02 - length:  1:12:42 - title: "Een andere weg uit de crisis (1) - James Roolvink en Hans Siepel"
get_one "https://odysee.com/een-andere-weg-uit-de-crisis-1-james:ba89694790fbf46f5db4251fb42b2f52514a969c" --language nl

#date: 2021-02-28 - length:    16:30 - title: "Verdwaald schilderij | Ate de Jong"
get_one "https://odysee.com/verdwaald-schilderij-ate-de-jong:753a6d2649b9a272bc49727c0e733fdfc318d0a5" --language nl

#date: 2021-02-27 - length:  1:04:42 - title: "Het OMT ontspoord | James Roolvink met Jan Huurman, bedenker van het OMT"
get_one "https://odysee.com/het-omt-ontspoord-james-roolvink-met-dr:cfe0f8b3c3308130daeb0d9e052fbdfd65d4c32a" --language nl

#date: 2021-02-25 - length:    18:46 - title: "Ad Nuis - Onze kinderen zijn proefkonijnen"
get_one "https://odysee.com/ad-nuis-onze-kinderen-zijn-proefkonijnen:c6889f2535ade8cf4fc5936428601dc57251a8c5" --language nl

#date: 2021-02-24 - length:    29:35 - title: "Pleitnota Viruswaarheid: wat het kabinet doet, kan niet"
get_one "https://odysee.com/pleitnota-viruswaarheid-wat-het-kabinet:c468d3d1748699eeff9cf5ab5d17239add04dedd" --language nl

#date: 2021-02-24 - length:    19:41 - title: "Nederland open op 2 maart? – Karel Beckman met Jeroen Pols"
get_one "https://odysee.com/nederland-open-op-2-maart-karel-beckman:b4068846f2bf1da6933a3e1aa1b6e25f4675494f" --language nl

#date: 2021-02-19 - length:    30:46 - title: "Mark, nodig me uit! | Richard Beune met Maurice de Hond"
get_one "https://odysee.com/mark-nodig-me-uit-richard-beune-met:6234f577667abf4a66d2599739debd9205d0397c" --language nl

#date: 2021-02-19 - length:    13:08 - title: "Open brief aan Mark | Maurice de Hond"
get_one "https://odysee.com/open-brief-aan-mark-maurice-de-hond:dd4604a195e5f792f381b44ae09bfcec2793e7f4" --language nl

#date: 2021-02-18 - length:    33:00 - title: "Uitspraak Avondklok | Joris de Wilde en Willem Engel"
get_one "https://odysee.com/20210217---Joris-de-Wilde-en-Willem-Engel:34466f931d9dff99a13abf13a32656378def6e3d" --language nl

#date: 2021-02-16 - length:    29:12 - title: "Medisch groepsdenken - Michiel de Jong met Giliam Kuijpers"
get_one "https://odysee.com/20210129---Michiel-de-Jong-en-Giliam-Kuijpers:cda396793c0dce2aad1fa41ead5c44f80b5a5389" --language nl

#date: 2021-02-13 - length:    19:44 - title: "Het Juridisch Corona Journaal #2 -  Isa Kriens en Frank Stadermann"
get_one "https://odysee.com/Het-Juridisch-Corona-Journaal--2----Isa-Kriens-en-Frank-Stadermann:d827a3f8ff86b57bc2bd66cba6fb5c54615a4f12" --language nl

#date: 2021-02-12 - length:    34:55 - title: "Armoede en de menselijke maat | Pim Giel met Will Roode, beroepsvrijwilliger"
get_one "https://odysee.com/armoede-en-de-menselijke-maat-pim-giel-2:e6b1c196ba663f684892333498a4c6cec0435710" --language nl

#date: 2021-02-11 - length:     9:44 - title: "Dame Blanche | Ate de Jong"
get_one "https://odysee.com/dame-blanche-ate-de-jong:13488ab35edd22b85161105ec9cdc7cf2e4a1a11" --language nl

#date: 2021-02-11 - length:    26:04 - title: "Het Juridisch Corona Journaal #1 - Isa Kriens met Frank Stadermann"
get_one "https://odysee.com/20210203---Isa-Kriens-en-Frank-Stadermann---deel-1:c310884fcd0168e1f76a9127807473f6dbde7ae6" --language nl

#date: 2021-02-09 - length:    22:40 - title: "Ad Nuis - een permanente brandoefening"
get_one "https://odysee.com/Ad-Nuis---een-permanente-brandoefening:174ca4f0f0cb3d5d9b829d7b824c55452a2a8d64" --language nl

#date: 2021-02-07 - length:     9:51 - title: "#51 AB GIETELINK I PERFORMANCE OVER AVONDKLOK, SPREEKTAAL EN QUARANTAINE FACILITEIT"
get_one "https://odysee.com/-51-AB-GIETELINK-I-PERFORMANCE-OVER-AVONDKLOK,-SPREEKTAAL-EN-QUARANTAINE-FACILITEIT:c2efd8199db4cfad100ee50bbdf5217598f90a58" --language nl

#date: 2021-02-07 - length:    16:06 - title: "Cher, ma chère | Ate de Jong"
get_one "https://odysee.com/20201231---Ate-de-Jong---Cher,-ma-chere:b4cd8383e58cb76939805562ea89b5a93adfbb19" --language nl

#date: 2021-02-06 - length:    56:51 - title: "Parallelle samenleving - Pieter Stuurman met Ad Broere"
get_one "https://odysee.com/cher-ma-ch-re-ate-de-jong:d8206a4add5a633cf00dbd36b5554c38e196117b" --language nl

#date: 2021-02-03 - length:    36:17 - title: "Redt de burgerjournalistiek de democratie? | Michiel de Jong en Paul de Bruijn"
get_one "https://odysee.com/20210119---Michiel-de-Jong-en-Paul-de-Bruijn:84c83b44138b69c4b18290a6ecccf7aae57d4967" --language nl

#date: 2021-02-02 - length:  1:44:58 - title: "Het sprookje van 2021 | Frank Stadermann, Sven Ake Hulleman en Jeroen Pols"
get_one "https://odysee.com/20210112---Ton-Kuik-met-Frank-Stadermann,-Sven-Ake-Hulleman-en-Jeroen-Pols:c9a63f20ff6ccee30d0c49fb6178d0569551661e" --language nl

#date: 2021-02-01 - length:    50:45 - title: "Armoede en de menselijke maat  | Pim Giel met Hilde Latour"
get_one "https://odysee.com/armoede-en-de-menselijke-maat-pim-giel:d7ae7b9fe880791d596b8fc20269d5e7f6ec7bea" --language nl

#date: 2021-01-31 - length:    49:47 - title: "Informed consent voor een medisch experiment | Jorn Lukaszczyk met Elke de Klerk en Arno van Kessel"
get_one "https://odysee.com/intro-informed-consent-medisch:6993224cb4a641913d7ca5374ffd6e9e8f0579a1" --language nl

#date: 2021-01-28 - length:    16:30 - title: "'Je suis Wappie' | Ab Gietelink"
get_one "https://odysee.com/20210122-_-Column-Ab-Gietelink-(Publicatie-Wo-2021-01-27):31cfb6f24994a80dd9e7e401ab9ad306e9b2e187" --language nl

#date: 2021-01-22 - length:    47:47 - title: "De Aanval op de Horeca | Ab Gietelink met Barry van den Berg en René Pluijm"
get_one "https://odysee.com/20201222---Ab-Gietelink-met-Barry-van-den-Berg-en-Rene-Pluim---Compressed:8c2ea032b03db644c2577b9fc9988379585b1137" --language nl

#date: 2021-01-21 - length:  1:05:06 - title: "The Great Reset, mensen weten wel beter! | Pieter Stuurman en Filip van Houte"
get_one "https://odysee.com/Interview-Pieter-Stuurman-Filip-Van-Houten:d9e17b06dfd043d8d9f8adab4c6f79ee0fe3a5c2" --language nl

#date: 2021-01-20 - length:    30:37 - title: "Ad Nuis: Alles is fake news"
get_one "https://odysee.com/20210108---Pieter-Stuurman---Karel-van-Wolferen-LBRY:98f42b7388612ee4be15ce234547be328eedb50a" --language nl

#date: 2021-01-18 - length:    43:00 - title: "Internet brengt ons terug naar de middeleeuwen | Pieter Stuurman met Frans van der Reep"
get_one "https://odysee.com/internet-brengt-ons-terug-naar-de:6660fad0854753493b5a3893d94bd2d76e0fba05" --language nl

#date: 2021-01-08 - length:  2:22:51 - title: "Verboden Jaaroverzicht 2020 - Alles wat je niet mocht weten in 2020"
get_one "https://odysee.com/Verboden-Jaaroverzicht-2020:0d7478ec1756d025ae6adcfe405f4e23578ee69c" --language nl

#date: 2021-01-03 - length:    37:29 - title: "Ademvrijbijmij.nl biedt ondernemers lucht. Jorn Lukaszczyk in gesprek met Olaf Weller."
get_one "https://odysee.com/ademvrijbijmij-nl-biedt-ondernemers:846f878f5628debdd484d31a2fed379625b257d3" --language nl

#date: 2020-12-29 - length:    31:35 - title: "#46 De beschadiging vd jeugd. Ab Gietelink met Renate Tillema, Maartje vd Berg en Aarjan Bergshoeff."
get_one "https://odysee.com/46-de-beschadiging-vd-jeugd-ab-gietelink:9b3a68ac6598cd4a723b08716a9a3a235983933a" --language nl

#date: 2020-12-27 - length:    41:24 - title: "Armoede, de menselijke maat. Pim Giel in gesprek met Grietje Bouw."
get_one "https://odysee.com/armoede-de-menselijke-maat-pim-giel-in:5714c69898fcfa9f5c00a62827d019e483ee84b1" --language nl

#date: 2020-12-26 - length:    39:39 - title: "Angstcultuur op scholen door mondkapjes -  Karel Beckman met Daniel Pardoen en Nicole ter Borgh"
get_one "https://odysee.com/Angstcultuur-op-scholen-door-mondkapjes---Karel-Beckman-met-Daniel-Pardoen-en-Nicole-ter-Borgh:4471bb621a58cecd618070e8bd16cd35c7cf5dd2" --language nl

#date: 2020-12-25 - length:    36:56 - title: "'Stephanie Lonkt Weer.' Column van Ad Nuis."
get_one "https://odysee.com/stephanie-lonkt-weer-column-van-ad-nuis:22bccda35ac703621020e41245dafd2f98625f77" --language nl

#date: 2020-12-25 - length:    17:07 - title: "#48 Kerstboodschap van de nieuwe Minister-President I Ab Gietelink"
get_one "https://odysee.com/48-kerstboodschap-van-de-nieuwe-minister:bc430f8eaae357d7ca0793692af7d309c7fbfe51" --language nl

#date: 2020-12-23 - length:    47:43 - title: "#45 Pandemie van de Angst I  Ab Gietelink in gesprek met Kees van der Pijl."
get_one "https://odysee.com/45-pandemie-van-de-angst-i-ab-gietelink:c702d3a75ed89ad5d2d864682556c553762e9472" --language nl

#date: 2020-12-23 - length:    29:15 - title: "Wat niet verteld wordt over het C-vaccin. Frank Reusink en Del Bigtree (deel 1)"
get_one "https://odysee.com/wat-niet-verteld-wordt-over-het-c-vaccin:68c76afa45f9818e34da9772873fd389e4e8463e" --language nl

#date: 2020-12-22 - length:  1:03:24 - title: "Wat betekent 'The Great Reset' voor de burger? Rein de Vries en Fiona Zwart"
get_one "https://odysee.com/wat-betekent-the-great-reset-voor-de:85a5acbdb1eb381dd35cea1b006427b3a060f635" --language nl

#date: 2020-12-20 - length:    12:51 - title: "#44 Ab Gietelink I Satirische Corona Encyclopedie"
get_one "https://odysee.com/44-ab-gietelink-i-satirische-corona:790dae48729276027981e75b1d80b671bcac9b3b" --language nl

#date: 2020-12-19 - length:  1:38:16 - title: "Weltschmerz Academy | Spelen politici voor God? | Pedro Kuit en ToN Kuik"
get_one "https://odysee.com/weltschmerz-academy-spelen-politici-voor:75643210f3cf3dadd02e25d781ad3775eeba6f9c" --language nl

#date: 2020-12-16 - length:  1:05:50 - title: "Race tegen infecties | Ton Kuik en  Michael Bleekemolen"
get_one "https://odysee.com/race-tegen-infecties-ton-kuik-en-michael:bd58670f5dc4736975d6bdd1763288e9e1288559" --language nl

#date: 2020-12-15 - length:     4:36 - title: "Dutch Guerilla Mask Force | Witte Pakken Mars"
get_one "https://odysee.com/dutch-guerilla-mask-force-witte-pakken:b4f27ee7440cbdf00bbe65f2e9d39e817fcf394c" --language nl

#date: 2020-12-13 - length:  1:08:17 - title: "Komt er een volksopstand? Sid Lukkassen en Joost Niemöller"
get_one "https://odysee.com/komt-er-een-volksopstand-sid-lukkassen:de228ec9b5324058c48f94080fdeb9b58440e2c5" --language nl

#date: 2020-12-12 - length:    38:35 - title: "Weg met de koning? Floris Müller en Pieter Verhoeve."
get_one "https://odysee.com/weg-met-de-koning-floris-m-ller-en:cc5819b6dcab58105b8b5d0ac977cd32a93b9411" --language nl

#date: 2020-12-10 - length:    40:27 - title: "#43 Media weigert ‘COVID 19’ documentaire. Ab Gietelink, Nico Sloot en Belgin Inal."
get_one "https://odysee.com/43-media-weigert-covid-19-documentaire:29ad9174d4a3eb4f1ce662881c23be6b31342461" --language nl

#date: 2020-12-09 - length:  1:08:33 - title: "De menselijke maat in gezondheidszorg | documentaire van Pim Giel."
get_one "https://odysee.com/de-menselijke-maat-in-gezondheidszorg:c325cb2271e20c9dfcb254852313bd8adc1bb09f" --language nl

#date: 2020-12-08 - length:  1:09:05 - title: "Onthullend telefoongesprek met RIVM. Fiona Zwart met Peter Grootwagers en Ferdinand van der Neut."
get_one "https://odysee.com/onthullend-telefoongesprek-met-rivm:d7d5b9325b2803771bb03b25193665569631154e" --language nl

#date: 2020-12-06 - length:    44:00 - title: ""Bill Gates is a problem" - Karel Beckman and Roger W. Koops"
get_one "https://odysee.com/bill-gates-is-a-problem-karel-beckman:41fd3bbba2bad203e87337d81936361976fbcc27" --language nl

#date: 2020-12-05 - length:    59:41 - title: "#42 Is de 'Coronastorm fascistisch?' Prof. René ten Bos en Ab Gietelink"
get_one "https://odysee.com/42-is-de-coronastorm-fascistisch-prof:3ef02b8a1459d8aef3f1ab613dc7f500b1fb019b" --language nl

#date: 2020-12-04 - length:    43:43 - title: "Angst en humor in coronatijd | Pieter Stuurman met Paul Smit"
get_one "https://odysee.com/angst-en-humor-in-coronatijd-pieter:c5dda9cf18b08643170d073f6af80552651e36e7" --language nl

#date: 2020-12-03 - length:  1:17:30 - title: "RIVM en de ‘veiligheid’ van vaccinatie | Joris Baas en Door Frankema"
get_one "https://odysee.com/rivm-en-de-veiligheid-van-vaccinatie:614df5c6a1ed4380834710c379dca036a84e86ad" --language nl

#date: 2020-12-01 - length:     4:07 - title: "Mysterieuze, kunstzinnige protestmars in Nederland | Guerilla Mask Force"
get_one "https://odysee.com/mysterieuze-kunstzinnige-protestmars-in:9c640087f8dedbb98dd667456c46f88547815c31" --language nl

#date: 2020-11-30 - length:    55:02 - title: "For the Motherland - Sass Rogando Sasot and Max van den Werff"
get_one "https://odysee.com/for-the-motherland-sass-rogando-sasot:379a9c95a907934ec44e8a0d0e627805eaa7f0b6" --language nl

#date: 2020-11-30 - length:    23:54 - title: "Vaccineren doe je zo | column Ad Nuis"
get_one "https://odysee.com/vaccineren-doe-je-zo-column-ad-nuis:971dfa3d9b856012962c7acd662b61fef6e5a92e" --language nl

#date: 2020-11-29 - length:  1:00:24 - title: "Pedo's in het nauw | Rudie Kagie met Carine Hutsebaut"
get_one "https://odysee.com/pedo-s-in-het-nauw-rudie-kagie-met:0db71e0d3d1434010946bc680e98ac37efc836b6" --language nl

#date: 2020-11-28 - length:    45:20 - title: "#40 Media-oorlog in Coronatijd | Ab Gietelink met professor Cees Hamelink"
get_one "https://odysee.com/40-media-oorlog-in-coronatijd-ab:2c0c12ae33f13da571e453d6a181a4e63f889b95" --language nl

#date: 2020-11-27 - length:    33:35 - title: "Beroepsethiek medici onder zware druk | Pieter Stuurman en Berber Pieksma."
get_one "https://odysee.com/beroepsethiek-medici-onder-zware-druk:7a0270c8874d997ca5d4a2acbb3f6ccd58271ee4" --language nl

#date: 2020-11-26 - length:  1:06:53 - title: "Het PCR-doek valt’ | Peter Borger en Jorn Lukaszczyk"
get_one "https://odysee.com/het-pcr-doek-valt-peter-borger-en-jorn:7681960d59c114b3de930bd592e1eb051ef57f58" --language nl

#date: 2020-11-25 - length:    26:22 - title: "Studenten staan op voor hun toekomst. Fiona Zwart met Laura Hos en Steven de Oude."
get_one "https://odysee.com/studenten-staan-op-voor-hun-toekomst:f8e285bd17554f19528456e917e50dd73e2bf510" --language nl

#date: 2020-11-24 - length:    46:10 - title: "Gaat Viruswaarheid de politiek in? Ab Gietelink, Willem Engel en Jeroen Pols."
get_one "https://odysee.com/gaat-viruswaarheid-de-politiek-in-ab:733fcf1b02b9bd55a7c0a7d3b142ce4e509a01e8" --language nl

#date: 2020-11-22 - length:    18:13 - title: "#37 Persconferentie van de nieuwe Premier I Ab Gietelink"
get_one "https://odysee.com/37-persconferentie-van-de-nieuwe-premier:be9ba88e9dd6d45a554956c29d8646b6dcb32d0f" --language nl

#date: 2020-11-21 - length:    43:44 - title: "'Politiek debat wordt dialoog' | Wassila Hachchi en Fiona Zwart"
get_one "https://odysee.com/politiek-debat-wordt-dialoog-wassila:5fd7bc45f15e9d74b3fdc12757440e28b894182b" --language nl

#date: 2020-11-20 - length:  1:08:09 - title: "Ontwaken uit de massahypose. Fiona Zwart in gesprek met Edwin Selij"
get_one "https://odysee.com/ontwaken-uit-de-massahypose-fiona-zwart:eac46c41e6b6589d7b576d10d25756b2ac2924fa" --language nl

#date: 2020-11-19 - length:    50:54 - title: "De pandemie van depressie. Jorn Lukaszczyk met Jef Eagle."
get_one "https://odysee.com/de-pandemie-van-depressie-jorn:24656d25cd215bcb89aae44b52bf383e27a61bae" --language nl

#date: 2020-11-18 - length:    25:53 - title: "Mijn moeder en het “Sirus” | column Ad Nuis"
get_one "https://odysee.com/mijn-moeder-en-het-sirus-column-ad-nuis:8c5ea6f9fa9e9de2cde658ba25f16557b40292d1" --language nl

#date: 2020-11-17 - length:    31:18 - title: "Chaos en verdeeldheid in de VS | Pim van Galen, Hans Kriek en Guy Penard."
get_one "https://odysee.com/chaos-en-verdeeldheid-in-de-vs-pim-van:a8231c1ea5a3de0fae197a9b70bdf0dd845b1bd7" --language nl

#date: 2020-11-16 - length:    36:36 - title: "Pandemie van slaafsheid en zelfonderschatting | Fiona Zwart in gesprek met Pieter Stuurman."
get_one "https://odysee.com/pandemie-van-slaafsheid-en:ff3fc372acbc4b3c5f06cef9f20be6660aa9c5e1" --language nl

#date: 2020-11-14 - length:  1:05:02 - title: "De macht (en kracht) van propaganda | Sietske Bergsma en Jorn Lukaszczyk"
get_one "https://odysee.com/de-macht-en-kracht-van-propaganda:ce4c631cb1d4a94af289788601098517b2250423" --language nl

#date: 2020-11-13 - length:    41:48 - title: "#39 Ab Gietelink I  Tunnelvisies in de Media tijdens Coronadictatuur"
get_one "https://odysee.com/39-ab-gietelink-i-tunnelvisies-in-de:75fc3a151c538d2a19d366a81f0a41519bfae9f9" --language nl

#date: 2020-11-12 - length:    29:45 - title: "Licht in het donker. Fiona Zwart in gesprek met 'De Vrouwen voor Vrijheid', Sascha, Romy en Romy."
get_one "https://odysee.com/licht-in-het-donker-fiona-zwart-in:7013b0ce28c979b4e1870cd28ab9f14c8b2eb159" --language nl

#date: 2020-11-10 - length:    53:08 - title: "Medicijngebruik verzwakt natuurlijke vitaliteit | Fiona Zwart en drs.Richard de Leth."
get_one "https://odysee.com/medicijngebruik-verzwakt-natuurlijke:5936d5fa81c160fa9f544bc32a63848b6af3dc6d" --language nl

#date: 2020-11-08 - length:    53:31 - title: "‘Het geloof in het systeem verloren’,  Jorn Lukaszczyk en Lawrence Jacobs"
get_one "https://odysee.com/het-geloof-in-het-systeem-verloren-jorn:20e6acbf9995ce714fd5ba46a2e52623d6d820a8" --language nl

#date: 2020-11-07 - length:    48:34 - title: "‘De Andere K(r)ant'. Pieter Stuurman en Sander Compagner."
get_one "https://odysee.com/de-andere-k-r-ant-pieter-stuurman-en:06a5267a5a682fb2605bed6083c5ede4867e5073" --language nl

#date: 2020-11-06 - length:     1:27 - title: ""Netjes aan het lijntje" - Ramon Bril"
get_one "https://odysee.com/netjes-aan-het-lijntje-ramon-bril:58cafd60b591f3f783d41fc1d2ee65481148b345" --language nl

#date: 2020-11-05 - length:    27:56 - title: "De gevolgen van het rechtssysteem van de EU. Leon Baten in gesprek met Raisa Blommestijn"
get_one "https://odysee.com/de-gevolgen-van-het-rechtssysteem-van-de:e4e203b98e751c744771ab525e1dcff0bbdd768b" --language nl

#date: 2020-11-04 - length:    24:24 - title: ""Persmomenten" - Column door Ad Nuis"
get_one "https://odysee.com/persmomenten-column-door-ad-nuis:71e2b65e89346a1ee4558e6af904399c44039c28" --language nl

#date: 2020-11-03 - length:    33:27 - title: "Over 40 jaar zijn we een republiek. Pim van Galen in gesprek met Floris Müller"
get_one "https://odysee.com/over-40-jaar-zijn-we-een-republiek-pim:b7f0e895a4559b646ececdc3a2158d880407a0fc" --language nl

#date: 2020-11-02 - length:    56:25 - title: "#38 Wat te verwachten van Trump en Biden? I  Ab Gietelink interviewt Kees van der Pijl."
get_one "https://odysee.com/38-wat-te-verwachten-van-trump-en-biden:daca80f0972c2965bb6910c69a1a9167dbb60774" --language nl

#date: 2020-11-01 - length:  1:05:28 - title: "In hongerstaking wegens grove schending journalistieke code. Fiona Zwart met Ferdinand van der Neut."
get_one "https://odysee.com/in-hongerstaking-wegens-grove-schending:51c21b6b2ee6ec7cc3d7c2338817ba39c92154e7" --language nl

#date: 2020-10-31 - length:    53:06 - title: "‘Wie heeft het nog, gezond verstand?’ Max von Kreyfelt en Karel van Wolferen"
get_one "https://odysee.com/wie-heeft-het-nog-gezond-verstand-max:6171ee2a6799d7b10047dfb5fdeadc6019b63be3" --language nl

#date: 2020-10-28 - length:    42:43 - title: "Het psychopathie-virus. Jorn Lukaszczyk in gesprek met Jan Storms. (deel 2)"
get_one "https://odysee.com/het-psychopathie-virus-jorn-lukaszczyk:6765dde0efa7ed7f193536e3f9d134b77d46ee13" --language nl

#date: 2020-10-23 - length:       28 - title: "Is dit Café Weltschmerz's laatste video? Ga nu naar Steun.cafeweltschmerz.nl"
get_one "https://odysee.com/is-dit-caf-weltschmerz-s-laatste-video:60a7da95dbaa4d9fe692e0e3d8c567481f48cff4" --language nl

#date: 2020-10-22 - length:    48:40 - title: "Falend testbeleid, bron van ellende -  Mario Ortiz en Lars Admiraal met Jorn Lukaszczyk"
get_one "https://odysee.com/falend-testbeleid-bron-van-ellende-mario:e995836b7d756804727288ace4d7134e55cfb6ea" --language nl

#date: 2020-10-22 - length:    29:38 - title: "Dweilen met de kraan open - Maurice de Hond met Pim van Galen"
get_one "https://odysee.com/dweilen-met-de-kraan-open-maurice-de:c17eb94330fa5af81404cf977e75b959eb4f6a88" --language nl

#date: 2020-10-21 - length:    12:24 - title: "#7 De lachzakshow van Arjen Lubach | column Ad Nuis"
get_one "https://odysee.com/7-de-lachzakshow-van-arjen-lubach-column:a877e86c0fa7bdad47647ef192f72becc18d6548" --language nl

#date: 2020-10-20 - length:    52:49 - title: "Kindermisbruik bij een filmmaker | Rudie Kagie en Ate de Jong"
get_one "https://odysee.com/kindermisbruik-bij-een-filmmaker-rudie:e83d4286794624d3f2beb39e026007f22f86a685" --language nl

#date: 2020-10-18 - length:    29:46 - title: "#36 Ab Gietelink I  Taboes in de Media en Alternatieven voor Lockdown"
get_one "https://odysee.com/36-ab-gietelink-i-taboes-in-de-media-en:9b46db62bed00e5b425743ba3bdfdb3b7ebc7b4b" --language nl

#date: 2020-10-17 - length:     2:49 - title: "‘Er komt een moment dat iedereen het door heeft.’ Ramon Bril"
get_one "https://odysee.com/er-komt-een-moment-dat-iedereen-het-door:ab82b86b19f20f3dfc08793989595b78c73d90fa" --language nl

#date: 2020-10-16 - length:    33:51 - title: "Hoe komt het dat zoveel mensen de maatregelen blijven accepteren?"
get_one "https://odysee.com/hoe-komt-het-dat-zoveel-mensen-de:628b965d38d55d4f92e6384dc30f76b9f6c4be6f" --language nl

#date: 2020-10-15 - length:    38:58 - title: "Mensen zullen alles doen om van hun angst af te komen."
get_one "https://odysee.com/mensen-zullen-alles-doen-om-van-hun:722714f5143e4cdd0a2821ddb5d10436ccb74b0f" --language nl

#date: 2020-10-13 - length:  1:27:14 - title: "Terugblik op 6 maanden beleid"
get_one "https://odysee.com/terugblik-op-6-maanden-beleid:b32beca44d33916b5400e41c52168e2e895ac4d3" --language nl

#date: 2020-10-13 - length:    10:18 - title: "WELTSCHMERTZ MICROQUIZ #1"
get_one "https://odysee.com/weltschmertz-microquiz-1:662f4e7b48ed3333ce645e1db16fff090b58ad8b" --language nl

#date: 2020-10-11 - length:    56:12 - title: "#35 Hoe komen we uit de crisis?"
get_one "https://odysee.com/35-hoe-komen-we-uit-de-crisis:854a2dfdae0584434b992d4dd7d81368779ac08d" --language nl

#date: 2020-10-10 - length:    48:45 - title: "Valkuilen door blind geloof in politiek en wetenschap."
get_one "https://odysee.com/valkuilen-door-blind-geloof-in-politiek:dd234b9a7b8cdf2fc18e2751130f07f2760af7cb" --language nl

#date: 2020-10-10 - length:    16:34 - title: "#6 Een schuldeneconomie failliet"
get_one "https://odysee.com/6-een-schuldeneconomie-failliet:9ef876be630693b71cfe079ae7b7f09bcee5fee6" --language nl

#date: 2020-10-08 - length:     7:32 - title: "#34 Ab Gietelink I Performance tegen de (censuur)maatregelen"
get_one "https://odysee.com/34-ab-gietelink-i-performance-tegen-de:e8269107eeea0edfd0fb1c5ff587f58d4a5952c4" --language nl

#date: 2020-10-06 - length:    48:26 - title: "Positie Trump binnen de wereldcrisis, prof. Kees van der Pijl en drs. Hajo Smit"
get_one "https://odysee.com/positie-trump-binnen-de-wereldcrisis:5ae749a52b2ab52bc46c2dc639ef1c994f7c3b15" --language nl

#date: 2020-10-03 - length:    45:39 - title: "Nieuw magazine; ‘Gezond Verstand’"
get_one "https://odysee.com/nieuw-magazine-gezond-verstand:56dccb75e95195b10b82765c02276589032c6e76" --language nl

#date: 2020-10-03 - length:    37:24 - title: "Alle ondernemers weg bij de VVD"
get_one "https://odysee.com/alle-ondernemers-weg-bij-de-vvd:040cbf310716cfe460f99365640c0c073c72c9d1" --language nl

#date: 2020-10-02 - length:    43:12 - title: "#33 Gevaarlijke sekteleider of geschoolde criticus?  Willem Engel en Ab Gietelink"
get_one "https://odysee.com/33-gevaarlijke-sekteleider-of-geschoolde:59c38b6a20480e4b24f7e4103699f220ee327f3a" --language nl

#date: 2020-10-02 - length:    11:33 - title: "Burgerinitiatief EFTA presenteert haar blik op Europa. Ramon Bril, Leon Baten, Marie de Boer"
get_one "https://odysee.com/burgerinitiatief-efta-presenteert-haar:796eedf3be36edd875bd328a21ad89e2296c5706" --language nl

#date: 2020-10-01 - length:    12:44 - title: "#5 "Hugo de Jonge onze laatste cabaretier." Column Ad Nuis"
get_one "https://odysee.com/5-hugo-de-jonge-onze-laatste-cabaretier:aefa45cb5ed179b70f81a087988994e1b37650d6" --language nl

#date: 2020-09-30 - length:     3:58 - title: "‘Aan de vertegenwoordigers van het Nederlandse volk; STOP DE NOODWET’, Ab Gietelink Column"
get_one "https://odysee.com/aan-de-vertegenwoordigers-van-het:44d2ce6aa494a68cf8887aaaea008b603f6baa89" --language nl

#date: 2020-09-29 - length:     8:26 - title: "‘Kamerleden, stap nu over naar VSN!’ Ab Gietelink Bas Filippini Anna Zeven"
get_one "https://odysee.com/kamerleden-stap-nu-over-naar-vsn-ab:ec3c1585e9b6585c1d87733ca892527eb4229931" --language nl

#date: 2020-09-29 - length:    38:02 - title: "Boekbespreking: Politiek van het Gezond Verstand, Paul Cliteur en Thierry Baudet"
get_one "https://odysee.com/boekbespreking-politiek-van-het-gezond:90a111717fddb67caf87d80a32bf028ab855ae93" --language nl

#date: 2020-09-28 - length:    58:26 - title: "“De Mainstream Media moet zich schamen” Nadia Duinker en Jorn Lukaszczyk"
get_one "https://odysee.com/de-mainstream-media-moet-zich-schamen:b477b685f4edfd1384bad67d106b3707e0c2c991" --language nl

#date: 2020-09-26 - length:    40:50 - title: "De ‘Coronawet’ puntsgewijs ontleed: Ab Gietelink en Jeroen Pols"
get_one "https://odysee.com/de-coronawet-puntsgewijs-ontleed-ab:076cbb8e57778508fc9b3da51c4e8fc700e94f02" --language nl

#date: 2020-09-25 - length:    44:58 - title: "Een Marokkaanse Jood: Paul Cliteur en David Pinto"
get_one "https://odysee.com/een-marokkaanse-jood-paul-cliteur-en:302464d258fa61a7daafcf3e77140e398de040db" --language nl

#date: 2020-09-24 - length:  1:08:58 - title: "Waar ligt feitelijk de politieke leiding van landen?: Isa Kriens en Jorn Lukaszczyk"
get_one "https://odysee.com/waar-ligt-feitelijk-de-politieke-leiding:30bca159e2f8dcf95e094469b0f72cb01c6d27c6" --language nl

#date: 2020-09-21 - length:    14:58 - title: "#4 “De macht van de witte miljardairs: Column Ad Nuis"
get_one "https://odysee.com/4-de-macht-van-de-witte-miljardairs:c9dd07ed648b8e0d5a530d916612d9bf738e5636" --language nl

#date: 2020-09-20 - length:    38:46 - title: "#29 VSN nieuwe politieke partij tegen noodwet I Bas Filippini en Ab Gietelink"
get_one "https://odysee.com/29-vsn-nieuwe-politieke-partij-tegen:e3258bf6a8eac6414a6817e2b48a4d58be1ab389" --language nl

#date: 2020-09-19 - length:    35:37 - title: "#28 Wat staat er werkelijk in de Noodwet? Slapen de Kamerfracties? Jeroen Pols en Ab Gietelink"
get_one "https://odysee.com/28-wat-staat-er-werkelijk-in-de-noodwet:ff5a57e193c15f9843430124d9997333ae94194f" --language nl

#date: 2020-09-18 - length:  1:07:57 - title: "‘Er gaan meer mensen dood aan honger dan aan Corona’: Tisjeboy Jay en Jorn Lukaszczyk"
get_one "https://odysee.com/er-gaan-meer-mensen-dood-aan-honger-dan:35528790b6748b9ad13ea1a8353a620fdf4f894a" --language nl

#date: 2020-09-17 - length:    51:05 - title: "NRC demoniseert en marginaliseert de kritische media: Kees van der Pijl en Ab Gietelink"
get_one "https://odysee.com/nrc-demoniseert-en-marginaliseert-de:2ee2527336508f1ca57b7fcf79c6c25fd753a14d" --language nl

#date: 2020-09-16 - length:    36:37 - title: "Honderden protestgroepen tegen Corona actief: Ab Gietelink en Ferdinand van der Neut"
get_one "https://odysee.com/honderden-protestgroepen-tegen-corona:2e03d114e1400b2fba010284bee07437c2597a30" --language nl

#date: 2020-09-14 - length:    57:17 - title: "Justitie faalt bij vervolging kindermisbruik. Rudie Kagie, Yvonne Keuls en Marlies van Muiswinkel"
get_one "https://odysee.com/justitie-faalt-bij-vervolging:28593a23631a6beae49d087eb7d0b12cbd5cc466" --language nl

#date: 2020-09-13 - length:    45:33 - title: "Nederland moet met Duitsland reset Euro en EU voorbereiden: Lex Hoogduin en Paul Buitink"
get_one "https://odysee.com/nederland-moet-met-duitsland-reset-euro:04053556b765ab8540426a06cfef076915721043" --language nl

#date: 2020-09-13 - length:    42:32 - title: "“De schade door deze gijzeling is onvoorstelbaar” Sander Groet en Jorn Lukaszczyk"
get_one "https://odysee.com/de-schade-door-deze-gijzeling-is:fc04cfe378216ab0d8fdc32ee68c93554088586e" --language nl

#date: 2020-09-13 - length:    40:29 - title: "VSN; introductie van de nieuwe partij Vrij en Sociaal Nederland."
get_one "https://odysee.com/vsn-introductie-van-de-nieuwe-partij:5ef57b892b01242fd59db61340ca10330f6eca72" --language nl

#date: 2020-09-12 - length:    36:59 - title: "#5 Is de Corona Scam iets nieuws? Pierre Capel College"
get_one "https://odysee.com/5-is-de-corona-scam-iets-nieuws-pierre:a9d35707c6cb698c3c925d021371f805d6f83a1d" --language nl

#date: 2020-09-12 - length:    12:33 - title: "#2 Politici en de waarheid hebben een moeizame relatie: column Ad Nuis"
get_one "https://odysee.com/2-politici-en-de-waarheid-hebben-een:8b1b4f457ccdc0c7721fd7954c9918f4cdd88f2d" --language nl

#date: 2020-09-11 - length:    37:07 - title: "Studeerden wij Medicijnen of Geneeskunde? Huisarts Lieneke van de Griendt over functional medicine"
get_one "https://odysee.com/studeerden-wij-medicijnen-of-geneeskunde:87e160daaf2acdcb8be2535c36e2eded06a0d535" --language nl

#date: 2020-09-10 - length:    42:39 - title: "Kortgeding YouTube verloren en ‘gewonnen’: Ab Gietelink en Pieter Lakeman"
get_one "https://odysee.com/kortgeding-youtube-verloren-en-gewonnen:08bf85e54642422275e27d7c7a65fb7b78cc1cf4" --language nl

#date: 2020-09-09 - length:     7:11 - title: "Arno Scholtens Column"
get_one "https://odysee.com/arno-scholtens-column:4db27d506b6f12da7ad542dee1621446ae03047f" --language nl

#date: 2020-09-08 - length:     7:53 - title: "#2 Column: Ad Nuis over Feike Sijbesma, AstraZeneca en de ongeloofwaardigheid!"
get_one "https://odysee.com/2-column-ad-nuis-over-feike-sijbesma:73ca641f7b32dd7fd4ad94a39cb1ec4e6bd39db7" --language nl

#date: 2020-09-08 - length:    36:11 - title: "Actie Minister Slob was ONgehoord! Arnold Karskens en Peter Vlemminx met Flavio Pasquino"
get_one "https://odysee.com/actie-minister-slob-was-ongehoord-arnold:ac0c8225468db1b698f488920ce5ee219e20fb1a" --language nl

#date: 2020-09-07 - length:    50:25 - title: "Vaccinatie ondermijnd het natuurlijke afweersysteem: Fiona Zwart en Door Frankema"
get_one "https://odysee.com/vaccinatie-ondermijnd-het-natuurlijke:952503af962d61a96bba543a5ddffe88f202de8f" --language nl

#date: 2020-09-06 - length:     9:24 - title: "Kinderen zijn de slachtoffers van de Lockdown: Professor Doctor Wieland Kiess"
get_one "https://odysee.com/kinderen-zijn-de-slachtoffers-van-de:4451e4c514845586ce7d3e0c31111c50f58842c5" --language nl

#date: 2020-09-05 - length:    39:49 - title: "# 4 Afweer genoeg, ook zonder vaccin. College Pierre Capel"
get_one "https://odysee.com/4-afweer-genoeg-ook-zonder-vaccin:fafbd60314ee1045da81b44037da6a3743923bef" --language nl

#date: 2020-09-04 - length:    38:53 - title: "Bestaat SARS-Cov-2 wel? Waar is het bewijs dan?:Patrick Savalle en Flavio Pasquino"
get_one "https://odysee.com/bestaat-sars-cov-2-wel-waar-is-het:86e2f5a2fd3b7687d68f903bdc4fa34f98e36e32" --language nl

#date: 2020-09-03 - length:     7:29 - title: "#1 De Europese en het fakenieuws: Column Ad Nuis"
get_one "https://odysee.com/1-de-europese-en-het-fakenieuws-column:f5a6e7db541119fa3971be2827959fdc8c3bbea8" --language nl

#date: 2020-09-02 - length:     8:55 - title: "#25 Ab Gietelink I  Open brief aan Minister Grapperhaus"
get_one "https://odysee.com/25-ab-gietelink-i-open-brief-aan:79effe324b9c21745b524180133483cf092e0c9a" --language nl

#date: 2020-09-02 - length:    30:33 - title: "'De ultieme machtsgreep van een onzichtbare vijand' Pieter Stuurman en Ramon Bril"
get_one "https://odysee.com/de-ultieme-machtsgreep-van-een:21d7ba14ae58762ead1ca210dcd7e6a3c9a15f58" --language nl

#date: 2020-09-02 - length:     1:48 - title: "BINNENKORT. pedofilie en kindermisbruik: Rudie Kagie, Yvonne Keuls en ‘de moeder van Lisa’."
get_one "https://odysee.com/binnenkort-pedofilie-en-kindermisbruik:14f938b274330dd91e82e92d8c9fccfe33481005" --language nl

#date: 2020-09-01 - length:     9:31 - title: "#24 Ab Gietelink I  Open brief aan Burgemeester Halsema. Deel 2"
get_one "https://odysee.com/24-ab-gietelink-i-open-brief-aan:8fe909615e4accf5af8e368137695afbbf248971" --language nl

#date: 2020-08-30 - length:    43:18 - title: "“Mensen die altijd liegen moet je ineens gaan geloven”: Willie Wartaal en Jorn Lukaszczyk"
get_one "https://odysee.com/mensen-die-altijd-liegen-moet-je-ineens:180ba6a5a2e535085fee82d452cf820314c09afb" --language nl

#date: 2020-08-30 - length:       38 - title: "Kinderfeestje anno 2020"
get_one "https://odysee.com/kinderfeestje-anno-2020:ba3b015cd5d1ef957f57a4472aa151c41d76288a" --language nl

#date: 2020-08-30 - length:    30:55 - title: "#3 Angst, de grote Sloper: College Pierre Capel"
get_one "https://odysee.com/3-angst-de-grote-sloper-college-pierre:9db402a5442bd7817abb4e5b7213b0e339cf849c" --language nl

#date: 2020-08-30 - length:  1:18:06 - title: "5G Apocalypse"
get_one "https://odysee.com/5g-apocalypse:192090410882a1727cfb808289f077d8a6606192" --language nl

#date: 2020-08-29 - length:     7:27 - title: "“Een overheid bepaalt niet over mijn bedrijf”, introductie van Jorn Lukaszczyk met Ramon Bril"
get_one "https://odysee.com/een-overheid-bepaalt-niet-over-mijn:dd9332cc26ac9c9ca08f6aae8a02bd219801b98f" --language nl

#date: 2020-08-28 - length:    30:52 - title: "Grootschalig testen om te zwendelen: Willem Engel en Ramon Bril"
get_one "https://odysee.com/grootschalig-testen-om-te-zwendelen:dc9e3d56b388dbb480311080820f38aee8399089" --language nl

#date: 2020-08-26 - length:    28:34 - title: "Identiteitspolitiek leidt tot maatschappelijke ontwrichting: Column Frits Bosch"
get_one "https://odysee.com/identiteitspolitiek-leidt-tot:d042c76c3dacff067cfec705e96e562757ed9557" --language nl

#date: 2020-08-24 - length:    30:00 - title: "#2 Kappen met kapjes, er bestaat géén maatregel tegen Corona: column Pierre Capel"
get_one "https://odysee.com/2-kappen-met-kapjes-er-bestaat-g-n:af22a1b76e2c94c29c029082f51b590f4985ca9e" --language nl

#date: 2020-08-24 - length:    13:47 - title: "De alternatieve persconferentie van "premier" de Hond"
get_one "https://odysee.com/een-afwezig-evenwicht-tussen:85f6a83ca4056eebf67ee5d51621f4086b7a2016" --language nl

#date: 2020-08-23 - length:    18:05 - title: "#1. Er is geen ‘samen tegen corona’. Introductie van columnist Ad Nuis door Flavio Pasquino"
get_one "https://odysee.com/1-er-is-geen-samen-tegen-corona:9e7c655c6ff1ccdd33d0d3ac355a84293c5c9e71" --language nl
