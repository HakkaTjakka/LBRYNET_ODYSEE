#!/bin/bash

FILENAME=$1
echo FILENAME=$FILENAME
BASENAME="${FILENAME%.*}"

BIT_RATE=$(ffprobe -v error -show_entries format=bit_rate -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
echo BIT_RATE=$BIT_RATE

ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:a]aresample=44100" \
	-c:v h264_nvenc -pix_fmt yuv420p -preset slow -c:a aac -ac 2 -b:a 64k -b:v $BIT_RATE "$BASENAME.recoded.mp4"
