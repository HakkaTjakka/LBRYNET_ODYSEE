#!/bin/bash

ffmpeg -i "$FILENAME" \
-f", "s16le",
-ac", "1",
-acodec", "pcm_s16le",
-ar", str(sr),
-"
    ]