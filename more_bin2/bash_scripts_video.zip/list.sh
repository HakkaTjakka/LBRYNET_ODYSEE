echo " \\" > add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="De Gulden Middenweg"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=9V_onif2fqg" --language nl

exit

echo " \\" > add_fix.txt
echo '	--tags="Candace Owens"' >> add_fix.txt

# sa "https://www.youtube.com/watch?v=5gmDHw-lO4Q" --language en # - date: 2024-10-10 - title: Neil Oliver Interviews Candace Owens
# sa "https://www.youtube.com/watch?v=GcmOmkKfuPA" --language en # - date: 2024-10-09 - title: This Is Why I Choose Not To Vaccinate My Kids | Candace Ep 82
# sa "https://www.youtube.com/watch?v=EeORk6BMOF4" --language en # - date: 2024-10-08 - title: Forbidden History: The Christian Holocaust | Candace Ep 81
# sa "https://www.youtube.com/watch?v=oFa1xMAM28s" --language en # - date: 2024-10-07 - title: What Really Happened To Malaysian Airlines Flight 370? | Candace EP 80
# sa "https://www.youtube.com/watch?v=apxdK6WzrUI" --language en # - date: 2024-10-03 - title: I Spoke With Kamala's Uncle! | Candace Ep 78
# sa "https://www.youtube.com/watch?v=hFc9G6ZmGuI" --language en # - date: 2024-09-27 - title: The Kamala Investigation Continues… | Candace Ep 74
# sa "https://www.youtube.com/watch?v=vnEIBuJdQzc" --language en # - date: 2024-08-28 - title: INSANE TikTok Trend: Get Pregnant Without A Man | Candace Ep 54
# sa "https://www.youtube.com/watch?v=iwOXLfVsieA" --language en # - date: 2024-08-15 - title: Andrew Tate x Candace Owens | Candace Ep 46
# exit
# sa "https://www.youtube.com/watch?v=nBFNAbOSNe0" --language en # - date: 2024-08-13 - title: MAGA Civil War?! What’s going on with the Trump Campaign… | Candace Ep 44
# sa "https://www.youtube.com/watch?v=kl_zuU3l5u0" --language en # - date: 2024-08-12 - title: Off Record With Kanye: More Secrets Revealed... | Candace Ep 43
# sa "https://www.youtube.com/watch?v=sDisyP3NhHU" --language en # - date: 2024-08-06 - title: Ray J Debates Transgenderism | Candace Ep 41
# sa "https://www.youtube.com/watch?v=HGK8AlX5UAQ" --language en # - date: 2024-08-05 - title: Dave Smith x Candace Owens | Candace Ep 40
# sa "https://www.youtube.com/watch?v=n-hXMZ3SK3k" --language en # - date: 2024-08-04 - title: She Said The N-Word And Went Viral | Candace Ep 39
# sa "https://www.youtube.com/watch?v=RBeG-YXVa7A" --language en # - date: 2024-07-26 - title: Amber Rose x Candace Owens | Candace Ep 33
# list2.sh
# exit
# sa "https://www.youtube.com/watch?v=aMW8j7HWd5Y" --language en # - date: 2024-07-18 - title: Rappers EXPOSE Demonic Agenda In Music | Candace Ep 28
# sa "https://www.youtube.com/watch?v=ARXHSOM31pk" --language en # - date: 2024-07-17 - title: Candace Owens + Alex Jones: Who Wanted To Kill Trump? | Candace Ep 27
# sa "https://www.youtube.com/watch?v=mu4P1C36Ap4" --language en # - date: 2024-07-11 - title: SMACKDOWN! My Heated Debate With Don Lemon | Candace Ep 23
# sa "https://www.youtube.com/watch?v=bqa_rpqIojs" --language en # - date: 2024-07-10 - title: Russell Brand & I Are Going To Break The Internet | Candace Ep 22
# sa "https://www.youtube.com/watch?v=iEOP5hKdgfc" --language en # - date: 2024-07-09 - title: Is This The End Of Jordan Peterson? | Candace Ep 21
# sa "https://www.youtube.com/watch?v=FtBvkpDKO6M" --language en # - date: 2024-07-08 - title: BOMBSHELL: Is Diddy A Fed Asset? | Candace Ep 20
# sa "https://www.youtube.com/watch?v=lQPWUHyw4xY" --language en # - date: 2024-07-05 - title: DEBATE: Is Everything Antisemitism? | Candace Ep 19
# sa "https://www.youtube.com/watch?v=rFsAEzjEsA8" --language en # - date: 2024-07-03 - title: The SHOCKING Satanic Origins of NASA | Candace Ep 18
# sa "https://www.youtube.com/watch?v=qhLXcvxdIyw" --language en # - date: 2024-07-02 - title: Literally Hitler. Why Can't We Talk About Him? | Candace Ep 17
# sa "https://www.youtube.com/watch?v=8wlq-Q4YgtM" --language en # - date: 2024-07-01 - title: Why I Left This Religion | Candace Ep 16
# sa "https://www.youtube.com/watch?v=dcKxmN4pKl0" --language en # - date: 2024-06-28 - title: Debate Review: Biden was TOTALLY Fine | Candace Ep 15
# sa "https://www.youtube.com/watch?v=fegp0B1ZLAs" --language en # - date: 2024-06-27 - title: OUCH! Tucker Carlson Embarrasses The Australian Press | Candace Ep 14
# sa "https://www.youtube.com/watch?v=sTXqHi0lOX8" --language en # - date: 2024-06-26 - title: Piers Morgan Caught LYING About Brigitte Macron | Candace Ep 13
# sa "https://www.youtube.com/watch?v=tucTJi2KqPk" --language en # - date: 2024-06-25 - title: More SHOCKING Revelations About 9/11 | Candace Ep 12
# sa "https://www.youtube.com/watch?v=HGx5nlwo5I4" --language en # - date: 2024-06-24 - title: Chrissy Teigen Needs An Exorcism | Candace Ep 11
# sa "https://www.youtube.com/watch?v=-882bdPSR4M" --language en # - date: 2024-06-21 - title: The Great Debate: Israel v Palestine | Candace Ep 10
# sa "https://www.youtube.com/watch?v=nJj4TA9Stt4" --language en # - date: 2024-06-20 - title: What REALLY happened on 9/11? | Candace Ep 9
# sa "https://www.youtube.com/watch?v=zzxEa54wB4E" --language en # - date: 2024-06-19 - title: I Say Ban Porn, Cardi B Defends It | Candace Ep 8
# sa "https://www.youtube.com/watch?v=D1-_9so7OYU" --language en # - date: 2024-06-18 - title: Everything We Learned About World War 2 Is A Lie | Candace Ep 7
# exit
sa "https://www.youtube.com/watch?v=mXGUHYVUZZk" --language en # - date: 2024-06-17 - title: So...Is Brigitte Macron A Man? | Candace Ep 6
sa "https://www.youtube.com/watch?v=kngK3gX8X-M" --language en # - date: 2024-06-14 - title: Another Person Fired For Criticizing Israel?! | Candace Ep 5
sa "https://www.youtube.com/watch?v=yXyVzAn_EMo" --language en # - date: 2024-06-13 - title: SMACKDOWN! Piers Morgan Tried To Ambush Me... | Candace Ep 4
sa "https://www.youtube.com/watch?v=s5akZ4gw5xs" --language en # - date: 2024-06-12 - title: Candace Owens vs Piers Morgan HEATED Debate on Christ Is King
sa "https://www.youtube.com/watch?v=OypsfQ_ZCTM" --language en # - date: 2024-06-12 - title: Uh-oh! Black Americans Can No Longer Be Controlled | Candace Ep 3
sa "https://www.youtube.com/watch?v=G54TJpDxFeU" --language en # - date: 2024-06-12 - title: Why Does Nikki Haley Love Israel More Than the US?
sa "https://www.youtube.com/watch?v=mHPJEUM2avo" --language en # - date: 2024-06-11 - title: Candace + Ye Podcast Episode — COMING SOON!
sa "https://www.youtube.com/watch?v=JAidnEeZHQs" --language en # - date: 2024-06-11 - title: The REAL Reason My Show Was Canceled | Candace Ep 2
sa "https://www.youtube.com/watch?v=qQBuDkrGglM" --language en # - date: 2024-06-10 - title: Uh-oh! I Got Fired. | Candace Ep 1
sa "https://www.youtube.com/watch?v=TN0yZSyDvxs" --language en # - date: 2024-02-29 - title: A Brief Explanation of the Dark History of Birth Control
sa "https://www.youtube.com/watch?v=j-dRGWptHUY" --language en # - date: 2023-10-14 - title: What Is a Marriage?
sa "https://www.youtube.com/watch?v=nGAeZHhjhRA" --language en # - date: 2023-10-07 - title: Candace Owens REACTS to Childless Woman
sa "https://www.youtube.com/watch?v=70XQ8hGOHx4" --language en # - date: 2023-09-30 - title: Feminism Is the Number One Attack on Family
sa "https://www.youtube.com/watch?v=TYCgonvxLqM" --language en # - date: 2023-09-23 - title: The Impact of OnlyFans on Women
sa "https://www.youtube.com/watch?v=UbCsRH3KcB4" --language en # - date: 2022-10-17 - title: "We've Identified the Gender Studies Majors" | Candace's @turningpointusa Speech Sparks Protest
sa "https://www.youtube.com/watch?v=ZNy3-e9wk7s" --language en # - date: 2022-10-09 - title: Delete Your PayPal Account
sa "https://www.youtube.com/watch?v=K1n3IOSyGwY" --language en # - date: 2022-09-09 - title: Will Candace Owens Ever Run for Office?
sa "https://www.youtube.com/watch?v=ylekIG541gw" --language en # - date: 2022-09-08 - title: BLM Can “Say Their Names” Because the Names Are So Few
sa "https://www.youtube.com/watch?v=uFcQeRgeH5s" --language en # - date: 2022-09-08 - title: Is It Race or Personal Choices That Determine Poverty Rates?
sa "https://www.youtube.com/watch?v=UxnpQZ12fVA" --language en # - date: 2022-07-08 - title: No Matter What They Say, Women Do NOT Like Men in Dresses
sa "https://www.youtube.com/watch?v=cLRn6MbfOBg" --language en # - date: 2022-07-07 - title: Modern Feminism Is RUINING the Next Generation of Women
sa "https://www.youtube.com/watch?v=cgV7ScwDrZM" --language en # - date: 2022-07-07 - title: Where Did Candace Owens Get Her Start?
sa "https://www.youtube.com/watch?v=yKsUp0Ar6EM" --language en # - date: 2022-06-26 - title: A Message to Pro-Choicers: Do Your Research on the History of Abortion
sa "https://www.youtube.com/watch?v=U5oohuE7qBM" --language en # - date: 2022-06-25 - title: Candace Owens REACTS to Amy Schumer's HORRIBLE Abortion Take
sa "https://www.youtube.com/watch?v=PmFlFoKGMgQ" --language en # - date: 2022-06-19 - title: Candace Owens SHUTS DOWN Rep Ted Lieu At Congressional Hearing
sa "https://www.youtube.com/watch?v=BF3B9r3-0NQ" --language en # - date: 2022-06-15 - title: Freedom Feels Nice – But It's Hard
sa "https://www.youtube.com/watch?v=MLWR5I5EuC0" --language en # - date: 2022-06-14 - title: Candace Owens's Most VIRAL Instagram Rants
sa "https://www.youtube.com/watch?v=U9-4_rMK0vo" --language en # - date: 2022-06-13 - title: How the Left Capitalizes On Your Emotions
sa "https://www.youtube.com/watch?v=VE1daS-eV5A" --language en # - date: 2022-06-12 - title: How the Democrats BUY Votes with YOUR Money
sa "https://www.youtube.com/watch?v=KDGkQ0BkMyg" --language en # - date: 2022-06-11 - title: Candace Owens Shuts Down Race-Baiting Liberals at Congressional Hearing
sa "https://www.youtube.com/watch?v=yQ30tmn_IcU" --language en # - date: 2022-06-07 - title: The Education System Has Completely COLLAPSED
sa "https://www.youtube.com/watch?v=IMNf83c0pdQ" --language en # - date: 2022-06-04 - title: The Government Is Enslaving YOU
sa "https://www.youtube.com/watch?v=MGdQh9BOWBk" --language en # - date: 2022-06-02 - title: Candace Owens EXPOSES Climate Change Scare Tactics
sa "https://www.youtube.com/watch?v=H5JAjwuRTcQ" --language en # - date: 2022-06-01 - title: Candace Owens REACTS to the Johnny Depp v Amber Heard Verdict
sa "https://www.youtube.com/watch?v=XvhM6Jo6Er8" --language en # - date: 2022-05-29 - title: Why the Media Shifted From “Family Matters” to “Love & Hip Hop”
sa "https://www.youtube.com/watch?v=hXgQhmUejgo" --language en # - date: 2022-05-27 - title: What Direction Is Our Culture Going In? | With Brandon Tatum
sa "https://www.youtube.com/watch?v=v0MT9-2cEDw" --language en # - date: 2022-05-25 - title: True Story: Conservative Principles SAVED ME
sa "https://www.youtube.com/watch?v=vwazTtFAvX0" --language en # - date: 2022-05-24 - title: The Democrat Plantation STILL EXISTS Today
sa "https://www.youtube.com/watch?v=0XVjmepFjwI" --language en # - date: 2022-05-17 - title: The Greatest Lie Ever Sold: George Floyd & the Rise of BLM | OFFICIAL TRAILER
sa "https://www.youtube.com/watch?v=H3kb3wZHpIE" --language en # - date: 2022-05-16 - title: Women NEED To Value MASCULINE MEN – Here's Why
sa "https://www.youtube.com/watch?v=hAUaISf7VrY" --language en # - date: 2022-05-11 - title: Black America: It's Time To Learn What REALITY Is
sa "https://www.youtube.com/watch?v=IH87iIWt2WM" --language en # - date: 2022-05-10 - title: Here’s THE TRUTH About the Democrat Party They Don’t Want You to Know
sa "https://www.youtube.com/watch?v=pMc_EDK2S5Y" --language en # - date: 2022-05-09 - title: I Will Be EXPOSING Patrisse Cullors and Black Lives Matter
sa "https://www.youtube.com/watch?v=xvsdMVG8kA4" --language en # - date: 2022-04-26 - title: Black America: White People ARE NOT Holding You Back...
sa "https://www.youtube.com/watch?v=QUVcI7HLC2M" --language en # - date: 2022-04-22 - title: The Moment Everything Changed For Me | My Red Pill Journey
sa "https://www.youtube.com/watch?v=mnrva2PF_F4" --language en # - date: 2022-04-22 - title: Black America Owes Me AN APOLOGY — Here's Why
sa "https://www.youtube.com/watch?v=X9fyF-7EG-8" --language en # - date: 2022-04-21 - title: Black Americans: Stop Blaming White People For Your Problems
sa "https://www.youtube.com/watch?v=VxtXqVmkAuI" --language en # - date: 2022-04-21 - title: Candace Owens' Thoughts on Martin Luther King Jr.
sa "https://www.youtube.com/watch?v=QITmtEl3oT4" --language en # - date: 2022-04-06 - title: My Favorite Movies of All Time!
sa "https://www.youtube.com/watch?v=7e4Adeg1l7I" --language en # - date: 2022-02-05 - title: Kanye is right. 8-year-olds should not have social media.
sa "https://www.youtube.com/watch?v=Tkr-azJVTAM" --language en # - date: 2021-04-22 - title: DISGUSTING! Lebron James defends a knife-wielding maniac.
sa "https://www.youtube.com/watch?v=4lGGlbZRoV4" --language en # - date: 2021-01-09 - title: Facebook CENSORED a sitting President. None of us are safe!
sa "https://www.youtube.com/watch?v=2WlN3JhZE7M" --language en # - date: 2020-10-21 - title: MyBLEXIT Bryson Gray on Affecting Culture
sa "https://www.youtube.com/watch?v=h5IKPLQB2Gg" --language en # - date: 2020-10-20 - title: 50 CENT SAYS HE VOTING FOR DONALD TRUMP! BLACK PEOPLE FEEL "BETRAYED".
sa "https://www.youtube.com/watch?v=vjmho5h00fQ" --language en # - date: 2020-10-18 - title: Brandon Tatum at BLEXIT BACK the BLUE Wash  DC
sa "https://www.youtube.com/watch?v=qlNO4jjEOIk" --language en # - date: 2020-10-18 - title: Larry Elder  at  BLEXIT BACK THE BLUE Wash. D.C.
sa "https://www.youtube.com/watch?v=nPafnn0pU6k" --language en # - date: 2020-10-17 - title: Candace Owens at BLEXIT Back the Blue Wash DC
sa "https://www.youtube.com/watch?v=IubXYsyRP9E" --language en # - date: 2020-09-20 - title: BLEXIT is BACK!  Greenville SC
sa "https://www.youtube.com/watch?v=Yzw2a5H7IOE" --language en # - date: 2020-09-13 - title: BLEXIT Breakdown Greenville   Pierre Wilson
sa "https://www.youtube.com/watch?v=yHYsBHkWbrc" --language en # - date: 2020-09-13 - title: KingFace Tribute at BLEXIT Greenville
sa "https://www.youtube.com/watch?v=MPiT1U7zhIc" --language en # - date: 2020-09-13 - title: Candace Owens Closing Remarks   BLEXIT Greenville
sa "https://www.youtube.com/watch?v=JzMCTmpT0lM" --language en # - date: 2020-09-13 - title: Mark Robinson at BLEXIT Greenville
sa "https://www.youtube.com/watch?v=bw_HsjFlTR0" --language en # - date: 2020-09-13 - title: Dinesh D'Souza at BLEXIT Greenville
sa "https://www.youtube.com/watch?v=AWJvjrK5IlA" --language en # - date: 2020-09-13 - title: Brandon Tatum at BLEXIT Greenville
sa "https://www.youtube.com/watch?v=a8ZARshwdiw" --language en # - date: 2020-09-13 - title: Opening Remarks Candace Owens at BLEXIT Greenville
sa "https://www.youtube.com/watch?v=8kE2dTsCEZ8" --language en # - date: 2020-09-13 - title: Larry Elder at BLEXIT Greenville
sa "https://www.youtube.com/watch?v=0ZnOILj6Mow" --language en # - date: 2020-09-13 - title: Will Witt at BLEXIT Greenville
sa "https://www.youtube.com/watch?v=Zt1z2haQTaM" --language en # - date: 2020-08-28 - title: Candace Owens Personal Announcement
sa "https://www.youtube.com/watch?v=R5H5GsYKF78" --language en # - date: 2020-08-24 - title: My BLEXIT Is Multi-Cultural
sa "https://www.youtube.com/watch?v=f761LIbrj5o" --language en # - date: 2020-08-20 - title: My BLEXIT Is The Key
sa "https://www.youtube.com/watch?v=v4tHqlT1FXI" --language en # - date: 2020-08-17 - title: My BLEXIT - Feel The Love, KINGFACE
sa "https://www.youtube.com/watch?v=BmYZphmxruo" --language en # - date: 2020-08-13 - title: M BLEXIT - American Mentality
sa "https://www.youtube.com/watch?v=q4zKRZFaQ-k" --language en # - date: 2020-08-10 - title: My BLEXIT - Changing the 'Zip Code' Mindset
sa "https://www.youtube.com/watch?v=S-6lZcYCfZM" --language en # - date: 2020-08-06 - title: My BLEXIT - KingFace Gets 'em Glitchin'
sa "https://www.youtube.com/watch?v=VH71SYdMrWM" --language en # - date: 2020-07-31 - title: My BLEXIT is Flippin' the Narrative
sa "https://www.youtube.com/watch?v=hkiXP9C8N1c" --language en # - date: 2020-07-30 - title: My BLEXIT - Florida, The Liberty State!
sa "https://www.youtube.com/watch?v=8xfRM-TMxKU" --language en # - date: 2020-07-27 - title: My BLEXIT -  Bringing The Change
sa "https://www.youtube.com/watch?v=5t6Jd_mcAt0" --language en # - date: 2020-07-23 - title: My BLEXIT - Restoring the Family
sa "https://www.youtube.com/watch?v=iAbEaSJAlwI" --language en # - date: 2020-07-20 - title: My BLEXIT -  All Lives Matter!
sa "https://www.youtube.com/watch?v=Kfgz-o4asU8" --language en # - date: 2020-07-16 - title: My BLEXIT - A New Platform
sa "https://www.youtube.com/watch?v=mb5GTdExw_w" --language en # - date: 2020-07-13 - title: My BLEXIT - Leaving A Legacy
sa "https://www.youtube.com/watch?v=vlJ0Z1Fu-eQ" --language en # - date: 2020-07-09 - title: My BLEXIT - Freedom on the Other Side
sa "https://www.youtube.com/watch?v=lV7t_-aFGdo" --language en # - date: 2020-07-06 - title: Ft Lauderdale, Let's BLEXIT!
sa "https://www.youtube.com/watch?v=a5XSuheDGPs" --language en # - date: 2020-06-25 - title: My BLEXIT - A New Vanguard
sa "https://www.youtube.com/watch?v=qN90H7KzSnk" --language en # - date: 2020-06-22 - title: My BLEXIT was a paradigm shift
sa "https://www.youtube.com/watch?v=G41hFqQo8qE" --language en # - date: 2020-06-18 - title: Wilfred Ruck - My BLEXIT
sa "https://www.youtube.com/watch?v=Sy6U3IzQShE" --language en # - date: 2020-06-15 - title: My BLEXIT - America is Great!
sa "https://www.youtube.com/watch?v=9EbVYXfsOX0" --language en # - date: 2020-06-11 - title: My BLEXIT is Economic Freedom
sa "https://www.youtube.com/watch?v=QDJ4jBoHwK0" --language en # - date: 2020-06-08 - title: My BLEXIT is a Journey
sa "https://www.youtube.com/watch?v=XbkFB1EtReM" --language en # - date: 2020-06-01 - title: MyBLEXIT - A New Culture
sa "https://www.youtube.com/watch?v=idJ_gdyhXxM" --language en # - date: 2020-05-28 - title: My BLEXIT A New Era
sa "https://www.youtube.com/watch?v=QCIESylquRo" --language en # - date: 2020-05-26 - title: My BLEXIT  A New Home
sa "https://www.youtube.com/watch?v=uoFdI1jvOBE" --language en # - date: 2020-05-21 - title: My BLEXIT on A New Path
sa "https://www.youtube.com/watch?v=hTok988W-bg" --language en # - date: 2020-05-18 - title: My BLEXIT in A New Direction
sa "https://www.youtube.com/watch?v=oIWErZzaYrw" --language en # - date: 2020-05-14 - title: My BLEXIT is for Free Thinkers
sa "https://www.youtube.com/watch?v=lLOwnrBzuV4" --language en # - date: 2020-05-11 - title: My BLEXIT is Family
sa "https://www.youtube.com/watch?v=lPOd4rDAd2M" --language en # - date: 2020-05-07 - title: My BLEXIT is an Awakening
sa "https://www.youtube.com/watch?v=93ZZLN2D3AY" --language en # - date: 2020-05-07 - title: My BLEXIT Is About Diversity
sa "https://www.youtube.com/watch?v=inXJHOilkCA" --language en # - date: 2020-05-04 - title: William Davis   BLEXIT LOVES CHARLOTTE  CUT 2
sa "https://www.youtube.com/watch?v=nK3WX0yxYHg" --language en # - date: 2020-04-30 - title: My BLEXIT is about Acceptance
sa "https://www.youtube.com/watch?v=Bfi1JpTSuYA" --language en # - date: 2020-04-27 - title: Arielle Chambers - MY BLEXIT
sa "https://www.youtube.com/watch?v=Y5kLR2b3cVA" --language en # - date: 2020-04-23 - title: Prospering The Mind - Candace Owens' Honest Conversations
sa "https://www.youtube.com/watch?v=iOpV9WUp7iA" --language en # - date: 2020-04-20 - title: BLACK LIVES MAGA - Candace Owens' Honest Conversations
sa "https://www.youtube.com/watch?v=wJll5rheB-o" --language en # - date: 2020-04-16 - title: My BLEXIT is the American Dream  - Lisa Matthews
sa "https://www.youtube.com/watch?v=V2R5s4OOzdI" --language en # - date: 2020-04-13 - title: Lisa Matthews - MY BLEXIT
sa "https://www.youtube.com/watch?v=jdLtkIWECX0" --language en # - date: 2020-03-27 - title: MY BLEXIT - Grace Glass
sa "https://www.youtube.com/watch?v=5V47nKBAse4" --language en # - date: 2020-03-27 - title: MY BLEXIT - KingFace
sa "https://www.youtube.com/watch?v=Z4UFgPbmzfU" --language en # - date: 2020-03-24 - title: Florida Needs BLEXIT!
sa "https://www.youtube.com/watch?v=MTN-_EHgncc" --language en # - date: 2020-03-22 - title: BLEXIT Ft. Lauderdale was Sizzling HOT!
sa "https://www.youtube.com/watch?v=FvqlgK-kCPo" --language en # - date: 2020-03-21 - title: BLEXIT Hits The Streets - MLK Weekend in Charlotte
sa "https://www.youtube.com/watch?v=cbdWU0aNVf4" --language en # - date: 2020-03-20 - title: BLEXIT Charlotte - Be A VICTOR!
sa "https://www.youtube.com/watch?v=rMZv3Cr59x8" --language en # - date: 2020-03-19 - title: BLEXIT ATLANTA - A New Generation of Freedom Fighters
sa "https://www.youtube.com/watch?v=EPWDWTTABhE" --language en # - date: 2020-03-18 - title: BLEXIT - BORN READY for ATLANTA!
sa "https://www.youtube.com/watch?v=Z1oyWf2iZ6o" --language en # - date: 2020-03-09 - title: DINESH D'Souza at #BLEXITFL
sa "https://www.youtube.com/watch?v=X4lwDUahqOI" --language en # - date: 2020-03-09 - title: Will Witt @ #BLEXITFL
sa "https://www.youtube.com/watch?v=UY8Vu0Il9Zc" --language en # - date: 2020-03-09 - title: Candace Owens Opening Remarks BLEXITFL
sa "https://www.youtube.com/watch?v=UsfOv_QlmWs" --language en # - date: 2020-03-09 - title: BLEXITFL Breakdown Pierre Wilson
sa "https://www.youtube.com/watch?v=Krxb7rqVSn4" --language en # - date: 2020-03-09 - title: Brandon Tatum at #BLEXITFL
sa "https://www.youtube.com/watch?v=ICApzOjODBQ" --language en # - date: 2020-03-09 - title: "Amazing Grace" by Maddie Assel #BLEXITFL
sa "https://www.youtube.com/watch?v=dB4ZkJmOXHY" --language en # - date: 2020-03-09 - title: Larry Elder at #BLEXITFL
sa "https://www.youtube.com/watch?v=cf0qbouT8R8" --language en # - date: 2020-03-09 - title: Save The Babies! KingFace with Bryson Gray #BLEXITFL
sa "https://www.youtube.com/watch?v=A-H-zC42fcA" --language en # - date: 2020-03-09 - title: KingFace - Entire Presentation @ #BLEXITFL
sa "https://www.youtube.com/watch?v=4t2bjsbU7lo" --language en # - date: 2020-03-09 - title: Candace Owens Closing Remarks #BLEXITFL
sa "https://www.youtube.com/watch?v=jZ7wWnzkEEY" --language en # - date: 2020-01-21 - title: Mark Robinson at BLEXIT Charlotte
sa "https://www.youtube.com/watch?v=JQDep6y9xmg" --language en # - date: 2020-01-21 - title: BLEXIT Breakdown Charlotte with Pierre Wilson
sa "https://www.youtube.com/watch?v=eDJq3z2iaME" --language en # - date: 2020-01-21 - title: KingFace at BLEXIT Charlotte
sa "https://www.youtube.com/watch?v=AHMBCl1HcoA" --language en # - date: 2020-01-21 - title: Will Witt at BLEXIT Charlotte
sa "https://www.youtube.com/watch?v=40suMmbfnn8" --language en # - date: 2020-01-21 - title: Larry Elder at BLEXIT Charlotte
sa "https://www.youtube.com/watch?v=XKm8WIMpzMU" --language en # - date: 2020-01-20 - title: Brandon Tatum at BLEXIT Charlotte
sa "https://www.youtube.com/watch?v=MmblNqC-0YE" --language en # - date: 2020-01-20 - title: Candace Owens at BLEXIT Charlotte  Closing remarks
sa "https://www.youtube.com/watch?v=eRJc8nv3k4w" --language en # - date: 2020-01-20 - title: BLEXIT Charlotte Candace Owens' Opening Remarks
sa "https://www.youtube.com/watch?v=z5ATINaBzKo" --language en # - date: 2019-11-11 - title: BLEXIT ATLANTA Bishop E.W. Jackson
sa "https://www.youtube.com/watch?v=x943qTbD2P0" --language en # - date: 2019-11-11 - title: BLEXIT ATLANTA Candace Owens' Wedding Highlights and  Closing Remarks
sa "https://www.youtube.com/watch?v=OKqaWG1zvmw" --language en # - date: 2019-11-11 - title: BLEXIT ATLANTA David Harris Jr.
sa "https://www.youtube.com/watch?v=Kf6hUc2bHek" --language en # - date: 2019-11-11 - title: BLEXIT ATLANTA KingFace
sa "https://www.youtube.com/watch?v=GXEKNvPotd0" --language en # - date: 2019-11-11 - title: BLEXIT ATLANTA Terrence K Williams
sa "https://www.youtube.com/watch?v=CrByEkvn04Q" --language en # - date: 2019-11-11 - title: BLEXIT ATLANTA Candace Owens Opening Remarks
sa "https://www.youtube.com/watch?v=c2Pob4LvHJk" --language en # - date: 2019-11-11 - title: BLEXIT ATLANTA Maj Toure - Black Guns Matter
sa "https://www.youtube.com/watch?v=2fNoAEouLew" --language en # - date: 2019-11-11 - title: BLEXIT ATLANTA Brandon Tatum
sa "https://www.youtube.com/watch?v=rQAJbt7HsEQ" --language en # - date: 2019-09-15 - title: Rob Smith - BLEXIT Baltimore
sa "https://www.youtube.com/watch?v=QC1vqPFh5qw" --language en # - date: 2019-09-15 - title: BLEXIT Baltimore - Candace Owens Opening Remarks
sa "https://www.youtube.com/watch?v=jmF8njJKNzU" --language en # - date: 2019-09-15 - title: Will Witt - BLEXIT Baltimore
sa "https://www.youtube.com/watch?v=_-DA9ttmu_s" --language en # - date: 2019-09-15 - title: Shannon Wright - BLEXIT BALTIMORE
sa "https://www.youtube.com/watch?v=7cbSFSCyuYw" --language en # - date: 2019-09-15 - title: Brandon Tatum - BLEXIT Baltimore
sa "https://www.youtube.com/watch?v=5Z3SXQjDmsc" --language en # - date: 2019-09-15 - title: David J Harris Jr. - BLEXIT Baltimore
sa "https://www.youtube.com/watch?v=4p5GZNyPhrE" --language en # - date: 2019-09-15 - title: Candace Owens at BLEXIT Baltimore
sa "https://www.youtube.com/watch?v=VLoc1hbwRwA" --language en # - date: 2019-04-28 - title: BLEXIT DALLAS - David J. Harris Jr. & Birthday Wishes for Candace
sa "https://www.youtube.com/watch?v=nXARVLg2HgU" --language en # - date: 2019-04-28 - title: BLEXIT DALLAS - Rob Smith Jr.
sa "https://www.youtube.com/watch?v=hSjaccs_Zcg" --language en # - date: 2019-04-28 - title: BLEXIT DALLAS Opening Remarks: Candace Owens & Brandon Tatum
sa "https://www.youtube.com/watch?v=hCpVYOIvdCU" --language en # - date: 2019-04-28 - title: BLEXIT DALLAS Will Witt
sa "https://www.youtube.com/watch?v=GNnG9KYB0_E" --language en # - date: 2019-04-28 - title: BLEXIT DALLAS Mike Ayetiwa
sa "https://www.youtube.com/watch?v=FjslBvqKNJk" --language en # - date: 2019-04-28 - title: BLEXIT DALLAS - Brandon Tatum
sa "https://www.youtube.com/watch?v=8bADCVYLPJk" --language en # - date: 2019-04-28 - title: BLEXIT DALLAS - Rogan O'Handley
sa "https://www.youtube.com/watch?v=-89CKymtA3U" --language en # - date: 2019-04-28 - title: BLEXIT DALLAS Dinesh D'Souza
sa "https://www.youtube.com/watch?v=ujHRL6-62o0" --language en # - date: 2019-03-03 - title: Bishop E.W. Jackson at BLEXITRVA
sa "https://www.youtube.com/watch?v=TBH_JkJXmbM" --language en # - date: 2019-03-03 - title: Dinesh D'Souza at BLEXITRVA
sa "https://www.youtube.com/watch?v=SWZoc7q9oV0" --language en # - date: 2019-03-03 - title: Will Witt at BLEXITRVA
sa "https://www.youtube.com/watch?v=QZbyTj4D-IE" --language en # - date: 2019-03-03 - title: Rob Smith at BLEXITRVA
sa "https://www.youtube.com/watch?v=Lvs04rv8xM0" --language en # - date: 2019-03-03 - title: Q&A at BLEXITRVA
sa "https://www.youtube.com/watch?v=dNHiuEZT-fM" --language en # - date: 2019-03-03 - title: BLEXITRVA Candace Owens' Opening Remarks
sa "https://www.youtube.com/watch?v=aIopYNSdCmI" --language en # - date: 2019-03-03 - title: Jerome Hudson at BLEXITRVA
sa "https://www.youtube.com/watch?v=5L5Jd8ZNMkw" --language en # - date: 2019-03-03 - title: DC Draino at BLEXITRVA
sa "https://www.youtube.com/watch?v=4tSOxfo_M3M" --language en # - date: 2019-03-03 - title: Brandon Tatum at BLEXITRVA
sa "https://www.youtube.com/watch?v=uNV_D4VQ4lY" --language en # - date: 2019-02-28 - title: BLACKS AND LATINOS ARE EXITING THE DEMOCRAT PARTY!
sa "https://www.youtube.com/watch?v=KmaZKkx7zw4" --language en # - date: 2019-01-23 - title: Opening Remarks & Larry Elder at BLEXITLA
sa "https://www.youtube.com/watch?v=xrNaFxNHVII" --language en # - date: 2019-01-22 - title: Will Witt @ BLEXITLA  Full Speech
sa "https://www.youtube.com/watch?v=PEaBdP4Rwvg" --language en # - date: 2019-01-22 - title: Brandon Tatum @ BLEXITLA Full Speech
sa "https://www.youtube.com/watch?v=256XW5Lbw3w" --language en # - date: 2019-01-22 - title: Ann Coulter @ BLEXITLA Full Speech
sa "https://www.youtube.com/watch?v=vNAwKf3cSNA" --language en # - date: 2019-01-21 - title: Larry Elder at BLEXITLA
sa "https://www.youtube.com/watch?v=tXOHchFcyEA" --language en # - date: 2019-01-21 - title: Major Williams at BLEXITLA
sa "https://www.youtube.com/watch?v=Rro4Zq45Zw4" --language en # - date: 2019-01-21 - title: Rob Smith at BLEXITLA
sa "https://www.youtube.com/watch?v=MpxQaMIadAg" --language en # - date: 2019-01-21 - title: Candace's Closing Remarks at BLEXITLA
sa "https://www.youtube.com/watch?v=HWbvsHM2zqQ" --language en # - date: 2019-01-21 - title: Hip Hop Panel
sa "https://www.youtube.com/watch?v=7zRYQ6Q5Ce4" --language en # - date: 2019-01-21 - title: LEXIT AT BLEXITLA
sa "https://www.youtube.com/watch?v=Pe5u20JO2sk" --language en # - date: 2018-12-17 - title: Fact or Narrative: Are Private Prisons Evil?
sa "https://www.youtube.com/watch?v=OYTBiwaRIkk" --language en # - date: 2018-05-11 - title: What Candace Owens Thinks (How to create a mind)
sa "https://www.youtube.com/watch?v=ByjXeilefJs" --language en # - date: 2018-02-22 - title: Black Panther: A Pro-Trump Movie
sa "https://www.youtube.com/watch?v=at0t53G3C7U" --language en # - date: 2018-02-13 - title: White Guilt: a trend that needs to die
sa "https://www.youtube.com/watch?v=KwEWlstT9lA" --language en # - date: 2018-01-23 - title: Women Marching In America Again? What a JOKE.
sa "https://www.youtube.com/watch?v=KrwmLH8QD7I" --language en # - date: 2018-01-05 - title: The Left Thinks Black People Are Stupid
sa "https://www.youtube.com/watch?v=Nkns8In6jH4" --language en # - date: 2018-01-03 - title: Tax Cuts For Dummies
sa "https://www.youtube.com/watch?v=iD0CYKK_mMo" --language en # - date: 2017-12-14 - title: Trump Derangement Syndrome: An American Epidemic
sa "https://www.youtube.com/watch?v=evd_uwHgXeA" --language en # - date: 2017-12-08 - title: The Left Uses "Racism" To Control Black Voters
sa "https://www.youtube.com/watch?v=7Bl_LSa4sJA" --language en # - date: 2017-11-27 - title: Kaepernick, Jay Z and Al Sharpton Are Frauds
sa "https://www.youtube.com/watch?v=FdN8lDc1kAU" --language en # - date: 2017-11-06 - title: Chelsea Handler Blames Mass Shooting Victims For Their Own Deaths?
sa "https://www.youtube.com/watch?v=TfE_I-V4_C8" --language en # - date: 2017-10-29 - title: Halloween Is Cancelled Because Liberalism.
sa "https://www.youtube.com/watch?v=HcnwJyFcQsM" --language en # - date: 2017-10-14 - title: Harvey Weinstein, Eminem, and why the left can't stop losing
sa "https://www.youtube.com/watch?v=rHG0vom4xjs" --language en # - date: 2017-09-30 - title: The NFL is Anti American?
sa "https://www.youtube.com/watch?v=U8oosSynpdU" --language en # - date: 2017-09-20 - title: Nobody Likes Feminism: that's what happened, Hillary.
sa "https://www.youtube.com/watch?v=bLSB7oxib9I" --language en # - date: 2017-09-08 - title: Dear Celebrities: NOBODY CARES WHAT YOU THINK!!!
sa "https://www.youtube.com/watch?v=DWGUIjterF4" --language en # - date: 2017-09-01 - title: What Youtube and Facebook REALLY think of Black people
sa "https://www.youtube.com/watch?v=085u0NnAgjA" --language en # - date: 2017-08-26 - title: WTF? Black Lives Matter Has A List of Demands for White People!
sa "https://www.youtube.com/watch?v=ILQXW2Ob1PU" --language en # - date: 2017-08-22 - title: How to Escape the Democrat Plantation (an easy guide).
sa "https://www.youtube.com/watch?v=4S2TZOdXAtQ" --language en # - date: 2017-08-16 - title: I Don't Care About Charlottesville, the KKK, or White Supremacy
sa "https://www.youtube.com/watch?v=fvEYQqlNno8" --language en # - date: 2017-08-07 - title: Rape Vs. Regret: Here's the difference
sa "https://www.youtube.com/watch?v=3syO-43OboM" --language en # - date: 2017-07-29 - title: No Transgender People in the Army: Who cares?
sa "https://www.youtube.com/watch?v=M7M4y8jEn_s" --language en # - date: 2017-07-25 - title: Sovieta RX (A prescription to combat Russian Hysteria)
sa "https://www.youtube.com/watch?v=hJRdRhsuNok" --language en # - date: 2017-07-21 - title: The Myth of the "Coon": Black Lives Don't Matter
sa "https://www.youtube.com/watch?v=OLHx2HPJPE8" --language en # - date: 2017-07-16 - title: Feminism vs. Also Feminism
sa "https://www.youtube.com/watch?v=dgKc-2rFcRw" --language en # - date: 2017-07-10 - title: Mom, Dad....I'm a Conservative.exit
exit

#batch_sa "https://x.com/sloantv1/status/1841830580243296649"
#batch_sa "https://x.com/sloantv1/status/1841847945676915042"
#batch_sa "https://x.com/sloantv1/status/1841855498599203011"

# cd ~/movies
# dnw.sh
exit
# batch_sa "https://odysee.com/@jeremypoole:b/PROF-RYSZARD-LEGUTKO--Two-minutes-of-truth,-of-bitter-truth--in-the-European-Parliament:b9" --language en
# batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/the-demon-in-democracy-%E2%80%93-ryszard:6" --language en
# batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/the-demon-in-democracy-%E2%80%93-ryszard-2:7" --language en
# batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/the-demon-in-democracy-%E2%80%93-ryszard-3:f" --language en
# batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/the-demon-in-democracy-%E2%80%93-ryszard-4:6" --language en
# batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/the-demon-in-democracy-%E2%80%93-ryszard-5:4" --language en
# batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/the-demon-in-democracy-%E2%80%93-ryszard-6:5" --language en
# batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/the-demon-in-democracy-%E2%80%93-ryszard-7:0" --language en
# batch_sa "https://odysee.com/@kaschuta:f/ryszard-legutko-are-we-free:c" --language en

#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human:2" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-2:6" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-3:5" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-4:b" --language en
#exit
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-5:b" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-6:0" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-7:8" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-8:d" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-9:7" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-10:5" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-11:d" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-12:9" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-13:1" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-14:6" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-15:b" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-16:d" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-17:4" --language en
#batch_sa "https://odysee.com/@EugenRichterAudiobooks:2/mass-control-engineering-human-18:2" --language en
#batch_sa "https://odysee.com/@ElijahOsborne:3/Jim-Keith-Mass-Control:1" --language en


# sleep 10
# shutdown
exit

# batch_sa "https://rumble.com/v5fxyit-insider-uk-govt-hired-mercenary-nurses-to-involuntarily-euthanize-millions-.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5fu1to-fbi-seize-horrific-obama-freak-off-tapes-featuring-underage-justin-bieber.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5fpuh1-the-deep-state-plot-to-kill-trump-is-more-sinister-thank-you-think-intervie.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5fjbel-police-discover-dirty-bomb-at-new-york-trump-rally-cover-up-exposed.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5fdyz1-wef-unveil-tech-to-forcefully-rewire-dangerous-conspiracy-theorists-brains.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5f70ch-wef-insider-warns-elite-planning-dirty-bomb-terror-attack-at-trump-rally.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5f2ed9-murdered-fbi-chiefs-last-interview-uncovered-d.c.-elite-are-satanic-pedophi.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5eyadl-japan-declares-pharma-execs-enemies-of-the-state-for-role-in-mrna-massacre.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5etmqk-cia-agent-testifies-agency-created-hip-hop-to-keep-black-americans-enslaved.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5ektc4-usaf-pilot-exposes-top-secret-chemtrails-mind-control-program-to-destroy-ci.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5efc6l-elon-musk-caught-plotting-with-wef-to-eradicate-sovereignty.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5ealop-prosecutors-trudeau-facing-prison-for-destroying-mrna-genocide-evidence.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5e5lzx-taylor-swift-insider-leaks-adrenochrome-contract-elites-must-sign-to-join-i.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5e14h1-wef-insider-elite-deploying-ai-terrorists-to-cancel-us-election.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5dwnas-gates-insider-digital-id-will-be-embedded-under-the-skin-of-every-child-by-.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5doe35-gates-foundation-insider-admits-ivermectin-cures-man-made-turbo-cancer.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5dh9gt-adrenochrome-taskforce-rescues-hundreds-of-kids-trafficked-by-marina-abramo.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5dcdf9-japan-warns-covid-vaccines-causing-global-population-collapse.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5d09er-insider-trump-to-shatter-un-into-a-thousand-pieces-and-arrest-covid-plandem.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5cvoel-pfizer-insiders-admit-vaccinated-men-are-being-chemically-castrated.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5crg78-trump-insider-arrest-warrants-ready-for-elites-spraying-genocidal-chemtrail.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5cm5ph-official-nasa-documents-confirm-plans-for-mass-extinction-event-in-2025.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5ch7y5-insider-gates-developing-october-surprise-supervirus-to-force-lockdowns-bef.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5ccmxx-whistleblower-nancy-pelosi-murdered-a-child-in-horrific-adrenochrome-ritual.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5c9fib-korea-launches-investigation-into-genocidal-mrna-nanotech-found-in-billions.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5c5119-investigators-tom-hanks-facing-prison-on-sickening-pedophilia-and-murder-ch.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5bzks5-wef-document-confirms-6-billion-humans-will-die-in-2025.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5bq2f1-insider-alex-soros-has-secret-back-door-access-to-23k-voting-machines.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5bm04t-whistleblower-bill-gates-inserting-hiv-in-monkeypox-vaccine.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5bg7sl-whistleblower-bill-gates-seeding-monkeypox-in-major-cities-via-chemtrails.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5bf4c2-false-flag-financial-collapse-is-coming-are-you-prepared-interview-with-pau.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5bcsad-pope-frances-orders-humanity-to-follow-universal-bishop-klaus-schwab-during.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5b65lx-wef-memo-outlines-plot-to-roll-out-sharia-law-and-legalize-pedophilia-in-we.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5b2we5-doctors-killed-in-plane-crash-had-found-cure-for-man-made-turbo-cancer.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5axf9h-taylor-swift-insider-reveals-singer-is-a-man-who-worships-satan.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5aszxh-doctors-killed-in-plane-crash-vowed-to-release-evidence-linking-mrna-to-tur.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5alksz-adrenochrome-whistleblower-zelensky-and-other-leaders-are-addicted-to-child.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5agvnd-japans-declares-state-of-emergency-after-nanobots-found-in-96-million-citiz.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5actk5-pfizer-vp-blows-whistle-viruses-do-not-exist.html?e9s=src_v1_ucp" --language en
# exit
# batch_sa "https://rumble.com/v5a8db0-wef-memo-reveals-plan-to-usher-in-financial-great-reset-via-false-flag-race.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5a3q1h-kamala-harris-pizzagate-crimes-exposed-as-her-dad-reveals-shameful-history.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v59x9l0-official-govt-docs-prove-brigitte-macron-is-a-male-pedophile-media-blackout.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v59ogjh-covid-vaccine-inventor-blows-whistle-mrna-was-designed-to-depopulate-the-wo.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v59kp3h-millions-of-brits-rise-up-against-govt-plan-to-eliminate-natives-by-2030.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v59d2hx-bill-gates-and-who-call-for-military-to-round-up-mrna-vaccine-refusers-duri.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5961pp-olympics-insider-hundreds-of-kids-tortured-and-killed-during-satanic-games-.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v58w9i5-wef-memo-reveals-plan-to-depopulate-the-world-of-1-billion-white-people-by-.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v58qfdf-japan-launches-covid-mrna-vaccine-taskforce-to-investigate-crimes-against-h.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v58lmdh-bill-gates-convinces-govt-to-force-jab-public-by-adding-mrna-to-everyday-fo.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v58fcp9-mel-gibson-biden-sacrificed-by-illuminati-as-new-satanic-leader-selected-in.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v58adbx-how-to-prepare-for-the-coming-grid-collapse-interview-with-paul-stone.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v584emd-wef-plotting-catastrophic-grid-outage-that-will-permanently-reset-america-b.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v57v0c3-top-pilot-testifies-bill-gates-is-fumigating-cities-with-mood-altering-chem.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v57o4e1-wef-order-govts-to-strip-parents-of-all-rights-children-belong-to-the-state.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v57gdv1-philippines-demand-mrna-genocide-investigation-following-millions-of-vax-de.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v57d59t-wef-memo-reveals-three-more-trump-assassination-attempts-incoming.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5736cy-leaked-secret-service-video-proves-trump-assassination-attempt-was-inside-j.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v56yb3n-putins-adrenochrome-taskforce-intercept-israeli-ship-trafficking-hundreds-o.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v56tpmt-usaf-veteran-blows-whistle-chemtrails-op-has-targeted-kill-rate-of-86.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v56ms31-pfizer-vp-blows-whistle-vaccine-designed-to-cause-lucrative-health-problems.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v56ep2d-uk-govt-docs-quietly-admit-vaccine-holocaust-will-kill-millions-of-children.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v566ldc-top-pilot-issues-warning-bill-gates-force-vaxxing-mrna-via-chemtrails.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v55y28s-lgbtq-leaders-sign-wef-treaty-to-accept-pedophiles-as-legally-protected-min.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v55qjsj-vaccinated-corpses-are-emitting-radio-frequencies-that-trace-back-to-bill-g.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v55cuxo-leaked-docs-show-michelle-obama-listed-as-male-on-2024-voter-forms.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5532mj-bidens-family-admit-elite-replaced-real-joe-biden-years-ago.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v54pzzh-pilots-testify-bill-gates-is-carpet-bombing-cities-with-chemtrails.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v54hxwz-wef-unveils-ai-smart-tech-to-ethically-eliminate-non-compliant-humans.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v54d5wu-putin-issues-urgent-warning-us-preparing-bird-flu-false-flag-to-sabotage-el.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v53xixe-icc-insider-arrest-warrants-issued-for-elites-who-committed-crimes-against-.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v53l84i-israeli-official-admits-we-orchestrated-911-to-sabotage-america.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v53b2wd-putin-vows-to-shut-down-hollywood-adrenochrome-supply-chain.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5343n6-us-govt-building-secret-detention-facilities-in-50-states-for-non-compliant.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v52xfsl-george-soros-caught-boasting-all-future-elections-are-100-rigged.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v52qjni-japan-billions-of-dying-vaxxed-have-dementia-perpetrators-must-be-punished.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v52jnu7-russia-rescues-hundreds-of-adrenochrome-victims-destined-for-washington-d.c.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v52adis-bill-gates-chef-says-billionaire-refused-to-feed-his-family-fake-meat.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v51zmc9-australia-mandates-food-rations-to-prepare-for-bird-flu-pandemic.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v51svce-kate-middleton-caught-sending-sos-to-world-theyre-going-to-kill-me.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v51lv5d-george-clooney-working-with-police-to-shut-down-alternative-media.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v51fn7k-world-leader-confesses-unvaxxed-were-right-we-tried-poisoning-billions-of-y.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v518gzb-putin-vows-to-release-sickening-hunter-biden-child-sex-tapes-that-will-end-.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v50zilu-top-bbc-presenter-found-dead-after-vowing-to-expose-covid-vaccines.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v50lbl6-hillary-clinton-facing-life-in-prison-for-crimes-against-children.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v50duix-pope-francis-urges-pride-organizers-to-be-inclusive-of-pedosexuals.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v505icx-fauci-boasted-mrna-is-lethal-to-kids-in-newly-leaked-video.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4ztazu-global-elite-declares-war-ondangerous-anti-vaxxers-who-must-be-stripped-of-.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4zl88z-japan-billions-of-vaccinated-will-die-those-responsible-must-pay.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4zcz16-wef-unveils-mandatory-brain-implants-to-eradicate-conspiracy-theories.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4z5gou-wef-insider-klaus-schwab-facing-death-penalty-for-crimes-against-humanity.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4yiitl-bill-gates-caught-telling-inner-circle-global-famine-will-make-elites-god-l.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4yaivr-how-to-protect-your-money-from-agenda-2030-interview-with-paul-stone.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4y1xat-cia-agent-testifies-we-invented-mrna-as-a-bioweapon-with-gates-and-wef.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4xpdju-hospitals-murdered-patients-in-cold-blood-to-meet-covid-targets-whistleblow.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4xdq9h-wef-orders-govts-to-burn-millions-of-bees-to-usher-in-global-famine.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4wzoxl-pfizer-insider-admits-pandemic-was-a-depopulation-scam.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4wlvh9-elite-pedo-victim-claims-hung-michelle-obama-attended-satanic-sex-parties.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4w7mjw-deleted-wef-memo-reveals-trump-is-on-hit-list-of-leaders-to-be-assassinated.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4vyz00-busted-secret-hollywood-pharmacy-caught-selling-adrenochrome-pills-to-elite.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4vioxw-covid-vaccines-have-highest-kill-rate-in-medical-history-media-blackout.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4v51he-ashley-biden-singing-like-a-canary-in-elite-pedophile-investigation.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4up4xi-100-digital-wef-orders-govts-to-outlaw-cash-for-non-licensed-individuals.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4ubg6t-trudeau-orders-military-to-round-up-conspiracy-theorists-in-reeducation-cam.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4u3u3q-gates-foundation-insider-admits-the-pandemic-was-a-hoax.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4tqh78-japan-to-ban-mrna-as-turbo-cancers-among-vaxxed-skyrocket.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4t0725-doctors-ordered-to-euthanize-millions-of-vaccinated-patients-to-cover-up-di.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4sfs2z-epstein-victim-names-vips-who-rape-and-torture-kids-for-satan.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4sbd0x-gates-insider-admits-elite-planning-to-euthanise-billions-via-bird-flu-vacc.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4s2uh5-top-doctor-blows-the-whistle-chemicals-in-vaccines-are-turning-kids-trans.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4rwvn6-sickening-tape-of-bernie-sanders-raping-boy-surfaces-in-new-pizzagate-files.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4rlbtt-un-says-dangerous-conspiracy-theorists-must-be-punished-like-terrorists.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4r7hw6-wef-insider-warns-steaks-will-soon-be-made-from-human-sht.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4qq8jl-mel-gibson-hollywood-pedos-using-diddy-to-cover-up-horrific-crimes-of-satan.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4qd8yo-docs-reveal-israel-iran-conflict-planned-100-years-ago-to-spark-world-war-3.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4pxszq-pfizer-admits-mrna-jabs-contain-nanobots-that-permanently-alters-dna.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4phenf-justin-trudeau-facing-life-behind-bars-on-child-rape-charges.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4p8aec-uk-govt-to-imprison-citizens-who-eat-meat-under-absolute-zero-rules.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4ou4ze-boeing-whistleblower-plane-crashes-are-inside-job-by-global-elite-to-usher-.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4ogsk6-us-states-sign-wef-treaty-to-spray-chemtrails-that-permanently-block-the-su.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4o2bak-p-diddy-insider-sickening-child-sex-tapes-involving-elite-vips-given-to-fbi.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4nvpo5-top-virologist-warns-massive-massive-tsunami-of-mrna-vaccinated-deaths-on-h.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4nffrf-john-kerrys-daughter-says-billions-of-humans-must-die-for-the-new-world-ord.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4n41a6-german-govt-admits-there-was-no-pandemic.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4ltzet-wef-declares-pedophilia-sexual-orientation-must-be-added-to-lgbtq.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4ltp2b-wef-memo-orders-devastating-cyber-attacks-on-us-water-supply.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4ltea6-palace-insider-kate-middletons-cancer-is-psy-op-to-normalize-turbo-cancer-d.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4lp9ef-putin-says-barack-obama-is-a-legitimate-military-target-following-moscow-at.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4l8ul3-top-doctor-details-huge-financial-incentives-for-hospitals-to-murder-covid-.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4kngqi-putin-accuses-western-leaders-of-pedophilia-and-cannibalism.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4kem6z-royal-insider-kate-middleton-was-sacrificed-and-replaced-with-body-double.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4k0ym3-clintons-secret-pedophile-and-cannibal-club-in-haiti-exposed-by-locals.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4jlzq9-royal-insider-kate-middleton-was-murdered-in-illuminati-blood-sacrifice.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4jb6qx-scientists-discover-alien-dna-hidden-in-blood-of-vaccinated-people.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v4j0yt5-bill-gates-urges-govts-to-replace-farmers-with-ai-smart-farming-bots.html?e9s=src_v1_ucp" --language en

# batch_sa "https://rumble.com/v5gbh58-rfk-i-have-evidence-to-lock-up-cdc-and-big-pharma-execs-for-life.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5g2cm3-rfk-jr-fauci-must-be-prosecuted-for-330k-murders-as-mass-graves-found-outsi.html?e9s=src_v1_ucp" --language en
# batch_sa "https://rumble.com/v5g6jkt-celebrities-and-ceos-facing-life-in-prison-as-diddys-adrenochrome-ring-bust.html?e9s=src_v1_ucp" --language en


batch_sa "https://rumble.com/v4ikcuw-wef-insider-reveals-the-new-911-will-be-a-global-famine.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4i6y22-michelle-obama-beat-sht-out-of-barack-after-trans-rumors-forced-her-out-of-.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4hsrnh-justin-bieber-jay-z-rapes-and-murders-children-in-satanic-rituals.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4hgmfu-wef-orders-govts-to-digitize-billions-of-citizens-brains-before-mass-extinc.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4h0c7x-mel-gibson-global-elites-will-keep-dying-to-make-way-for-the-antichrist.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4gomr0-hollywood-elite-panic-as-p-diddy-victim-vows-to-name-vip-pedophiles.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4gd9rw-trudeau-panics-as-arrest-warrants-issued-against-wef-young-global-leaders.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4g1hjt-wef-insider-imminent-false-flag-cyber-attack-will-disrupt-2024-election.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4fa6dl-child-rape-victim-testifies-michelle-obama-raped-me-when-she-was-a-man.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4etz69-rfk-jr-covid-jabs-are-bioweapons-developed-by-u.s.-military.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4efzbh-wef-passes-new-law-to-criminalize-criticism-of-mrna.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4e5vo6-mel-gibson-prince-william-is-the-antichrist.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4do2or-eu-legalizes-child-porn-as-wef-agenda-to-normalize-pedophilia-accelerates.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4ddarr-pfizer-to-rake-in-trillions-from-turbo-cancer-deaths-insider-claims.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4cqr9o-bill-gates-orders-govts-to-blacklist-citizens-who-share-non-mainstream-cont.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4ceis6-top-oncologist-blows-whistle-on-mrna-fallout-weve-never-seen-cancers-behavi.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4c1qni-pope-francis-orders-christians-to-pray-to-satan-for-real-enlightenment.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4bm4oq-king-charles-and-close-friends-raped-hundreds-of-children-explosive-new-tes.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4bbiif-american-leaders-sign-wef-treaty-to-ration-meat-electricity-and-gas.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4aquui-taylor-swift-murdered-a-fan-in-satanic-blood-ritual-to-join-illuminati-insi.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4aaktf-covid-vaccines-are-officially-deadliest-drug-in-history-and-nobody-is-allow.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4a1eck-wef-unveils-flying-microchips-that-can-detect-thought-crimes-and-disable-yo.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v49flc6-top-doctor-blows-the-whistle-admits-vaccinated-are-developing-full-blown-ai.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v499myf-wef-tells-americans-your-god-given-rights-are-a-fiction-you-will-be-happier.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v48t24u-turbo-aids-set-to-kill-billions-after-disease-x-rollout-gates-insider-warns.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v48j9uc-child-sex-workers-fully-booked-at-davos-wef-insider-says.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v47t0xl-hillary-clinton-named-person-of-interest-in-child-sex-trafficking-investiga.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v47inw0-wef-insider-admits-disease-x-will-be-final-solution-to-depopulate-6-billion.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v4708dl-oprah-facing-life-behind-bars-on-child-sex-trafficking-charges.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v46oqyu-horrific-child-adrenochrome-market-found-in-nyc-jewish-tunnels-media-blacko.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v46fqw0-democrat-insider-warns-michelle-obamas-history-as-a-man-is-being-exposed.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v467m3r-millions-of-germans-rise-up-against-fascist-wef-agenda-media-blackout.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v45nn5q-russia-declares-covid-pandemic-was-strategic-operation-to-control-humanity.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v45jh70-fbi-horrific-child-sex-tapes-of-top-politicians-hidden-in-epstein-case.html?e9s=src_v1_ucp" --language en
exit
batch_sa "https://rumble.com/v455x4k-pfizer-insider-admits-mrna-set-to-kill-billions-within-months.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v44ynuq-leaked-bill-gates-ai-plot-to-install-wef-leaders-worldwide-in-2024.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v448g83-the-people-are-rising-up-2023-was-the-year-conspiracy-theories-became-mains.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v43v2fr-pizzagate-investigator-who-exposed-vip-pedophile-network-to-millions-found-.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v433hnh-pope-francis-authorizes-wef-to-rewrite-fact-checked-holy-bible.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v42lmrk-official-govt-docs-prove-michelle-obama-did-not-give-birth.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v41zffv-putin-exposes-the-truth-about-the-fake-moon-landings.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v41fdyd-first-world-leader-facing-murder-charges-for-pushing-mrna-vaccines-on-publi.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v41bh34-barack-obama-orders-govts-to-prepare-public-for-imminent-depopulation-event.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v40yhta-putin-declares-globalist-terrorist-klaus-schwab-is-a-legitimate-military-ta.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v40gaw7-wef-orders-govts-to-arrest-whiteblowers-who-expose-depopulation-agenda.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v405w54-canada-euthanizing-thousands-of-citizens-with-low-credit-scores-every-week-.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3zmmlm-leaked-video-reveals-rockefeller-predicted-covid-jab-depopulation-agenda-in.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3yu1yd-military-insider-reveals-shocking-truth-about-malaysia-airlines-flight-370.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3ym3xp-fbi-begin-arresting-journalists-connected-to-pizzagate-pedophile-ring.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3yfjz4-zelensky-insider-blows-whistle-on-massive-elite-pedophile-ring-in-ukraine.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3y6wby-kanye-west-hollywood-elites-are-compromised-because-they-have-sex-with-kids.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3xr821-bill-gates-insider-boasts-billions-will-die-in-2024-plandemic.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3xekjq-mark-zuckerberg-partners-with-wef-to-imprison-billions-of-humans-in-digital.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3x352d-john-podestas-friend-and-pizzagate-debunker-caught-raping-babies.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3woamy-wef-orders-world-govts-to-lower-age-of-consent-to-12.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3wbahw-klaus-schwab-brags-wef-has-infiltrated-every-msm-outlet-in-the-world.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3vx4dg-leaked-docs-reveal-hamas-israel-false-flag-was-planned-in-detail-by-global-.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3va0up-obama-outed-as-shadow-president-secretly-orchestrating-hamas-israel-false-f.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3uxm6p-eu-declares-citizens-who-refuse-use-bill-gates-digital-id-will-be-excluded-.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3ubvgj-us-general-admits-globalists-planning-financial-crash-there-will-be-no-2024.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3tmia7-wef-insiders-jump-ship-as-prosecutors-prepare-nuremberg-2.0-trials.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3t8n76-bill-gates-facing-life-behind-bars-on-child-rape-charges.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3squzn-matthew-perry-vowed-to-expose-hollywood-pedophile-ring-before-he-was-found-.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3s2jfd-wef-founders-son-singing-like-a-bird-to-prosecutors-in-crimes-against-human.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3rs74a-canada-caught-harvesting-the-blood-and-organs-of-babies-for-elite-vips.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3rgcz7-hamas-insider-blows-whistle-cia-created-us-to-advance-new-world-order.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3qlxgg-wef-boasts-billions-of-humans-will-soon-be-replaced-with-ai-hybrids.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3qbtis-klaus-schwab-signs-order-drafting-us-men-and-women-to-fight-for-globalists-.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3pvpap-gates-foundation-insider-admits-depopulation-drugs-are-pumped-into-fast-foo.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3ozjw1-pope-francis-declares-klaus-schwab-is-more-important-than-jesus-christ.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3oez3v-insider-israel-attack-was-false-flag-to-start-holy-war-and-usher-in-one-wor.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3nvuxp-klaus-schwab-announces-hes-bringing-forward-the-end-of-car-ownership.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3ng5fm-mass-graves-of-thousands-of-children-killed-by-fauci-in-illegal-experiments.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3mxkrj-wef-orders-global-water-rationing-to-starve-billions-into-submission.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3mia11-john-kerrys-daughter-orders-govts-to-mass-euthanize-billions-of-people-befo.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3lui8v-un-declares-war-on-dangerous-conspiracy-theorists-who-are-threatening-agend.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3le26j-satanic-pedophile-marina-abramovic-becomes-head-of-ukraines-adrenochrome-fa.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3krlxv-klaus-schwab-admits-agenda-2030-is-failing-as-millions-rise-up-against-elit.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3jxp34-wef-calls-for-free-speech-concentration-camps-to-jail-first-amendment-terro.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3ja8u4-prince-warned-humanity-about-wefs-depopulation-agenda-in-1996.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3j20io-fbi-chief-warns-satanic-pedophiles-are-working-to-depopulate-earth.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3hz0au-klaus-schwab-hails-arrival-of-new-world-order-as-wef-seizes-control-over-na.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3hh6mu-cia-agent-confesses-on-deathbed-billions-will-die-in-2024.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3h0zc0-adl-declares-pedophiles-will-liberate-america.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3g19bc-prince-andrew-accused-of-sexually-abusing-children-in-ukraine.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3fdq3e-bidens-family-admit-he-died-and-was-replaced-by-an-actor-in-2019.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3ez5fg-barack-obamas-ex-boyfriend-admits-he-was-prime-suspect-in-gay-serial-killer.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3e47vn-wef-insider-boasts-of-plot-to-force-humanity-to-stop-eating-meat.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3dob72-wef-caught-paying-arsonists-to-burn-down-the-world-as-part-of-sick-depopula.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3cmt1y-wef-signs-order-cancelling-us-election-americans-must-be-ruled-by-global-el.html?e9s=src_v1_ucp" --language en
batch_sa "https://rumble.com/v3ccvpi-bill-gates-people-who-resist-mrna-tsunami-will-be-excluded-from-society.html?e9s=src_v1_ucp" --language en
