yt-dlp -i --merge-output-format mp4 --trim-filenames 50 --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')
echo "VAR: $VAR"

COMMAND="yt-dlp --sleep-subtitles 1 --merge-output-format mp4 --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime \
    	--write-auto-subs --write-subs --sub-langs "en,ru,uk,de,fr,es,pt,nl,iw"  --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass \"$*\" --cookies cookies/twitter.com_cookies.txt -o $FILENAME"
#

echo "$COMMAND" >> COMMANDS.SH
echo "$COMMAND" > command.sh
chmod +x command.sh
./command.sh
#exit
find . -maxdepth 1 -type f -name "$VAR.*.vtt" -print0 | sort -z | while IFS= read -r -d '' line; # do
do
	LANGUAGE="${line%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	echo "Converting subtitle file to .srt and fixing: $line"
	echo "Converting subtitle file to .srt and fixing: $line" >> error.log
	ffmpeg -n -hide_banner -i $BASENAME.$LANGUAGE.vtt $BASENAME.$LANGUAGE.srt
#	rm -f $BASENAME.$LANGUAGE.vtt
	echo "sof/sof $BASENAME.$LANGUAGE.srt" >> COMMANDS.SH
	sof/sof $BASENAME.$LANGUAGE.srt
#	echo "Moving $BASENAME.$LANGUAGE.srt* to dir: subs/$LANGUAGE"
	if [ ! -d "subs/$BASENAME" ]; then
		mkdir "subs/$BASENAME"
	fi	

	if [ ! -d "subs/$BASENAME/$LANGUAGE" ]; then
		mkdir "subs/$BASENAME/$LANGUAGE"
	fi	
	mv "$BASENAME.$LANGUAGE.vtt" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt.single" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt.double" "subs/$BASENAME/$LANGUAGE"

 	 if [ "$LANGUAGE" == "af"        ]; 	then LANGUAGE_FULL="Afrikaans" ; fi
     if [ "$LANGUAGE" == "he"        ]; 	then LANGUAGE_FULL="Hebrew" ; fi
     if [ "$LANGUAGE" == "pt"        ]; 	then LANGUAGE_FULL="Portuguese" ; fi
     if [ "$LANGUAGE" == "sq"        ]; 	then LANGUAGE_FULL="Albanian" ; fi
     if [ "$LANGUAGE" == "mrj"       ]; 	then LANGUAGE_FULL="Hill Mari" ; fi
     if [ "$LANGUAGE" == "pa"        ]; 	then LANGUAGE_FULL="Punjabi" ; fi
     if [ "$LANGUAGE" == "am"        ]; 	then LANGUAGE_FULL="Amharic" ; fi
     if [ "$LANGUAGE" == "hi"        ]; 	then LANGUAGE_FULL="Hindi" ; fi
     if [ "$LANGUAGE" == "otq"       ]; 	then LANGUAGE_FULL="Querétaro Otomi" ; fi
     if [ "$LANGUAGE" == "ar"        ]; 	then LANGUAGE_FULL="Arabic" ; fi
     if [ "$LANGUAGE" == "hmn"       ]; 	then LANGUAGE_FULL="Hmong" ; fi
     if [ "$LANGUAGE" == "ro"        ]; 	then LANGUAGE_FULL="Romanian" ; fi
     if [ "$LANGUAGE" == "hy"        ]; 	then LANGUAGE_FULL="Armenian" ; fi
     if [ "$LANGUAGE" == "mww"       ]; 	then LANGUAGE_FULL="Hmong Daw" ; fi
     if [ "$LANGUAGE" == "ru"        ]; 	then LANGUAGE_FULL="Russian" ; fi
     if [ "$LANGUAGE" == "az"        ]; 	then LANGUAGE_FULL="Azerbaijani" ; fi
     if [ "$LANGUAGE" == "hu"        ]; 	then LANGUAGE_FULL="Hungarian" ; fi
     if [ "$LANGUAGE" == "sm"        ]; 	then LANGUAGE_FULL="Samoan" ; fi
     if [ "$LANGUAGE" == "ba"        ]; 	then LANGUAGE_FULL="Bashkir" ; fi
     if [ "$LANGUAGE" == "is"        ]; 	then LANGUAGE_FULL="Icelandic" ; fi
     if [ "$LANGUAGE" == "gd"        ]; 	then LANGUAGE_FULL="Scots Gaelic" ; fi
     if [ "$LANGUAGE" == "eu"        ]; 	then LANGUAGE_FULL="Basque" ; fi
     if [ "$LANGUAGE" == "ig"        ]; 	then LANGUAGE_FULL="Igbo" ; fi
     if [ "$LANGUAGE" == "sr-Cyrl"   ]; 	then LANGUAGE_FULL="Serbian" ; fi
     if [ "$LANGUAGE" == "be"        ]; 	then LANGUAGE_FULL="Belarusian" ; fi
     if [ "$LANGUAGE" == "id"        ]; 	then LANGUAGE_FULL="Indonesian" ; fi
     if [ "$LANGUAGE" == "sr-Latn"   ]; 	then LANGUAGE_FULL="Serbian (Latin)" ; fi
     if [ "$LANGUAGE" == "bn"        ]; 	then LANGUAGE_FULL="Bengali" ; fi
     if [ "$LANGUAGE" == "ga"        ]; 	then LANGUAGE_FULL="Irish" ; fi
     if [ "$LANGUAGE" == "st"        ]; 	then LANGUAGE_FULL="Sesotho" ; fi
     if [ "$LANGUAGE" == "bs"        ]; 	then LANGUAGE_FULL="Bosnian" ; fi
     if [ "$LANGUAGE" == "it"        ]; 	then LANGUAGE_FULL="Italian" ; fi
     if [ "$LANGUAGE" == "sn"        ]; 	then LANGUAGE_FULL="Shona" ; fi
     if [ "$LANGUAGE" == "bg"        ]; 	then LANGUAGE_FULL="Bulgarian" ; fi
     if [ "$LANGUAGE" == "ja"        ]; 	then LANGUAGE_FULL="Japanese" ; fi
     if [ "$LANGUAGE" == "sd"        ]; 	then LANGUAGE_FULL="Sindhi" ; fi
     if [ "$LANGUAGE" == "yue"       ]; 	then LANGUAGE_FULL="Cantonese" ; fi
     if [ "$LANGUAGE" == "jv"        ]; 	then LANGUAGE_FULL="Javanese" ; fi
     if [ "$LANGUAGE" == "si"        ]; 	then LANGUAGE_FULL="Sinhala" ; fi
     if [ "$LANGUAGE" == "ca"        ]; 	then LANGUAGE_FULL="Catalan" ; fi
     if [ "$LANGUAGE" == "kn"        ]; 	then LANGUAGE_FULL="Kannada" ; fi
     if [ "$LANGUAGE" == "sk"        ]; 	then LANGUAGE_FULL="Slovak" ; fi
     if [ "$LANGUAGE" == "ceb"       ]; 	then LANGUAGE_FULL="Cebuano" ; fi
     if [ "$LANGUAGE" == "kk"        ]; 	then LANGUAGE_FULL="Kazakh" ; fi
     if [ "$LANGUAGE" == "sl"        ]; 	then LANGUAGE_FULL="Slovenian" ; fi
     if [ "$LANGUAGE" == "ny"        ]; 	then LANGUAGE_FULL="Chichewa" ; fi
     if [ "$LANGUAGE" == "km"        ]; 	then LANGUAGE_FULL="Khmer" ; fi
     if [ "$LANGUAGE" == "so"        ]; 	then LANGUAGE_FULL="Somali" ; fi
     if [ "$LANGUAGE" == "zh-CN"     ]; 	then LANGUAGE_FULL="Chinese Simple" ; fi
     if [ "$LANGUAGE" == "tlh"       ]; 	then LANGUAGE_FULL="Klingon" ; fi
     if [ "$LANGUAGE" == "es"        ]; 	then LANGUAGE_FULL="Spanish" ; fi
     if [ "$LANGUAGE" == "zh-TW"     ]; 	then LANGUAGE_FULL="Chinese Tradit" ; fi
     if [ "$LANGUAGE" == "tlh-Qaak"  ]; 	then LANGUAGE_FULL="Klingon (pIqaD)" ; fi
     if [ "$LANGUAGE" == "su"        ]; 	then LANGUAGE_FULL="Sundanese" ; fi
     if [ "$LANGUAGE" == "co"        ]; 	then LANGUAGE_FULL="Corsican" ; fi
     if [ "$LANGUAGE" == "ko"        ]; 	then LANGUAGE_FULL="Korean" ; fi
     if [ "$LANGUAGE" == "sw"        ]; 	then LANGUAGE_FULL="Swahili" ; fi
     if [ "$LANGUAGE" == "hr"        ]; 	then LANGUAGE_FULL="Croatian" ; fi
     if [ "$LANGUAGE" == "ku"        ]; 	then LANGUAGE_FULL="Kurdish" ; fi
     if [ "$LANGUAGE" == "sv"        ]; 	then LANGUAGE_FULL="Swedish" ; fi
     if [ "$LANGUAGE" == "cs"        ]; 	then LANGUAGE_FULL="Czech" ; fi
     if [ "$LANGUAGE" == "ky"        ]; 	then LANGUAGE_FULL="Kyrgyz" ; fi
     if [ "$LANGUAGE" == "ty"        ]; 	then LANGUAGE_FULL="Tahitian" ; fi
     if [ "$LANGUAGE" == "da"        ]; 	then LANGUAGE_FULL="Danish" ; fi
     if [ "$LANGUAGE" == "lo"        ]; 	then LANGUAGE_FULL="Lao" ; fi
     if [ "$LANGUAGE" == "tg"        ]; 	then LANGUAGE_FULL="Tajik" ; fi
     if [ "$LANGUAGE" == "nl"        ]; 	then LANGUAGE_FULL="Dutch" ; fi
     if [ "$LANGUAGE" == "la"        ]; 	then LANGUAGE_FULL="Latin" ; fi
     if [ "$LANGUAGE" == "ta"        ]; 	then LANGUAGE_FULL="Tamil" ; fi
     if [ "$LANGUAGE" == "mhr"       ]; 	then LANGUAGE_FULL="Eastern Mari" ; fi
     if [ "$LANGUAGE" == "lv"        ]; 	then LANGUAGE_FULL="Latvian" ; fi
     if [ "$LANGUAGE" == "tt"        ]; 	then LANGUAGE_FULL="Tatar" ; fi
     if [ "$LANGUAGE" == "emj"       ]; 	then LANGUAGE_FULL="Emoji" ; fi
     if [ "$LANGUAGE" == "lt"        ]; 	then LANGUAGE_FULL="Lithuanian" ; fi
     if [ "$LANGUAGE" == "te"        ]; 	then LANGUAGE_FULL="Telugu" ; fi
     if [ "$LANGUAGE" == "en"        ]; 	then LANGUAGE_FULL="English" ; fi
     if [ "$LANGUAGE" == "lb"        ]; 	then LANGUAGE_FULL="Luxembourgish" ; fi
     if [ "$LANGUAGE" == "th"        ]; 	then LANGUAGE_FULL="Thai" ; fi
     if [ "$LANGUAGE" == "eo"        ]; 	then LANGUAGE_FULL="Esperanto" ; fi
     if [ "$LANGUAGE" == "mk"        ]; 	then LANGUAGE_FULL="Macedonian" ; fi
     if [ "$LANGUAGE" == "to"        ]; 	then LANGUAGE_FULL="Tongan" ; fi
     if [ "$LANGUAGE" == "et"        ]; 	then LANGUAGE_FULL="Estonian" ; fi
     if [ "$LANGUAGE" == "mg"        ]; 	then LANGUAGE_FULL="Malagasy" ; fi
     if [ "$LANGUAGE" == "tr"        ]; 	then LANGUAGE_FULL="Turkish" ; fi
     if [ "$LANGUAGE" == "fj"        ]; 	then LANGUAGE_FULL="Fijian" ; fi
     if [ "$LANGUAGE" == "ms"        ]; 	then LANGUAGE_FULL="Malay" ; fi
     if [ "$LANGUAGE" == "udm"       ]; 	then LANGUAGE_FULL="Udmurt" ; fi
     if [ "$LANGUAGE" == "tl"        ]; 	then LANGUAGE_FULL="Filipino" ; fi
     if [ "$LANGUAGE" == "ml"        ]; 	then LANGUAGE_FULL="Malayalam" ; fi
     if [ "$LANGUAGE" == "uk"        ]; 	then LANGUAGE_FULL="Ukrainian" ; fi
     if [ "$LANGUAGE" == "fi"        ]; 	then LANGUAGE_FULL="Finnish" ; fi
     if [ "$LANGUAGE" == "mt"        ]; 	then LANGUAGE_FULL="Maltese" ; fi
     if [ "$LANGUAGE" == "ur"        ]; 	then LANGUAGE_FULL="Urdu" ; fi
     if [ "$LANGUAGE" == "fr"        ]; 	then LANGUAGE_FULL="French" ; fi
     if [ "$LANGUAGE" == "mi"        ]; 	then LANGUAGE_FULL="Maori" ; fi
     if [ "$LANGUAGE" == "uz"        ]; 	then LANGUAGE_FULL="Uzbek" ; fi
     if [ "$LANGUAGE" == "fy"        ]; 	then LANGUAGE_FULL="Frisian" ; fi
     if [ "$LANGUAGE" == "mr"        ]; 	then LANGUAGE_FULL="Marathi" ; fi
     if [ "$LANGUAGE" == "vi"        ]; 	then LANGUAGE_FULL="Vietnamese" ; fi
     if [ "$LANGUAGE" == "gl"        ]; 	then LANGUAGE_FULL="Galician" ; fi
     if [ "$LANGUAGE" == "mn"        ]; 	then LANGUAGE_FULL="Mongolian" ; fi
     if [ "$LANGUAGE" == "cy"        ]; 	then LANGUAGE_FULL="Welsh" ; fi
     if [ "$LANGUAGE" == "ka"        ]; 	then LANGUAGE_FULL="Georgian" ; fi
     if [ "$LANGUAGE" == "my"        ]; 	then LANGUAGE_FULL="Myanmar" ; fi
     if [ "$LANGUAGE" == "xh"        ]; 	then LANGUAGE_FULL="Xhosa" ; fi
     if [ "$LANGUAGE" == "de"        ]; 	then LANGUAGE_FULL="German" ; fi
     if [ "$LANGUAGE" == "ne"        ]; 	then LANGUAGE_FULL="Nepali" ; fi
     if [ "$LANGUAGE" == "yi"        ]; 	then LANGUAGE_FULL="Yiddish" ; fi
     if [ "$LANGUAGE" == "el"        ]; 	then LANGUAGE_FULL="Greek" ; fi
     if [ "$LANGUAGE" == "no"        ]; 	then LANGUAGE_FULL="Norwegian" ; fi
     if [ "$LANGUAGE" == "yo"        ]; 	then LANGUAGE_FULL="Yoruba" ; fi
     if [ "$LANGUAGE" == "gu"        ]; 	then LANGUAGE_FULL="Gujarati" ; fi
     if [ "$LANGUAGE" == "pap"       ]; 	then LANGUAGE_FULL="Papiamento" ; fi
     if [ "$LANGUAGE" == "yua"       ]; 	then LANGUAGE_FULL="Yucatec Maya" ; fi
     if [ "$LANGUAGE" == "ht"        ]; 	then LANGUAGE_FULL="Haitian Creole" ; fi
     if [ "$LANGUAGE" == "ps"        ]; 	then LANGUAGE_FULL="Pashto" ; fi
     if [ "$LANGUAGE" == "zu"        ]; 	then LANGUAGE_FULL="Zulu" ; fi
     if [ "$LANGUAGE" == "ha"        ]; 	then LANGUAGE_FULL="Hausa" ; fi
     if [ "$LANGUAGE" == "fa"        ]; 	then LANGUAGE_FULL="Persian" ; fi
     if [ "$LANGUAGE" == "haw"       ]; 	then LANGUAGE_FULL="Hawaiian" ; fi
     if [ "$LANGUAGE" == "pl"        ]; 	then LANGUAGE_FULL="Polish" ; fi

    if [ "$LANGUAGE" == "en" ]; 	then LANGUAGE_FULL="English"; fi
    if [ "$LANGUAGE" == "es" ]; 	then LANGUAGE_FULL="Spanish"; fi
    if [ "$LANGUAGE" == "nl" ]; 	then LANGUAGE_FULL="Dutch"; fi
#nl-en-GB
#en-GB
    if [ "$LANGUAGE" == "nl-en-GB" ]; 	then LANGUAGE_FULL="Dutch"; fi
    if [ "$LANGUAGE" == "en-GB" ];     then LANGUAGE_FULL="English"; fi

    if [ "$LANGUAGE" == "fr" ]; 	then LANGUAGE_FULL="French"; fi
    if [ "$LANGUAGE" == "it" ]; 	then LANGUAGE_FULL="Italian"; fi
    if [ "$LANGUAGE" == "de" ]; 	then LANGUAGE_FULL="German"; fi
    if [ "$LANGUAGE" == "tr" ]; 	then LANGUAGE_FULL="Turkish"; fi
    if [ "$LANGUAGE" == "pt" ]; 	then LANGUAGE_FULL="Portuguese"; fi
    if [ "$LANGUAGE" == "ru" ]; 	then LANGUAGE_FULL="Russian"; fi
    if [ "$LANGUAGE" == "uk" ]; 	then LANGUAGE_FULL="Ukrainian"; fi
    if [ "$LANGUAGE" == "ar" ]; 	then LANGUAGE_FULL="Arabic"; fi
    if [ "$LANGUAGE" == "ja" ]; 	then LANGUAGE_FULL="Japanese"; fi
    if [ "$LANGUAGE" == "zh-CN" ]; 	then LANGUAGE_FULL="Chinese (Simplified)"; fi









     if [ "$LANGUAGE" == "af-en-US"        ];     then LANGUAGE_FULL="Afrikaans" ; fi
     if [ "$LANGUAGE" == "he-en-US"        ];     then LANGUAGE_FULL="Hebrew" ; fi
     if [ "$LANGUAGE" == "pt-en-US"        ];     then LANGUAGE_FULL="Portuguese" ; fi
     if [ "$LANGUAGE" == "sq-en-US"        ];     then LANGUAGE_FULL="Albanian" ; fi
     if [ "$LANGUAGE" == "mrj-en-US"       ];     then LANGUAGE_FULL="Hill Mari" ; fi
     if [ "$LANGUAGE" == "pa-en-US"        ];     then LANGUAGE_FULL="Punjabi" ; fi
     if [ "$LANGUAGE" == "am-en-US"        ];     then LANGUAGE_FULL="Amharic" ; fi
     if [ "$LANGUAGE" == "hi-en-US"        ];     then LANGUAGE_FULL="Hindi" ; fi
     if [ "$LANGUAGE" == "otq-en-US"       ];     then LANGUAGE_FULL="Querétaro Otomi" ; fi
     if [ "$LANGUAGE" == "ar-en-US"        ];     then LANGUAGE_FULL="Arabic" ; fi
     if [ "$LANGUAGE" == "hmn-en-US"       ];     then LANGUAGE_FULL="Hmong" ; fi
     if [ "$LANGUAGE" == "ro-en-US"        ];     then LANGUAGE_FULL="Romanian" ; fi
     if [ "$LANGUAGE" == "hy-en-US"        ];     then LANGUAGE_FULL="Armenian" ; fi
     if [ "$LANGUAGE" == "mww-en-US"       ];     then LANGUAGE_FULL="Hmong Daw" ; fi
     if [ "$LANGUAGE" == "ru-en-US"        ];     then LANGUAGE_FULL="Russian" ; fi
     if [ "$LANGUAGE" == "az-en-US"        ];     then LANGUAGE_FULL="Azerbaijani" ; fi
     if [ "$LANGUAGE" == "hu-en-US"        ];     then LANGUAGE_FULL="Hungarian" ; fi
     if [ "$LANGUAGE" == "sm-en-US"        ];     then LANGUAGE_FULL="Samoan" ; fi
     if [ "$LANGUAGE" == "ba-en-US"        ];     then LANGUAGE_FULL="Bashkir" ; fi
     if [ "$LANGUAGE" == "is-en-US"        ];     then LANGUAGE_FULL="Icelandic" ; fi
     if [ "$LANGUAGE" == "gd-en-US"        ];     then LANGUAGE_FULL="Scots Gaelic" ; fi
     if [ "$LANGUAGE" == "eu-en-US"        ];     then LANGUAGE_FULL="Basque" ; fi
     if [ "$LANGUAGE" == "ig-en-US"        ];     then LANGUAGE_FULL="Igbo" ; fi
     if [ "$LANGUAGE" == "sr-Cyrl-en-US"   ];     then LANGUAGE_FULL="Serbian" ; fi
     if [ "$LANGUAGE" == "be-en-US"        ];     then LANGUAGE_FULL="Belarusian" ; fi
     if [ "$LANGUAGE" == "id-en-US"        ];     then LANGUAGE_FULL="Indonesian" ; fi
     if [ "$LANGUAGE" == "sr-Latn-en-US"   ];     then LANGUAGE_FULL="Serbian (Latin)" ; fi
     if [ "$LANGUAGE" == "bn-en-US"        ];     then LANGUAGE_FULL="Bengali" ; fi
     if [ "$LANGUAGE" == "ga-en-US"        ];     then LANGUAGE_FULL="Irish" ; fi
     if [ "$LANGUAGE" == "st-en-US"        ];     then LANGUAGE_FULL="Sesotho" ; fi
     if [ "$LANGUAGE" == "bs-en-US"        ];     then LANGUAGE_FULL="Bosnian" ; fi
     if [ "$LANGUAGE" == "it-en-US"        ];     then LANGUAGE_FULL="Italian" ; fi
     if [ "$LANGUAGE" == "sn-en-US"        ];     then LANGUAGE_FULL="Shona" ; fi
     if [ "$LANGUAGE" == "bg-en-US"        ];     then LANGUAGE_FULL="Bulgarian" ; fi
     if [ "$LANGUAGE" == "ja-en-US"        ];     then LANGUAGE_FULL="Japanese" ; fi
     if [ "$LANGUAGE" == "sd-en-US"        ];     then LANGUAGE_FULL="Sindhi" ; fi
     if [ "$LANGUAGE" == "yue-en-US"       ];     then LANGUAGE_FULL="Cantonese" ; fi
     if [ "$LANGUAGE" == "jv-en-US"        ];     then LANGUAGE_FULL="Javanese" ; fi
     if [ "$LANGUAGE" == "si-en-US"        ];     then LANGUAGE_FULL="Sinhala" ; fi
     if [ "$LANGUAGE" == "ca-en-US"        ];     then LANGUAGE_FULL="Catalan" ; fi
     if [ "$LANGUAGE" == "kn-en-US"        ];     then LANGUAGE_FULL="Kannada" ; fi
     if [ "$LANGUAGE" == "sk-en-US"        ];     then LANGUAGE_FULL="Slovak" ; fi
     if [ "$LANGUAGE" == "ceb-en-US"       ];     then LANGUAGE_FULL="Cebuano" ; fi
     if [ "$LANGUAGE" == "kk-en-US"        ];     then LANGUAGE_FULL="Kazakh" ; fi
     if [ "$LANGUAGE" == "sl-en-US"        ];     then LANGUAGE_FULL="Slovenian" ; fi
     if [ "$LANGUAGE" == "ny-en-US"        ];     then LANGUAGE_FULL="Chichewa" ; fi
     if [ "$LANGUAGE" == "km-en-US"        ];     then LANGUAGE_FULL="Khmer" ; fi
     if [ "$LANGUAGE" == "so-en-US"        ];     then LANGUAGE_FULL="Somali" ; fi
     if [ "$LANGUAGE" == "zh-CN-en-US"     ];     then LANGUAGE_FULL="Chinese Simple" ; fi
     if [ "$LANGUAGE" == "tlh-en-US"       ];     then LANGUAGE_FULL="Klingon" ; fi
     if [ "$LANGUAGE" == "es-en-US"        ];     then LANGUAGE_FULL="Spanish" ; fi
     if [ "$LANGUAGE" == "zh-TW-en-US"     ];     then LANGUAGE_FULL="Chinese Tradit" ; fi
     if [ "$LANGUAGE" == "tlh-Qaak-en-US"  ];     then LANGUAGE_FULL="Klingon (pIqaD)" ; fi
     if [ "$LANGUAGE" == "su-en-US"        ];     then LANGUAGE_FULL="Sundanese" ; fi
     if [ "$LANGUAGE" == "co-en-US"        ];     then LANGUAGE_FULL="Corsican" ; fi
     if [ "$LANGUAGE" == "ko-en-US"        ];     then LANGUAGE_FULL="Korean" ; fi
     if [ "$LANGUAGE" == "sw-en-US"        ];     then LANGUAGE_FULL="Swahili" ; fi
     if [ "$LANGUAGE" == "hr-en-US"        ];     then LANGUAGE_FULL="Croatian" ; fi
     if [ "$LANGUAGE" == "ku-en-US"        ];     then LANGUAGE_FULL="Kurdish" ; fi
     if [ "$LANGUAGE" == "sv-en-US"        ];     then LANGUAGE_FULL="Swedish" ; fi
     if [ "$LANGUAGE" == "cs-en-US"        ];     then LANGUAGE_FULL="Czech" ; fi
     if [ "$LANGUAGE" == "ky-en-US"        ];     then LANGUAGE_FULL="Kyrgyz" ; fi
     if [ "$LANGUAGE" == "ty-en-US"        ];     then LANGUAGE_FULL="Tahitian" ; fi
     if [ "$LANGUAGE" == "da-en-US"        ];     then LANGUAGE_FULL="Danish" ; fi
     if [ "$LANGUAGE" == "lo-en-US"        ];     then LANGUAGE_FULL="Lao" ; fi
     if [ "$LANGUAGE" == "tg-en-US"        ];     then LANGUAGE_FULL="Tajik" ; fi
     if [ "$LANGUAGE" == "nl-en-US"        ];     then LANGUAGE_FULL="Dutch" ; fi
     if [ "$LANGUAGE" == "la-en-US"        ];     then LANGUAGE_FULL="Latin" ; fi
     if [ "$LANGUAGE" == "ta-en-US"        ];     then LANGUAGE_FULL="Tamil" ; fi
     if [ "$LANGUAGE" == "mhr-en-US"       ];     then LANGUAGE_FULL="Eastern Mari" ; fi
     if [ "$LANGUAGE" == "lv-en-US"        ];     then LANGUAGE_FULL="Latvian" ; fi
     if [ "$LANGUAGE" == "tt-en-US"        ];     then LANGUAGE_FULL="Tatar" ; fi
     if [ "$LANGUAGE" == "emj-en-US"       ];     then LANGUAGE_FULL="Emoji" ; fi
     if [ "$LANGUAGE" == "lt-en-US"        ];     then LANGUAGE_FULL="Lithuanian" ; fi
     if [ "$LANGUAGE" == "te-en-US"        ];     then LANGUAGE_FULL="Telugu" ; fi
     if [ "$LANGUAGE" == "en-en-US"        ];     then LANGUAGE_FULL="English" ; fi
     if [ "$LANGUAGE" == "lb-en-US"        ];     then LANGUAGE_FULL="Luxembourgish" ; fi
     if [ "$LANGUAGE" == "th-en-US"        ];     then LANGUAGE_FULL="Thai" ; fi
     if [ "$LANGUAGE" == "eo-en-US"        ];     then LANGUAGE_FULL="Esperanto" ; fi
     if [ "$LANGUAGE" == "mk-en-US"        ];     then LANGUAGE_FULL="Macedonian" ; fi
     if [ "$LANGUAGE" == "to-en-US"        ];     then LANGUAGE_FULL="Tongan" ; fi
     if [ "$LANGUAGE" == "et-en-US"        ];     then LANGUAGE_FULL="Estonian" ; fi
     if [ "$LANGUAGE" == "mg-en-US"        ];     then LANGUAGE_FULL="Malagasy" ; fi
     if [ "$LANGUAGE" == "tr-en-US"        ];     then LANGUAGE_FULL="Turkish" ; fi
     if [ "$LANGUAGE" == "fj-en-US"        ];     then LANGUAGE_FULL="Fijian" ; fi
     if [ "$LANGUAGE" == "ms-en-US"        ];     then LANGUAGE_FULL="Malay" ; fi
     if [ "$LANGUAGE" == "udm-en-US"       ];     then LANGUAGE_FULL="Udmurt" ; fi
     if [ "$LANGUAGE" == "tl-en-US"        ];     then LANGUAGE_FULL="Filipino" ; fi
     if [ "$LANGUAGE" == "ml-en-US"        ];     then LANGUAGE_FULL="Malayalam" ; fi
     if [ "$LANGUAGE" == "uk-en-US"        ];     then LANGUAGE_FULL="Ukrainian" ; fi
     if [ "$LANGUAGE" == "fi-en-US"        ];     then LANGUAGE_FULL="Finnish" ; fi
     if [ "$LANGUAGE" == "mt-en-US"        ];     then LANGUAGE_FULL="Maltese" ; fi
     if [ "$LANGUAGE" == "ur-en-US"        ];     then LANGUAGE_FULL="Urdu" ; fi
     if [ "$LANGUAGE" == "fr-en-US"        ];     then LANGUAGE_FULL="French" ; fi
     if [ "$LANGUAGE" == "mi-en-US"        ];     then LANGUAGE_FULL="Maori" ; fi
     if [ "$LANGUAGE" == "uz-en-US"        ];     then LANGUAGE_FULL="Uzbek" ; fi
     if [ "$LANGUAGE" == "fy-en-US"        ];     then LANGUAGE_FULL="Frisian" ; fi
     if [ "$LANGUAGE" == "mr-en-US"        ];     then LANGUAGE_FULL="Marathi" ; fi
     if [ "$LANGUAGE" == "vi-en-US"        ];     then LANGUAGE_FULL="Vietnamese" ; fi
     if [ "$LANGUAGE" == "gl-en-US"        ];     then LANGUAGE_FULL="Galician" ; fi
     if [ "$LANGUAGE" == "mn-en-US"        ];     then LANGUAGE_FULL="Mongolian" ; fi
     if [ "$LANGUAGE" == "cy-en-US"        ];     then LANGUAGE_FULL="Welsh" ; fi
     if [ "$LANGUAGE" == "ka-en-US"        ];     then LANGUAGE_FULL="Georgian" ; fi
     if [ "$LANGUAGE" == "my-en-US"        ];     then LANGUAGE_FULL="Myanmar" ; fi
     if [ "$LANGUAGE" == "xh-en-US"        ];     then LANGUAGE_FULL="Xhosa" ; fi
     if [ "$LANGUAGE" == "de-en-US"        ];     then LANGUAGE_FULL="German" ; fi
     if [ "$LANGUAGE" == "ne-en-US"        ];     then LANGUAGE_FULL="Nepali" ; fi
     if [ "$LANGUAGE" == "yi-en-US"        ];     then LANGUAGE_FULL="Yiddish" ; fi
     if [ "$LANGUAGE" == "el-en-US"        ];     then LANGUAGE_FULL="Greek" ; fi
     if [ "$LANGUAGE" == "no-en-US"        ];     then LANGUAGE_FULL="Norwegian" ; fi
     if [ "$LANGUAGE" == "yo-en-US"        ];     then LANGUAGE_FULL="Yoruba" ; fi
     if [ "$LANGUAGE" == "gu-en-US"        ];     then LANGUAGE_FULL="Gujarati" ; fi
     if [ "$LANGUAGE" == "pap-en-US"       ];     then LANGUAGE_FULL="Papiamento" ; fi
     if [ "$LANGUAGE" == "yua-en-US"       ];     then LANGUAGE_FULL="Yucatec Maya" ; fi
     if [ "$LANGUAGE" == "ht-en-US"        ];     then LANGUAGE_FULL="Haitian Creole" ; fi
     if [ "$LANGUAGE" == "ps-en-US"        ];     then LANGUAGE_FULL="Pashto" ; fi
     if [ "$LANGUAGE" == "zu-en-US"        ];     then LANGUAGE_FULL="Zulu" ; fi
     if [ "$LANGUAGE" == "ha-en-US"        ];     then LANGUAGE_FULL="Hausa" ; fi
     if [ "$LANGUAGE" == "fa-en-US"        ];     then LANGUAGE_FULL="Persian" ; fi
     if [ "$LANGUAGE" == "haw-en-US"       ];     then LANGUAGE_FULL="Hawaiian" ; fi
     if [ "$LANGUAGE" == "pl-en-US"        ];     then LANGUAGE_FULL="Polish" ; fi

    if [ "$LANGUAGE" == "en-en-US" ];     then LANGUAGE_FULL="English"; fi
    if [ "$LANGUAGE" == "es-en-US" ];     then LANGUAGE_FULL="Spanish"; fi
    if [ "$LANGUAGE" == "nl-en-US" ];     then LANGUAGE_FULL="Dutch"; fi
#nl-en-GB
#en-GB
    if [ "$LANGUAGE" == "nl-en-GB" ];   then LANGUAGE_FULL="Dutch"; fi
    if [ "$LANGUAGE" == "en-GB" ];     then LANGUAGE_FULL="English"; fi

    if [ "$LANGUAGE" == "fr-en-US" ];     then LANGUAGE_FULL="French"; fi
    if [ "$LANGUAGE" == "it-en-US" ];     then LANGUAGE_FULL="Italian"; fi
    if [ "$LANGUAGE" == "de-en-US" ];     then LANGUAGE_FULL="German"; fi
    if [ "$LANGUAGE" == "tr-en-US" ];     then LANGUAGE_FULL="Turkish"; fi
    if [ "$LANGUAGE" == "pt-en-US" ];     then LANGUAGE_FULL="Portuguese"; fi
    if [ "$LANGUAGE" == "ru-en-US" ];     then LANGUAGE_FULL="Russian"; fi
    if [ "$LANGUAGE" == "uk-en-US" ];     then LANGUAGE_FULL="Ukrainian"; fi
    if [ "$LANGUAGE" == "ar-en-US" ];     then LANGUAGE_FULL="Arabic"; fi
    if [ "$LANGUAGE" == "ja-en-US" ];     then LANGUAGE_FULL="Japanese"; fi
    if [ "$LANGUAGE" == "zh-CN-en-US" ];  then LANGUAGE_FULL="Chinese (Simplified)"; fi

    echo title=$LANGUAGE_FULL
    echo lang==$LANGUAGE

	MAP_COUNT_NEXT=$(echo "($MAP_COUNT+$ONE)"| bc -l);  
    MAP_COUNT_NEXT="${MAP_COUNT_NEXT%.*}"
	echo -n " -map $MAP_COUNT_NEXT" >> map.txt
	echo " -metadata:s:s:$MAP_COUNT language=$LANGUAGE -metadata:s:s:$MAP_COUNT title=$LANGUAGE_FULL \\" >> map.txt
	MAP_COUNT=$MAP_COUNT_NEXT

	echo " -i \"subs/$BASENAME/$LANGUAGE/$BASENAME.$LANGUAGE.srt.double\" \\" >> in.txt
done
echo " " >> map.txt
MAP=$(cat map.txt)
IN=$(cat in.txt)
