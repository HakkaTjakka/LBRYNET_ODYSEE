#!/bin/bash

get_page() {
	curl  --location --request POST \
		'https://api.lbry.tv/api/v1/proxy' \
		--header 'Content-Type: application/json' \
		--data-raw '{
		"method": "claim_search",
			"params": {
				"channel": "@English_Subtitles:b",
				"order_by": "creation_timestamp",
				"page": '$1',
				"release_time": "<'$2'",
				"page_size": 50
			}
		}' > test.json

# 			"release_time": "<1725400800",
}

proces_json() {
	if [ -f "hoppa.txt" ]; then
		rm hoppa.txt 
	fi
	start=true
	while IFS= read -r line1 && IFS= read -r line2 <&3 && IFS= read -r line3 <&4; do
	  	counter=$((counter+1))
	  	counter_tot=$((counter_tot+1))
	  	date=$(date -d @$line1 +"%F %T")
		if [ $start == true ]; then 
			start=false
			date_start=$(date -d @$line1 +"%F_%T")
		fi
		timestamp_end=$line1
	  	printf "%4d timestamp: $line1 - date: %s - title: %s - ulr: %s\n" "$counter_tot" "$date" "$line2" "$line3" >> $4
	  	printf "%4d timestamp: $line1 - date: %s - title: %s - ulr: %s\n" "$counter_tot" "$date" "$line2" "$line3"
	  	printf "%s\n" "$date" >> dates.tot

	done < $1 3< $2 4< $3
}

proces_json2() {
	start=true
	while IFS= read -r line1 && IFS= read -r line2 <&3; do
	  	counter=$((counter+1))
	  	counter_tot=$((counter_tot+1))
	  	date=$(date -d @$line1 +"%F %T")
		if [ $start == true ]; then 
			start=false
			date_start=$(date -d @$line1 +"%F_%T")
		fi
		timestamp_end=$line1
	  	printf "%4d timestamp: $line1	- date: %s  - url/title: %s \n" "$counter_tot" "$date" "$line2" >> $3
	  	printf "%4d timestamp: $line1	- date: %s  - url/title: %s \n" "$counter_tot" "$date" "$line2"
	done < $1 3< $2
}

GET_1000_MAX() {
	if [ ! -d "output" ]; then
		mkdir output
	fi
	counter=0
	date_start=""
	date_end=""
	
	if [ -f "hoppa.tot" ]; then
		rm hoppa.tot 
	fi
	
	PAGE=1
	now=$1
	while : ; do
		get_page $PAGE $now

		jq -r '  .result.items.[].meta.creation_timestamp ' test.json > creation_timestamp.txt
		jq -r '  .result.items.[].canonical_url ' test.json > canonical_url.txt
		jq -r '  .result.items.[].value.title ' test.json > title.txt
		jq -r '  .result.items.[].value.tags | @sh ' test.json > tags.txt
		jq -r '  .result.items.[].value.video.duration ' test.json > duration.txt
		jq -r '  .result.items.[].value.thumbnail.url ' test.json > thumbnail.txt

		cat creation_timestamp.txt >> creation_timestamp.tot
		cat canonical_url.txt >> canonical_url.tot
		cat title.txt >> title.tot
		cat tags.txt >> tags.tot
		cat duration.txt >> duration.tot
		cat thumbnail.txt >> thumbnail.tot

#		date -d@12345 -u +%H:%M:%S

#		jq -r '  .result.items.[].short_url ' test.json > hoppa2.txt
	
		proces_json creation_timestamp.txt canonical_url.txt title.txt hoppa.txt
	
		filename="English_Subtitles_"$date_start".json"
		cp "test.json" "output/$filename"
	
		cat hoppa.txt >> hoppa.tot
		PAGES=$(jq -r '.result| "\(.page) \(.total_pages)"' test.json)
		IFS=' ' read PAGE TOTAL_PAGES	<<< $(echo $PAGES)
		echo "Page $PAGE of $TOTAL_PAGES"
		if [ $PAGE == $TOTAL_PAGES ]; then
		 	break
		else
		# 	echo -n "Sleeping 5"
		# 	sleep 1
		# 	echo -ne "\rSleeping 4"
		# 	sleep 1
		# 	echo -ne "\rSleeping 3"
		# 	sleep 1
		# 	echo -ne "\rSleeping 2"
		# 	sleep 1
		 	echo -ne "\rSleeping 1"
		 	sleep 1
		  	echo -ne "\r          \r"
		fi
		PAGE=$((PAGE+1))
	done
	
	sort --key=3 -r hoppa.tot >> hoppa.srt
	
	date_end=$(date -d @$timestamp_end +"%F_%T")
	filename="English_Subtitles_"$date_end".srt"
	cp "hoppa.srt" "output/$filename"
}

timestamp_end=0
counter_tot=0
counter=0

rm creation_timestamp.tot
rm canonical_url.tot
rm title.tot
rm tags.tot
rm duration.tot
rm thumbnail.tot

GET_1000_MAX $(date +%s)
while [ $counter == 1000 ];
do
	GET_1000_MAX $timestamp_end
done

rm dates.tot

#now=$(date +%s)
#now=1731514873
#now=1727389683

rm url.tot
rm total_title.tot
rm title_url.tot

counter_tot=0
counter=0

proces_json2 creation_timestamp.tot canonical_url.tot url.tot

counter_tot=0
counter=0

proces_json2 creation_timestamp.tot title.tot total_title.tot

counter_tot=0
counter=0

proces_json creation_timestamp.tot title.tot canonical_url.tot title_url.tot

sort --key=3 -r url.tot > url.srt
sort --key=3 -r total_title.tot > total_title.srt
sort --key=3 -r title_url.tot > total_title_url.srt

sort --key=10 url.tot > url2.srt
sort --key=10 total_title.tot > total_title2.srt
sort --key=10 title_url.tot > total_title_url2.srt


