#ffmpeg -hwaccel cuda -i Crater_Earth_-_ra-waves-[zwrztYTWR7I].webm -c:v h264_nvenc -profile:v high -pix_fmt yuv420p out.mp4
ffmpeg -i Crater_Earth_-_ra-waves-[zwrztYTWR7I].webm -c:v h264_nvenc -profile:v high -pix_fmt yuv420p out.mp4

#../nvidia/ffmpeg/ffmpeg -hwaccel cuda -i spiderman.mkv spider.mp4
