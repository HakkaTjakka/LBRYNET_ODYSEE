#!/bin/bash

FILENAME="$1"
BASENAME="${FILENAME%.*}"

FILENAME=$(echo $FILENAME | sed 's/[][]/\\&/g' |  sed 's/ /\\ /g')

TITLE=$(jq --raw-output .title "$1")

#RELEASE_DATE=$(jq -r .release_date "$1")
#echo "Release_date= $RELEASE_DATE - Link=$WEBPAGE_URL"
#STRING=$(jq -r .release_date,.webpage_url "$1" | sort -z | while IFS= read -r -d ' ' item; do; echo $item; done;)
#RELEASE_DATE=$(jq --raw-output .release_date "$1")

UPLOAD_DATE=$(jq --raw-output .upload_date "$1")
UPLOAD_DATE=$(echo "$UPLOAD_DATE" | sed -E 's/(....)(..)(..)/\1\-\2\-\3/')

#UPLOAD_DATE=$(printf '%c8s\n' "$UPLOAD_DATE")
#echo '20220416124334' | sed -E 's/(....)(..)(..)(..)(..)(..)/\1\/\2\/\3 \4:\5:\6/'

WEBPAGE_URL=$(jq --raw-output .webpage_url "$1")

DURATION_STRING=$(jq --raw-output .duration_string "$1")
DURATION_STRING=$(printf '%8s\n' "$DURATION_STRING")

DURATION=$(jq --raw-output .duration "$1")
DURATION=$(printf '%6s\n' "$DURATION")

TAGS=$(jq --raw-output .tags "$1")
TAGS=$(echo $TAGS | sed "s/\n/ /g")

if [ -f "DESCRIPTION.TXT" ]; then
	rm "DESCRIPTION.TXT"
fi

jq -r .description "$1" > DESCRIPTION.TXT
DESCRIPTION=$(	cat "DESCRIPTION.TXT" | \
				sed 's/\$\\n\\n/\n/g' | \
				grep "Video Source\:" | \
				sed "s/Video Source\: //" \
			)

#if [ ! "$RELEASE_DATE" == "null"        ]; then
if [ ! "$UPLOAD_DATE" == "null"        ]; then
	echo "title: $TITLE"

	echo -n "title:  \"$TITLE\" <BREAK> " >> download.list
	echo -n "url:    \"$WEBPAGE_URL\" <BREAK> " >> download.list
	echo -n "source: \"$DESCRIPTION\" <BREAK> " >> download.list
	echo -n "length: $DURATION_STRING <BREAK> " >> download.list
	echo -n "tags:   $TAGS <BREAK> " >> download.list
	echo "=============================================================" >> download.list

	echo -n "\"$TITLE\"\\" 			>> spreadsheet.txt
	echo -n "\"$WEBPAGE_URL\"\\" 	>> spreadsheet.txt
	echo -n "\"$DESCRIPTION\"\\" 	>> spreadsheet.txt
	echo -n "\"$DURATION_STRING\"\\" >> spreadsheet.txt
	TAGS=$(echo $TAGS | sed "s/\[ \"/#/" | sed "s/\", \"/ #/g" | sed "s/\" \]//")
	echo "\"$TAGS\"" 				>> spreadsheet.txt


#	echo "date: $RELEASE_DATE - url: $WEBPAGE_URL - length: $DURATION_STRING	($DURATION)"
#	echo "date: $RELEASE_DATE - url: $WEBPAGE_URL - length: "$(printf '%8s' "$DURATION_STRING")"	($DURATION)"
#	echo -e "sa \"$WEBPAGE_URL\" --language nl # $UPLOAD_DATE - $DURATION_STRING - $TITLE" >> list.json.sh
fi
#fi

#printf '..%7s..' 'hello'

#echo -e "\n"

#find . -maxdepth 1 -type f -name "*.info.json" -print0 | sort -z | while IFS= read -r -d '' line;

#echo -e "\n"
#echo $STRING

#echo "====================================="
#echo -e "\n"
#upload
