## echo " \\" > add_fix.txt
## echo '	--tags="The Jimmy Dore Show" \' >> add_fix.txt
## echo '	--tags="Catherine Austin Fitts" \' >> add_fix.txt
## echo '	--tags="$21 TRILLION"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=eqidDO6T5x0" --language en

echo " \\" > add_fix.txt
echo '	--tags="Jensen" \' >> add_fix.txt
echo '	--tags="De Jensen Show"' >> add_fix.txt

## subtitle_ass_file.sh recoded_703.mp4
## 
## echo Press enter
## read a
## subtitle_ass_file.sh recoded_702.mp4
## subtitle_ass_file.sh recoded_701.mp4
## subtitle_ass_file.sh recoded_700.mp4
## subtitle_ass_file.sh recoded_699.mp4
## subtitle_ass_file.sh recoded_698.mp4
## 
## subtitle_ass_file.sh recoded_697.mp4
## 
## echo PRESS ENTER
## read a
## 
## subtitle_ass_file.sh recoded_696.mp4
## subtitle_ass_file.sh recoded_695.mp4
## subtitle_ass_file.sh recoded_694.mp4
## subtitle_ass_file.sh recoded_693.mp4
## subtitle_ass_file.sh recoded_692.mp4
## subtitle_ass_file.sh recoded_691.mp4
## subtitle_ass_file.sh recoded_690.mp4
## subtitle_ass_file.sh recoded_689.mp4
## subtitle_ass_file.sh recoded_688.mp4

## subtitle_ass_file.sh recoded_687.mp4 --language nl
## subtitle_ass_file.sh recoded_686.mp4 --language nl

## subtitle_ass_file.sh recoded_697.mp4 --language nl
## subtitle_ass_file.sh recoded_685.mp4 --language nl
## subtitle_ass_file.sh recoded_684.mp4 --language nl
## subtitle_ass_file.sh recoded_683.mp4 --language nl
## subtitle_ass_file.sh recoded_682.mp4 --language nl
## subtitle_ass_file.sh recoded_681.mp4 --language nl
## subtitle_ass_file.sh recoded_680.mp4 --language nl
## subtitle_ass_file.sh recoded_679.mp4 --language nl
## subtitle_ass_file.sh recoded_678.mp4 --language nl
## subtitle_ass_file.sh recoded_677.mp4 --language nl
## subtitle_ass_file.sh recoded_676.mp4 --language nl
## subtitle_ass_file.sh recoded_675.mp4 --language nl
## subtitle_ass_file.sh recoded_674.mp4 --language nl
## subtitle_ass_file.sh recoded_673.mp4 --language nl
## subtitle_ass_file.sh recoded_672.mp4 --language nl
## subtitle_ass_file.sh recoded_671.mp4 --language nl
## subtitle_ass_file.sh recoded_670.mp4 --language nl

for ((VID = 669; VID >= 600; --VID)); do
	subtitle_ass_file.sh recoded_$VID.mp4 --language nl
	#GETVIDEOTS $VID
done


exit

echo " \\" > add_fix.txt
echo '	--tags="A.J. Berkhout" \' >> add_fix.txt
echo '	--tags="De toekomst van Nederland"' >> add_fix.txt

#sa "https://www.youtube.com/watch?v=U71k96LEdng" --language nl # 1
sa "https://www.youtube.com/watch?v=d64IRatwO_8" --language nl # 2
sa "https://www.youtube.com/watch?v=iLPVz8zNn3w" --language nl # 4

#sa "https://www.youtube.com/watch?v=t7bIpx9jeZw"

exit

## yt-dlp -i "https://www.youtube.com/watch?v=U71k96LEdng" --merge-output-format mp4 --restrict-filenames --get-filename --geo-bypass
## 	--skip-unavailable-fragments \
## 	--geo-bypass \
## 	--get-filename \
## 	--no-playlist \
## 	--cookies cookies/cookies.txt > filename.txt


echo " \\" > add_fix.txt
echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
echo '	--tags="De Gulden Middenweg"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=RmbcnS9Wsec" --language nl

exit

echo " \\" > add_fix.txt
echo '	--tags="DVO JOURNAAL" \' >> add_fix.txt
echo '	--tags="de vrije omroep"' >> add_fix.txt

## sa "https://odysee.com/vaccin-journaal-8:6856cf5198a89d4febb69e7dd4d1684fbe0813c4" --language nl # 2022-12-06 -    36:21 - DVO VACCIN JOURNAAL | DVO JOURNAAL #8
## sa "https://odysee.com/Jaarjournaal-8.3.2-2.1Mbit-Master-1:e9a124db6a8dc181dac9eb52778443ea6bff1875" --language nl # 2022-10-11 -  1:02:30 - HET CORONA-JAAR-JOURNAAL | DE VRIJE OMROEP -  DVO
## sa "https://odysee.com/dvo-nieuws-5:e7f6de520cf51327a80a6a506facb70afbbc52f0" --language nl # 2022-03-30 -  1:04:25 - DVO NIEUWS #5 - JURIDISCHE ANALYSE VAN DE COVID-19 CRISIS MET MR DRS ARNO VAN KESSEL
## sa "https://odysee.com/dvo-canada-reportage_2:8070d1f2059711aed35ed828da35f953991cf497" --language nl # 2022-02-22 -     5:29 - CANADA FREEDOM CONVOY REPORTAGE #2 | DVO SHARE
## sa "https://odysee.com/dvo-canada-reportage_1:bb2c43545a9593ec61c0e7bde13e8c1039eae2c6" --language nl # 2022-02-22 -     2:53 - CANADA FREEDOM CONVOY REPORTAGE #1 | DVO SHARE

## sa "https://odysee.com/dvo_digitaal-paspoort_1:71876a1e19d3bac27f76a6dcb7f7aa35e238b3f1" --language nl # 2022-02-22 -     2:36 - DE LEUGENS ROND HET COVID PASPOORT | DVO SHARE
## sa "https://odysee.com/DVO_weeknieuws-4:0f71f9d199f32f1629a2b9e345890e2ca1f5f441" --language nl # 2022-02-21 -    21:34 - DVO WEEK NIEUWS - VERVOLG CANADA EN VERGOEDING BIJ VACCINSCHADE | FEBRUARI #4

## sa "https://odysee.com/vaccinatieschade-vergoeding-nl:c974ab052c24d0d0d44d3a7436fe79910223fc07" --language nl # 2022-02-21 -    13:07 - WIE VERGOEDT DE KOSTEN IN HET GEVAL VAN VACCINATIESCHADE? | DVO SHARE
## sa "https://odysee.com/DVO_week-nieuws-3:a597b0f2e1dbc05d2e936b866a7fb23b733316e8" --language nl # 2022-02-18 -    15:08 - DVO WEEK NIEUWS MET FALENDE OMT ANGSTZAAIERIJ EN DE CANADA REVOLUTIE | JANUARI #3
## sa "https://odysee.com/DVO_week-nieuws-2:8aeb3af41cce5c2f95a85f029d8c28ae7805aa6c" --language nl # 2022-01-28 -    11:22 - DVO WEEK NIEUWS MET EVA VAN ZEELAND | JANUARI #2
## sa "https://odysee.com/DVO-JOURNAAL-0401:d8ef4c82a2b314b495c48cac5c73611210f24802" --language nl # 2022-01-27 -     9:59 - JOURNAAL #4 CENSUUR OVER PCR EN VACCIN | De Vrije Omroep (DVO) 
## sa "https://odysee.com/dvo-journaal-05:099a924020d7a46173c07076dd856f6aeaf73a6f" --language nl # 2022-01-27 -    13:03 - JOURNAAL #5 FINANCIËLE BELANGEN VACCIN-DICTATUUR | De Vrije Omroep DVO
## sa "https://odysee.com/journaal-6:e0fe85954732c801cae344e6f63c55ca05c178e7" --language nl # 2022-01-26 -    13:15 - DE RELATIE TUSSEN ZENDMASTEN - COVID19 EN KLIMAAT | DVO JOURNAAL #6: 
## sa "https://odysee.com/code-rood-dvo-journaal-9:66fb683228a85686c96b59a48858593c40fb2d2e" --language nl # 2022-01-25 -    10:52 - CODE ROOD 🆘 DVO JOURNAAL #9
## sa "https://odysee.com/Dvo-Week-Nieuws-no1:aabf06be87ccfa6acab853df3807e7edd020ebf3" --language nl # 2022-01-24 -     9:48 - DVO WEEK NIEUWS MET EVA VAN ZEELAND | JANUARI #1
## sa "https://odysee.com/dvo-corona-year-news:cef1c47368df89d7f8c6fb9c9f1294dd27f7cbb8" --language nl # 2021-08-25 -  1:02:25 - DVO CORONA 1ST YEAR NEWS (Dutch with English subs)

## sa "https://odysee.com/Dvo-Journaal-03-03-Politiegeweld-14-Maart-1080p:8254b1b1c27c4bbcde5f88e6f5ccbe9457aab95e" --language nl # 2021-04-21 -     8:09 - JOURNAAL#3 POLITIEGEWELD | De Vrije Omroep (DVO) (Full-HD)
## sa "https://odysee.com/dvo-journaal-04-01-fuellmich_1080p:6d713adf16aa5bba6bb7ecbaa82110e5430c2318" --language nl # 2021-04-09 -     2:21 - JOURNAAL #2 REINER FUELLMICH | De Vrije Omroep DVO (Full-HD)
## sa "https://odysee.com/corona-jaar-journaal_deel-3:0efdf2909f7c6d0a3593f9ae7601f662a3223170" --language nl # 2021-03-23 -     8:40 - HET (CORONA) JAAR JOURNAAL DEEL 3 | De Vrije Omroep DVO
## sa "https://odysee.com/corona-jaar-journaal_deel-1:78c58a0de0a48e0f82301cced601aeb5bd7551a9" --language nl # 2021-03-23 -    17:50 - HET (CORONA) JAAR JOURNAAL DEEL 1 | De Vrije Omroep DVO
## sa "https://odysee.com/corona-jaar-journaal_deel-5:59413078f6273f0f71d85626bf314d5c7a385ff0" --language nl # 2021-03-23 -    15:14 - HET (CORONA) JAAR JOURNAAL DEEL 5 | De Vrije Omroep DVO
## sa "https://odysee.com/corona-jaar-journaal_deel-2:ccc02cace7445376f4f34e9051b7fa633a5c24da" --language nl # 2021-03-23 -    11:33 - HET (CORONA) JAAR JOURNAAL DEEL 2 | De Vrije Omroep DVO
## sa "https://odysee.com/corona-jaar-journaal_deel-4:7919a26f9b7a4196a1af14236c22997c553ded15" --language nl # 2021-03-23 -    10:41 - HET (CORONA) JAAR JOURNAAL DEEL 4 | De Vrije Omroep DVO

echo " \\" > add_fix.txt
echo '	--tags="de nieuwe wereld"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=PAh4enDZVBA" --language nl # 2024-10-08 -    48:22 - "80% van EU-burgers is tegen chat control-wetgeving" | #1725 Matthijs Pontier
## sa "https://www.youtube.com/watch?v=MSMKYdwTJJo" --language nl # 2024-10-08 -    57:06 - Hoe komen we tot realistisch asiel- en migratiebeleid? | #1726 Ruud Koopmans
## sa "https://www.youtube.com/watch?v=bgPj_hYXoF4" --language nl # 2024-10-09 -  1:08:46 - "Wie definieert wat mis- en desinformatie is?" | #1727 Christiaan Alting von Geusau
## sa "https://www.youtube.com/watch?v=nz5nZAoX1u4" --language nl # 2024-10-10 -    59:30 - "40% van serieuze meldingen verdwijnt" | #1728 Wouter Aukema
## sa "https://www.youtube.com/watch?v=ghpTfA9KX0s" --language nl # 2024-10-11 -  1:09:09 - "Islamisering trekt ons het conflict in" | #1729 Uri Rosenthal
## sa "https://www.youtube.com/watch?v=0JYZWQgnQWA" --language nl # 2024-10-12 -  1:15:58 - Youtube-profeten staan op | Filosofisch Actueel Gesprek met Ad, Jelle en Marlies #1730
## sa "https://www.youtube.com/watch?v=NK440hGSpmQ" --language nl # 2024-10-13 -  1:16:23 - Val kabinet onvermijdelijk? Migratie, Noodwet, Algemene beschouwingen, Trump & meer | NvdW #1732
## sa "https://www.youtube.com/watch?v=tSCoh64oyHo" --language nl # 2024-10-14 -    49:47 - "Het systeem is gecorrumpeerd" | #1733 met Jeroen Pols
## sa "https://www.youtube.com/watch?v=wy6blc_xdUo" --language nl # 2024-10-15 -    57:25 - Het bijzondere verhaal van de gabber DJ met stropdas | #1734 met Sefa Vlaarkamp
## sa "https://www.youtube.com/watch?v=sj63rDjBwUY" --language nl # 2024-10-16 -  1:06:40 - "Verzekeraar op stoel van de arts" | #1735 met Armand Girbes
## sa "https://www.youtube.com/watch?v=_0ZypMit_tw" --language nl # 2024-10-17 -  1:13:56 - "3e wereldoorlog niet langer uitgesloten" | Jasper van Dijk met Bastiaan van Apeldoorn #1736
## 
## echo "Press enter"
## read aaa
## 
## cd ../movies
## echo " \\" > add_fix.txt
## echo '	--tags="KHAZARIAN MAFIA" \' >> add_fix.txt
## echo '	--tags="Hidden History"' >> add_fix.txt
## 
## sa "https://rumble.com/v2f95p6-the-khazarian-mafia-explained-in-12-minutes.html" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="SATANIC KABBALAH" \' >> add_fix.txt
## echo '	--tags="NWO"' >> add_fix.txt
## 
## sa "https://rumble.com/v2w6li8--satanic-kabbalah-exposed.-the-true-goal-is-world-domination-the-nwo.html" --language en
## 
## cd ..
## cd movies3

sa "https://www.youtube.com/watch?v=1U8EeVoqp6Q" --language nl # 2024-10-18 -  1:13:14 - Op weg naar de Amerikaanse verkiezingen | #1737 met Charles Groenhuijsen
sa "https://www.youtube.com/watch?v=JtdMePb90Ng" --language nl # 2024-10-19 -    46:07 - Journalisten? Laffe bangheid ten top! |  Jelle van Baardewijk in gesprek met Bart Nijman #1738
sa "https://www.youtube.com/watch?v=_EdHidKiCHA" --language nl # 2024-10-20 -  1:24:37 - Anti-asiel politiek gedwarsboomd, Oekraïne kernmacht? ASML en meer | Nieuws van de Week #1739
sa "https://www.youtube.com/watch?v=mexHfbe6PRw" --language nl # 2024-10-21 -  1:12:30 - Epidemiologie; menselijk al te menselijk | Jona Walk in gesprek met Jos Frantzen #1740
sa "https://www.youtube.com/watch?v=EV1_EtV7qrE" --language nl # 2024-10-22 -    50:49 - Hoe datahonger de GGZ overneemt | #1741 Tom Grosfeld
sa "https://www.youtube.com/watch?v=JOzD36hGDAI" --language nl # 2024-10-23 -  1:04:22 - Orban, Meloni, Draghi en de toekomst van Europa | #1742 met Harald Benink
sa "https://www.youtube.com/watch?v=vK2z_5Bo85Q" --language nl # 2024-10-24 -    56:27 - Einddoel Witte Huis: Amerikaanse verkiezingen en de macht van de president | #1743 Koen Petersen
sa "https://www.youtube.com/watch?v=umI0P74tkl8" --language nl # 2024-10-25 -  1:05:17 - "Cultuur veel belangrijker dan economie" | #1744 Derk Jan Eppink
sa "https://www.youtube.com/watch?v=n52QLRzX4m8" --language nl # 2024-10-26 -  1:03:04 - Exit-strategie voor de oorlog in Oekraïne? | #1745 Guido van Leemput
sa "https://www.youtube.com/watch?v=4FfsbKOP9N0" --language nl # 2024-10-27 -  1:22:52 - Noodwet van de baan; cancelling Jan van de Beek; Trump❤️McDonalds; BRICS | #1746 Nieuws van de Week
sa "https://www.youtube.com/watch?v=LQ7_rjYOzkc" --language nl # 2024-10-28 -    59:55 - Hoe het gelukkigste land ter wereld zijn goede humeur verloor | #1747 Martin Sommer
sa "https://www.youtube.com/watch?v=Py48Lbc5E-c" --language nl # 2024-10-29 -  1:24:09 - Ego en het open veld van ervaring | #1748 met Han de Wit
sa "https://www.youtube.com/watch?v=w1PAeUbssmA" --language nl # 2024-10-29 -     8:08 - Nieuwe escalatie oorlog Oekraïne? | DNW Kort
sa "https://www.youtube.com/watch?v=C9fH0HdnfdQ" --language nl # 2024-10-30 -    56:40 - "Blij dat China en Rusland vrienden zijn" | #1750 Gordon Dumoulin
sa "https://www.youtube.com/watch?v=5jY3SeDDV10" --language nl # 2024-10-30 -    59:09 - De twee zielen van Amerika | #1749 Ad Verbrugge, Govert Buijs en Christiaan Alting von Geusau
sa "https://www.youtube.com/watch?v=X665hvqvzwQ" --language nl # 2024-10-31 -    51:51 - 20 jaar na moord Theo van Gogh: hoe staat het met het vrije woord? | #1751 Wierd Duk
sa "https://www.youtube.com/watch?v=iL1jsT24xMk" --language nl # 2024-10-31 -     7:11 - Oproep van Ad Verbrugge inzake toekomst De Nieuwe Wereld
sa "https://www.youtube.com/watch?v=L1N2YCmsYkI" --language nl # 2024-11-01 -  1:04:01 - Filosofie als levenswijze | #1752 Pablo Lamberti
sa "https://www.youtube.com/watch?v=zBR2-iq_It8" --language nl # 2024-11-02 -  1:20:57 - Theo van Gogh: briljant briefschrijver en provocateur | Rogier van Bemmel & Jaap Cohen
sa "https://www.youtube.com/watch?v=hyVxBiWTr9U" --language nl # 2024-11-02 -    47:47 - Volk & elite, cultuuroorlog & klassenstrijd | #1753 Gabriël van den Brink
sa "https://www.youtube.com/watch?v=8Pw7knJQ-TY" --language nl # 2024-11-03 -  1:18:00 - NCTV, NAVO en pandemische paraatheid, falende onderwijsinspectie, Amerika | #1754 Nieuws van de Week
sa "https://www.youtube.com/watch?v=h6HShcFDUYg" --language nl # 2024-11-04 -    53:56 - "Westen bereidt zich voor op groter conflict" Einde petrodollar?| #1755 Willem Middelkoop
sa "https://www.youtube.com/watch?v=KRFvvefp_Gg" --language nl # 2024-11-05 -  1:09:15 - Alles wat je moet weten over de Amerikaanse verkiezingen | Jelle spreekt Joost Kramer #1756
sa "https://www.youtube.com/watch?v=WGNdAbgqG7c" --language nl # 2024-11-07 -  1:02:42 - De tragedie van Midden-Europa | #1757 Martin de Haan en Paul Scheffer
sa "https://www.youtube.com/watch?v=rvD-HL0Wzjo" --language nl # 2024-11-08 -  1:06:19 - "Seksverslaving gaat niet over seks" | #1758 Gertjan van Zessen
sa "https://www.youtube.com/watch?v=aKIKfZuA6Jc" --language nl # 2024-11-09 -    48:21 - "Geef mensen geen slachtofferidentiteit" | #1759 Arjan Erkel
sa "https://www.youtube.com/watch?v=ULj6fRM9Fgk" --language nl # 2024-11-10 -  1:24:17 - Rellen Amsterdam, verkiezing Trump, verspreidt DNW misinformatie? en meer | #1760 Nieuws van de Week
sa "https://www.youtube.com/watch?v=VaLhhNbyYxY" --language nl # 2024-11-11 -  1:02:59 - "Ongecontroleerde migratie is bedreiging voor democratie" | #1761 Jan van de Beek
sa "https://www.youtube.com/watch?v=6s9A1pFJkpc" --language nl # 2024-11-12 -  1:00:46 - "Huwelijk nog steeds een hoger verbond" | #1762 Pol van de Wiel
sa "https://www.youtube.com/watch?v=WZUTT8_5mxM" --language nl # 2024-11-13 -  1:14:05 - Is het boek ten dode opgeschreven? | #1764 Gabriël van den Brink, Bettina Baltschev, Wouter van Gils
sa "https://www.youtube.com/watch?v=Ncdrqj2E33Y" --language nl # 2024-11-13 -    41:05 - Hoe ziet de ideale universiteit eruit? | #1763 Floris Cohen
sa "https://www.youtube.com/watch?v=5ndLQ6Yb9yE" --language nl # 2024-11-14 -    58:00 - Duitse democratie onder hoogspanning | #1765 Sietske Bergsma en Ad Verbrugge
sa "https://www.youtube.com/watch?v=FswPBs5xJWo" --language nl # 2024-11-15 -    49:29 - Sinterklaas: meer dan een kinderfeest? | #1766 Michiel de Jong
sa "https://www.youtube.com/watch?v=tdZ8SwY0UXs" --language nl # 2024-11-16 -    35:10 - Ad, Jelle en Marlies over 'The Awakening' | #1767B Filosofisch Actueel Gesprek
sa "https://www.youtube.com/watch?v=MiuEMbNLsMs" --language nl # 2024-11-16 -    54:54 - Ad, Jelle & Marlies over "The Substance" | #1767A Filosofisch Actueel Gesprek
sa "https://www.youtube.com/watch?v=OcGbp-ZQub4" --language nl # 2024-11-17 -  1:12:02 - NCTV op de universiteit? Tijd voor een nationale agenda; Benoemingen Trump | #1768 Nieuws v/d Week
sa "https://www.youtube.com/watch?v=zHW7qF9TFss" --language nl # 2024-11-18 -    58:59 - Tussen boetedoeners en borstkloppers | #1769 Martin Bossenbroek
sa "https://www.youtube.com/watch?v=arY0VS4jDWU" --language nl # 2024-11-19 -  1:08:48 - Vrienden en vijanden van het menselijk geweten in coronatijd | #1770 Christiaan Alting von Geusau
sa "https://www.youtube.com/watch?v=KYM6EvVV9_E" --language nl # 2024-11-20 -  1:05:26 - "De vrije markt bestaat helemaal niet" | #1771 Irene van Staveren
sa "https://www.youtube.com/watch?v=iApplecSW90" --language nl # 2024-11-21 -    47:09 - Bestaat polarisatie wel? | #1772 Quita Muis
sa "https://www.youtube.com/watch?v=pRDuPedRZHQ" --language nl # 2024-11-22 -    50:38 - "We laten ons gek maken door de meetrevolutie" | #1773 Simon Rozendaal
sa "https://www.youtube.com/watch?v=pFVXNQsW1pU" --language nl # 2024-11-23 -  1:13:16 - Van zuil tot zwerm: waar vinden we nieuw gezag? | #1774 Paul Visser en Ad Verbrugge
sa "https://www.youtube.com/watch?v=2GUtBweDxoo" --language nl # 2024-11-24 -  1:34:09 - Vastlopende democratie; arrestatiebevel Netanyahu; voorkomt Trump WO3? | #1775 Nieuws van de Week
sa "https://www.youtube.com/watch?v=iqyvQOIlMlc" --language nl # 2024-11-25 -    48:38 - Sinterklaastips van De Nieuwe Wereld | #1776 Jelle, Ad en Mark Wildschut
sa "https://www.youtube.com/watch?v=ka6Fna7Uklg" --language nl # 2024-11-26 -  1:11:44 - Leven met trauma | #1777 Marc van Steenkiste
sa "https://www.youtube.com/watch?v=xqZ_cxgqTvU" --language nl # 2024-11-26 -    16:50 - Trump als revolutionair en vredestichter? | DNW Kort
sa "https://www.youtube.com/watch?v=RbQwIpAligo" --language nl # 2024-11-27 -    58:16 - Euro, systeemcrisis, nucleaire dreiging: leven we op geleende tijd? | #1778 Paul Buitink
sa "https://www.youtube.com/watch?v=1L_nAo1sjP0" --language nl # 2024-11-28 -    50:26 - Pim Fortuyn, inflatie op de huizenmarkt en het casinopensioen | #1779 Eduard Bomhoff
sa "https://www.youtube.com/watch?v=go1eBxXK-pU" --language nl # 2024-11-29 -  1:13:20 - Zwijgcultuur in het ziekenhuis: "Ineens zijn je ogen open: hier klopt niets van" | #1780 Jim Reekers
sa "https://www.youtube.com/watch?v=BSph6Q4Okcw" --language nl # 2024-11-30 -  2:12:00 - Hegel over heer en knecht | #1781 Hoorcollege Ad Verbrugge
sa "https://www.youtube.com/watch?v=LQ28JkxTqH0" --language nl # 2024-12-01 -  1:12:37 - Oorlog met Rusland?; onderwijsbezuinigingen; deïndustrialisatie Duitsland | #1782 Nieuws van de Week
sa "https://www.youtube.com/watch?v=ug0KC4mQzNI" --language nl # 2024-12-02 -    50:27 - Wederzijds wantrouwen leidt tot wapenwedloop | #1783 Benjamin Duerr
sa "https://www.youtube.com/watch?v=9Z3B2plGWDk" --language nl # 2024-12-02 -     9:07 - Bubbels, beeldvorming en mediaal moralisme | DNW Kort
sa "https://www.youtube.com/watch?v=AV039DWqVmo" --language nl # 2024-12-03 -  1:11:59 - "Economie gaat eraan door klimaatbeleid EU" | #1784 Arno Wellens & Hester Bais
sa "https://www.youtube.com/watch?v=IgtMx82etMU" --language nl # 2024-12-04 -  1:03:27 - Zit Dawkins ernaast met zijn 'selfish gene'? | #1785 Jos de Mul
sa "https://www.youtube.com/watch?v=cAgJcN2UOR8" --language nl # 2024-12-05 -    44:42 - Wij-zij en de mens achter de mening | #1786 Marthe Walter
sa "https://www.youtube.com/watch?v=lg_aas_BTEk" --language nl # 2024-12-06 -    13:44 - "Het zou een zegen zijn als de nieuwe pensioenwet er niet komt" | DNW Kort
sa "https://www.youtube.com/watch?v=G0UO_MKWjLA" --language nl # 2024-12-06 -    57:42 - "De sterrenkunde is in korte tijd snel veranderd" | #1787 Nienke van der Marel
sa "https://www.youtube.com/watch?v=Kw5p9MlmlT8" --language nl # 2024-12-07 -    54:05 - "Nederland is gidsland in onbestuurbaarheid" | #1789 Wierd Duk
sa "https://www.youtube.com/watch?v=yXq0vNCaEyg" --language nl # 2024-12-07 -    57:57 - Hoe maak je goed ruzie? | #1788 Inge Marit Wielinga-Pols
sa "https://www.youtube.com/watch?v=NRsA9D7Rut8" --language nl # 2024-12-08 -  2:04:51 - Globalisme opgelegd of niet?; Vrijheid van meningsuiting; Syrië; Corona | #1790 Nieuws van de Week
sa "https://www.youtube.com/watch?v=IANylHtdXPU" --language nl # 2024-12-09 -  1:14:58 - Geopolitieke beschouwingen met Marlies, Ad, Kees de Kort en Govert Buijs | #1791 Nacht van DNW V
sa "https://www.youtube.com/watch?v=K1q04cIGpjs" --language nl # 2024-12-10 -  1:12:41 - Wie wordt er wakker? Trump, links, Oekraïne, desinformatie en meer volgens Ewald Engelen | #1792
sa "https://www.youtube.com/watch?v=bC-FPxlP4WE" --language nl # 2024-12-11 -     3:49 - "We verwarren Rusland met de Sovjetunie" | DNW Kort
sa "https://www.youtube.com/watch?v=Q0HwMAUkDTs" --language nl # 2024-12-11 -    51:02 - Bezuinigingen hoger onderwijs: goed idee of niet? | #1793 Felix Huygen
sa "https://www.youtube.com/watch?v=kt_8udTI-xs" --language nl # 2024-12-12 -    57:55 - Syrië: Realpolitik of morele plicht? | #1794 Marcel Kurpershoek
sa "https://www.youtube.com/watch?v=IpE9bJIqFGQ" --language nl # 2024-12-13 -  1:28:25 - "We worden geconditioneerd om spiritueel onderontwikkeld te blijven" | #1796 Maarten Oversier
sa "https://www.youtube.com/watch?v=INV8dBeBKUg" --language nl # 2024-12-13 -    37:41 - Rondetafelgesprek over lerarenopleidingen in de Tweede Kamer met Ad Verbrugge | #1795
sa "https://www.youtube.com/watch?v=H3zEjzwn6Qs" --language nl # 2024-12-14 -    57:42 - Zijn de media gelijkgeschakeld? | #1797 Cees Hamelink
sa "https://www.youtube.com/watch?v=xE976hXwWm0" --language nl # 2024-12-15 -  1:35:49 - Heropening Notre Dame; Trump en Macron; Syrië; Rutte bij NAVO | #1798 Nieuws van de Week
sa "https://www.youtube.com/watch?v=H-5d76yos3g" --language nl # 2024-12-16 -  1:00:01 - "Bestrijd problemen in plaats van populisten" | #1799 Marcelo Mooren
sa "https://www.youtube.com/watch?v=ewHrnbkNNsg" --language nl # 2024-12-17 -    58:14 - Liever dood dan slaaf. Ode aan de Friese vrijheid | #1800 Rypke Zeilmaker
sa "https://www.youtube.com/watch?v=OV3XC7GE6Uc" --language nl # 2024-12-18 -    59:53 - De lablektheorie, arrogante wetenschappers en het belang van troost | #1801 Jan Bonte
sa "https://www.youtube.com/watch?v=R2MO9jZukNY" --language nl # 2024-12-19 -  1:15:34 - Het einde van anonimiteit op internet? | #1802 Michel Portier
sa "https://www.youtube.com/watch?v=W3p1YypEi0s" --language nl # 2024-12-20 -  2:05:59 - Scepticisme, corona, politiek, wetenschap, AI en meer volgens Maurice de Hond | #1803
sa "https://www.youtube.com/watch?v=WbOkSMboKhM" --language nl # 2024-12-21 -  1:00:49 - Carmody Grey on remaining hopeful in spite of crises | #1804
sa "https://www.youtube.com/watch?v=oOekdmvZyV0" --language nl # 2024-12-21 -    19:26 - Internationaal arrestatiebevel voor Netanyahu | DNW Kort
sa "https://www.youtube.com/watch?v=u115zb44J1k" --language nl # 2024-12-22 -  1:54:44 - Propaganda Defensie, zzp'ers, verbod AfD, Luigi Mangione, kerst en meer | #1805 Nieuws van de Week
sa "https://www.youtube.com/watch?v=Za47KveGoWg" --language nl # 2024-12-23 -  1:22:21 - Wat voor land willen we eigenlijk zijn? | #1806 Wouter de Heij
sa "https://www.youtube.com/watch?v=up_ZNs_nkxU" --language nl # 2024-12-24 -  1:06:45 - Propaganda en desinformatie rond Nederlandse militaire missies | #1807 Jip van Dort
sa "https://www.youtube.com/watch?v=7BD0w9LbH7g" --language nl # 2024-12-24 -    14:47 - Luigi Mangione, de zorgverzekeraars en sociale media | DNW Kort
sa "https://www.youtube.com/watch?v=wbO8GDsPheY" --language nl # 2024-12-25 -  1:11:26 - Een wereld in barensnood: kerstgesprek met dominee Paul Visser | #1808
sa "https://www.youtube.com/watch?v=n24Vl62z1_A" --language nl # 2024-12-25 -    24:43 - Kijkje Achter de Schermen 2024
sa "https://www.youtube.com/watch?v=SK7HYfDU2OA" --language nl # 2024-12-26 -    59:53 - De seksuele revolutie: een bevrijding die geen bevrijding bleek? | #1809 Beatrijs Smulders
sa "https://www.youtube.com/watch?v=nP5tAMmZExY" --language nl # 2024-12-27 -  1:03:31 - Nietzsche als vitalist: amor fati, eeuwige wederkeer en de dood van God | #1810 Joep Dohmen
sa "https://www.youtube.com/watch?v=UZm-B2DYAKE" --language nl # 2024-12-28 -  1:38:33 - "Ik werd gecanceld door RTL", eindejaarsbespiegelingen met Willem Middelkoop #1811
sa "https://www.youtube.com/watch?v=LdJaT77ldIs" --language nl # 2024-12-29 -  1:49:55 - Aanslag Magdeburg, kersttoespraak koning, globalisme vs nationalisme e.m. | #1812 Nieuws van de Week
sa "https://www.youtube.com/watch?v=kk0AdA2Trss" --language nl # 2024-12-30 -    12:12 - Porno, podcasts en dopamineverslaving | DNW Kort
sa "https://www.youtube.com/watch?v=FyXe3eKGMqA" --language nl # 2024-12-31 -    57:29 - "Er komt iets af op de zorg..." | #1813 Marc Jacobs
sa "https://www.youtube.com/watch?v=S2QFc-ovpGs" --language nl # 2025-01-01 -    57:05 - Overheidsfalen van Oltmans tot de toeslagenaffaire | #1814 Ellen Pasman
sa "https://www.youtube.com/watch?v=7AobLcXc0rs" --language nl # 2025-01-02 -  1:25:33 - De geschiedenis van het nationalisme | #1815 Eric Storm
sa "https://www.youtube.com/watch?v=1Qi0COwAPA0" --language nl # 2025-01-03 -  1:16:16 - De EU, de NAVO en de veiligheidsparadox | #1816 Tom de Bruijn
sa "https://www.youtube.com/watch?v=jP1cc-ED1j0" --language nl # 2025-01-04 -    59:44 - Links elite-instituut, diplomafabriek of hoeksteen van de vrije samenleving? | #1817 Willem Halffman
sa "https://www.youtube.com/watch?v=bV0swfLmK0Q" --language nl # 2025-01-05 -  1:13:29 - Vuurwerk, energie-oorlog, Oekraïne, aanslagen New Orleans en Trump tower | #1818 Nieuws van de Week
sa "https://www.youtube.com/watch?v=UsOVCqVD-fw" --language nl # 2025-01-06 -    54:07 - Waarom verliest links steeds verkiezingen? | #1819 Jesse Frederik
sa "https://www.youtube.com/watch?v=f48T9xDzhNE" --language nl # 2025-01-07 -  1:06:59 - "Voor zorgverzekeraars draait het enkel om geld" | #1820 Ger Jager
sa "https://www.youtube.com/watch?v=YItNejJb2eY" --language nl # 2025-01-08 -    12:54 - Plutopopulisme versus de liberale democratie | DNW Kort
sa "https://www.youtube.com/watch?v=tsQ2vPgZz1I" --language nl # 2025-01-08 -    52:36 - "In 2025 staat ons een aardverschuiving te wachten" | Eindejaarsuitzending tafel 1
sa "https://www.youtube.com/watch?v=SZCZWg7TnHw" --language nl # 2025-01-09 -  1:11:13 - "Wetenschap bestaat bij de gratie van discussie" | #1821 Jona Walk
sa "https://www.youtube.com/watch?v=ODoY15VXmeE" --language nl # 2025-01-10 -  1:10:57 - Migratie van gastarbeider tot internationale student en kenniswerker | #1822 Jan van de Beek
sa "https://www.youtube.com/watch?v=w9mb4r5Z8bI" --language nl # 2025-01-11 -  1:25:25 - Revolutionaire tijden: Art Rooijakkers, grooming gangs, Weidel, Musk en Trump vlg. Wierd Duk | #1824
sa "https://www.youtube.com/watch?v=LBvEbPibV64" --language nl # 2025-01-11 -    33:39 - Wil Trump echt Groenland en Canada overnemen? | #1823
sa "https://www.youtube.com/watch?v=FipLLV4roGY" --language nl # 2025-01-12 -  1:45:26 - Trump, Musk, Weidel, Tommy Robinson, Soros, Tate, Demi Moore en meer | #1825 Nieuws van de Week
sa "https://www.youtube.com/watch?v=qI2IkR_U54U" --language nl # 2025-01-13 -  1:07:42 - "Geen onderscheid tussen lichaam en geest" | #1826 HendrikJan Houthoff
sa "https://www.youtube.com/watch?v=gZeMrrrDgbc" --language nl # 2025-01-14 -  1:01:14 - Persoon, erkenning, eigendom: over Hegels rechtsfilosofie deel I | #1827
sa "https://www.youtube.com/watch?v=ECDo5FrBFwI" --language nl # 2025-01-15 -  1:06:17 - "Kritische burger nu per definitie een wappie" | #1828 Arno Wellens
sa "https://www.youtube.com/watch?v=tz12Q9ht7lc" --language nl # 2025-01-16 -    14:49 - Weet je wel zeker dat je aan de goede kant van de geschiedenis staat? | #1829 Jelle van Baardewijk
sa "https://www.youtube.com/watch?v=g1ENQSj0EBo" --language nl # 2025-01-17 -    48:13 - "Discussie over WO II uit de bocht gevlogen" | #1831 Chris van der Heijden
sa "https://www.youtube.com/watch?v=cuGb719AhAQ" --language nl # 2025-01-18 -  2:31:41 - Hegel over het ik dat een wij wordt | #1830 Ad Verbrugge
sa "https://www.youtube.com/watch?v=RqREx2DGCxg" --language nl # 2025-01-19 -  1:46:00 - Trump & Hollywood, Roemenië, Soros, inflatie, Optimus en meer | #1831 Nieuws van de Week
sa "https://www.youtube.com/watch?v=RBTtUiEDNQs" --language nl # 2025-01-20 -    56:39 - Bosbranden in Los Angeles en de situatie in Gaza | #1832 Leon de Winter
sa "https://www.youtube.com/watch?v=RvspKKWKIiw" --language nl # 2025-01-21 -    54:21 - Waarom zijn er zo weinig klassieke musici van kleur? | #1833 Maria Paula Majoor
sa "https://www.youtube.com/watch?v=p36R3B824RI" --language nl # 2025-01-22 -  1:09:50 - "Ze kunnen me veroordelen tot vijf jaar gevangenisstraf" | #1834 Jan Roos
sa "https://www.youtube.com/watch?v=N-BhPSw6m2c" --language nl # 2025-01-23 -    13:12 - Mens, matrix en machine | DNW Kort
sa "https://www.youtube.com/watch?v=M_Kj4ixq2WU" --language nl # 2025-01-24 -  2:04:57 - Karl Marx over de moderniteit en het kapitalisme | #1835 Jelle van Baardewijk
sa "https://www.youtube.com/watch?v=0A8YCMyEOGU" --language nl # 2025-01-25 -    26:05 - Dark matter, kwantummechanica en keuzes | #1836 Jelle & Marlies
sa "https://www.youtube.com/watch?v=0k4wMG38KVg" --language nl # 2025-01-26 -  1:22:01 - Trump en het caesarisme; verbod op sociale media; stikstof en de rechter | #1837 Nieuws van de Week
sa "https://www.youtube.com/watch?v=Ytrzp26lHho" --language nl # 2025-01-27 -    46:40 - "Amerika heeft de laatste tien jaar lopen slapen" | #1838 Yuri van Geest
sa "https://www.youtube.com/watch?v=lKcQgAhz4-s" --language nl # 2025-01-28 -  1:04:11 - Kan AI de zorg wel verbeteren? | #1839 Cobie Groenendijk
sa "https://www.youtube.com/watch?v=ieb4yrM9FkY" --language nl # 2025-01-28 -    14:42 - "Reguliere media hebben gefaald" | DNW Kort
sa "https://www.youtube.com/watch?v=mHqxo3WLiv4" --language nl # 2025-01-29 -    13:10 - Greenpeace, de stikstoffuik en de rechter als politieke actor | DNW Kort
sa "https://www.youtube.com/watch?v=TqNtQ_eCgRM" --language nl # 2025-01-30 -    53:46 - "Het recht is de idee en de verwerkelijking van de vrijheid" | #1840 Ruben & Ad
sa "https://www.youtube.com/watch?v=Scg96W37Se0" --language nl # 2025-01-31 -    39:50 - Op bezoek bij Gabriël van den Brink en de "unboxing" van De Actualiteit van het archaïsche | #1841
sa "https://www.youtube.com/watch?v=V0meTrs_lpg" --language nl # 2025-02-01 -  2:25:24 - Hegel over arbeid en het ongelukkige bewustzijn | #1842 Ad Verbrugge
sa "https://www.youtube.com/watch?v=qocyboyDWa4" --language nl # 2025-02-02 -  1:33:45 - Vastlopende democratie; Brandmauer gevallen; RFK vs. Bernie Sanders en meer | #1843 Nieuws v/d Week
sa "https://www.youtube.com/watch?v=ad8E5e3mB7E" --language nl # 2025-02-03 -    53:09 - "Mijn vertrouwen in de overheid heeft een enorme knauw gekregen" | #1844 Hans van Tellingen
sa "https://www.youtube.com/watch?v=U4aC8e00fJk" --language nl # 2025-02-04 -    56:05 - Hoe bouw je een fijne stad? | #1845 Ruben Hanssen
sa "https://www.youtube.com/watch?v=ScZ3Du0zTAY" --language nl # 2025-02-05 -  1:03:48 - "Ellende in Midden-Oosten is nalatenschap kolonialisme" | #1846 Carolien Roelants
sa "https://www.youtube.com/watch?v=OjztGRkLico" --language nl # 2025-02-06 -  1:00:08 - "De kennis van mensen die het werk doen wordt geminacht" | #1847 Gabriël van den Brink
sa "https://www.youtube.com/watch?v=ka1l5RXmtYs" --language nl # 2025-02-06 -     8:11 - Bombardement Hawija, Srebrenica en Defensie als doofpotministerie | DNW Kort
sa "https://www.youtube.com/watch?v=O9ANd35_xos" --language nl # 2025-02-07 -    26:14 - Statistiekles met Maurice de Hond | #1848
sa "https://www.youtube.com/watch?v=__P-MApAjKs" --language nl # 2025-02-08 -  1:09:40 - Brave New World: geluk of zin? | #1849 Jelle van Baardewijk
sa "https://www.youtube.com/watch?v=ojjWnlNd9o0" --language nl # 2025-02-09 -  1:24:46 - Fatbikes, de euro, DOGE, miljardairssocialisme, Gaza en meer | #1850 Nieuws van de Week


exit

echo " \\" > add_fix.txt
echo '	--tags="forum inside" \' >> add_fix.txt
echo '	--tags="FVD" \' >> add_fix.txt
echo '	--tags="Forum voor democratie"' >> add_fix.txt

## sa "https://www.youtube.com/watch?v=jSjlDgOHrY8" --language nl # 2024-10-28 -  1:32:39 - Forum Inside LIVE met oud PVV-Kamerlid Machiel de Graaf, Gideon van Meijeren & Pieter Stuurman | FVD
## sa "https://www.youtube.com/watch?v=FP6F2Pf2T24" --language nl # 2024-11-04 -  1:07:20 - Kritische artsen voor de rechter, Pfizer sjoemelt met tests & een hit job op Godfather van rechts
## sa "https://www.youtube.com/watch?v=Pr-LNyA1v7M" --language nl # 2024-11-11 -  1:02:45 - JENSEN SPECIAL: Trump & Kennedy vs deep state, Joe Rogan, Elon Musk en transhumanisme
## sa "https://www.youtube.com/watch?v=2tlRKkhGlTs" --language nl # 2024-11-18 -    59:19 - PEPIJN VERTREKT! Kabinet in crisis & hoe komt de mens weer in contact met zijn natuurlijke staat?
## sa "https://www.youtube.com/watch?v=ah9_2yJGiTM" --language nl # 2024-11-25 -  1:03:08 - Keukentips van elitechef Schandrin, dieetwensen van Clinton, Trump & Beatrix en het geheim van vlees
## sa "https://www.youtube.com/watch?v=gBfyL8_46KQ" --language nl # 2024-12-09 -  1:09:53 - Moordpoging & hatespeech zelfde straf, omwenteling coronanarratief en stroomnet op ontploffen?
sa "https://www.youtube.com/watch?v=9Tb2kH_00x0" --language nl # 2024-12-16 -  1:03:51 - Assad slachtoffer van Rusland-deal? Dennis Schouten over arrestatie Jan Roos en Paarse Vrijdag | FVD
sa "https://www.youtube.com/watch?v=novdL9Ak1uw" --language nl # 2024-12-23 -  1:02:57 - Dries van Langenhove over lawfare en de rol van journalisten | Musk, crypto en technologie | FVD
sa "https://www.youtube.com/watch?v=fJXZYogssL0" --language nl # 2025-01-20 -  1:00:03 - Trump inauguratie: wat te verwachten? Filip Dewinter over omvolking! Toekomst financiële stelsel
sa "https://www.youtube.com/watch?v=wheZVv5guR0" --language nl # 2025-02-03 -  1:11:19 - Van Houwelingen, Lemm en Cliteur over oorlogsgeld, kolonialisme, diversiteit en BlackRock

exit


echo " \\" > add_fix.txt
echo '	--tags="Ab Gietelink" \' >> add_fix.txt
echo '	--tags="Alternatief.TV"' >> add_fix.txt

sa "https://www.youtube.com/watch?v=mb1bma1_3og" --language nl # 2025-01-25 -  1:12:34 - 382 Alt. Forum #15 Trump decreten, Oekraïne, Midden-Oosten en WEF. Kees van der Pijl en Ab Gietelink

cd ..
cd movies

echo " \\" > add_fix.txt
echo '	--tags="Mike Benz" \' >> add_fix.txt
echo '	--tags="Tucker Carlson"' >> add_fix.txt
sa "https://x.com/TuckerCarlson/status/1888054969145651464"

cd ..
cd movies3


sa "https://www.youtube.com/watch?v=SD0M7ZCfWdo" --language nl # 2025-01-29 -    53:57 - 383 Economische horizon 2025. Trump, EU, Oekraïne en BRICS. Ab Gietelink interviewt Frank Knopers

## cd ..
## cd movies
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Mike Benz" \' >> add_fix.txt
## echo '	--tags="Tucker Carlson"' >> add_fix.txt
## sa2 "https://x.com/TuckerCarlson/status/1888054969145651464"
## 
## cd ..
## cd movies3

echo 'Press Enter'
read aaa

sa "https://www.youtube.com/watch?v=WfXz1lxXIMA" --language nl # 2025-02-01 -    56:31 - 384 Prof. Glenn Diesen. 'The war in Ukraine and the Eurasian World Order'. Interview Ab Gietelink
sa "https://www.youtube.com/watch?v=qTWPA5lVGZo" --language nl # 2025-02-08 -  1:09:44 - 385 Mainstream Media versus Sociale Media. Pieter Klok (Volkskrant) versus Ab Gietelink




# sa "https://www.youtube.com/watch?v=lwWCGaYnd7Q" --language nl # 2025-01-19 -     9:58 - 381 Polygoonparodie ''Nederland werkt aan Vrede en Veiligheid !'' : Ab Gietelink
# sa "https://www.youtube.com/watch?v=0UipLsD35aM" --language nl # 2025-01-11 -  1:11:13 - 380 Kritische Joodse stemmen. Ab Gietelink In gesprek met Jaap Hamburger en Mordechai Krispijn
# sa "https://www.youtube.com/watch?v=QUrSgE06l8A" --language nl # 2025-01-05 -  1:14:05 - 379 Oud SP kamerlid Harry van Bommel over EU, Oost-Europa en Midden-Oosten. Ab Gietelink interviewt

exit

# # 2008-07-18 -     4:21 - Gijsbrecht van Aemstel- Proloog -Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=Apxmq6dboi0" --language nl

# # 2009-04-23 -     2:14 - Faust - Trailer Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=T3a7uVHqMeM" --language nl
# 
# # 2010-09-06 -     2:04 - Neerlands Trots in Barre Tijden 2 -Trailer - Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=z4yRGzAX2SE" --language nl
# 
# # 2011-06-01 -     1:20 - Danton en de Franse Revolutie - Trailer- Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=zajukO87o80" --language nl
# 
# # 2011-06-09 -     1:13 - Immortelle LX -Piet Paaltjens - Ab Gietelink
# sa "https://www.youtube.com/watch?v=t4n4ILIlZY8" --language nl
# 
# # 2011-06-09 -     1:39 - Boutade - de Genestet - Rapversie - Ab Gietelink
# sa "https://www.youtube.com/watch?v=8jVoOZtHTFY" --language nl
# 
# # 2011-06-09 -     2:05 - Aan Rika - Piet Paaltjens - Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=g4Zqrl_Aluc" --language nl
# 
# # 2011-06-09 -     3:24 - 1914-1918 Het lied 'Het Wijnglas' over WO1 van Dirk Witte. Door: Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=6j3J9Jj4riE" --language nl
# 
# # 2011-06-09 -     3:26 - Oote (Jan Hanlo) en De Stijl (Piet Mondriaan) door Ab Gietelink
# sa "https://www.youtube.com/watch?v=O4HhES4GvMY" --language nl
# 
# # 2011-06-09 -     4:33 - Neerlands Trots 2 - Proloog - Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=LPNhDKdd5n4" --language nl
# 
# # 2011-06-16 -     1:04 - Colijn -Jaren 30 -Crisis- Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=xgTtzxqZwGw" --language nl
# 
# # 2011-06-16 -     1:37 - Anne Frank in Gaza - Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=wX7UjnbWc_M" --language nl
# 
# # 2011-06-16 -     1:38 - Euthenasie: Dood, veeg je voeten en wees welkom ! - Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=OS4f-1O4uEo" --language nl
# 
# # 2011-06-16 -     1:53 - 1973 Vakbondsman met Internationale- Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=LXgTHINLMc8" --language nl
# 
# # 2011-06-16 -     2:09 - Het Lied der Achttien Dooden - Jan Campert - Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=avvhgvGbsdQ" --language nl
# 
# # 2011-06-16 -     3:11 - Vincent van Gogh - Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=cCEsYbFLmOI" --language nl
# 
# # 2011-06-16 -     3:45 - Max Havelaar - Aanklacht Multatuli- Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=_G8ph7Uv5sc" --language nl
# 
# # 2011-06-16 -     3:47 - 1980 Geen Woning, Geen Kroning 1898 Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=jNbSe8s6PlQ" --language nl
# 
# # 2011-06-17 -     2:13 - Islamitische vrouwen tegen stropdas - Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=ElPqewLrKR8" --language nl
# 
# # 2011-06-23 -    13:20 - Gijsbrecht van Aemstel 03/12- Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=Iu4aUX3Yu_w" --language nl
# 
# # 2011-06-23 -     9:54 - Gijsbrecht van Aemstel 02/12 - Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=jfl0E9Ed21I" --language nl
# 
# # 2011-06-24 -     4:18 - Gijsbrecht van Aemstel 01/12 - Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=TjTmXfywM88" --language nl
# 
# # 2011-06-24 -     4:30 - Gijsbrecht van Aemstel 09/12 - Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=Mx4gX408gxY" --language nl
# 
# # 2011-06-24 -     4:53 - Gijsbrecht van Aemstel 04/12 - Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=mmQVkqfpgKc" --language nl
# 
# # 2011-06-24 -     6:39 - Gijsbrecht van Aemstel 05/12 - Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=KuEAlmNtnGU" --language nl
# 
# # 2011-06-24 -     6:52 - Gijsbrecht van Aemstel 07/12 - Stadsoorlog- Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=47TqhupDBqk" --language nl
# 
# # 2011-06-24 -     6:58 - Gijsbrecht van Aemstel 08/12 - Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=zNdtIlWJK3k" --language nl
# 
# # 2011-06-24 -     7:00 - Gijsbrecht van Aemstel 06/12 - O, Kerstnacht als Islamitisch gebed- Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=PzACfAxfJz8" --language nl
# 
# # 2011-06-25 -     2:59 - Bewakingsruimte-Islamiet moet stropdas om! - Ab Gietelink & Theater Nomade
# sa "https://www.youtube.com/watch?v=VbDHnvkHsV0" --language nl
# 
# # 2011-06-25 -     3:42 - Noodpakket- Veiligheid- Paranoia- Ab Gietelink &Theater Nomade
# sa "https://www.youtube.com/watch?v=UaETtP6wfPg" --language nl
# 
# # 2011-06-25 -     4:22 - Gijsbrecht van Aemstel 12/12 - Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=bGxTi8TLHkU" --language nl
# 
# # 2011-06-25 -     5:12 - Gijsbrecht van Aemstel 10/12 - Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=nvdSPYDGZeo" --language nl
# 
# # 2011-06-25 -     5:21 - Gijsbrecht van Aemstel 11/12 - Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=7DudxfIhmbs" --language nl
# 
# # 2012-01-15 -     2:13 - Danton en de Franse Revolutie 00/12 Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=NOXUOa40Nrk" --language nl
# 
# # 2012-01-15 -     4:07 - Danton en de Franse Revolutie 03/12 Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=8Wp9suSkBkY" --language nl
# 
# # 2012-01-15 -     5:49 - Danton en de Franse Revolutie  02/12 Theater Nomade & Ab  Gietelink
# sa "https://www.youtube.com/watch?v=30rEfUh3SN0" --language nl
# 
# # 2012-01-15 -     6:01 - Danton en de Franse Revolutie 04/12 Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=Yak-hRVr7NA" --language nl
# 
# # 2012-01-16 -     5:24 - Danton en de Franse Revolutie  06/12- Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=r6Y_PNsM61I" --language nl
# 
# # 2012-01-16 -     7:15 - Danton en de Franse Revolutie  05/12- Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=nzEFnRjlOGg" --language nl
# 
# # 2012-01-16 -     9:17 - Danton en de Franse Revolutie 01/12- Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=zhvazi3trww" --language nl
# 
# # 2012-05-19 -     2:24 - The King's Speech Trailer Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=J4tCRlIgaiA" --language nl
# 
# # 2013-01-22 -  1:03:23 - The Kings Speech 1/2- Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=o-OTFr3rmYM" --language nl
# 
# # 2013-01-22 -    55:20 - The Kings Speech 2/2 -Theater Nomade & Ab Gietelink
# sa "https://www.youtube.com/watch?v=o2j0hzeigbg" --language nl
# 
## 
# 2013-05-28 -    40:53 - Wij verlangen onze Vrijheid ! Cees Maris & Ab Gietelink
## 
## sa "https://www.youtube.com/watch?v=ENp4o-x8Rek" --language nl
## ## 
## 
## ## 
## # 2013-07-22 -     1:16 - Trailer Anthony Fokker. Met Albert Plesman op de ELTA (1919).- Ab Gietelink& Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=_tmQuIU2LzE" --language nl
## ## 
## 
## ## 
## # 2013-09-19 -     3:31 - Trailer Anthony Fokker.  Fokkerfabriek in Amsterdam Noord, Jaren 20
## ## 
## sa "https://www.youtube.com/watch?v=4fOvgD_jF_Y" --language nl
## ## 
## 
## ## 
## # 2014-04-28 -     5:54 - Trailer Anthony Fokker. Met de KLM naar Londen (1921)- Ab Gietelink & Theater Nomade
## ## 
## sa "https://www.youtube.com/watch?v=jL1lf0bnXdY" --language nl
## ## 
## 
## ## 
## # 2014-11-18 -    53:25 - Anthony Fokker, Documentaire van Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=NSpueGPvoVA" --language nl
## ## 
## 
## ## 
## # 2014-12-29 -    48:45 - Anthony Fokker, Muziektheatervoorstelling, 2e Deel- Ab Gietelink & Theater Nomade
## ## 
## sa "https://www.youtube.com/watch?v=cEaioF7oh1g" --language nl
## ## 
## 
## ## 
## # 2014-12-29 -    54:24 - Anthony Fokker, Muziektheaterproductie, 1e deel -  Ab Gietelink & Theater Nomade
## ## 
## sa "https://www.youtube.com/watch?v=gDrIRAoC9qo" --language nl
## ## 
## 
## ## 
## # 2015-03-19 -     1:10 - Als de Menschen kunnen Vliegen- Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=K5BeAS5Bjk4" --language nl
## ## 
## 
## ## 
## # 2015-03-19 -     2:27 - Anthony Fokker- Trailer 2015 -Ab Gietelink &Theater Nomade
## ## 
## sa "https://www.youtube.com/watch?v=9qGS1QXylBs" --language nl
## ## 
## 
## ## 
## # 2016-11-29 -  1:18:37 - 14-18 WO I Achter de Hollandse Waterlinie Theater Nomade & Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=LGWlAxj4ED0" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     1:06 - 20 De 5 sterren beweging brengt de verbeelding aan de macht. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=ZTxfFaiPpFk" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     1:07 - 19 Drone aanslagen. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=ftz1xFPmIQw" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     1:08 - 13 Babchenko, de fictieve moord op een Kremlincriticus. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=WFlTHgDNVRk" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     1:27 - 04 Er komen andere tijden. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=_AVO0kGkwC8" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     1:41 - 33 Hoe in Nederland alles Anders kan?  Ab Gietelink & Theater Nomade
## ## 
## sa "https://www.youtube.com/watch?v=XAPrEatNI5E" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     1:45 - 09 Het Russisch Volkslied. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=w7taDOcu0Ns" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     1:46 - 17 Minister President, slaap zacht. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=DcMyDK_F4cA" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     1:53 - 02 Tunnelvisie Regeert !   Ab Gietelink &Theater Nomade
## ## 
## sa "https://www.youtube.com/watch?v=VfnDi2PB38Y" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     2:01 - 14 Spionage, of de pot verwijt de ketel dat hij zwart ziet. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=Iej8YaHVfUw" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     2:10 - 21 Opstand in de Nederlanden en in Catalonie. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=N4QAgJH9c64" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     2:27 - 11 De gifgasleugen van Douma. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=tmjz_j6Uh-Y" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     2:33 - 10 Irakoorlog: Hoe Vijandsbeelden de Leugen laten regeren. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=ttPrIjZYAXU" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     2:42 - 26 Wij zijn hier de baas! Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=Q9S4HU6yysw" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     2:46 - 12 Valse beschuldigingen in de Skripal casus. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=YFa9BlP3fWY" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     2:50 - 30 Zelfmoordenaar moet betalen. Ab Gietelink & Theater Nomade
## ## 
## sa "https://www.youtube.com/watch?v=ZQbXHaesQiA" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     2:53 - 15 Tunnelvisie in het MH17 debat. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=8om3Jlq9mIA" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     2:58 - 29 Het onbehagen bij #MeToo. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=QWtcmAYX-VU" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     2:59 - 22 Inburgeringscursus Europees Volkslied. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=QORg_Eo5o2U" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     3:04 - 16 Den Haag, van Vredespaleis tot strafhof. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=jK4V07wdwZ4" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     3:37 - 07 Hoe het Westen de Nieuwe Koude Oorlog maakte. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=ydPY7_ebxbA" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     3:38 - 18 Trump, Kim, Poetin en Gdaffi. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=KdPC26jv73c" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     3:45 - 28 Verboden te masturberen in je eigen huis. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=V7mcvswuUZY" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     3:51 - 06 Churchill, No more heroes anymore. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=WuUfUdoCJXQ" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     3:58 - 24 Het verraad van D66. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=MNwqVXl32K0" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -       39 - 27 De politie is mijn beste kameraad (Lied). Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=zF7IwOn69ps" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     4:15 - 25 Er was eens een godvrezend land. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=INrjaG-Da-I" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     4:17 - 03 Reis naar de Achterkant van het Gelijk. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=x7dipU_umAc" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     4:21 - 05 Hoe de wereldgeschiedenis anders had kunnen stromen. Ab Gietelink & Theater Nomade
## ## 
## sa "https://www.youtube.com/watch?v=Mo78wtUdAzM" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     4:24 - 01 De Leugen regeert! Ab Gietelink & Theater Nomade -
## ## 
## sa "https://www.youtube.com/watch?v=zttIRWNcyUM" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     4:52 - 32 Stop de fietsen razzia's. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=9cYOLh_4RXg" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     4:54 - 31 Het verdriet van zwarte Piet. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=4RIGzvwK_v4" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     5:04 - 08 De leugen van Halbe Zijlstra. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=kF67P6ZjjeY" --language nl
## ## 
## 
## ## 
## # 2019-01-10 -     9:14 - 23 Waarom Nederland een falende democratie is. Ab Gietelink & Theater Nomade.
## ## 
## sa "https://www.youtube.com/watch?v=TRqSd7BuRg8" --language nl
## ## 
## 
## ## 
## # 2019-06-06 -     2:39 - Willem van Oranje - Trailer Theatervoorstelling
## ## 
## sa "https://www.youtube.com/watch?v=xIgGBEo3rkU" --language nl
## ## 
## 
## ## 
## # 2020-12-05 -    17:47 - #37 Persconferentie van de nieuwe Minister President. Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=9RMlrDvLfCA" --language nl
## ## 
## 
## ## 
## # 2020-12-11 -     7:35 - #34 Performance tegen de Coronawet I Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=eAW1Vk1bew8" --language nl
## ## 
## 
## ## 
## # 2020-12-16 -    24:39 - #12 De Ionisator is de oplossing van de Pandemie Ton Rademaker en Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=02gcwpmh3ug" --language nl
## ## 
## 
## ## 
## # 2020-12-18 -    44:50 - #40 Media oorlog in Coronatijd   Ab Gietelink met Prof. Cees Hamelink
## ## 
## sa "https://www.youtube.com/watch?v=oXACNtFjS4c" --language nl
## ## 
## 
## ## 
## # 2020-12-19 -    59:21 - #42 Is de 'Coronastorm fascistisch' Prof  René ten Bos en Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=7dSPY2v4ug4" --language nl
## ## 
## 
## ## 
## # 2021-01-07 -    16:40 - #46 De Beschadiging van jongeren. Ab, Renate Tillema, Maartje Van De Berg en Aartjan Bergshoeff
## ## 
## sa "https://www.youtube.com/watch?v=k8txxAg2V20" --language nl
## ## 
## 
## ## 
## # 2021-01-23 -    47:44 - #45 Pandemie van de Angst I  Ab Gietelink interviewt Kees van der Pijl.
## ## 
## sa "https://www.youtube.com/watch?v=VYPPrjqvUEM" --language nl
## ## 
## 
## ## 
## # 2021-01-24 -    12:23 - #44 Ab Gietelink Column I Satirische Corona Encyclopedie
## ## 
## sa "https://www.youtube.com/watch?v=T2P0-W9t6sc" --language nl
## ## 
## 
## ## 
## # 2021-01-25 -    16:40 - #48 Kerstboodschap van de nieuwe minister-president I Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=7hDGn2fNv98" --language nl
## ## 
## 
## ## 
## # 2021-02-06 -     3:39 - #49 Mens durf te Leven I  Protestlied Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=vrdscXxs7aw" --language nl
## ## 
## 
## ## 
## # 2021-02-28 -     5:27 - #52 Ab Gietelink I Ik zou willen leven in een Nederland...
## ## 
## sa "https://www.youtube.com/watch?v=Rs4ZlQMo2Ho" --language nl
## ## 
## 
## ## 
## # 2021-03-22 -    56:02 - #38 Wat te verwachten van Trump en Biden? I  Ab Gietelink interviewt Kees van der Pijl.
## ## 
## sa "https://www.youtube.com/watch?v=UcSf9l8L8ks" --language nl
## ## 
## 
## ## 
## # 2021-03-26 -    43:15 - #33 Gevaarlijke sekteleider of wetenschappelijk criticus ?  Ab Gietelink interviewt Willem Engel
## ## 
## sa "https://www.youtube.com/watch?v=OSG9PD5abJ4" --language nl
## ## 
## 
## ## 
## # 2021-03-29 -    16:19 - #23 Ab Gietelink I  Burgemeester Halsema: Stop de Mondkapjesplicht! Deel 1
## ## 
## sa "https://www.youtube.com/watch?v=K1iPVW7Z1FU" --language nl
## ## 
## 
## ## 
## # 2021-03-31 -     9:34 - #24 Ab Gietelink I  Open brief aan Burgemeester Halsema. Deel 2
## ## 
## sa "https://www.youtube.com/watch?v=tTYFf25UzfU" --language nl
## ## 
## 
## ## 
## # 2021-04-02 -    40:53 - #28 Wat staat er in de Noodwet. Slapen de Kamerfracties?/ jeroen Pols en Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=zRfD8hXuXtA" --language nl
## ## 
## 
## ## 
## # 2021-04-03 -    29:49 - #36 Ab Gietelink I  Taboes in de Media en Alternatieven voor Lockdown
## ## 
## sa "https://www.youtube.com/watch?v=i4ruPrffcKI" --language nl
## ## 
## 
## ## 
## # 2021-04-06 -    41:24 - #39 Ab Gietelink I  Tunnelvisies in de Media tijdens Coronadictatuur
## ## 
## sa "https://www.youtube.com/watch?v=E-w6N_Wpb6A" --language nl
## ## 
## 
## ## 
## # 2021-04-09 -    35:19 - # 27  Honderden actiegroepen (ABC') tegen het Coronabeleid. Ferdinand van der Neut en Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=EhZXgeMnUSc" --language nl
## ## 
## 
## ## 
## # 2021-04-14 -     9:04 - #25 Ab Gietelink I  Open brief aan Minister Grapperhuis
## ## 
## sa "https://www.youtube.com/watch?v=xpr7-T21pf4" --language nl
## ## 
## 
## ## 
## # 2021-04-29 -    26:50 - #20 Ab Gietelink I  Het Censuurproces tegen YouTube en de Zelfcensuur van de media.
## ## 
## sa "https://www.youtube.com/watch?v=CBVRnkP7FEE" --language nl
## ## 
## 
## ## 
## # 2021-05-03 -    20:36 - #57 Ab Gietelink I  Brief aan onze kwaliteitsmedia in Coronatijd
## ## 
## sa "https://www.youtube.com/watch?v=kQkiieIJrQk" --language nl
## ## 
## 
## ## 
## # 2021-05-07 -    18:05 - #55 Ab Gietelink I  Brief van het Museumplein aan Burgemeester Femke Lukashenko
## ## 
## sa "https://www.youtube.com/watch?v=uzvKL28G2N0" --language nl
## ## 
## 
## ## 
## # 2021-05-17 -    15:48 - #58 Ab GietelinkI Persoonlijke Brief aan Premier Mark Rutte
## ## 
## sa "https://www.youtube.com/watch?v=PV-I9shdmE0" --language nl
## ## 
## 
## ## 
## # 2021-05-18 -    16:47 - #56 Ab Gietelink I Brief aan het OMT, Keizer zonder Kleren
## ## 
## sa "https://www.youtube.com/watch?v=iwOns4m6ouc" --language nl
## ## 
## 
## ## 
## # 2021-05-21 -     9:43 - #51 Ab Gietelink I Performance over Avondklok, Spreektaal en Quarantainefaciliteit
## ## 
## sa "https://www.youtube.com/watch?v=65M2bTrUvuI" --language nl
## ## 
## 
## ## 
## # 2021-05-26 -    54:09 - #53 Mediadisciplinering tijdens Krakersrellen en Coronacrisis  Ab Gietelink met Stan van Houcke
## ## 
## sa "https://www.youtube.com/watch?v=lWdSAJg6WCM" --language nl
## ## 
## 
## ## 
## # 2021-05-29 -     5:27 - #52 Ab Gietelink I Ik zou willen leven in een Nederland !
## ## 
## sa "https://www.youtube.com/watch?v=YOwPKYaFmaE" --language nl
## ## 
## 
## ## 
## # 2021-06-23 -    18:46 - #61 Column Ab Gietelink I  De schaduw van de Wuhan Lab fout in het Post Coronatijdperk
## ## 
## sa "https://www.youtube.com/watch?v=lVGnweju_dQ" --language nl
## ## 
## 
## ## 
## # 2021-06-30 -    15:32 - #59 Ab Gietelink – Was de 5 mei poster echt zo fout
## ## 
## sa "https://www.youtube.com/watch?v=xHwgp9N-8bs" --language nl
## ## 
## 
## ## 
## # 2021-07-07 -    16:01 - #50 Ab Gietelink I Je Suis Wappie !
## ## 
## sa "https://www.youtube.com/watch?v=oeLBktANuM4" --language nl
## ## 
## 
## ## 
## # 2021-09-25 -    18:19 - 63 Performance Ab Gietelink I Coronapas maakt Nederland tot Apartheidsstaat !
## ## 
## sa "https://www.youtube.com/watch?v=MmT02s_rCG8" --language nl
## ## 
## 
## ## 
## # 2021-09-27 -    45:51 - 64 Hoe interpreteren we de actuele oversterftecijfers ?  Ab Gietelink interviewt Ir.Luc Sala
## ## 
## sa "https://www.youtube.com/watch?v=H5pdxsuBtrU" --language nl
## ## 
## 
## ## 
## # 2021-09-30 -  1:10:03 - 65 ´Pandemie van de Angst' en Coronapas. Ab Gietelink interviewt Prof. Kees van der Pijl.
## ## 
## sa "https://www.youtube.com/watch?v=IrCfm8qwHmY" --language nl
## ## 
## 
## ## 
## # 2021-10-04 -    13:44 - 66  Pfizer bezorgde mijn zoon een gezichtsverlamming. Een persoonlijk verhaal van Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=20j1w1nFU6Y" --language nl
## ## 
## 
## ## 
## # 2021-10-07 -     1:43 - 00 Alternatief.TV. Introductiefilm van een nieuw Visionair, Kritisch en Dissident kanaal
## ## 
## sa "https://www.youtube.com/watch?v=nTeyfT4JXvs" --language nl
## ## 
## 
## ## 
## # 2021-10-09 -    53:11 - 67 Meldpunt Vaccinatie registreert de schade.  Ab  Gietelink interviewt Pieter en Jade Kuit
## ## 
## sa "https://www.youtube.com/watch?v=Ipf_4LiHPP4" --language nl
## ## 
## 
## ## 
## # 2021-10-12 -    17:52 - 68 Column Ab Gietelink. Hoe wegen we de morele argumentatie achter het QR Paspoort ?
## ## 
## sa "https://www.youtube.com/watch?v=4xTSfTnKXkY" --language nl
## ## 
## 
## ## 
## # 2021-10-16 -    56:54 - 69 Media zwijgt over de verloren oorlog in Afghanistan. Ab Gietelink ontvangt Stan van Houcke
## ## 
## sa "https://www.youtube.com/watch?v=FNPur9LyXFc" --language nl
## ## 
## 
## ## 
## # 2021-10-20 -    13:40 - 70 Column Ab Gietelink I De Media falen in kritiek op illusiepolitiek in Afghanistan.
## ## 
## sa "https://www.youtube.com/watch?v=RTuWpyBwz5w" --language nl
## ## 
## 
## ## 
## # 2021-10-23 -  1:04:19 - 71 Society 4.0 versus The Great Reset. Prof. Bob de Wit en Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=4yLjAAw75KM" --language nl
## ## 
## 
## ## 
## # 2021-10-27 -     9:26 - 72 Column Ab Gietelink. Crisis rechtsstaat en 19 fracties gebaat bij Extraparlementair Kabinet
## ## 
## sa "https://www.youtube.com/watch?v=Ll65rYUzocM" --language nl
## ## 
## 
## ## 
## # 2021-10-30 -    57:13 - 73 Mordechai Krispijn over Corona, Waku waku. QR code, Demos en Army of Love. Ab Gietelink vraagt
## ## 
## sa "https://www.youtube.com/watch?v=PVNx-JYiX5A" --language nl
## ## 
## 
## ## 
## # 2021-11-05 -     6:14 - 75 Column Ab Gietelink. De Begroetingsrevolutie in Coronatijd.
## ## 
## sa "https://www.youtube.com/watch?v=P9bV6pg9l88" --language nl
## ## 
## 
## ## 
## # 2021-11-11 -    59:06 - 77 Metje Blaak: Een leven in prostitutie en kunst. Ab Gietelink interviewt
## ## 
## sa "https://www.youtube.com/watch?v=HcPm-uFLYzE" --language nl
## ## 
## 
## ## 
## # 2021-11-16 -     8:55 - 78 Column Ab Gietelink. Demonstratie 7 November. Welke koers kiest het Coronaprotest?
## ## 
## sa "https://www.youtube.com/watch?v=M5yPUYZ-LEg" --language nl
## ## 
## 
## ## 
## # 2021-11-19 -     1:52 - 79 Fragment Ab Gietelink. De aanval op het vrouwelijk lichaam.
## ## 
## sa "https://www.youtube.com/watch?v=9gT1gvELzAU" --language nl
## ## 
## 
## ## 
## # 2021-11-20 -  1:11:35 - 80  We maken de Balans op met Maurice de Hond. Ab Gietelink interviewt.
## ## 
## sa "https://www.youtube.com/watch?v=i6uyJK9yMKI" --language nl
## ## 
## 
## ## 
## # 2021-11-26 -    53:55 - 81 De media kleurt en manipuleert de werkelijkheid. Ab Gietelink interviewt Cees Hamelink
## ## 
## sa "https://www.youtube.com/watch?v=NmUpGSmVDkY" --language nl
## ## 
## 
## ## 
## # 2021-11-29 -    18:17 - 82 Column Ab Gietelink. De Opstand van de Jongeren vs Excessief politiegeweld en eenzijdige media.
## ## 
## sa "https://www.youtube.com/watch?v=QS-t_UVBNgQ" --language nl
## ## 
## 
## ## 
## # 2021-12-02 -    10:45 - 83 Column Ab Gietelink. Krijgen ongevaccineerden met antistoffen met bloedtest een QR code ?
## ## 
## sa "https://www.youtube.com/watch?v=BRMmY7ZxELM" --language nl
## ## 
## 
## ## 
## # 2021-12-05 -    46:40 - 84 Ionisator schept virusvrije ruimten. Waterstofgas heeft Toekomst.  Ab Gietelink en Ton Rademaker
## ## 
## sa "https://www.youtube.com/watch?v=B7eR4YIAHNg" --language nl
## ## 
## 
## ## 
## # 2021-12-10 -    55:13 - 85 Wij streven naar Basisdemocratie en Referendum.  Ab Gietelink interviewt Niesco Dubbelboer
## ## 
## sa "https://www.youtube.com/watch?v=QLtP0EYOwTo" --language nl
## ## 
## 
## ## 
## # 2021-12-13 -     8:35 - 86 Persconferentie met nieuwe maatregelen. Theatermaker Ab Gietelink en Acteur Marcel Schouwstra.
## ## 
## sa "https://www.youtube.com/watch?v=SH5az_kxawc" --language nl
## ## 
## 
## ## 
## # 2021-12-17 -     1:35 - 87 Intro Column Ab Gietelink. SOS. CBS meldt aanhoudende oversterfte. Waar komt die vandaan?
## ## 
## sa "https://www.youtube.com/watch?v=h_J9QMZ5ICw" --language nl
## ## 
## 
## ## 
## # 2021-12-18 -     9:12 - 88 Column Ab Gietelink. Het Omikrontijdperk: Noodscenario of afschaffing van de maatregelen ?
## ## 
## sa "https://www.youtube.com/watch?v=FvRoxvg88F0" --language nl
## ## 
## 
## ## 
## # 2021-12-20 -    46:00 - 89  Willem Engel over zijn Dissertatie, van Ranst, Rechtszaken en Omikron. Ab Gietelink interviewt.
## ## 
## sa "https://www.youtube.com/watch?v=0ZpScQEO9VM" --language nl
## ## 
## 
## ## 
## # 2021-12-25 -     7:25 - 90 Kersttoespraak van de Nieuwe Minister-President. Performance Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=G-Vbk3jLIV8" --language nl
## ## 
## 
## ## 
## # 2021-12-28 -    42:01 - 91 'Coronabeleid heeft weinig wetenschappelijke onderbouw'. Ab Gietelink interviewt Dr. Peter Borger
## ## 
## sa "https://www.youtube.com/watch?v=HEMh6QWtKI0" --language nl
## ## 
## 
## ## 
## # 2022-01-02 -  1:02:09 - 92 Filosofische reflecties op het Coronatijdperk door Prof. René ten Bos. Ab Gietelink interviewt
## ## 
## sa "https://www.youtube.com/watch?v=GsU_Bwvburw" --language nl
## ## 
## 
## ## 
## # 2022-01-08 -    19:24 - 93 Brief van het Museumplein aan Burgemeester Halsema I Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=i2T22CjxjdI" --language nl
## ## 
## 
## ## 
## # 2022-01-17 -    12:20 - 94 Het OMT is het Hart van de Virologische Dictatuur
## ## 
## sa "https://www.youtube.com/watch?v=aCbLlfwyNjI" --language nl
## ## 
## 
## ## 
## # 2022-01-24 -     7:01 - 95. Engeland bleef open tijdens Omikrongolf. Nederlandse Lockdown was zinloos. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=qkQ-wxbm0AI" --language nl
## ## 
## 
## ## 
## # 2022-01-29 -    48:27 - 96  De Andere Krant durft dissident nieuws te brengen.  Ab Gietelink interviewt Sander Compagner
## ## 
## sa "https://www.youtube.com/watch?v=z1GriA4NHU4" --language nl
## ## 
## 
## ## 
## # 2022-02-01 -    51:10 - 97 Tom de Ket (Verleiders) over cancelcultuur en troostkunst. Ab Gietelink interviewt.
## ## 
## sa "https://www.youtube.com/watch?v=KDvkcnqzVS0" --language nl
## ## 
## 
## ## 
## # 2022-02-05 -    35:47 - 99 Hart voor Vrijheid is coronakritisch en links-midden. Pim van Galen en lijsttrekker Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=rBRYWaWHEKE" --language nl
## ## 
## 
## ## 
## # 2022-02-05 -     7:33 - 98. Ik heb Omikron ! /Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=28rWMgzFQvU" --language nl
## ## 
## 
## ## 
## # 2022-02-13 -    54:10 - 100 MH17 proces is moreel laakbaar en rust op onvoldoende bewijs. Ab Gietelink en Eric van de Beek.
## ## 
## sa "https://www.youtube.com/watch?v=SafM8NcR6nQ" --language nl
## ## 
## 
## ## 
## # 2022-02-27 -    11:56 - 101 Viroscience Lab van Erasmus MC wil nieuw ‘’hoog risico’’ Lab in Rotterdam I Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=gJHubAzVOTs" --language nl
## ## 
## 
## ## 
## # 2022-03-04 -    22:06 - 102. Stop de Navo expansie. Stop de EU Embargo's. Een Pacifistisch Manifest  I Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=Sz-IQ5weBlk" --language nl
## ## 
## 
## ## 
## # 2022-03-07 -  1:05:14 - 103  Wat zijn de oorzaken van de Oekraine oorlog?   Ab Gietelink interviewt Marie-Therese ter Haar
## ## 
## sa "https://www.youtube.com/watch?v=H1Jv8eEaje8" --language nl
## ## 
## 
## ## 
## # 2022-03-13 -    45:16 - 104. Hart voor Vrijheid Amsterdam, Corona kritisch. Antiautoritair en Links. Ab Gietelink interviewt
## ## 
## sa "https://www.youtube.com/watch?v=eyfvJf7yDxY" --language nl
## ## 
## 
## ## 
## # 2022-03-17 -    15:06 - 105. Vrede komt pas als het Westen Oekraïne aanzet tot rechtvaardig compromis. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=Qr3V3QjH83c" --language nl
## ## 
## 
## ## 
## # 2022-03-24 -     5:51 - 106. Intro televisietoespraak Poetin 21-02-2022. In Nederlands voorgelezen door Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=Ys8tsIzThic" --language nl
## ## 
## 
## ## 
## # 2022-03-26 -     9:20 - 107 Open brief aan Rechtbank Den Haag over burgerrechtenactivist Willem Engel. Brief Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=KlgRSuMLkSg" --language nl
## ## 
## 
## ## 
## # 2022-03-29 -    10:21 - 108. Wat deed het Westen fout? Welke vredesregeling voor Oekraïne is haalbaar? Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=ncXUSfXL8x0" --language nl
## ## 
## 
## ## 
## # 2022-04-02 -     6:09 - 109. Docu ‘Ukraine on Fire’ over Maidanrevolutie schetst oorzaken Oekraïne oorlog.  Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=Sgkw1YUSqeU" --language nl
## ## 
## 
## ## 
## # 2022-04-06 -  1:16:08 - 110. Interview met Aleksander Sjoelgin, de Russische Ambassadeur in Nederland, door Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=auBrkcn5QGQ" --language nl
## ## 
## 
## ## 
## # 2022-04-09 -    10:51 - 111. Wat wil Poetin? Wat zegt het Russisch persbureau TASS ? Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=xXTKvO5CfbM" --language nl
## ## 
## 
## ## 
## # 2022-04-15 -     6:22 - 112. Nederlandse internetproviders censureren Russische zenders van RT. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=Y2xUIgobY60" --language nl
## ## 
## 
## ## 
## # 2022-04-16 -     7:52 - 113 Hoe zou Jezus van Nazareth oordelen over Coronacrisis en Oekraïneoorlog? Paascolumn Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=JW-CCt4-pck" --language nl
## ## 
## 
## ## 
## # 2022-04-22 -    57:02 - 114 Hans Siepel: Klokkenluider over de Nederlandse bestuurscultuur. Ab Gietelink interviewt.
## ## 
## sa "https://www.youtube.com/watch?v=KEdqYVteArc" --language nl
## ## 
## 
## ## 
## # 2022-04-24 -     8:50 - 115 Open Brief aan President Zelenski. Auteur Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=R4GSBO_3Hnw" --language nl
## ## 
## 
## ## 
## # 2022-04-27 -     8:43 - 116. Regering Scholz streeft naar Duitse herbewapening en vaccinatieplicht. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=xROyQ3ZuXDY" --language nl
## ## 
## 
## ## 
## # 2022-04-30 -  1:06:22 - 117 Feiten in Oekraïne waar de 'Mainstream Media' over zwijgen. Ab Gietelink met Prof. Kees vd. Pijl
## ## 
## sa "https://www.youtube.com/watch?v=MNOGy1fEkRk" --language nl
## ## 
## 
## ## 
## # 2022-05-04 -  1:01:22 - 118. Dissidente reflecties over Rusland, Oekraïne en het Westen. Ab Gietelink met Prof. René ten Bos
## ## 
## sa "https://www.youtube.com/watch?v=4bn3V2LWe5g" --language nl
## ## 
## 
## ## 
## # 2022-05-07 -    11:54 - 119. Westen miskent zelfbeschikkingsrecht van de Krim. Opinieartikel Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=b4M27Uv6gXk" --language nl
## ## 
## 
## ## 
## # 2022-05-12 -    10:02 - 120 Herstelt Elon Musk met Twitter de Vrijheid van Meningsuiting op sociale media? door Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=fNUiHkuxD_0" --language nl
## ## 
## 
## ## 
## # 2022-05-14 -    37:34 - 121 Integrale Televisierede: Poetin 24 Febr. 2022 met inleiding door voorlezer Ab Gietelink.
## ## 
## sa "https://www.youtube.com/watch?v=xEUqdOmLFYY" --language nl
## ## 
## 
## ## 
## # 2022-05-19 -     5:16 - 122 Militaire dienstplicht bij Corona en Oekraïne is aanval op Burgerrechten. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=EualDxSQHOQ" --language nl
## ## 
## 
## ## 
## # 2022-05-21 -  1:04:30 - 123 De Sanctieoorlog faalt. De EU bevolking betaalt. Ab Gietelink met Frank Knopers
## ## 
## sa "https://www.youtube.com/watch?v=ZSCIV83NC0A" --language nl
## ## 
## 
## ## 
## # 2022-05-25 -    10:10 - 124 Voert Rusland in Oost-Oekraïne een bevrijdingsoorlog? Column Ab Gietelink.
## ## 
## sa "https://www.youtube.com/watch?v=B_O_J4FkyiM" --language nl
## ## 
## 
## ## 
## # 2022-05-28 -    19:39 - 125 NAVO expansie met Finland en Zweden verhoogt nucleaire dreiging. Column Ab Gietelink.
## ## 
## sa "https://www.youtube.com/watch?v=yef4ehc-aN4" --language nl
## ## 
## 
## ## 
## # 2022-05-31 -     9:40 - 126 Zelensky verbood 11 partijen en liet oppositieleider Medvedchuk opsluiten. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=OTJr82mB1t0" --language nl
## ## 
## 
## ## 
## # 2022-06-05 -     6:52 - 127  Westerse sanctieoorlog. Oekraineoorlg en  Lockdowns maken voedselcrisis. Column Ab Gietelink.
## ## 
## sa "https://www.youtube.com/watch?v=WxcYbOFy6xg" --language nl
## ## 
## 
## ## 
## # 2022-06-08 -    17:03 - 128 Internat. Strafhof is eenzijdig Westers/Oekraïens en moet worden afgeschaft. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=XnQAO6IKDss" --language nl
## ## 
## 
## ## 
## # 2022-06-13 -    12:13 - 129 Brief aan Zelensky. NLReferendumvoorstel: Stop bewapening en sanctieoorlog. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=uvf44E9VFU4" --language nl
## ## 
## 
## ## 
## # 2022-06-17 -  1:05:33 - 130  Crisis in onze economie Waarom en Hoe? Wat te doen?  Ab Gietelink en Eric Mecking
## ## 
## sa "https://www.youtube.com/watch?v=hMIP1M6coKk" --language nl
## ## 
## 
## ## 
## # 2022-06-22 -  1:11:10 - 106A Integrale televisietoespraak van Poetin 21-02-2022. In Nederlands voorgelezen door Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=u98fDVVnOE8" --language nl
## ## 
## 
## ## 
## # 2022-06-25 -  1:00:32 - 131 Wat willen de inwoners van Oost Oekraine? Ab Gietelink zoomt met reporter Sonja van den Ende.
## ## 
## sa "https://www.youtube.com/watch?v=wMJfZ78cSN0" --language nl
## ## 
## 
## ## 
## # 2022-06-29 -    12:28 - 132 Westerse media selecteren, kleuren en manipuleren informatie.  Analyse Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=I3PcGvPETe0" --language nl
## ## 
## 
## ## 
## # 2022-07-03 -  1:12:28 - 133 De wereldeconomie sinds 1944 en hoe nu verder? Ab Gietelink interviewt Sander Boon
## ## 
## sa "https://www.youtube.com/watch?v=4qd0g35iw7Q" --language nl
## ## 
## 
## ## 
## # 2022-07-08 -    15:51 - 134 Meneer Rutte, Stop wapens en sancties! Tijd voor opsplitsing van Oekraine! Brief Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=OSNOHXs9PZk" --language nl
## ## 
## 
## ## 
## # 2022-07-16 -  1:12:50 - 136 Hoe oordeelt SP over Referenda en Oekraïne oorlog? Ab Gietelink met 2e Kamerlid Jasper van Dijk.
## ## 
## sa "https://www.youtube.com/watch?v=5Wtvo2BPjWY" --language nl
## ## 
## 
## ## 
## # 2022-07-21 -    13:09 - 137 Nederland stelt sanctieoorlog Rusland boven energiebelang eigen bevolking. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=8KALLdVR9fI" --language nl
## ## 
## 
## ## 
## # 2022-07-26 -     8:10 - 138 Amsterdam wil verbanning van Wallen-prostitutie en introductie van wietpas. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=TlDL4pgT7dI" --language nl
## ## 
## 
## ## 
## # 2022-07-30 -    19:09 - 139 BRICS landen dagen Westerse dominantie uit. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=1a8Nu6o6yTQ" --language nl
## ## 
## 
## ## 
## # 2022-08-03 -    19:05 - 140 De Tragedie van Evropa 1e Deel. Een politiek sprookje van Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=RfGYfwSncio" --language nl
## ## 
## 
## ## 
## # 2022-08-05 -    18:46 - 141 De Tragedie van Evropa. 2e Deel  De broedertwist van Vladimir en Volodymir. Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=-lupn5d_NEA" --language nl
## ## 
## 
## ## 
## # 2022-08-10 -  1:19:18 - 142 Hoe het Russisch denken te begrijpen? Ab Gietelink interviewt Prof. Evert van der Zweerde
## ## 
## sa "https://www.youtube.com/watch?v=qzyQ7z2mORU" --language nl
## ## 
## 
## ## 
## # 2022-08-14 -  1:00:07 - 143 Rusland is positief over haar toekomst. Ab Gietelink interviewt zakenman Peter van Stigt
## ## 
## sa "https://www.youtube.com/watch?v=aGzbNJ4JjL4" --language nl
## ## 
## 
## ## 
## # 2022-08-26 -    55:12 - 144 Stikstof. Prof. Han Lindeboom. geeft alternatieven. Ab Gietelink interviewt
## ## 
## sa "https://www.youtube.com/watch?v=GQE7zFqCugE" --language nl
## ## 
## 
## ## 
## # 2022-08-31 -    11:59 - 145 Novorossiya of hoe Oekraïne op te delen? Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=yHBW1HFvL2M" --language nl
## ## 
## 
## ## 
## # 2022-09-03 -    49:17 - 146 Blckbx oprichter en TVmaker Flavio Pasquino over alternatieve media.  Ab Gietelink interviewt
## ## 
## sa "https://www.youtube.com/watch?v=ynIjf33I230" --language nl
## ## 
## 
## ## 
## # 2022-09-10 -    43:45 - 147 Van Bioboer naar LabVoedsel ?  Ab Gietelink interviewt Elze van Hamelen
## ## 
## sa "https://www.youtube.com/watch?v=_b8uomKFgUI" --language nl
## ## 
## 
## ## 
## # 2022-09-16 -  1:03:25 - 148. 5G schept gezondheidsrisico's en surveillancestaat. Ab Gietelink interviewt Sylvia Slegers
## ## 
## sa "https://www.youtube.com/watch?v=rUq6HufklC4" --language nl
## ## 
## 
## ## 
## # 2022-09-21 -    10:08 - 149 Het Stikstofdebat in 25 Kernbegrippen en namen ! Woordenlijst door Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=QIMVr8l848M" --language nl
## ## 
## 
## ## 
## # 2022-09-24 -  1:00:31 - 150 Alternatieven voor het Stikstofbeleid. Ab Gietelink interviewt Prof. Johan Sanders.
## ## 
## sa "https://www.youtube.com/watch?v=P0rFKkofCHs" --language nl
## ## 
## 
## ## 
## ## echo " \\" > add_fix.txt
## ## 
## ## echo '	--tags="Veritas Vos Liberabit" \' >> add_fix.txt
## ## 
## ## echo '	--tags="De Gulden Middenweg"' >> add_fix.txt
## ## 
## ## 
## ## 
## ## sa "https://www.youtube.com/watch?v=yXSy_XlitJ8" --language nl
## ## 
## ## 
## ## 
## ## echo " \\" > add_fix.txt
## ## 
## ## echo '	--tags="Ab Gietelink" \' >> add_fix.txt
## ## 
## ## echo '	--tags="Alternatief.TV"' >> add_fix.txt
## ## 
## 
## ## 
## echo "Press Enter"
## ## 
## read a 
## ## 
## 
## ## 
## # 2022-09-27 -     9:46 - 151 Hoe had Gorbatsjov als Westers leider de Oekraïnecrisis opgelost ? Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=ycMOb1USZLk" --language nl
## ## 
## 
## ## 
## # 2022-09-30 -     9:06 - 152 Nordstream. Wie pleegde de terreuraanslag en waarom? Wat zijn de gevolgen ? Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=1_EPn5oY30Q" --language nl
## ## 
## 
## ## 
## # 2022-10-02 -    12:16 - 153 Wil de meerderheid in de Referenda-gebieden bij Rusland? Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=Lcktlxhu99Y" --language nl
## ## 
## 
## ## 
## # 2022-10-08 -    11:32 - 154 Hoe de Nederlands/ Europese sanctieoorlog ontploft in ons eigen gezicht. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=yX2MsNH_0y8" --language nl
## ## 
## 
## ## 
## # 2022-10-10 -     8:16 - 155 Troonrede. Waarom de Regering Nederland in een destructieve spiraal brengt? Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=kevbhJB7RnQ" --language nl
## ## 
## 
## ## 
## # 2022-10-15 -     9:38 - 156 Oekraïne, Rusland en het Westen zitten in zelfvernietigende spiraal. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=4PAPFlJZHJA" --language nl
## ## 
## 
## ## 
## # 2022-10-18 -    12:04 - 157 Brief aan vicepremier Kaag. D66 vernietigt haar eigen  erfgoed. Brief Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=WnV5C3Gl93g" --language nl
## ## 
## 
## ## 
## # 2022-10-21 -    14:00 - 158 Manifest Stop de wapenleveranties, sancties en laat referenda beslissen ! Tekst Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=3AIZZOeTatM" --language nl
## ## 
## 
## ## 
## # 2022-10-24 -    58:22 - 159 De Slag om Oekraïne. Ab Gietelink interviewt Prof. Kees van der Pijl
## ## 
## sa "https://www.youtube.com/watch?v=VoB0qVPtiiE" --language nl
## ## 
## 
## ## 
## # 2022-10-29 -    10:14 - 160 Premier Rutte is NLoorlogshitser nummer 1. Brief van Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=pHRW6wl0GII" --language nl
## ## 
## 
## ## 
## # 2022-11-05 -    11:53 - 161 Vermeend antisemitisme David Icke overschaduwt vredesdemonstratie. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=ehqpbCn6-g8" --language nl
## ## 
## 
## ## 
## # 2022-11-07 -     7:12 - 162 Elon Musk wil Vrijheid op Twitter en Vrede met Rusland ! Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=nLJPVisYZDs" --language nl
## ## 
## 
## ## 
## # 2022-11-12 -    47:25 - 163 Media voert propagandaoorlog tegen satan Poetin. Ab Gietelink interviewt Prof. Cees Hamelink.
## ## 
## sa "https://www.youtube.com/watch?v=bp7cWVTxctk" --language nl
## ## 
## 
## ## 
## # 2022-11-16 -     7:49 - 164 Hoe Vrede met Rusland te realiseren? 7 Voorstellen. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=OtmA6oroGWQ" --language nl
## ## 
## 
## ## 
## # 2022-11-20 -    31:40 - 165 Ruslandkenner ter Haar:"Referendacijfers in Russisch-Oekraine realistisch!'' Ab Gietelink vraagt
## ## 
## sa "https://www.youtube.com/watch?v=Pxc1oesQbro" --language nl
## ## 
## 
## ## 
## # 2022-11-23 -    13:01 - 166 Maak niet het voetbal en cultuur tot instrument van embargo en oorlog! Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=bH5MkscgzYY" --language nl
## ## 
## 
## ## 
## # 2022-12-01 -    11:28 - 167 Beschadigde Arib was tevens voorzitter enquêtecommissie coronamaatregelen. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=tzgBcS7rYYY" --language nl
## ## 
## 
## ## 
## # 2022-12-04 -     7:29 - 168 VN topadviseur Sachs bekritiseert Oekraïneverhaal en herkomst coronavirus. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=WoipsqWb58s" --language nl
## ## 
## 
## ## 
## # 2022-12-09 -     9:25 - 169 Maak de digitale euro anoniem en niet programmeerbaar. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=NvNI_FnREX0" --language nl
## ## 
## 
## ## 
## # 2022-12-11 -    52:23 - 170 Europa vernietigt zichzelf! Ab Gietelink interviewt journalist Stan van Houcke.
## ## 
## sa "https://www.youtube.com/watch?v=ueSwhqx4Zvg" --language nl
## ## 
## 
## ## 
## # 2022-12-15 -     7:34 - 171 The Twitter Files tonen censuursystemen sociale media. Artikel Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=vN839I_eplc" --language nl
## ## 
## 
## ## 
## # 2022-12-18 -    10:36 - 172 Mevr. Von der Leyen: U escaleert de oorlog ! Brief Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=FUyBw9xdl1U" --language nl
## ## 
## 
## ## 
## # 2022-12-23 -    11:00 - 173 Mediafixatie op ‘grensoverschrijdend gedrag’ leidt tot schandpaalcultuur!. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=1Sk2WYeJX2A" --language nl
## ## 
## 
## ## 
## # 2022-12-27 -     9:58 - 174 Oekraïne glijdt af naar dictatuur. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=jMhyYW2PNpI" --language nl
## ## 
## 
## ## 
## # 2023-01-06 -    58:23 - 175  Dissidente berichten uit Moskou. Ab Gietelink interviewt Sonja van den Ende
## ## 
## sa "https://www.youtube.com/watch?v=8j9aJdD9nGM" --language nl
## ## 
## 
## ## 
## # 2023-01-10 -    10:48 - 176 Laat een referendum onder VN toezicht beslissen over territoriale claims. Column Ab Gietelink
## ## 
## sa "https://www.youtube.com/watch?v=78JhM7ATe1M" --language nl
## ## 
## 
## ## 
## # 2023-01-13 -    11:38 - 177 Coronaprotest, antiglobalisme & vredesactivisme breken Links-Rechts schema. Essay Ab Gietelink.
## ## 
## sa "https://www.youtube.com/watch?v=2hV8j3YnkZw" --language nl
## 
## 

## # 2023-01-18 -     9:15 - 178 Reconstructie: Rusland vroeg 7 jaar om uitvoering Minskakkoorden. Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=lohJPOrihOY" --language nl
## 
## # 2023-01-27 -     5:56 - 179 Journalist Chemeris: Oekraine is een totalitaire staat!. Artikel Ab Gietelink
## sa "https://www.youtube.com/watch?v=Gb2kcXcYYzk" --language nl
## 
## # 2023-01-31 -     8:56 - 180 Elon Musk: ''Alle Complottheorieën over Twitter blijken waar!' Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=wO7lzg0yeT0" --language nl
## 
## # 2023-02-04 -    53:52 - 181 Het Wokisme bijt in haar eigen staart ! Ab Gietelink met UvA wetenschapper Laurens Buijs.
## sa "https://www.youtube.com/watch?v=r4uQ7ffxYCg" --language nl
## 
## # 2023-02-11 -    56:24 - 182  Wat willen Oost-  en West Oekraïners ? Ab Gietelink in gesprek met Marie-Therese ter Haar.
## sa "https://www.youtube.com/watch?v=CYpIcL4I08M" --language nl
## 
## # 2023-02-17 -     9:43 - 183 Vredesdemonstratie tegen wapenleveranties Oekraïne. Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=nbymf4igAic" --language nl
## 
## # 2023-02-22 -     9:16 - 184 De pot verwijt de ketel of wat deed het westen fout? Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=4R-48JbOL4w" --language nl
## 
## # 2023-02-24 -     4:01 - 185 WO1 14-18 'Het wijnglas'', pacifistisch lied van Dirk Witte. Door Ab Gietelink & Theater Nomade
## sa "https://www.youtube.com/watch?v=sZ1houaw2JM" --language nl
## 
## # 2023-02-26 -  1:23:22 - 186 Bedreigt de VS aanslag op Nordstream de NAVO? Ab Gietelink interviewt Prof Kees van der Pijl
## sa "https://www.youtube.com/watch?v=zQ5yvOVbsMQ" --language nl
## 
## # 2023-03-01 -    22:19 - 187 1e Vredesdemonstratie in NL Zo 19 Febr. Reportage Hugo Gietelink
## sa "https://www.youtube.com/watch?v=HNZMjI-BvYU" --language nl
## 
## # 2023-03-03 -     8:07 - 188 Geachte Bondskanselier, Brief over Nordstream en Stalingrad. Afzender Ab Gietelink.
## sa "https://www.youtube.com/watch?v=LEOK01KYuFA" --language nl
## 
## # 2023-03-06 -    57:34 - 189 Complotcatalogus. Hoe complotdenker te worden? Ab Gietelink interviewt Patrick Savalle.
## sa "https://www.youtube.com/watch?v=BMCZ__u-A7s" --language nl
## 
## # 2023-03-11 -    35:39 - 190 Wie Is Max de Fakkeldrager en hoe beoordelen we hem? Ab Gietelink interviewt
## sa "https://www.youtube.com/watch?v=Sz1dBaL6NT0" --language nl
## 
## # 2023-03-17 -     9:03 - 191 Wapenleveranties Oekraïne leidt tot ontheemding bij klassiek linkse kiezers. Ab Gietelink
## sa "https://www.youtube.com/watch?v=Z7RzVrSbk6I" --language nl
## 
## # 2023-03-19 -    10:05 - 192 Was Capitool 6 jan. ‘’dodelijke opstand’’ of ‘’grotendeels vreedzame chaos’’?  Ab Gietelink
## sa "https://www.youtube.com/watch?v=LXLSvAW1I-o" --language nl
## 
## # 2023-03-21 -  1:00:32 - 193 Wie is Doegin? ’’Het brein van Poetin’’? Ab Gietelink interviewt Joost Niemoller
## sa "https://www.youtube.com/watch?v=2Kbjf5dkMwk" --language nl
## 
## # 2023-03-25 -     2:32 - 194 Lied: Minister-president slaap zacht!  Ab Gietelink. Van Syrie naar Oekraine.
## sa "https://www.youtube.com/watch?v=S5ya_IpJKsM" --language nl
## 
## # 2023-03-28 -    52:10 - 195 Stan van Houcke: 'VS verloor alle oorlogen sinds 1945. Incl. Oekraine. Ab Gietelink interviewt
## sa "https://www.youtube.com/watch?v=-RBXhe-FDjQ" --language nl
## 
## # 2023-04-01 -     9:45 - 196 BBB = realistisch! Meer boeren, gezonder voedsel, minder gif en minder stikstof. Ab Gietelink
## sa "https://www.youtube.com/watch?v=7HcU4CqMWkU" --language nl
## 
## # 2023-04-03 -  1:03:19 - 197 Verdiende BPOC haar donaties?  Oordeelt u zelf over hun vaccinatiemeldpunt ! Ab Gietelink.
## sa "https://www.youtube.com/watch?v=g_RHr1iIxGw" --language nl
## 
## # 2023-04-07 -     8:12 - 198 Hoe zou Jezus van Nazareth oordelen over Coronacrisis en Oekraïneoorlog? Paascolumn Ab Gietelink
## sa "https://www.youtube.com/watch?v=zx28OvtX_vU" --language nl
## 
## # 2023-04-10 -  1:04:42 - 199 Handen af van de Wallen!  Ab Gietelink interviewt oud-Sexwerkers Mariska Majoor en Metje Blaak
## sa "https://www.youtube.com/watch?v=kRRC9zuhDk4" --language nl
## 
## # 2023-04-14 -    11:09 - 200 Strafzaak Trump bedreigt Amerikaanse democratie. Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=Y_f4DkVCD1w" --language nl
## 
## # 2023-04-17 -     6:15 - 201 Voer 0% Btw-tarief voor groente en fruit in ! Ab Gietelink
## sa "https://www.youtube.com/watch?v=HDRXk2zsEOU" --language nl
## 
## # 2023-04-20 -    49:14 - 202 Police for freedoms'' Dennis Spaanstra met kritiek op politieorganisatie. Ab Gietelink ontvangt
## sa "https://www.youtube.com/watch?v=yMNFXkbhJbw" --language nl
## 
## # 2023-04-28 -    10:02 - 203 NL F16 piloten vuurden 2188 raketbommen af in Irak en Syrië. Hoeveel slachtoffers? Ab Gietelink
## sa "https://www.youtube.com/watch?v=YOotllw_7LU" --language nl
## 
## # 2023-05-01 -    57:16 - 204 Wat gaat AI, ChatGPT en deeplearning ons brengen?  Ab Gietelink ontvangt Vincent Everts.
## sa "https://www.youtube.com/watch?v=v38sTJ4suV0" --language nl
## 
## # 2023-05-04 -     2:58 - 205. Herdenking 4 en 5 mei. Het Lied der Achttien Dooden. Performance Ab Gietelink
## sa "https://www.youtube.com/watch?v=e62TnFLEjnc" --language nl
## 
## # 2023-05-06 -    13:17 - 206 Mijn nieuwe boek beschikbaar! Tunnelvisies of Hoe realiseren we Vrede in Oekraine? Ab Gietelink
## sa "https://www.youtube.com/watch?v=FX-1qfVhGbQ" --language nl
## 
## # 2023-05-10 -    11:09 - 207 Hoe hadden we Nederlands-Indië vreedzaam kunnen overdragen? Ab Gietelink
## sa "https://www.youtube.com/watch?v=54243bp-XWU" --language nl
## 
## # 2023-05-19 -    10:23 - 208 Oud-president Medvedev zegt wat Russische hardliners denken. Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=-FpjWfh_h-s" --language nl
## 
## # 2023-05-23 -     6:32 - 209 Richard de Mos verdient na vrijspraak eerherstel OM en terugkeer in Haags B&W. Ab Gietelink
## sa "https://www.youtube.com/watch?v=OkNiwDp23Gk" --language nl
## 
## # 2023-05-27 -    53:38 - 210 Pepijn van Houwelingen (FvD) over Japan, EU, WPG en Oekraine. Ab Gietelink Interviewt.
## sa "https://www.youtube.com/watch?v=fNq_FCYhrhU" --language nl
## 
## # 2023-06-04 -    12:26 - 211 Hoe kwamen we in de Oekraïne-oorlog? Hoe komen we er weer uit? Ab Gietelink
## sa "https://www.youtube.com/watch?v=U8K7XqTwOEo" --language nl
## 
## # 2023-06-10 -    25:52 - 212 Vredestoespraak Kennedy uit 1963 inspiratiebron voor Oekraïne. Ab Gietelink
## sa "https://www.youtube.com/watch?v=MCa443ypHJ0" --language nl
## 
## # 2023-06-13 -    46:46 - 213 Prof. Bob de Wits' Democratie 4.0 is vervolg op Society 4.0  Ab Gietelink interviewt
## sa "https://www.youtube.com/watch?v=lxMJey9R85I" --language nl
## 
## # 2023-06-16 -    11:31 - 214 Herteken de grenzen van Kosovo met Servie !  Ab Gietelink
## sa "https://www.youtube.com/watch?v=Tg5Fj8wRZjQ" --language nl
## 
## # 2023-06-19 -  1:02:22 - 215 De Tragedie van Oekraine. Ab Gietelink ontvangt Prof. Kees van der Pijl.
## sa "https://www.youtube.com/watch?v=89Z3X14_330" --language nl
## 
## echo "Press Enter"
## read aaa
## 
## # 2023-06-23 -     7:35 - 216 Poetin opent SPIEF '23: ''Russische economie groeit 1,5%''. Ab Gietelink
## sa "https://www.youtube.com/watch?v=UpYICd3rbvw" --language nl
## 
## # 2023-06-26 -     7:06 - 217 ‘Tucker on Twitter’ krijgt meer views dan MSM in VS.  Ab Gietelink.
## sa "https://www.youtube.com/watch?v=5Mh4Mu_xM1k" --language nl
## 
## # 2023-06-30 -    13:24 - 218 Wagner muiterij tegen de afschaffing van hun Russische subsidies. Ab Gietelink
## sa "https://www.youtube.com/watch?v=USdu-TGzlZY" --language nl
## 
## # 2023-07-02 -    59:53 - 219 Hoe gaat het nu in Rusland? Ab Gietelink ontvangt zakenman Peter van Stigt
## sa "https://www.youtube.com/watch?v=DQVqq7KdZJA" --language nl
## 
## # 2023-07-09 -     8:41 - 220 Globale expansie NAVO vergroot kans op 3e Wereldoorlog. Ab Gietelink
## sa "https://www.youtube.com/watch?v=-DKHgcUVj6c" --language nl
## 
## # 2023-07-16 -     7:26 - 221 Ukrainian PR Army voorziet westerse media van het politiek correcte nieuws. Ab Gietelink
## sa "https://www.youtube.com/watch?v=-FsGm5hTDzc" --language nl
## 
## # 2023-07-23 -     3:59 - 222 Oekraine is in 2014 gebroken. Opdeling is noodzakelijk. Ab Gietelink bij ON
## sa "https://www.youtube.com/watch?v=MtINguWNtlg" --language nl
## 
## # 2023-07-29 -    10:44 - 223 Rusland: ""Westen kwam graandeal niet na!"" Ab Gietelink
## sa "https://www.youtube.com/watch?v=32TjnePGOd4" --language nl
## 
## # 2023-08-02 -    55:11 - 224 Zomergasten Alternatief 1: Prof.Jean Tilly, democratie, corona en kraakbeweging. Ab Gietelink
## sa "https://www.youtube.com/watch?v=IAw9SQsnlUo" --language nl
## 
## # 2023-08-05 -     4:06 - 225 Vredesprotestsong: Zeg me waar de bloemen zijn? Liedtekst en uitvoering Ab Gietelink
## sa "https://www.youtube.com/watch?v=FHQc1cYI220" --language nl
## 
## # 2023-08-10 -  1:02:09 - 226 Zomergasten Alternatief 2: Prof. Kees vd. Pijl over Polen en de Informatieoorlog. Ab Gietelink
## sa "https://www.youtube.com/watch?v=yAvgtRfQRdY" --language nl
## 
## # 2023-08-15 -  1:10:25 - 227 Kritiek van Oekraïnse en Russische vrouwen.  Ab Gietelink interviewt Elena, Natalia en Elena.
## sa "https://www.youtube.com/watch?v=HcK7kFRHndY" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="BLCKBX"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=weT-2_G3RDA" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Ab Gietelink" \' >> add_fix.txt
## echo '	--tags="Alternatief.TV"' >> add_fix.txt
## 
## # 2023-08-19 -  1:01:36 - 228 Oud-minister Jan Pronk: 'Internationale rechtsorde gebroken''. Ab Gietelink en Maurice van Ulden
## sa "https://www.youtube.com/watch?v=gL00wVqHYkM" --language nl
## 
## # 2023-08-22 -    10:29 - 229 Is aanklacht tegen Arib instrument bij ondermijning parlementaire enquête corona?  Ab Gietelink
## sa "https://www.youtube.com/watch?v=9IjpJjvXHo0" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="FVD" \' >> add_fix.txt
## echo '	--tags="Forum voor democratie"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=HEWAdQ_eIdY" --language nl
## 
## echo " \\" > add_fix.txt
## echo '	--tags="TRUMP" \' >> add_fix.txt
## echo '	--tags="Crash" \' >> add_fix.txt
##  echo '	--tags="Briefing After Plane-Helicopter"' >> add_fix.txt
## 
## sa "https://www.youtube.com/watch?v=9jQT-jnyo6E" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Ab Gietelink" \' >> add_fix.txt
## echo '	--tags="Alternatief.TV"' >> add_fix.txt
## 
## # 2023-08-24 -    47:25 - 231 Hoe onderhandelen we over vrede in Oekraïne? Ab Gietelink interviewt Paul Meerts
## sa "https://www.youtube.com/watch?v=T_N3EHbJC_k" --language nl
## 
## # 2023-08-24 -     8:20 - 230 Wie pleegde de vliegtuigaanslag op Prigozjin? Ab Gietelink
## sa "https://www.youtube.com/watch?v=a3mMi0gWr08" --language nl
## 
## # 2023-08-28 -    10:35 - 232 Nieuw Sociaal Contract (NSC) van Omzigt gunstig voor kritiek en oppositie. Ab Gietelink
## sa "https://www.youtube.com/watch?v=YU8xuwLVfDs" --language nl
## 
## # 2023-08-31 -  1:05:43 - 233 Waarom steunt NL de oorlog in Oekraïne? Vredesactivist  Jakob de Jonge en Ab Gietelink
## sa "https://www.youtube.com/watch?v=u_TUdeKdOmc" --language nl
## 
## # 2023-09-03 -    51:13 - 234 Terugkijken op corona.  Toekomst met WHO-verdrag en Censuurwet. Ab Gietelink met Jeroen Pols
## sa "https://www.youtube.com/watch?v=BWidu488OcI" --language nl
## 
## # 2023-09-08 -  1:21:37 - 235 Russian Ambassador, Alexander Shulgin about Ukraine. Interview Ab Gietelink
## sa "https://www.youtube.com/watch?v=nLrlZsae5hY" --language nl
## 
## # 2023-09-12 -     4:22 - 236 Max Havelaar slottekst: ''Ik wil gelezen worden''  Performance Ab Gietelink
## sa "https://www.youtube.com/watch?v=bmN5meFs4CE" --language nl
## 
## # 2023-09-15 -    16:58 - 237 BRICS versus Westerse dominantie. Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=Bf_jmitd2NQ" --language nl
## 
## # 2023-09-19 -    19:16 - 238 Wie is Zelensky? Van televisiester tot proxy-dictator. Analyse Ab Gietelink
## sa "https://www.youtube.com/watch?v=QWxtTmVFLwM" --language nl
## 
## # 2023-09-23 -    54:09 - 239 Hoe realiseren we Vrede in Oekraine?  Jelle van Baardewijk (DNW) interviewt Ab Gietelink
## sa "https://www.youtube.com/watch?v=Eahx2K7tYZg" --language nl
## 
## # 2023-09-29 -     7:39 - 240  VN faalt. Geef Nagorno Karabach zelfbeschikking ! Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=5frGUIaES-k" --language nl
## 
## # 2023-10-06 -    49:10 - 241 Dedollarisatie, inflatie, krimp en herinvoering gulden. Ab Gietelink interviewt Jelena Postuma
## sa "https://www.youtube.com/watch?v=cKMRm6cohvI" --language nl
## 
## # 2023-10-10 -    42:43 - 242 Journalistenforum De Andere Krant #1. Ab Gietelink, Sander Compagner, Eric vd Beek, Wouter Meijs
## sa "https://www.youtube.com/watch?v=_DbOWHt9xtQ" --language nl
## 
## # 2023-10-13 -    12:14 - 243 Inzake Palestina staat Nederland aan de foute kant van de Geschiedenis. Ab Gietelink
## sa "https://www.youtube.com/watch?v=fLDZ7jnFPIg" --language nl
## 
## # 2023-10-15 -    22:03 - 244 Reisverslag: Jezus in Israel & Palestina. Door Ab Gietelink
## sa "https://www.youtube.com/watch?v=_7pfkWmiu0c" --language nl
## 
## # 2023-10-18 -  1:07:59 - 245  Geschiedenis van Israël & Palestina. Ab Gietelink in samenspraak met Prof. Kees van der Pijl
## sa "https://www.youtube.com/watch?v=kLjYI0Qtaw4" --language nl
## 
## # 2023-10-20 -     8:06 - 246 Gaza-oorlog geeft film ‘Golda’ over Jom Kipour oorlog (1973) actualiteit. Ab Gietelink
## sa "https://www.youtube.com/watch?v=o__HhIyA3Lk" --language nl
## 
## # 2023-10-22 -     8:56 - 247 Faciliteerde regering Netanyahu doelbewust de Hamasaanval? Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=MS5Ykpk-fB4" --language nl
## 
## # 2023-10-24 -    52:22 - 248 Journalistenforum De Andere Krant #2. Ab Gietelink, Sander Compagner, Toine Rongen, Ad Nuis
## sa "https://www.youtube.com/watch?v=Uq9z7gWJIoM" --language nl
## 
## # 2023-10-27 -    12:47 - 249 NRC Journalisten verspreiden valse complottheorie over Vredesdemonstratie. Brief Ab Gietelink
## sa "https://www.youtube.com/watch?v=zc5fVlP7Loc" --language nl
## 
## # 2023-10-29 -    22:16 - 250 Gaza, Hamas en Nakba historie. Worden de Palestijnen verdreven? Ab Gietelink
## sa "https://www.youtube.com/watch?v=vOFZp0gpCzU" --language nl
## 
## # 2023-11-01 -  1:00:52 - 251 Linkse vredespolitiek,  Oekraïne en Palestina. Ab Gietelink interviewt Guido van Leemput
## sa "https://www.youtube.com/watch?v=kCy5ASIfw-o" --language nl
## 
## # 2023-11-03 -    12:32 - 252 Premier Rutte, NAVO oorlogshitser #1  Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=0ce0b6J87Jo" --language nl
## 
## # 2023-11-05 -    57:43 - 253 Journalistenforum De Andere Krant #3. Karel Beckman, Erick Overveen, Kees vd Pijl, Ab Gietelink
## sa "https://www.youtube.com/watch?v=pnIYAx-rBbQ" --language nl
## 
## # 2023-11-07 -    55:32 - 254 Medialeugens, Mensenrechten, Oekraïne en Palestina.  Ab Gietelink interviewt prof. Cees Hamelink
## sa "https://www.youtube.com/watch?v=oHQF-gF8wyM" --language nl
## 
## # 2023-11-09 -    11:48 - 255 Hamas: Terreurgroep of verzetsbeweging? Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=LcLZNGc2KwM" --language nl
## 
## # 2023-11-11 -  1:03:14 - 256 Journalist Stan van Houcke met keiharde kritiek op Israel. Interview Ab Gietelink
## sa "https://www.youtube.com/watch?v=BuCwgx1mhas" --language nl
## 
## # 2023-11-13 -     9:37 - 257 Docu ‘Roadmap to Apartheid’ vergelijkt Israëlische en Zuid-Afrikaanse Apartheid. Ab Gietelink
## sa "https://www.youtube.com/watch?v=EA8dAc3v1bU" --language nl
## 
## # 2023-11-15 -    47:19 - 258  Onteigening van Boeren en Vissers. Koers 2030.  Ab Gietelink in gesprek met Elze van Hamelen
## sa "https://www.youtube.com/watch?v=iJTvJZnmPxw" --language nl
## 
## # 2023-11-17 -     7:56 - 259 Wie is Netanyahu? Mr. security of oorlogsmisdadiger?
## sa "https://www.youtube.com/watch?v=HzHvq8SHknc" --language nl
## 
## # 2023-11-19 -    55:56 - 260 Journalistenforum DAK #4. Pieter Stuurman, Barbara Le Noble, Bert Brandsma en Ab Gietelink
## sa "https://www.youtube.com/watch?v=dChNx-iuVqM" --language nl
## 
## # 2023-11-21 -    12:55 - 261 Welke partij moeten we kiezen?  Waarom geen referenda? Ab Gietelink
## sa "https://www.youtube.com/watch?v=T28j_hjodaE" --language nl
## 
## # 2023-11-26 -    15:18 - 262 Historie van Israël & Palestina Deel 1.  Auteur: Ab Gietelink
## sa "https://www.youtube.com/watch?v=BZ2fFARFJRA" --language nl
## 
## # 2023-11-29 -    16:59 - 263 Historie van Israël & Palestina. Deel 2.  Auteur: Ab Gietelink
## sa "https://www.youtube.com/watch?v=rEBAxITSwhc" --language nl
## 
## # 2023-12-01 -    17:37 - 264 Verkiezingsuitslag vraagt rechts Extraparlementair minderheidskabinet. Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=rx3Xih7-DhY" --language nl
## 
## # 2023-12-03 -    15:46 - 265 Wie is Geert Wilders? Wat wil de PVV? Analyse Ab Gietelink
## sa "https://www.youtube.com/watch?v=LwYmZG1_UjY" --language nl
## 
## # 2023-12-05 -    50:42 - 266 Journalistenforum De Andere Krant #5. Willem Ernee, Arjen Pasma, Jeroen Arents en Ab Gietelink
## sa "https://www.youtube.com/watch?v=5zFAfVGoEVs" --language nl
## 
## # 2023-12-08 -    49:42 - 267 PVV grootste partij. Wat te doen? Ab Gietelink interviewt George van Houts.
## sa "https://www.youtube.com/watch?v=OiQDp_X6iEQ" --language nl
## 
## # 2023-12-12 -    29:33 - 268 Wat wil Hamas? Hamas Handvest (Integrale tekst). Voorlezer Ab Gietelink
## sa "https://www.youtube.com/watch?v=eQNDKSFgbm8" --language nl
## 
## # 2023-12-16 -    17:37 - 269 EU expansie met Oekraïne is stap naar nieuwe oorlog. Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=WEy9ZcrrpJo" --language nl

## # 2023-12-18 -    53:08 - 270 Journalistenforum DeAndereKrant #6 Sander Compagner, Karel Beckman, Ido Dijkstra en Ab Gietelink
## sa "https://www.youtube.com/watch?v=XBDrKir4aJI" --language nl
## 
## # 2023-12-21 -  1:04:40 - 271 Wilders, PVV, Nieuwe Democratie en Referendum. Ab Gietelink interviewt Peter Baars
## sa "https://www.youtube.com/watch?v=MLj2_UxjoK0" --language nl
## 
## # 2023-12-24 -    14:40 - 272 Mijn Kerstboodschap. Blijven de dominees van Europa de oorlogen legitimeren? Ab Gietelink
## sa "https://www.youtube.com/watch?v=HthOprtvHIM" --language nl
## 
## # 2023-12-27 -    14:43 - 273 Militaire dienstplicht is ernstige mensenrechtenschending. Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=mznfRGCWdOo" --language nl
## 
## # 2023-12-30 -    50:19 - 274 Stotteren Is een ademhalingsprobleem ! The Kings'Speech. Ab Gietelink ontvangt Ingrid Del Ferro
## sa "https://www.youtube.com/watch?v=7-2mWhA99qU" --language nl
## 
## # 2024-01-05 -    12:56 - 275 Zwitserland is een referendumdemocratie. Nederland een oligarchische meritocratie 1 Ab Gietelink
## sa "https://www.youtube.com/watch?v=GTXDvKuNJ_A" --language nl
## 
## # 2024-01-07 -    14:52 - 276 Zwitserland is een referendumdemocratie. Nederland een oligarchische meritocratie 2 Ab Gietelink
## sa "https://www.youtube.com/watch?v=TAd4TG4QR9w" --language nl
## 
## # 2024-01-10 -    49:53 - 277 'Israel heeft een Judeo-fascistische regering !' stelt Jaap Hamburger. Interview Ab Gietelink
## sa "https://www.youtube.com/watch?v=dJKLOr33vCY" --language nl
## 
## # 2024-01-13 -     9:26 - 278 Processen tegen Trump bedreigen Amerikaanse democratie. Ab Gietelink
## sa "https://www.youtube.com/watch?v=fJVbJCd1yXU" --language nl
## 
## # 2024-01-15 -  1:04:35 - 279 Wat is historisch Links en Rechts? #1 1789-1917. Presentatie: Ab Gietelink en Kees van der Pijl
## sa "https://www.youtube.com/watch?v=cW0YPJu-lBk" --language nl
## 
## # 2024-01-18 -  1:05:32 - 280 Harry van Bommel over de PVV, de SP, Oost-Europa, Oekraine en Gaza. Ab Gietelink interviewt
## sa "https://www.youtube.com/watch?v=NpNzLVscp8Q" --language nl
## 
## # 2024-01-21 -    12:20 - 281 Politie faciliteerde Koranverbranding door Pegida.  Ab Gietelink
## sa "https://www.youtube.com/watch?v=zlA3Ey3naSU" --language nl
## 
## # 2024-01-23 -     7:44 - 282 Leegloop Kabinet Rutte. Wie regeert Nederland eigenlijk? Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=Rz1__fxGvVw" --language nl
## 
## # 2024-01-26 -  1:22:57 - 283 Wat is historisch Links en Rechts? #2 1917-1991. Prof. Kees vd Pijl en Ab Gietelink
## sa "https://www.youtube.com/watch?v=sYb9wiqkJXw" --language nl
## 
## # 2024-01-28 -     7:43 - 284 Zal Trump Europa van Oekraïne-oorlog verlossen?  Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=xObj96CJTXo" --language nl
## 
## # 2024-01-31 -    50:30 - 285 Hoe verbeteren we de democratie? Ab Gietelink interviewt Rients Hofstra
## sa "https://www.youtube.com/watch?v=RYiZpadRHdM" --language nl
## 
## # 2024-02-03 -    56:21 - 286 Falende Hulpinstanties en Verstoten Vaders. Jeroen Arents, Arthur Victorie en Ab Gietelink
## sa "https://www.youtube.com/watch?v=m8XBvBhy7fA" --language nl
## 
## # 2024-02-06 -    10:17 - 287 Jemen: De burgeroorlog vraagt om 2-Statenoplossing. Analyse Ab Gietelink
## sa "https://www.youtube.com/watch?v=DvDmPIJNzWc" --language nl
## 
## # 2024-02-09 -    11:21 - 288 ‘Imperium USA’ schetst ontluisterende geschiedenis van Amerikaanse wereldmacht. Ab Gietelink
## sa "https://www.youtube.com/watch?v=vT-Z4VSzreY" --language nl
## 
## # 2024-02-12 -  1:33:30 - 289 Wat is historisch Links en Rechts? #3 1991-2024. Presentatie Kees van der Pijl en Ab Gietelink
## sa "https://www.youtube.com/watch?v=pbIGzkMh5ZM" --language nl
## 
## # 2024-02-18 -    14:12 - 290 Argentijnse president Milei is een globalistische ultra-kapitalistische autocraat. Ab Gietelink
## sa "https://www.youtube.com/watch?v=KnhgTTeWWvs" --language nl
## 
## # 2024-02-23 -     9:54 - 291 Navalny was een burgerrechtenactivist. Assange is de westerse Navalny. Ab Gietelink
## sa "https://www.youtube.com/watch?v=gdy_i9hIoyE" --language nl
## 
## # 2024-02-26 -     9:39 - 292 Extraparlementair kabinet. Wat zijn de voordelen? Hoe werkt het? Ab Gietelink
## sa "https://www.youtube.com/watch?v=wHWM9sI-5lM" --language nl
## 
## # 2024-02-29 -    15:10 - 293 Hoe de CIA de wereld destabiliseert. Tekst Prof. Sachs. Voorlezing Ab Gietelink
## sa "https://www.youtube.com/watch?v=TnKyf6kayPc" --language nl
## 
## # 2024-03-02 -  1:23:25 - 294 Alternatief Forum #1 Assange, Navalny, Gaza, Oekraïne. Kees vd Pijl, Stan v Houcke, Ab Gietelink
## sa "https://www.youtube.com/watch?v=IY6_iVKwXh4" --language nl
## 
## # 2024-03-05 -    37:06 - 295 Hamas over 7 okt 2023. Operatie Al-Aqsa Flood. Voorlezer Ab Gietelink
## sa "https://www.youtube.com/watch?v=RpwHsWZBCJs" --language nl
## 
## # 2024-03-08 -    10:23 - 296 Gaza wordt verwoest en uitgemoord. Wat doet de wereld? Ab Gietelink
## sa "https://www.youtube.com/watch?v=onWuXGeiWaQ" --language nl
## 
## # 2024-03-10 -    49:35 - 297 Willem Engel over Oekraïne, Gaza en Pacifisme. Ab Gietelink interviewt.
## sa "https://www.youtube.com/watch?v=szZk14wyDcI" --language nl
## 
## 
## ## echo " \\" > add_fix.txt
## ## echo '	--tags="geo engineering" \' >> add_fix.txt
## ## echo '	--tags="CIA"' >> add_fix.txt
## ## 
## ## sa "https://x.com/BGatesIsaPyscho/status/1885636099940225076" --language en
## 
## echo " \\" > add_fix.txt
## echo '	--tags="indepen"' >> add_fix.txt
## 
## #date: 2024-12-27 - length:    21:02 - title: "Indepen Nieuws EU Special aflevering 2"
## sa "https://www.youtube.com/watch?v=LGkSaM_SJro" --language nl
## 
## #date: 2024-12-27 - length:    15:49 - title: "Indepen Nieuws EU Special aflevering 3"
## sa "https://www.youtube.com/watch?v=Ut_vF6hYq_A" --language nl
## 
## #date: 2024-12-27 - length:    14:38 - title: "Indepen Nieuws EU Special aflevering 1"
## sa "https://www.youtube.com/watch?v=fxLmsdA1dRo" --language nl
## 
## #date: 2024-12-27 - length:    12:56 - title: "Indepen Nieuws EU Special aflevering 4"
## sa "https://www.youtube.com/watch?v=zps0T_tXwpI" --language nl
## 
## #date: 2024-12-23 - length:    10:52 - title: "Indepen Business Nieuws aflevering 8"
## sa "https://www.youtube.com/watch?v=GZVv-BHcdXQ" --language nl
## 
## #date: 2024-12-23 - length:    10:51 - title: "Indepen Business Nieuws aflevering 7"
## sa "https://www.youtube.com/watch?v=zjFNFT-SHPM" --language nl
## 
## #date: 2024-12-19 - length:     9:40 - title: "Miljardairs gaan er met EU-landbouwsubsidie vandoor; Indepen Business Nieuws aflevering 6"
## sa "https://www.youtube.com/watch?v=G1teKh8lD8Y" --language nl
## 
## #date: 2024-12-15 - length:     9:32 - title: "Verontrustende ontwikkeling Nederlandse economie; Indepen Business Nieuws Aflevering 5"
## sa "https://www.youtube.com/watch?v=fndCQWevVuo" --language nl
## 
## #date: 2024-12-06 - length:    14:58 - title: "Huizenprijzen in Nederland en de rest van de EU; Indepen Business Nieuws #4"
## sa "https://www.youtube.com/watch?v=q9K9v3kIiQs" --language nl
## 
## #date: 2024-11-07 - length:    19:32 - title: "De economie na jarenlang EU-wanbeleid; Indepen Business Nieuws #3"
## sa "https://www.youtube.com/watch?v=1KwTX3nP-CM" --language nl
## 
## #date: 2024-10-31 - length:    18:34 - title: "Duitse neergaande economie trekt Nederland mee; Indepen Business Nieuws #2"
## sa "https://www.youtube.com/watch?v=2eCclD0Bb-I" --language nl
## 
## #date: 2024-10-23 - length:    19:45 - title: "De Nederlandse economie; Indepen Business Nieuws #1"
## sa "https://www.youtube.com/watch?v=dNY3ZEYYnoY" --language nl
## 
## #date: 2024-09-25 - length:    10:24 - title: "Indepen Nieuws Aflevering 2"
## sa "https://www.youtube.com/watch?v=gaCucwtfId0" --language nl
## 
## #date: 2024-08-19 - length:    11:48 - title: "Indepen Nieuws Aflevering 1"
## sa "https://www.youtube.com/watch?v=o6I6_tVmMu4" --language nl
## 
## #date: 2024-06-26 - length:    12:47 - title: "Weermanipulatie: complot of realiteit?"
## sa "https://www.youtube.com/watch?v=x-ivVvHTJ0A" --language nl
## 
## #date: 2024-05-01 - length:     6:18 - title: "Jacht op huisartsen: ethiek bezwijkt onder bureaucratie"
## sa "https://www.youtube.com/watch?v=nebdK1PJMIM" --language nl
## 
## #date: 2023-12-20 - length:     7:07 - title: "Officier van Justitie verandert spelregels bij Gideon van Meijeren"
## sa "https://www.youtube.com/watch?v=tFaCrkZMWFY" --language nl
## 
## #date: 2023-10-12 - length:    22:37 - title: "Interview Prof. Kees de Lange over het klimaat"
## sa "https://www.youtube.com/watch?v=yWKsLtRLdp0" --language nl
## 
## #date: 2023-07-14 - length:     9:43 - title: "Reportage Wieringervisser Dirk Koster"
## sa "https://www.youtube.com/watch?v=82rpr3DYWGQ" --language nl
## 
## #date: 2023-07-13 - length:       48 - title: "Trailer Wieringervisser Dirk Koster"
## sa "https://www.youtube.com/watch?v=t6LbzLYl9BY" --language nl
## 
## #date: 2023-07-13 - length:     1:06 - title: "Trailer Wieringervisser Dirk Koster"
## sa "https://www.youtube.com/watch?v=dKDZfNY52FY" --language nl
## 
## #date: 2023-06-13 - length:     2:00 - title: "Graangeluk kort"
## sa "https://www.youtube.com/watch?v=By7af_zHMEI" --language nl
## 
## #date: 2023-06-13 - length:    12:59 - title: "Graangeluk"
## sa "https://www.youtube.com/watch?v=1h5XmyXrvhM" --language nl
## 
## #date: 2023-03-13 - length:     2:47 - title: "Verslag boerenprotest 11 maart 2023"
## sa "https://www.youtube.com/watch?v=0creu5Z3vI4" --language nl
## 
## #date: 2023-03-13 - length:    10:34 - title: "Volledige versie, Boeren Protest 11 maart 2023"
## sa "https://www.youtube.com/watch?v=lWTAcM-VXyo" --language nl
## 
## #date: 2023-03-02 - length:     1:14 - title: "De Echte Stemwijzer"
## sa "https://www.youtube.com/watch?v=KVWFFF1lzdc" --language nl
## 
## #date: 2023-02-19 - length:     5:26 - title: "Laatste palingvisser van Volendam blijft strijdbaar"
## sa "https://www.youtube.com/watch?v=bZ2URkzb6HQ" --language nl
## 
## #date: 2023-01-17 - length:    18:06 - title: "Heel interview: Prof. De Lange: De ‘stikstofcrisis’ is een ambtelijk verzinsel"
## sa "https://www.youtube.com/watch?v=0V7mZND-ZSU" --language nl
## 
## #date: 2022-12-02 - length:     3:11 - title: "Prof Kees de Lange"
## sa "https://www.youtube.com/watch?v=M7QdHXk_IIM" --language nl
## 
## #date: 2022-06-22 - length:     2:13 - title: "Boeren Protest 22 juni 2022"
## sa "https://www.youtube.com/watch?v=8WJRIQ-mDAo" --language nl
## 
## #date: 2022-05-31 - length:     1:28 - title: "Rutte pleit ervoor dat een deel van de soevereiniteit moet worden weggeven aan de EU."
## sa "https://www.youtube.com/watch?v=1ndrk9rk_T4" --language nl
## 
## #date: 2022-05-29 - length:       43 - title: "Kasja Ollongren pleit voor een Europees leger"
## sa "https://www.youtube.com/watch?v=ZSiOOsPsMZg" --language nl
## 
## #date: 2022-05-25 - length:     8:50 - title: "Indepen laat 67000 stemmen niet verloren gaan!"
## sa "https://www.youtube.com/watch?v=K_5P67W8Vw4" --language nl
## 
## 
## echo " \\" > add_fix.txt
## echo '	--tags="Ab Gietelink" \' >> add_fix.txt
## echo '	--tags="Alternatief.TV"' >> add_fix.txt
## 
## 
## # 2024-03-13 -    15:43 - 298 J''accuse. Stop de steun van politiek en media aan 10 jaar Oekraïense Burgeroorlog. Ab Gietelink
## sa "https://www.youtube.com/watch?v=niK2Fd5i340" --language nl
## 
## # 2024-03-16 -    13:37 - 299 Waarom stemmen Russen voor Poetin? Hoe democratisch is de Russische federatie? Ab Gietelink
## sa "https://www.youtube.com/watch?v=VGFNhDnZikY" --language nl
## 
## # 2024-03-20 -  1:04:01 - 300 Marcel van Silfhout over Joegoslavië jaren 90, Oekraïne en Graan. Ab Gietelink interviewt.
## sa "https://www.youtube.com/watch?v=bpSt5E_kvd4" --language nl
## 
## # 2024-03-23 -    13:23 - 301 Programkabinet = Beter bestuur. Plasterk premier ? Ab Gietelink
## sa "https://www.youtube.com/watch?v=-AHIaA_8HVQ" --language nl
## 
## # 2024-03-26 -  1:09:39 - 302 Misdaden van het Oranje Koningshuis. Ab Gietelink interviewt Frans Peeters.
## sa "https://www.youtube.com/watch?v=wW7Zv8nGFGs" --language nl
## 
## # 2024-03-28 -  1:10:16 - 303 Van Euro Naar Gulden?  Willen we dat?  Waarom en Hoe? Ab Gietelink interviewt Paul Buitink
## sa "https://www.youtube.com/watch?v=Mjnd1v6w_vM" --language nl
## 
## # 2024-03-31 -  1:13:29 - 304 Alternatief Forum #2. Formatie, Oekraïne en Gaza. Ab Gietelink en Kees van der Pijl
## sa "https://www.youtube.com/watch?v=hR6e29Ex95Q" --language nl
## 
## # 2024-04-03 -    13:31 - 305 Terreuraanslag in Moskou. Wie had het motief?  IS of Oekraïne?  Ab Gietelink
## sa "https://www.youtube.com/watch?v=Gk8r1FgTrPk" --language nl
## 
## # 2024-04-06 -    11:51 - 306 Antisemitisme, Islamofobie en Russofobie. Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=2SknS54iGbs" --language nl
## 
## # 2024-04-09 -  1:09:10 - 307 Huisarts vs Pharma. Welke alterrnatieven zijn er?  Ab Gietelink interviewt Felix van der Wissel.
## sa "https://www.youtube.com/watch?v=lLRI-q3PVGQ" --language nl
## 
## # 2024-04-12 -    15:10 - 308 Het Verraad van Groen Links. Van Vredescollectief tot Oorlogspartij. Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=rOhXT2fErWI" --language nl
## 
## # 2024-04-15 -  1:12:37 - 309 Alternatief Forum #3. Klaver, Oekraïne en Gaza. Ab Gietelink en Peter Baars
## sa "https://www.youtube.com/watch?v=1fE29Z4X3Hc" --language nl
## 
## # 2024-04-19 -     8:29 - 310 Vredesspeech Dam, Amsterdam. Ab Gietelink
## sa "https://www.youtube.com/watch?v=rCBTwEvSh2I" --language nl
## 
## # 2024-04-23 -    39:20 - 311 Russofobie! Moeten Russische Nederlanders zwijgen? Ab Gietelink interview Natalia Vorontsova
## sa "https://www.youtube.com/watch?v=ULaUjnMLQbU" --language nl
## 
## # 2024-04-27 -     9:21 - 312 ‘Civil War’ geeft dystopisch toekomstbeeld over burgeroorlog in Amerika. Recensie Ab Gietelink
## sa "https://www.youtube.com/watch?v=KLNfYLaEde0" --language nl
## 
## # 2024-04-30 -  1:01:28 - 313 Deep State, MI Complex, MSM, Rothschild en Agenda 2030. Ab Gietelink met Diedert de Wagt
## sa "https://www.youtube.com/watch?v=2V5k9X-MvdY" --language nl
## 
## # 2024-05-24 -    21:22 - 314 Rusland Dagboek #0 Herinneringen 1988-2019. Ab Gietelink
## sa "https://www.youtube.com/watch?v=V0y-fO68KO8" --language nl
## 
## # 2024-05-26 -    19:05 - 315 Rusland Dagboek #1 Kaliningrad. Auteur Ab Gietelink
## sa "https://www.youtube.com/watch?v=jN3cpC6wd_0" --language nl
## 
## # 2024-05-31 -    21:42 - 316 Rusland Dagboek #2. Sankt Petersburg. Auteur Ab Gietelink
## sa "https://www.youtube.com/watch?v=qu_Um8EqE3U" --language nl
## 
## # 2024-06-02 -  1:18:33 - 317 Alternatief Forum #4 Schoof, EU, Gaza en Oekraïne. Ab Gietelink, Kees vd. Pijl en Peter Baars
## sa "https://www.youtube.com/watch?v=ZnaSad9TDVY" --language nl
## 
## # 2024-06-05 -    17:04 - 318 Rusland Dagboek #3. Moskou. Auteur Ab Gietelink
## sa "https://www.youtube.com/watch?v=jmfHVWDmK-w" --language nl
## 
## # 2024-06-07 -    20:21 - 319 Brengt de Europese Unie ons in de 3e Wereldoorlog? Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=SiG_zK1lmxQ" --language nl
## 
## # 2024-06-09 -    11:28 - 320 Kritische Plasterk krijgt dolksteek. Ex-spion Schoof wordt Premier. Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=VxeF119uKRM" --language nl
## 
## # 2024-06-12 -  1:04:13 - 321 New Russian Ambassador Vladimir Tarabrin on Ukraine (NL vertaling). Interview Ab Gietelink
## sa "https://www.youtube.com/watch?v=0sAnqDRkw6w" --language nl
## 
## # 2024-06-14 -    13:37 - 322 EU: Lage opkomst en groei scepsis op links en rechts vraagt bescheidener rol EU.  Ab Gietelink
## sa "https://www.youtube.com/watch?v=0i5rp12guQU" --language nl
## 
## # 2024-06-17 -    56:02 - 323 Tom de Ket over zijn locatietheater en de kunstwereld.  Ab Gietelink interviewt
## sa "https://www.youtube.com/watch?v=AnJePSlayww" --language nl
## 
## # 2024-06-20 -    17:15 - 324 Rusland Dagboek #4 Vladimir & Suzdal. Ab Gietelink
## sa "https://www.youtube.com/watch?v=aaLeoYW8KNg" --language nl



## # 2024-06-23 -    51:17 - 325 Homeopathie. Hoe werkt het? Hoeveel succes heeft het? Ab Gietelink interviewt Arjen Pasma
## sa "https://www.youtube.com/watch?v=LSY_PWk5_cs" --language nl
## 
## # 2024-06-28 -  1:16:16 - 326 Alternatief Forum #5: Regering, EU, Gaza, Oekraine. Kees vd Pijl, George v Houts, Ab Gietelink
## sa "https://www.youtube.com/watch?v=qVoWyxpTeiw" --language nl
## 
## # 2024-06-30 -    15:07 - 327 Assange: Wat moeten we leren van zijn zaak? Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=SzsEVKz1jL8" --language nl
## 
## # 2024-07-03 -    19:44 - 328 Rusland Dagboek #5 Tallinn, Estland. Ab Gietelink
## sa "https://www.youtube.com/watch?v=l1PPTExmhUM" --language nl
## 
## # 2024-07-06 -    15:27 - 329 Groeiend verzet in Westerse politiek tegen oorlogssteun Oekraïne. Ab Gietelink
## sa "https://www.youtube.com/watch?v=QlO4utpIpQY" --language nl
## 
## # 2024-07-09 -     3:04 - 330  In 2010 was politiek links ook tegen Hoofddoekjes. Theaterscene door Ab Gietelink
## sa "https://www.youtube.com/watch?v=gsl-x-sk-wk" --language nl
## 
## # 2024-07-12 -    13:42 - 331 Afscheidsbrief aan premier Rutte. Afzender Ab Gietelink
## sa "https://www.youtube.com/watch?v=9n1rbQyujoI" --language nl
## 
## # 2024-07-15 -    12:34 - 332 Oekraïne splijt links Frankrijk. Mélenchon wil vredesregeling. Ab Gietelink
## sa "https://www.youtube.com/watch?v=jgr91-pAmSU" --language nl
## 
## # 2024-07-18 -  1:27:29 - 333 Alternatief Forum #6. Regering, EU, NAVO en Links. Cees Hamelink, Kees vd. Pijl, Ab Gietelink
## sa "https://www.youtube.com/watch?v=5hMAtAUSjOo" --language nl
## 
## # 2024-07-21 -    15:45 - 334 Trump versus Biden/Harris. Analyse Ab Gietelink
## sa "https://www.youtube.com/watch?v=TTUjJprIdqE" --language nl
## 
## # 2024-07-27 -    12:01 - 335 Hezbollah en Israël bewegen richting ‘totale oorlog’! Analyse Ab Gietelink
## sa "https://www.youtube.com/watch?v=4ddL7eIJu44" --language nl
## 
## # 2024-08-03 -    54:22 - 336 Euthanasiepraktijk faalt. Verstoten Vaders rechteloos. Documaker Elena Lindemans en Ab Gietelink
## sa "https://www.youtube.com/watch?v=wF35_MkgM5Q" --language nl
## 
## # 2024-08-17 -    14:02 - 337 Catalonië verdient een onafhankelijkheidsreferendum. Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=ZSbLYl8iXio" --language nl
## 
## # 2024-08-20 -    21:29 - 338 Nederland in de Eerste Wereldoorlog. Tentoonstellingsteksten en beelden Ab Gietelink
## sa "https://www.youtube.com/watch?v=I3-kuE2P9TM" --language nl
## 
## # 2024-08-25 -  1:13:42 - 339 Alternatief Forum #7.Olympics, VS, Gaza, Nordstream. Kees vd Pijl, Willem Erné, Ab Gietelink
## sa "https://www.youtube.com/watch?v=otXkoKVF0tw" --language nl
## 
## # 2024-08-29 -    14:32 - 340 Wie = Wie?  Pleitbezorgers van Vrede in Oekraine? Onderzoek Ab Gietelink
## sa "https://www.youtube.com/watch?v=csc0NnvrQos" --language nl
## 
## # 2024-09-01 -    11:46 - 341 Arrestatie Telegram eigenaar Pavel Doerov bedreigt Vrijheid van Publicatie. Door Ab Gietelink
## sa "https://www.youtube.com/watch?v=h9llpqddPGo" --language nl
## 
## # 2024-09-04 -    13:51 - 342 Robert Kennedy ‘s steun voor Trump tekent diepe splijting op links. Ab Gietelink
## sa "https://www.youtube.com/watch?v=1GYJmYeAbxk" --language nl
## 
## # 2024-09-08 -    19:39 - 343 Willem van Oranje Deel 1. Tentoonstelling Ab Gietelink
## sa "https://www.youtube.com/watch?v=I7G8IR5L0Ck" --language nl
## 
## # 2024-09-10 -    19:58 - 344 Willem van Oranje Deel 2: 1568-1648 De Geboorte van Nederland. Tentoonstelling Ab Gietelink
## sa "https://www.youtube.com/watch?v=PomPSr_TdN0" --language nl
## 
## # 2024-09-13 -    13:35 - 345 Sahra Wagenknecht. Bondskanselier voor links en rechts? Artikel Ab Gietelink
## sa "https://www.youtube.com/watch?v=BW2aB6Exa7A" --language nl
## 
## # 2024-09-16 -    13:44 - 346 Wie is Kamala Harris? Hoe verschilt ze van Trump? Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=sGSy8yxwDk8" --language nl
## 
## # 2024-09-21 -    16:47 - 347 Geachte Oorlogspropagandisten! Manifest Ab Gietelink
## sa "https://www.youtube.com/watch?v=j2gAh62oaSI" --language nl
## 
## # 2024-09-25 -     7:12 - 348 De Wolf en Roodkapje. Column Ab Gietelink
## sa "https://www.youtube.com/watch?v=LeiZZ1-EJ_s" --language nl
## 
## # 2024-09-27 -  1:08:01 - 349 Alternatief Forum #8. NL Regeerakkoord, Libanon. Kees vd Pijl, Sjoerd de Groot, Ab Gietelink
## sa "https://www.youtube.com/watch?v=vm9GrTEefis" --language nl
## 
## # 2024-09-30 -     8:40 - 350 Zwijgen Westerse politici over Israëlische terreur in Libanon is hypocriet. Opinie Ab Gietelink
## sa "https://www.youtube.com/watch?v=d6zIgyGcIrs" --language nl
## 
## # 2024-10-05 -    54:46 - 351 Hoe kan het zorgsysteem goedkoper? Taiwan (6% BBP) vs. NL(12%). Ab Gietelink met Vincent Everts.
## sa "https://www.youtube.com/watch?v=8ODk9CC0k6c" --language nl
## 
## # 2024-10-11 -  1:18:31 - 352 Alternatief Forum #9 Israel & Midden-Oosten. Kees vd. Pijl, Peter Baars en Ab Gietelink
## sa "https://www.youtube.com/watch?v=7ESaeZVXs9s" --language nl
## 
## # 2024-10-14 -    14:33 - 353 Brief aan Premier Netanyahu. Afzender Ab Gietelink
## sa "https://www.youtube.com/watch?v=vEu7fQKJd78" --language nl
## 
## # 2024-10-17 -     8:56 - 354 Hoe Israëli's zo gemakkelijk met bezetting leven- Speech Gideon Levy.  NL Voorlezer Ab Gietelink
## sa "https://www.youtube.com/watch?v=9QUkZTTWELw" --language nl
## 
## # 2024-10-19 -    12:38 - 355  ''Nederland is een democratie!''   Polygoonparodie 'van Ab Gietelink
## sa "https://www.youtube.com/watch?v=DyFBt0Yx8qI" --language nl
## 
## # 2024-10-23 -    25:14 - 356 ''Rusland bevrijdde Marioepol en bouwde het weer op !''. Ab Gietelink spreekt Nikolay Pilchuk
## sa "https://www.youtube.com/watch?v=q-pTBsbQTWw" --language nl
## 
## # 2024-10-27 -  1:18:04 - 357 Alternatief Forum #10. BRICS. Peter van Stigt, Diedert de Wagt, Kees vd Pijl, Ab Gietelink
## sa "https://www.youtube.com/watch?v=wTm_WXy1a3Y" --language nl
## 
## # 2024-10-31 -    20:37 - 358 Reisdagboek Iran. Herinneringen bij een dreigende oorlog tussen Israël en Iran. Ab Gietelink
## sa "https://www.youtube.com/watch?v=GgEY4EXh47s" --language nl
## 
## # 2024-11-04 -    31:52 - 359 Speech Kennedy Jr. Minister Volksgezondheid onder Trump. Ab Gietelink
## sa "https://www.youtube.com/watch?v=Q0YKU3HTd-E" --language nl
## 
## # 2024-11-08 -    12:23 - 360 President Trump. Wat kan de wereld verwachten? Ab Gietelink
## sa "https://www.youtube.com/watch?v=J3L43lxiG9Y" --language nl
## 
## # 2024-11-10 -  1:10:50 - 361 Alternatief Forum #11. Trump & Amerika. Willem Engel, Kees vd. Pijl, Ab Gietelink
## sa "https://www.youtube.com/watch?v=VmDagA5PUUU" --language nl
## 
## # 2024-11-15 -    13:40 - 362 Nederlandse politiek maakt van voetbalvandalisme en Israelkritiek ‘Antisemitisme’. Ab Gietelink
## sa "https://www.youtube.com/watch?v=K0lntxtReRk" --language nl
## 
## # 2024-11-17 -    55:16 - 363  Alternatief Forum #12 Ajax-Maccabi, Palestina. Stan v Houcke, Max vd Berg, Ab Gietelink
## sa "https://www.youtube.com/watch?v=Sf0v_HBfc-s" --language nl
## 
## # 2024-11-20 -    15:01 - 364 Pleidooi voor een progressieve alternatieve beweging. Ab Gietelink
## sa "https://www.youtube.com/watch?v=tLJy9fd6lxs" --language nl
## 
## # 2024-11-22 -    15:00 - 365 Trump wint. Zelensky draait. Biden escaleert. Poetin waarschuwt. Analyse Ab Gietelink
## sa "https://www.youtube.com/watch?v=49o3OiO7QcE" --language nl
## 
## # 2024-11-24 -  1:06:28 - 366 ''Praat met Soedan, Rusland, Hamas en Iran !'' Ex-Minister/ VN gezant Jan Pronk en Ab Gietelink.
## sa "https://www.youtube.com/watch?v=3w5uAvZkejw" --language nl
## 
## # 2024-11-27 -  1:01:02 - 367 Falend overheidsmanagement: Incompetent of corrupt? Ab Gietelink interviewt Wybren van Haga
## sa "https://www.youtube.com/watch?v=3D39KPV2mvE" --language nl
## 
## # 2024-11-29 -    21:16 - 368 De Regering Trump. Wie=Wie? Welk beleid is te verwachten? Ab Gietelink
## sa "https://www.youtube.com/watch?v=5Vmb1kRg9VU" --language nl
## 
## # 2024-12-02 -  1:07:54 - 369 Alternatief Forum #13. Regering Trump, Oekraïne, Israel. Kees vd Pijl, Peter Baars, Ab Gietelink
## sa "https://www.youtube.com/watch?v=EIheH45obyk" --language nl
## 
## # 2024-12-06 -    59:16 - 370 De strijd voor gezond voedsel. Ab Gietelink en Graanboernalist Marcel van Silfhout
## sa "https://www.youtube.com/watch?v=-A7XBeG3S34" --language nl
## 
## # 2024-12-08 -  1:52:34 - 371 Thierry Baudet #1. Wie is hij?  Wat is zijn programma? Interview Ab Gietelink
## sa "https://www.youtube.com/watch?v=RmYZKoa1nv8" --language nl
## 
## # 2024-12-11 -    46:01 - 372 Hart voor Humor. Jonathan Krispijn, Wouter Meijs, Badr Maghrani. Interview Ab Gietelink.
## sa "https://www.youtube.com/watch?v=vVKyLtVXOoo" --language nl
## 
## # 2024-12-14 -    13:21 - 373 Georgië: Behoud neutraliteit tussen Russische Federatie en Europese Unie ! Ab Gietelink
## sa "https://www.youtube.com/watch?v=JS0M0pmJJKQ" --language nl

# 2024-12-20 -    14:49 - 374 Syrië:  Waarom viel Assad en wat nu?  Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=7P8IwubKK5I" --language nl

# 2024-12-22 -    59:57 - 375 Alt. Forum #14.  Willem Engel was in Georgië. Nikko Norte over Syrië. Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=XEg4c-gQdoo" --language nl

# 2024-12-26 -     4:20 - 376 ''Bereid U voor op oorlog. Haal uw noodpakket in huis!''. Theaterscene Ab Gietelink
sa "https://www.youtube.com/watch?v=kFIYMNpIgXY" --language nl

# 2024-12-28 -  1:31:33 - 377 Uruzgan militair, stierenvechter, piloot en auteur Nikko Norte is te gast bij Ab Gietelink
sa "https://www.youtube.com/watch?v=hz-mZ2uNmAc" --language nl

# 2025-01-03 -    19:28 - 378 Reisdagboek Georgië. Georgische Droom ontworstelt zich aan VS en EU! Analyse Ab Gietelink
sa "https://www.youtube.com/watch?v=BxlXnQ_pI1g" --language nl

# 2025-01-05 -  1:14:05 - 379 Oud SP kamerlid Harry van Bommel over EU, Oost-Europa en Midden-Oosten. Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=QUrSgE06l8A" --language nl

# 2025-01-11 -  1:11:13 - 380 Kritische Joodse stemmen. Ab Gietelink In gesprek met Jaap Hamburger en Mordechai Krispijn
sa "https://www.youtube.com/watch?v=0UipLsD35aM" --language nl

# 2025-01-19 -     9:58 - 381 ''Nederland werkt aan Vrede en Veiligheid !'' Polygoonparodie: Ab Gietelink
sa "https://www.youtube.com/watch?v=lwWCGaYnd7Q" --language nl




