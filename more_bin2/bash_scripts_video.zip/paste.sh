#!/bin/bash

#	if test -f "out/$BASENAME.$LANGUAGE.mp4"; then

# if test -f "mylist.txt"; then
# 	rm mylist.txt
# fi	
# 
# for line in output*.mp4
# do
# 	echo "file '$line'" >> mylist.txt
# done

#ffmpeg -y -i music.mp3 -safe 0 -f concat -i mylist.txt -shortest -c:v libx264 -vf mpdecimate -preset slow output.mp4
#ffmpeg -y -i music.mp3 -safe 0 -f concat -i mylist.txt -shortest -c:v h264_nvenc -pix_fmt yuv420p -b:v 10M -vf mpdecimate -preset slow output.mp4
#~/nvidia/ffmpeg/ffmpeg -y -i music.mp3 -safe 0 -f concat -i mylist.txt -shortest -c:v h264_nvenc -pix_fmt yuv420p -b:v 10M -vf mpdecimate -preset slow output.mp4
#~/nvidia/ffmpeg/ffmpeg -y -i music.mp3 -safe 0 -f concat -i mylist.txt -shortest -c copy output.mp4
#ffmpeg -y -ss 00:30:00 -i music.mp3 -safe 0 -f concat -i mylist.txt -shortest -c copy output.mp4

#rem (for %%i in (output0*.mp4) do @echo file '%%i') > mylist.txt

#rem ffmpeg -y -safe 0 -f concat -i mylist.txt -c copy output_vid.mp4

#rem ffmpeg -y -i output_vid.mp4 -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -b:v 10M -bf:v 3 -preset slow -rc-lookahead 32 -vf mpdecimate -vsync vfr output_dec.mp4

# ffmpeg -y -ss 00:00:00 -i music.mp3 -i output_dec.mp4 -shortest -c copy output.mp4

# ffmpeg -y -ss 00:34:00 -i summer.mp3 -i output.mp4 -shortest -c copy output2.mp4


#-f rawvideo -pix_fmt bgr24 -s %WIDTH%x%HEIGHT% -r %FPS% -i - -vf vflip -c:v h264_nvenc -b:v 10m -pix_fmt yuv420p %NAME%.mp4

#-f rawvideo -pix_fmt bgr24 -s %WIDTH%x%HEIGHT% -r %FPS% -i - -vf vflip -c:v libx264 -preset ultrafast -tune zerolatency -qp 18 -pix_fmt yuv420p %NAME%.mp4

# ffmpeg -y -i music.mp3 -i 2022-03-08_08.55.56.mp4 -shortest -c copy output.mp4

#ffmpeg -i input.mp4 -i image.png -filter_complex "[0:v] [1:v] overlay=25:25:enable='between(t,0,20)'" -pix_fmt yuv420p -c:a copy output.mp4

#ffmpeg -i never_forget.mp4 -i image.png -filter_complex "[0:v] [1:v] overlay=W-w:H-h:enable='between(t,0,20)'" -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -b:v 10M -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy output.mp4

# ffmpeg -i Never_Forget.webp -i overlay2.png -filter_complex "[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black[a];[a][1:v]overlay=W-w:H-h,subtitles=f='never_forget.nl.srt.double':force_style='Fontname=Simply Rounded Bold,FontSize=20,Outline=2'" -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -b:v 10M -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy output.mp4

#ffmpeg -i norbert.webm -i overlay2.png -filter_complex "[0:v] [1:v] overlay=W-w:H-h" -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -b:v 10M -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy output.mp4

#"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=20,Outline=2'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""

#ffmpeg -i DVO.mp4 -ss 00:02:52.4 -t 00:00:22.5 -c:v h264_nvenc dvo_1.mp4
#ffmpeg -i DVO.mp4 -ss 00:03:32.4 -t 00:00:06.9 -c:v h264_nvenc dvo_2.mp4
#ffmpeg -ss 00:05:00.0 -i DVO.mp4 -ss 00:00:38.0 -t 00:02:42.0 -c:v h264_nvenc dvo_3.mp4
# 
# echo "file 'dvo_1.mp4'" > mylist.txt
# echo "file 'dvo_2.mp4'" >> mylist.txt
# echo "file 'dvo_1a.mp4'" >> mylist.txt
# echo "file 'dvo_1a.mp4'" >> mylist.txt
#  
# ffmpeg -y -safe 0 -f concat -i mylist.txt -c:v h264_nvenc dvo_1_2.mp4
# 
# ffmpeg -y -i dvo_1_2.mp4 -i penetrate.png -filter_complex "[0:v][1:v] overlay=W-w:H-h" -c:v h264_nvenc -c:a copy dvo_1_2_overlay.mp4
# 
# ffmpeg -y -i DVO.mp4 -ss 00:02:52.4 -t 00:00:02.3 -c:v h264_nvenc dvo_1a.mp4
# 
# echo "file 'dvo_1a.mp4'" > mylist.txt
# echo "file 'dvo_1a.mp4'" >> mylist.txt
# echo "file 'dvo_1a.mp4'" >> mylist.txt
# echo "file 'dvo_1a.mp4'" >> mylist.txt
# echo "file 'dvo_1_2_overlay.mp4'" >> mylist.txt
# 
# ffmpeg -y -safe 0 -f concat -i mylist.txt -c:v h264_nvenc dvo_tot.mp4
# 
# ffmpeg -y -i dvo_tot.mp4 -i einstein.png -filter_complex "[0:v][1:v] overlay=W-w:H-h:enable='between(t,12,15)" -c:v h264_nvenc -c:a copy dvo_tot2.mp4

# ffmpeg -ss 00:05:00.0 -i DVO.mp4 -ss 00:00:38.7 -t 00:02:42.0 -c:v h264_nvenc dvo_3.mp4

# ffmpeg -y -i dvo_3.mp4 -i ARROW.png -filter_complex "[0:v][1:v] overlay=W-w:H-h:enable='between(t,0.5,16)" -c:v h264_nvenc -c:a copy dvo_tot3.mp4

# ffmpeg -y -i dvo_tot3.mp4 -i einstein2.png -filter_complex "[0:v][1:v] overlay=W-w:H-h:enable='between(t,83,89)" -c:v h264_nvenc -c:a copy dvo_tot4.mp4

# echo "file 'dvo_tot2.mp4'" > mylist.txt
# echo "file 'dvo_tot4.mp4'" >> mylist.txt
# 
# ffmpeg -y -safe 0 -f concat -i mylist.txt -c:v h264_nvenc dvo_tot_tot.mp4 

#ffmpeg -y -safe 0 -f concat -i mylist.txt -c:v h264_nvenc -b:v 1300k dvo_tot_tot_small.mp4 

# ffmpeg -i simplescreenrecorder-2022-04-15_15.06.17.mkv -t 00:38:25 -c copy ongehoord.mkv

# ffmpeg -i Who_Is_Bill_Gates_Full_Documentary_2020-[TY-vLrz9XCc].mp4 gates.wav

# ffmpeg -y -i ww3.mp4 -vf "transpose=2" -c:v h264_nvenc -c:a copy ww3_rot.mp4

# ffmpeg -i in.mov -vf "transpose=1" out.mov

#ffmpeg -y -i output.mkv -c:v h264_nvenc -filter_complex "overlay=1:1" -c:a copy output_short.mp4

ffmpeg -i 'Facebook video #5355043731224857 [5355043731224857].mp4' -c:v libx264 -crf 20 -preset slow -vf format=yuv420p -c:a aac -movflags +faststart output2.mp4
ffmpeg -i 'Gerard Wensink [5351619641567266].mp4' -c:v libx264 -crf 20 -preset slow -vf format=yuv420p -c:a aac -movflags +faststart output3.mp4
