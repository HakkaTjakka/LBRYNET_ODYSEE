fix_english_to_odysee.sh ".English.mp4" "" 
