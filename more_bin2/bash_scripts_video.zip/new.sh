#!/bin/bash
download_new.sh "$*"
read -r FILENAME < out.txt
out/twitter.sh "$FILENAME"