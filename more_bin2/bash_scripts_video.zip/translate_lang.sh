#!/bin/bash
export LC_NUMERIC="en_US.UTF-8"


FILENAME=$3
FROM=$1
TO=$2
BASENAME="${FILENAME%.*}"

LANGUAGE="${FILENAME%.*}"
LANGUAGE="${LANGUAGE%.*}"
BASENAME2="${LANGUAGE%.*}"
LANGUAGE="${LANGUAGE##*.}"
echo $LANGUAGE

echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"
if test -f "$BASENAME2.$TO.srt.double"; then
        rm "$BASENAME2.$TO.srt.double"
fi

while IFS='' read -r line || [[ -n "$line" ]]; do
        if [[ "$line" != "" ]] ; then
                if [[ ! $line =~ [0-9] ]] ; then
                        echo ORIGINAL___  : $line
                        VAR=$(echo "$line" | trans -brief $FROM:$TO)
                        echo TRANSLATED_  : $VAR
                else
                        VAR=$line
                        echo NO TRANSLATE: $line
                fi
        else
                VAR=$line
                echo NO TRANSLATE: $line
        fi
#        echo original  $line
#        echo translate $VAR
        echo $VAR >> "$BASENAME2.$TO.srt.double"

done < "$FILENAME"

#trans [OPTIONS] [SOURCES]:[TARGETS] [TEXT]...
