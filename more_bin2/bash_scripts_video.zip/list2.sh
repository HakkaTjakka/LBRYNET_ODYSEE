echo " \\" > add_fix.txt
echo '	--tags="Viruswaarheid" \' >> add_fix.txt
echo '	--tags="Weekoverzicht"' >> add_fix.txt
sa "https://rumble.com/v5l49kq-weekoverzicht-44-2024-willem-engel-en-jeroen-pols.html" --language nl

# echo " \\" > add_fix.txt
# echo '	--tags="Forum voor Democratie" \' >> add_fix.txt
# echo '	--tags="FvD" \' >> add_fix.txt
# echo '	--tags="Forum Inside"' >> add_fix.txt

# sa "https://www.youtube.com/watch?v=DM9JrtIpgUs" --language nl # 2024-10-21
# sa "https://www.youtube.com/watch?v=RluJ8HJmo5o" --language nl # 2024-10-14
# sa "https://www.youtube.com/watch?v=NQxzxAKhJ78" --language nl # 2024-10-07
# sa "https://www.youtube.com/watch?v=cSQDBOyiT4A" --language nl # 2024-09-30
# sa "https://www.youtube.com/watch?v=fpUHp1SP3uw" --language nl # 2024-07-01
# sa "https://www.youtube.com/watch?v=ZS8AKiS43Mo" --language nl # 2024-06-24
# sa "https://www.youtube.com/watch?v=akyUidDmwVs" --language nl # 2024-05-20
# sa "https://www.youtube.com/watch?v=BfurvWTpC6E" --language nl # 2024-05-13
# sa "https://www.youtube.com/watch?v=IqklOuFkFew" --language nl # 2024-05-06
# sa "https://www.youtube.com/watch?v=Iwft3ABkTIM" --language nl # 2024-04-29

# sa "https://www.youtube.com/watch?v=zgAVOzREW0Y" --language nl # 2024-04-22
# sa "https://www.youtube.com/watch?v=WuvhPVULadc" --language nl # 2024-04-01
# sa "https://www.youtube.com/watch?v=kiQQKQf4LTc" --language nl # 2024-03-25
# sa "https://www.youtube.com/watch?v=PwpZXiPjX7k" --language nl # 2024-03-18
# sa "https://www.youtube.com/watch?v=MAoCHGqFjHo" --language nl # 2024-03-11
# sa "https://www.youtube.com/watch?v=HYgeJJIShrM" --language nl # 2024-03-04
# sa "https://www.youtube.com/watch?v=5i0oPpsyhcs" --language nl # 2024-02-26
# sa "https://www.youtube.com/watch?v=g8wTIEmgqyo" --language nl # 2024-02-19
# sa "https://www.youtube.com/watch?v=8OtyQX3Rig4" --language nl # 2024-02-12
# sa "https://www.youtube.com/watch?v=ZLQpYqnJBqg" --language nl # 2024-02-05
# sa "https://www.youtube.com/watch?v=PoRmtRz2IE8" --language nl # 2024-01-29
# sa "https://www.youtube.com/watch?v=84UpL-p0eMU" --language nl # 2024-01-22
# sa "https://www.youtube.com/watch?v=8UvSqc0HWRE" --language nl # 2024-01-09
# sa "https://www.youtube.com/watch?v=bWG5PiFgLxw" --language nl # 2024-01-08
# sa "https://www.youtube.com/watch?v=spsTkLFniKg" --language nl # 2023-12-25
# sa "https://www.youtube.com/watch?v=oDS9ZFlSeP8" --language nl # 2023-12-18
# sa "https://www.youtube.com/watch?v=6ho88zTlYGE" --language nl # 2023-12-11
# sa "https://www.youtube.com/watch?v=TP11ZMaS2Yw" --language nl # 2023-12-04
# sa "https://www.youtube.com/watch?v=udIyY-GRFKs" --language nl # 2023-11-14

#verrot? sa "https://www.youtube.com/watch?v=ZJ1ox-zDcyc" --language nl # 2023-11-06
# sa "https://www.youtube.com/watch?v=0WUDGXtM3us" --language nl # 2023-10-23
# sa "https://www.youtube.com/watch?v=eVHTrFPk980" --language nl # 2023-10-16
# sa "https://www.youtube.com/watch?v=5htwCsSsFGk" --language nl # 2023-10-09
# sa "https://www.youtube.com/watch?v=r3mV4G8Y1hM" --language nl # 2023-10-02
# sa "https://www.youtube.com/live/jSjlDgOHrY8"  --language nl # new
# 
# sa "https://www.youtube.com/watch?v=sjospzXewSw" --language nl # 2023-09-25
# sa "https://www.youtube.com/watch?v=YaDvTiLXx0w" --language nl # 2023-09-18
# sa "https://www.youtube.com/watch?v=ZpOwexWl2XQ" --language nl # 2023-09-11
# sa "https://www.youtube.com/watch?v=d30debO7N0I" --language nl # 2023-09-04
# sa "https://www.youtube.com/watch?v=_EU0usVBtRQ" --language nl # 2023-07-03
# sa "https://www.youtube.com/watch?v=4xnkjhW6LhY" --language nl # 2023-06-26
# sa "https://www.youtube.com/watch?v=4qcLm3sn_DE" --language nl # 2023-06-19
# sa "https://www.youtube.com/watch?v=EAl_d5K4jiU" --language nl # 2023-06-12

# sa "https://www.youtube.com/watch?v=IDSkQO3sud0" --language nl # 2023-06-05
# 
# echo " \\" > add_fix.txt
# echo '	--tags="Mike Benz" \' >> add_fix.txt
# echo '	--tags="The History of the Intelligence State"' >> add_fix.txt
# sa "https://rumble.com/v5g4s6i-the-history-of-the-intelligence-state-mike-benz-lecture-at-hillsdale-colleg.html" --language en
# 
# echo " \\" > add_fix.txt
# echo '	--tags="Forum voor Democratie" \' >> add_fix.txt
# echo '	--tags="FvD" \' >> add_fix.txt
# echo '	--tags="Forum Inside"' >> add_fix.txt
# sa "https://www.youtube.com/watch?v=JPry0mMednQ" --language nl # 2023-05-29
# sa "https://www.youtube.com/watch?v=6DE6BXNndIw" --language nl # 2023-05-22
# 
# echo " \\" > add_fix.txt
# echo '	--tags="jews" \' >> add_fix.txt
# echo '	--tags="Sacrifices" \' >> add_fix.txt
# echo '	--tags="jewish Sacrifices"' >> add_fix.txt
# sa "https://x.com/Wordsarewordz/status/1811950915559006499"  --language en
# 
# echo " \\" > add_fix.txt
# echo '	--tags="doomsayer press" \' >> add_fix.txt
# echo '	--tags="the jewish onslaught on the goyim"' >> add_fix.txt
# sa "https://x.com/KimDotcom/status/1851713063961207265/video/1" --language en
# 
# exit

# echo " \\" > add_fix.txt
# echo '	--tags="Forum voor Democratie" \' >> add_fix.txt
# echo '	--tags="FvD" \' >> add_fix.txt
# echo '	--tags="Forum Inside"' >> add_fix.txt

# sa "https://www.youtube.com/watch?v=_dOSAPnTSOc" --language nl # 2023-05-01
# sa "https://www.youtube.com/watch?v=bKLBCztMV1s" --language nl # 2023-04-24
# sa "https://www.youtube.com/watch?v=sN8iWjGLvU4" --language nl # 2023-04-17
# sa "https://www.youtube.com/watch?v=oO9u3R8wA9s" --language nl # 2023-04-11
# sa "https://www.youtube.com/watch?v=_4ZFH0SjDG0" --language nl # 2023-03-20
# sa "https://www.youtube.com/watch?v=iiHDmch65lU" --language nl # 2023-03-13

# sa "https://www.youtube.com/watch?v=URzhkJ9kuK8" --language nl # 2023-02-27
# sa "https://www.youtube.com/watch?v=l0CftuQE7LM" --language nl # 2023-02-20
# sa "https://www.youtube.com/watch?v=2ebbBqhA8ew" --language nl # 2023-02-13
# sa "https://www.youtube.com/watch?v=KfEKv1njJgQ" --language nl # 2023-02-06
# sa "https://www.youtube.com/watch?v=Ekvfm5Q3gJ0" --language nl # 2023-01-30
# sa "https://www.youtube.com/watch?v=cBQAu20ite4" --language nl # 2023-01-23


# echo " \\" > add_fix.txt
# echo '	--tags="De Nieuwe Wereld"' >> add_fix.txt
# sa "https://www.youtube.com/watch?v=X665hvqvzwQ" --language nl


echo " \\" > add_fix.txt
echo '	--tags="Forum voor Democratie" \' >> add_fix.txt
echo '	--tags="FvD" \' >> add_fix.txt
echo '	--tags="Forum Inside"' >> add_fix.txt

# sa "https://www.youtube.com/watch?v=PxBrsvEb-ys" --language nl # 2023-01-16
# sa "https://www.youtube.com/watch?v=-tVrIBIKPUQ" --language nl # 2023-01-10
# sa "https://www.youtube.com/watch?v=76HVeex5aDk" --language nl # 2023-01-09

sa "https://www.youtube.com/watch?v=N2mvJsXRriU" --language nl # 2023-01-03
sa "https://www.youtube.com/watch?v=zun1rEUq1V8" --language nl # 2022-12-26
sa "https://www.youtube.com/watch?v=CKojGT54t5A" --language nl # 2022-12-19
sa "https://www.youtube.com/watch?v=rVHWcu-kmEQ" --language nl # 2022-12-05
sa "https://www.youtube.com/watch?v=tUCEgqCD8OQ" --language nl # 2022-11-28
sa "https://www.youtube.com/watch?v=yBJkaWwk5z0" --language nl # 2022-11-21
sa "https://www.youtube.com/watch?v=xSRietD4P7s" --language nl # 2022-11-14
sa "https://www.youtube.com/watch?v=PG3iIu3GEYk" --language nl # 2022-11-07
sa "https://www.youtube.com/watch?v=UVKe2OJacU0" --language nl # 2022-10-31
sa "https://www.youtube.com/watch?v=LulA1JBAr-s" --language nl # 2022-10-24
sa "https://www.youtube.com/watch?v=k7fSqgRNXfw" --language nl # 2022-10-18
sa "https://www.youtube.com/watch?v=z2ZlBa1DcVI" --language nl # 2022-10-12
sa "https://www.youtube.com/watch?v=X0JN6Ut42zY" --language nl # 2022-10-03
exit



# echo " \\" > add_fix.txt
# echo "	--tags=\"Libya's Great Man-Made River Project\"" >> add_fix.txt
# sa "https://www.youtube.com/watch?v=DSzVrlNsaXM" --language en
# sa "https://www.youtube.com/watch?v=DSzVrlNsaXM" --language en
# sa "https://www.youtube.com/watch?v=jjOW6kLEckg" --language en
# sa "https://www.youtube.com/watch?v=v8gRcka738g" --language en
# sa "https://www.youtube.com/watch?v=Wh7JdYaGkEI" --language en
# sa "https://www.youtube.com/watch?v=kM5i72tyFek" --language en
# 
# echo " \\" > add_fix.txt
# echo '	--tags="Libya"' >> add_fix.txt
# sa "https://www.youtube.com/watch?v=tRI01QfNQDY" --language en
# 
# echo " \\" > add_fix.txt
# echo '	--tags="CIA Declassified" \' >> add_fix.txt
# echo '	--tags="Libya" \' >> add_fix.txt
# echo '	--tags="Gaddafi"' >> add_fix.txt
# sa "https://www.youtube.com/watch?v=UAvIxICQxNY" --language en
# 
# echo " \\" > add_fix.txt
# echo '	--tags="Libya"' >> add_fix.txt
# sa "https://www.youtube.com/watch?v=tRI01QfNQDY" --language en
# 
# list.sh

# echo " \\" > add_fix.txt
# echo '	--tags="Forum voor Democratie" \' >> add_fix.txt
# echo '	--tags="FvD"' >> add_fix.txt
# sa "https://www.youtube.com/watch?v=DM9JrtIpgUs" --language nl
# exit

# echo " \\" > add_fix.txt
# echo '	--tags="Jeffrey Sachs"' >> add_fix.txt
# sa "https://www.youtube.com/watch?v=KZbO62SSI9s" --language en # - date: 2024-10-19 - title: Jeffrey Sachs Interviews - Confidence or Delusion?
# sa "https://www.youtube.com/watch?v=sxI7CQ3ICsc" --language en # - date: 2024-10-18 - title: Jeffrey Sachs Interviews - Who’s Really Stirring Up Trouble?
# sa "https://www.youtube.com/watch?v=L81GdwEPw7o" --language en # - date: 2024-10-17 - title: Jeffrey Sachs Interviews - Predictions and Analysis
# sa "https://www.youtube.com/watch?v=MbcHD9TBUaI" --language en # - date: 2024-10-16 - title: Jeffrey Sachs Interviews - Factors Breaking Peace Talks
# sa "https://www.youtube.com/watch?v=azDdp6KpNq0" --language en # - date: 2024-10-10 - title: Jeffrey Sachs Interviews - 4 Major Unresolved Issue
# sa "https://www.youtube.com/watch?v=S6FNcJc_hJM" --language en # - date: 2024-10-06 - title: Jeffrey Sachs Interviews - What You Need to Know!
# sa "https://www.youtube.com/watch?v=tDIN0R7mYNM" --language en # - date: 2024-09-29 - title: Jeffrey Sachs Interviews - Trust and Diplomacy
# sa "https://www.youtube.com/watch?v=2lsLF8A8KgY" --language en # - date: 2024-09-28 - title: Jeffrey Sachs Interviews - Facing Reality
# sa "https://www.youtube.com/watch?v=62d7UDipC54" --language en # - date: 2024-09-22 - title: Jeffrey Sachs Interviews - Here’s Why They Won’t Lose!
# sa "https://www.youtube.com/watch?v=l5gIRkcF-Ps" --language en # - date: 2024-09-21 - title: Jeffrey Sachs Interviews - The Goal is to Move Forward
# sa "https://www.youtube.com/watch?v=DGFWJ2ubT1Y" --language en # - date: 2024-09-18 - title: Jeffrey Sachs Interviews - The Thing They call Victory.
# sa "https://www.youtube.com/watch?v=RYJULo7YONY" --language en # - date: 2024-09-12 - title: Jeffrey Sachs Interviews - Will They Restore All Their Land?

# sa "https://www.youtube.com/watch?v=loOa6ltpvdw" --language en # - date: 2024-09-09 - title: Jeffrey Sachs Interviews - How a Tight Alliance Can Change the Game
# sa "https://www.youtube.com/watch?v=RrIYqBljSEg" --language en # - date: 2024-09-05 - title: Jeffrey Sachs Interviews - Will Automation and AI Revolutionize the Workforce?
# sa "https://www.youtube.com/watch?v=26xS_qVRFLI" --language en # - date: 2024-08-30 - title: Jeffrey Sachs Interviews - A Tactical Move That Backfired
# sa "https://www.youtube.com/watch?v=k0BQcYBgJaM" --language en # - date: 2024-08-24 - title: Jeffrey Sachs Interviews - A Coalition War Is Drawing Near
# sa "https://www.youtube.com/watch?v=35ONmTp7D94" --language en # - date: 2024-08-21 - title: Jeffrey Sachs Interviews - As Superpowers Rise, Peace Grows Fragile
# sa "https://www.youtube.com/watch?v=sXA0zqJlpuU" --language en # - date: 2024-08-19 - title: Jeffrey Sachs Interviews - a Self-fulfilling Prophecy of Conflict.
# sa "https://www.youtube.com/watch?v=lDVc8e8V_aU" --language en # - date: 2024-08-14 - title: Jeffrey Sachs Interviews - Are We Repeating History?
# sa "https://www.youtube.com/watch?v=DFFQipQOlpw" --language en # - date: 2024-08-13 - title: Jeffrey Sachs Interviews - The Escalating Wave of Instability
# sa "https://www.youtube.com/watch?v=7JxHCk2rsNY" --language en # - date: 2024-08-10 - title: Jeffrey Sachs Interviews - How the World Watches in Silence
# sa "https://www.youtube.com/watch?v=SyAGzU4ZRDs" --language en # - date: 2024-08-09 - title: Jeffrey Sachs Interviews - What is About to Happen is Difficult to Prevent
# sa "https://www.youtube.com/watch?v=DGFJt8Ho6O4" --language en # - date: 2024-08-03 - title: Jeffrey Sachs Interviews - A Stark Reality
# sa "https://www.youtube.com/watch?v=K4Luf50mtWQ" --language en # - date: 2024-07-28 - title: Jeffrey Sachs Interviews - Global Savings of $100 trillion/Year
# sa "https://www.youtube.com/watch?v=bp8AbOSxEtw" --language en # - date: 2024-07-27 - title: Jeffrey Sachs Interviews - Superpower or Second Rate?
# sa "https://www.youtube.com/watch?v=bFkGj3HQMcc" --language en # - date: 2024-07-26 - title: Jeffrey Sachs on Ukraine Future - What's Next?
# sa "https://www.youtube.com/watch?v=TeAqr65PJoQ" --language en # - date: 2024-07-13 - title: Jeffrey Sachs Interview - What Lies Ahead?
# sa "https://www.youtube.com/watch?v=RINPYk5MZIc" --language en # - date: 2024-07-12 - title: Sustainable Development, Economic Growth, and Environmental Crisis - Jeffrey Sachs
# sa "https://www.youtube.com/watch?v=ExotjiSKHsw" --language en # - date: 2024-07-06 - title: Jeffrey Sachs Interview - There is no Longer Peace
# sa "https://www.youtube.com/watch?v=YRk4oMwKYao" --language en # - date: 2024-07-04 - title: Jeffrey Sachs Interview - Legacy of Ashes
# sa "https://www.youtube.com/watch?v=FJcVLJDAFHw" --language en # - date: 2024-07-03 - title: Jeffrey Sachs Interview - The Da.nger is being Covered up.
# sa "https://www.youtube.com/watch?v=jaU2BnCTTQg" --language en # - date: 2024-06-29 - title: Jeffrey Sachs Interview - Escalation-triggering Move
# sa "https://www.youtube.com/watch?v=Lvv0uau69Fg" --language en # - date: 2024-06-28 - title: Jeffrey Sachs Interview - An in-depth Analysis
# sa "https://www.youtube.com/watch?v=w1VlDfk06TY" --language en # - date: 2024-06-25 - title: Jeffrey Sachs Interview - Illegal Expansion
# sa "https://www.youtube.com/watch?v=dknDqcmQkKM" --language en # - date: 2024-06-24 - title: Jeffrey Sachs Interview - Rejection or Negotiation?
# sa "https://www.youtube.com/watch?v=zvNz6ryaG_4" --language en # - date: 2024-06-21 - title: Jeffrey Sachs Interview - Defensive Nature
# sa "https://www.youtube.com/watch?v=D7UflvMEx-g" --language en # - date: 2024-06-17 - title: Jeffrey Sachs Interview - This Changes Everything You Know
# sa "https://www.youtube.com/watch?v=YZenfo9qhY0" --language en # - date: 2024-06-15 - title: Jeffrey Sachs Interview - Addressing Worldwide Challenges
# sa "https://www.youtube.com/watch?v=53m04yUPf0c" --language en # - date: 2024-06-13 - title: Jeffrey Sachs Interview - Diplomatic Path Leads to Peace
# sa "https://www.youtube.com/watch?v=WcaaX_BKUIw" --language en # - date: 2024-06-12 - title: Jeffrey Sachs Interview - Strategic Threat
# sa "https://www.youtube.com/watch?v=2WKmt3Tx27w" --language en # - date: 2024-06-11 - title: Jeffrey Sachs Interview - Global Tensions Rise
# sa "https://www.youtube.com/watch?v=GtDGeywTpxM" --language en # - date: 2024-06-08 - title: Jeffrey Sachs Interview - When Will It Stop?
# sa "https://www.youtube.com/watch?v=lbzgOwsjEmc" --language en # - date: 2024-06-07 - title: Jeffrey Sachs Interview - A Story Every Person Should Know
# sa "https://www.youtube.com/watch?v=Q2Cnyxc1poY" --language en # - date: 2024-06-06 - title: Jeffrey Sachs Interview - The Rising Tensions
# sa "https://www.youtube.com/watch?v=9foXZAIjapI" --language en # - date: 2024-06-04 - title: Jeffrey Sachs Interview - Weakness or Strategic Silence?
# sa "https://www.youtube.com/watch?v=jdxROxFo0XI" --language en # - date: 2024-05-31 - title: Jeffrey Sachs Interview - Global Warming Accelerating
# sa "https://www.youtube.com/watch?v=938hQ35GHvk" --language en # - date: 2024-05-30 - title: Jeffrey Sachs Interview - A Comparative Study
# sa "https://www.youtube.com/watch?v=hCoV12x9wa8" --language en # - date: 2024-05-28 - title: Jeffrey Sachs Interview - A Historical Analysis
# sa "https://www.youtube.com/watch?v=gaUbsFWf9fI" --language en # - date: 2024-05-27 - title: Jeffrey Sachs Interview - Explain What is About to Happen
# sa "https://www.youtube.com/watch?v=hE2TD5XIf_w" --language en # - date: 2024-05-25 - title: Jeffrey Sachs Interview - Institutional Changes
# sa "https://www.youtube.com/watch?v=s4xCc6pTwAk" --language en # - date: 2024-05-23 - title: Jeffrey Sachs Interview - An Act of Evasion
# sa "https://www.youtube.com/watch?v=ct7KVp8Sx_A" --language en # - date: 2024-05-21 - title: Jeffrey Sachs Interview - We Can't Have Negotiations
# sa "https://www.youtube.com/watch?v=uJlTxMGRXE0" --language en # - date: 2024-05-20 - title: Jeffrey Sachs Interview - What Could Happen Next?
# sa "https://www.youtube.com/watch?v=l9LT8RRO8Ug" --language en # - date: 2024-05-18 - title: Jeffrey Sachs Interview - The Challenges Faced
# sa "https://www.youtube.com/watch?v=IVRqv-9mXPc" --language en # - date: 2024-05-16 - title: Jeffrey Sachs Interview - Technology Transformation & Sustainable Development.
# sa "https://www.youtube.com/watch?v=xUuUCGtUcNw" --language en # - date: 2024-05-12 - title: Jeffrey Sachs Interview - What Does It Mean?

# sa "https://www.youtube.com/watch?v=q8iCsZDtjPY" --language en # - date: 2024-05-08 - title: Jeffrey Sachs Interview - Fear of Losing Power
# sa "https://www.youtube.com/watch?v=nSJZ6GBED3k" --language en # - date: 2024-05-07 - title: Jeffrey Sachs Interview - Divide and Conquer Game
# sa "https://www.youtube.com/watch?v=MMWbGZL-Mww" --language en # - date: 2024-05-05 - title: Jeffrey Sachs Interview - The Inexplicable Nature
# sa "https://www.youtube.com/watch?v=aP0M0EaR9eo" --language en # - date: 2024-05-04 - title: Jeffrey Sachs Interview - The Urgent Need for Peace
# sa "https://www.youtube.com/watch?v=Okb0LKO-lq8" --language en # - date: 2024-05-03 - title: Jeffrey Sachs Interview - Global Economic Issues
# sa "https://www.youtube.com/watch?v=62HsBJ_kydM" --language en # - date: 2024-05-02 - title: Jeffrey Sachs Interview - Planning for a Unipolar World
# sa "https://www.youtube.com/watch?v=FrNliCv6Gq4" --language en # - date: 2024-04-30 - title: Jeffrey Sachs Interview - An in Depth Analysis
# sa "https://www.youtube.com/watch?v=q1Y4W-xaX9I" --language en # - date: 2024-04-22 - title: Jeffrey Sachs Interview - Need Some Restraint
# sa "https://www.youtube.com/watch?v=m95b03CF79g" --language en # - date: 2024-04-18 - title: Jeffrey Sachs Interview - Threaten the Position of a Great Power
# sa "https://www.youtube.com/watch?v=0p47Pz5Meis" --language en # - date: 2024-04-17 - title: Jeffrey Sachs Interview - A View from an Advisor
# sa "https://www.youtube.com/watch?v=HUrI4eFfdY4" --language en # - date: 2024-04-13 - title: Jeffrey Sachs Interview - Power-Sharing
# sa "https://www.youtube.com/watch?v=0ge8y9ZMKjk" --language en # - date: 2024-04-10 - title: Jeffrey Sachs Interview - A Critical Analysis
# sa "https://www.youtube.com/watch?v=hdHO9Vcz-Uw" --language en # - date: 2024-04-08 - title: Jeffrey Sachs Interview - Intelligence and Covert Operations
# sa "https://www.youtube.com/watch?v=0RqmOJearDc" --language en # - date: 2024-04-06 - title: Jeffrey Sachs Interview - a Wider War
# sa "https://www.youtube.com/watch?v=Ai47q0xpDj4" --language en # - date: 2024-04-05 - title: Jeffrey Sachs Interview - A Near Catas.Trophe
# sa "https://www.youtube.com/watch?v=Cv6PSW5XsBo" --language en # - date: 2024-04-03 - title: Jeffrey Sachs Interview - An Analysis with a Critical Perspective.
# sa "https://www.youtube.com/watch?v=bOpU6fDCHEg" --language en # - date: 2024-03-27 - title: Jeffrey Sachs Interview - Time for Action
# sa "https://www.youtube.com/watch?v=i1PUgA5yi2w" --language en # - date: 2024-03-24 - title: Jeffrey Sachs Interview - A Strategic Analysis
# sa "https://www.youtube.com/watch?v=LMCMhBP0mn4" --language en # - date: 2024-03-23 - title: Jeffrey Sachs Interview - Africa Will be world's Fastest-Growing Region
# sa "https://www.youtube.com/watch?v=z5QXb3fU0h4" --language en # - date: 2024-03-22 - title: Jeffrey Sachs Interview - A Fundamental Difference
# sa "https://www.youtube.com/watch?v=ZSj8d3Tk0cM" --language en # - date: 2024-03-21 - title: Jeffrey Sachs Interview - Year of Instability.
# sa "https://www.youtube.com/watch?v=Vqo013B1_js" --language en # - date: 2024-03-18 - title: Jeffrey Sachs Interview - Expert Analysis
# sa "https://www.youtube.com/watch?v=ZPDkLedmMAQ" --language en # - date: 2024-03-17 - title: Jeffrey Sachs Interview - A Series of Missteps and Consequences
# sa "https://www.youtube.com/watch?v=Nz9AGf8MX0M" --language en # - date: 2024-03-15 - title: Jeffrey Sachs Interview - The Cold War Continues
# sa "https://www.youtube.com/watch?v=zCm4wnIGRgI" --language en # - date: 2024-03-13 - title: Jeffrey Sachs Interview - A Comprehensive Analysis
# sa "https://www.youtube.com/watch?v=ia2Xn8Dy0Sk" --language en # - date: 2024-03-12 - title: Jeffrey Sachs Interview - Geopolitics and Military Operation
# sa "https://www.youtube.com/watch?v=T8e8BwagnKg" --language en # - date: 2024-03-11 - title: Jeffrey Sachs Interview - Unlocking the Potential
# sa "https://www.youtube.com/watch?v=PwFfuIfoOKw" --language en # - date: 2024-03-09 - title: Jeffrey Sachs Interview - Insights and Impact
# sa "https://www.youtube.com/watch?v=NU2kyZO5NQU" --language en # - date: 2024-03-07 - title: Jeffrey Sachs Interview - Escalation without Limits
# sa "https://www.youtube.com/watch?v=m5XV72rtvt4" --language en # - date: 2024-03-01 - title: Jeffrey Sachs Interview - A Crisis
# sa "https://www.youtube.com/watch?v=-lthfq2vAJ0" --language en # - date: 2024-02-28 - title: Jeffrey Sachs Interview - Blame Game and Its Consequences
# sa "https://www.youtube.com/watch?v=m-HOXsTFTIk" --language en # - date: 2024-02-25 - title: Jeffrey Sachs Interview - Ambition Without Strategy
# sa "https://www.youtube.com/watch?v=wsTaQdYahjU" --language en # - date: 2024-02-24 - title: Jeffrey Sachs Interview - A Tale from Wall Street
# sa "https://www.youtube.com/watch?v=41KRKP9HY1A" --language en # - date: 2024-02-22 - title: Jeffrey Sachs Interview - A Developing World Perspective
# sa "https://www.youtube.com/watch?v=Q6pbCiYmwaQ" --language en # - date: 2024-02-21 - title: Jeffrey Sachs Interview - Potential Challenges
# sa "https://www.youtube.com/watch?v=SAAZLrMXszk" --language en # - date: 2024-02-20 - title: Jeffrey Sachs Interview - a Big Military Power
# sa "https://www.youtube.com/watch?v=nC7MSP82mn8" --language en # - date: 2024-02-17 - title: Jeffrey Sachs Interview - Trigger Strategies
# sa "https://www.youtube.com/watch?v=IsZVj-pXhK0" --language en # - date: 2024-02-16 - title: Jeffrey Sachs Interview - Geopolitics, Multipolarity
# sa "https://www.youtube.com/watch?v=eh9le4XI6VE" --language en # - date: 2024-02-15 - title: Jeffrey Sachs Interview - An Important Analysis
# sa "https://www.youtube.com/watch?v=v2k47cH5IiE" --language en # - date: 2024-02-07 - title: Jeffrey Sachs Interview - Resolve Modern Global Conflicts.
# sa "https://www.youtube.com/watch?v=tmr5ry9Y3Ns" --language en # - date: 2024-01-31 - title: Jeffrey Sachs Interview - A Global Instability
# sa "https://www.youtube.com/watch?v=AP1vJ-56uyo" --language en # - date: 2024-01-27 - title: Jeffrey Sachs Interview - An Important Analysis
# sa "https://www.youtube.com/watch?v=KLOMAi4YOhk" --language en # - date: 2024-01-25 - title: Jeffrey Sachs Interview - Unveiling the Silence
# sa "https://www.youtube.com/watch?v=U_ySUtEv6wQ" --language en # - date: 2024-01-23 - title: Jeffrey Sachs Interview - Challenges and Opportunities
# sa "https://www.youtube.com/watch?v=As2o8euO7Po" --language en # - date: 2024-01-20 - title: Jeffrey Sachs Interview - A Responsible Perspective
# sa "https://www.youtube.com/watch?v=2vgjICAEbkY" --language en # - date: 2024-01-18 - title: Jeffrey Sachs Interview - The Unspoken Crisis
# sa "https://www.youtube.com/watch?v=pibloprbsfM" --language en # - date: 2024-01-14 - title: Jeffrey Sachs Interview - An in-depth Analysis
# sa "https://www.youtube.com/watch?v=pmWHgaNP9N4" --language en # - date: 2024-01-12 - title: Jeffrey Sachs Interview - Truth in Crisis
# sa "https://www.youtube.com/watch?v=mSc_JsHFMBA" --language en # - date: 2024-01-10 - title: Jeffrey Sachs Interview - The Unseen Gambit
# sa "https://www.youtube.com/watch?v=oskYyHl5sWE" --language en # - date: 2024-01-08 - title: Jeffrey Sachs Interview - Exploring Possible Outcomes
# sa "https://www.youtube.com/watch?v=Ub3pm86aV_c" --language en # - date: 2024-01-07 - title: Jeffrey Sachs Interview - I Call it a Military Adventure.
# sa "https://www.youtube.com/watch?v=lEV5--ssWds" --language en # - date: 2024-01-06 - title: Jeffrey Sachs Interview - A Powerful Alliance
# sa "https://www.youtube.com/watch?v=Jo57bJuylRc" --language en # - date: 2024-01-05 - title: Jeffrey Sachs Interview - A Comprehensive Plan
# sa "https://www.youtube.com/watch?v=5HQleP3fbfU" --language en # - date: 2023-12-27 - title: Jeffrey Sachs Interview - Predictable Failure
# sa "https://www.youtube.com/watch?v=0EH2tSxiIaU" --language en # - date: 2023-12-25 - title: Jeffrey Sachs Interview - Trade Tensions and Beyond
# sa "https://www.youtube.com/watch?v=iQ5gN8bWst8" --language en # - date: 2023-12-22 - title: Jeffrey Sachs Interview - Global Standing
# sa "https://www.youtube.com/watch?v=X3RzwBhXH2g" --language en # - date: 2023-12-21 - title: Jeffrey Sachs Interview - Huge Miscalculation
# sa "https://www.youtube.com/watch?v=YPOnoNH1OlE" --language en # - date: 2023-12-19 - title: Jeffrey Sachs Interview - Geopolitical Realities
# sa "https://www.youtube.com/watch?v=yj5xUevGlSw" --language en # - date: 2023-12-18 - title: Jeffrey Sachs Interview - Profits, Politics, and Wars
# sa "https://www.youtube.com/watch?v=lctlTehaqNM" --language en # - date: 2023-12-16 - title: Jeffrey Sachs Interview - Reforming the Global Financial Structure.
# sa "https://www.youtube.com/watch?v=0EbHeGIhZKo" --language en # - date: 2023-12-13 - title: Jeffrey Sachs Interview - Conflict and Resolution
# sa "https://www.youtube.com/watch?v=kd13ykSEB3Y" --language en # - date: 2023-12-12 - title: Jeffrey Sachs Interview - A Shifting Global Landscape
# sa "https://www.youtube.com/watch?v=49zQxn35eEk" --language en # - date: 2023-12-11 - title: Jeffrey Sachs Interview - China's Rise in Global Economy.
#exit
# sa "https://www.youtube.com/watch?v=gJ0bht7KBdY" --language en # - date: 2023-12-05 - title: Jeffrey Sachs Interview - Sustainable Development and Peace

# sa "https://www.youtube.com/watch?v=qtz-igG7KvU" --language en # - date: 2023-11-29 - title: Jeffrey Sachs Interview - Geopolitical Analysis
# sa "https://www.youtube.com/watch?v=3yGdzf0rsrc" --language en # - date: 2023-11-27 - title: Jeffrey Sachs Interview - US-China Relations and Ukraine Conflict.
# sa "https://www.youtube.com/watch?v=FywNkUllF84" --language en # - date: 2023-11-26 - title: Jeffrey Sachs Interview - The Complexity of Global Involvement
# sa "https://www.youtube.com/watch?v=AarsTwjwwsQ" --language en # - date: 2023-11-24 - title: Jeffrey Sachs Interview - US-China Relations and Grand Strategy.
# sa "https://www.youtube.com/watch?v=-mUi5QknEq4" --language en # - date: 2023-11-23 - title: Jeffrey Sachs Interview - Unraveling the Ongoing Conflict
# sa "https://www.youtube.com/watch?v=7qBkAvRTGoU" --language en # - date: 2023-11-22 - title: Jeffrey Sachs Interview - Addressing the Root Causes
# sa "https://www.youtube.com/watch?v=ytb2vId7K-4" --language en # - date: 2023-11-21 - title: Jeffrey Sachs Interview - A Closer Look
# sa "https://www.youtube.com/watch?v=ILzYYBecU-A" --language en # - date: 2023-11-19 - title: Jeffrey Sachs Interview - Geopolitical Tensions
# sa "https://www.youtube.com/watch?v=w-tCqNb84JA" --language en # - date: 2023-11-17 - title: Jeffrey Sachs Interview - A Ground Invasion
# sa "https://www.youtube.com/watch?v=sWmWWxsrBAY" --language en # - date: 2023-11-16 - title: Jeffrey Sachs W/John Mearsheimer - A Missed Opportunity for Peace
# sa "https://www.youtube.com/watch?v=7O2XMimgSjw" --language en # - date: 2023-11-14 - title: Jeffrey Sachs W/John Mearsheimer - Global Crises
# sa "https://www.youtube.com/watch?v=uuj627q2a88" --language en # - date: 2023-11-08 - title: Jeffrey Sachs Interview - An Analysis of the Current Situation
# sa "https://www.youtube.com/watch?v=KLalpunXWIM" --language en # - date: 2023-11-07 - title: Jeffrey Sachs Interview - The Deception Surrounding the Origins of the War
# sa "https://www.youtube.com/watch?v=bbwhPhPZSPw" --language en # - date: 2023-11-04 - title: Jeffrey Sachs Interview - Geopolitics and Global Response
# sa "https://www.youtube.com/watch?v=sst6OIMCKlo" --language en # - date: 2023-11-02 - title: Jeffrey Sachs Interview - Global Confrontation
# sa "https://www.youtube.com/watch?v=wHsNq40gY7k" --language en # - date: 2023-11-01 - title: Jeffrey Sachs Interview - The Decline of Hegemony
# sa "https://www.youtube.com/watch?v=7lSJmIi3ZHo" --language en # - date: 2023-10-31 - title: Jeffrey Sachs Interview - The Tragedy of Great Power Politics.
# sa "https://www.youtube.com/watch?v=25ZzEyTDHLU" --language en # - date: 2023-10-28 - title: Jeffrey Sachs Interview - Diplomacy's Decline
# sa "https://www.youtube.com/watch?v=BABmfnoQLaE" --language en # - date: 2023-10-27 - title: Jeffrey Sachs Interview - A bogged-down Battle
# sa "https://www.youtube.com/watch?v=Dljrpz_Avlg" --language en # - date: 2023-10-25 - title: Jeffrey Sachs Interview - The US policy Towards Russia is Reckless
# sa "https://www.youtube.com/watch?v=3CCqPcCbW48" --language en # - date: 2023-08-19 - title: Jeffrey Sachs Interview - NATO Would Expand to Ukraine and to Georgia
# sa "https://www.youtube.com/watch?v=4tXyzYYPq-I" --language en # - date: 2023-10-24 - title: Jeffrey Sachs Interview - Preventing Global Conflict
# sa "https://www.youtube.com/watch?v=2w5_xg-Y5Dc" --language en # - date: 2023-10-23 - title: Jeffrey Sachs Interview - Military Power Determines the Political Outcome.
# sa "https://www.youtube.com/watch?v=dLc4Rxp56Ks" --language en # - date: 2023-10-17 - title: Jeffrey Sachs Interview - War is The Continuation of Politics.
# sa "https://www.youtube.com/watch?v=R_i2COrK8ZA" --language en # - date: 2023-10-16 - title: Jeffrey Sachs Interview - China A Recipe for the World
# sa "https://www.youtube.com/watch?v=6OGkz5czqGw" --language en # - date: 2023-10-01 - title: Jeffrey Sachs Interview - Expand Military Power and Political Influence
# sa "https://www.youtube.com/watch?v=tTEfde8N6gQ" --language en # - date: 2023-09-28 - title: Jeffrey Sachs Interview - Economic Convergence, Multipolar Geopolitics
# sa "https://www.youtube.com/watch?v=YUifh-Wud4g" --language en # - date: 2023-09-25 - title: Jeffrey Sachs Interview - The US and Ukraine - A Deeper Look
# sa "https://www.youtube.com/watch?v=WMee4iWt_Zo" --language en # - date: 2023-09-24 - title: Jeffrey Sachs Interview - A war of Wills Between Two Superpowers
# sa "https://www.youtube.com/watch?v=MKMxMUG4cKA" --language en # - date: 2023-09-07 - title: Jeffrey Sachs Interview - The Biggest Mistake Imaginable.
# sa "https://www.youtube.com/watch?v=mPzlQNUfstc" --language en # - date: 2023-09-04 - title: Jeffrey Sachs Interview - BRICS Enlargement Tensions or Opportunities
# sa "https://www.youtube.com/watch?v=tbcp24Alabs" --language en # - date: 2023-08-30 - title: Jeffrey Sachs - Geopolitical Ambitions - A Global Struggle for Influence
# sa "https://www.youtube.com/watch?v=c1fJGruPZXo" --language en # - date: 2023-08-27 - title: Jeffrey Sachs Interview - BRICS and Allies Rise
# sa "https://www.youtube.com/watch?v=tiWe1Fr7bGs" --language en # - date: 2023-08-26 - title: Jeffrey Sachs Interview - Massing The Troops on The Border
# sa "https://www.youtube.com/watch?v=JkMwu5AWuQE" --language en # - date: 2023-08-24 - title: Jeffrey Sachs Interview - Aggression, and the Path to War
# sa "https://www.youtube.com/watch?v=wxq4zYGJZbQ" --language en # - date: 2023-08-22 - title: Jeffrey Sachs Interview - A Large-scale Destruction is Currently Unfolding.
# sa "https://www.youtube.com/watch?v=u6yQ0tt5PDY" --language en # - date: 2023-08-21 - title: Jeffrey Sachs Interview - From Crisis to Solution
# exit
# sa "https://www.youtube.com/watch?v=4Ti6lPl8bQ8" --language en # - date: 2023-08-18 - title: Jeffrey Sachs Interview - The Battle for Global Influence
# 
# echo " \\" > add_fix.txt
# echo '	--tags="Jews"' >> add_fix.txt
# sa "https://x.com/PMG_RIP/status/1849215423150964743" --language en

# echo " \\" > add_fix.txt
# echo '	--tags="Jeffrey Sachs"' >> add_fix.txt
# sa "https://www.youtube.com/watch?v=P6PlnKues2M" --language en # - date: 2023-08-15 - title: Jeffrey Sachs Interview - I Think Ukraine is Getting Destroyed
# sa "https://www.youtube.com/watch?v=VCARiu4HwVI" --language en # - date: 2023-08-13 - title: Jeffrey Sachs Interview - West's Indifference - Ukraine's Fate Hangs in the Balance
# sa "https://www.youtube.com/watch?v=9DbPAgnIgac" --language en # - date: 2023-08-12 - title: Jeffrey Sachs Interview - Preventing Nuclear War is The first Priority
# sa "https://www.youtube.com/watch?v=SNvpnjW8xwk" --language en # - date: 2023-08-09 - title: Jeffrey Sachs Interview - A Hot War Between The Two Largest Nuclear Powers
# sa "https://www.youtube.com/watch?v=tWFaKRS8iic" --language en # - date: 2023-08-07 - title: Jeffrey Sachs Interview - The Struggle for Power
# sa "https://www.youtube.com/watch?v=2sVKXlNc1O8" --language en # - date: 2023-08-05 - title: Jeffrey Sachs Interview - NATO Enlargement and Russian Resistance
# sa "https://www.youtube.com/watch?v=IVQ4UZrxk4c" --language en # - date: 2023-08-04 - title: Jeffrey Sachs Interview - Institutions for a Changing World
# sa "https://www.youtube.com/watch?v=bko8TPk2YsA" --language en # - date: 2023-08-03 - title: Jeffrey Sachs Interview - Tensions in Global Power: China's Unprecedented Ascent
# sa "https://www.youtube.com/watch?v=LRWtdE-u-xE" --language en # - date: 2023-08-02 - title: Jeffrey Sachs Interview - Strong Geopolitical Tensions.
# sa "https://www.youtube.com/watch?v=At26rZtnIHo" --language en # - date: 2023-08-01 - title: Jeffrey Sachs Interview - Resentment and Nuclear Threats
# sa "https://www.youtube.com/watch?v=yePa4OaH7qw" --language en # - date: 2023-07-30 - title: Jeffrey Sachs Interview - What Exactly is China's Modernization?
# sa "https://www.youtube.com/watch?v=U2DzuP9E9Ds" --language en # - date: 2023-07-27 - title: Jeffrey Sachs Interview - The Problem with Politics in China.
# sa "https://www.youtube.com/watch?v=K57kTd27Go8" --language en # - date: 2023-07-25 - title: Jeffrey Sachs Interview - Regional Challenge. Geopolitics.
# sa "https://www.youtube.com/watch?v=007qsCJUcQk" --language en # - date: 2023-07-23 - title: Jeffrey Sachs Interview - The Us Blocked a Peace Deal with Russia.
# sa "https://www.youtube.com/watch?v=PhRvd-CnFOg" --language en # - date: 2023-07-21 - title: Jeffrey Sachs Interview - A Dire Need for Objective Analysis
# sa "https://www.youtube.com/watch?v=rp2_-ysUyWU" --language en # - date: 2023-07-19 - title: Jeffrey Sachs Interivew - A Recipe for Disaster
# sa "https://www.youtube.com/watch?v=e4V0PWeX3jA" --language en # - date: 2023-07-17 - title: Jeffrey Sachs Interivew - The Global Balance of Power Shift
# sa "https://www.youtube.com/watch?v=Th_bE00qNb4" --language en # - date: 2023-07-13 - title: Jeffrey Sachs Interivew - The End of The Fed Tightening Cycle.
# sa "https://www.youtube.com/watch?v=o2dN1TlRqGY" --language en # - date: 2023-07-12 - title: Jeffrey Sachs Interivew - A new Cold War Against China
# sa "https://www.youtube.com/watch?v=svOaBugQToE" --language en # - date: 2023-07-10 - title: Jeffrey Sachs Interivew - The Insanity of a New Cold War


# sa "https://www.youtube.com/watch?v=9PYatsb0hxE" --language en # - date: 2023-07-08 - title: Jeffrey Sachs Interivew - A Silent Threat to Global Peace
# sa "https://www.youtube.com/watch?v=06Ytz9vGyBY" --language en # - date: 2023-07-07 - title: Jeffrey Sachs Interivew - Path to War With China.
# sa "https://www.youtube.com/watch?v=AcxcNkCH4XY" --language en # - date: 2023-07-06 - title: Jeffrey Sachs Interivew - China is Not The Hostile Force.
# sa "https://www.youtube.com/watch?v=jy3sSkNWMQk" --language en # - date: 2023-07-05 - title: Jeffrey Sachs Interivew - A Push Towards Disaster
# sa "https://www.youtube.com/watch?v=REWB32lhLTM" --language en # - date: 2023-07-04 - title: Jeffrey Sachs Interivew - Ambitious Plan
# sa "https://www.youtube.com/watch?v=TXt2_4H4DVQ" --language en # - date: 2023-06-30 - title: Jeffrey Sachs Interivew - U.S. and China: The Consequences of Political Maneuvers
# sa "https://www.youtube.com/watch?v=8hQfyj2loy8" --language en # - date: 2023-06-29 - title: Jeffrey Sachs Interivew - China's Ascendancy is Changing Global Relations
# sa "https://www.youtube.com/watch?v=DAE2qKB2R6k" --language en # - date: 2023-06-25 - title: Jeffrey Sachs Interivew - The Geopolitics of NATO Enlargement
# sa "https://www.youtube.com/watch?v=Ikfj4V_Aank" --language en # - date: 2023-06-21 - title: Jeffrey Sachs Interivew - Don't Put an Adversary at The Choice
# sa "https://www.youtube.com/watch?v=ubVkyrwTiMY" --language en # - date: 2023-06-19 - title: Jeffrey Sachs Interivew - The Battlefield Decisions: Who Wins, Who Loses?
# sa "https://www.youtube.com/watch?v=K4JLc3u6jic" --language en # - date: 2023-06-19 - title: Jeffrey Sachs Interivew - Don't Fear China
# sa "https://www.youtube.com/watch?v=xTWdCD-_IyE" --language en # - date: 2023-06-17 - title: Jeffrey Sachs Interivew - US Dominance: A Cause for Endless Wars
# sa "https://www.youtube.com/watch?v=O4kskux-pwM" --language en # - date: 2023-06-16 - title: Jeffrey Sachs Interivew - The Unwinnable War in Ukraine
# sa "https://www.youtube.com/watch?v=0wg-gT73V7I" --language en # - date: 2023-06-16 - title: Jeffrey Sachs Interivew - A Call for American Politics Repair
# sa "https://www.youtube.com/watch?v=HOe8pyU_dQU" --language en # - date: 2023-06-15 - title: Jeffrey Sachs Interivew - The Dangerous Path Forward
# sa "https://www.youtube.com/watch?v=skFGJ3_gfUU" --language en # - date: 2023-06-14 - title: Jeffrey Sachs Interivew - China's Ambitions and the Calamity of World War Three
# sa "https://www.youtube.com/watch?v=s15Mk8rmwQc" --language en # - date: 2023-06-13 - title: Jeffrey Sachs Interivew - Russia Has Escalatory Dominance and Will Keep Escalating.
# sa "https://www.youtube.com/watch?v=NQr3BrHhxj8" --language en # - date: 2023-06-12 - title: Jeffrey Sachs Interivew - Biden Continues to Ignore Russia's Red Lines.
# sa "https://www.youtube.com/watch?v=_YD9laGTZJM" --language en # - date: 2023-06-11 - title: Jeffrey Sachs Interivew - The Crucial Point in US-China Conflict
# sa "https://www.youtube.com/watch?v=5titSaIFzrs" --language en # - date: 2023-06-10 - title: Jeffrey Sachs Interivew - A Driving Force for Conflict with China
# sa "https://www.youtube.com/watch?v=gmCdFL8Bnfs" --language en # - date: 2023-06-09 - title: Jeffrey Sachs Interivew - Wall Street Debacle and the Recession.
# sa "https://www.youtube.com/watch?v=39z2i8nnW0I" --language en # - date: 2023-06-08 - title: Jeffrey Sachs Interivew - Geopolitical Tensions in China.
# sa "https://www.youtube.com/watch?v=AOJ9l5M7Oa0" --language en # - date: 2023-06-07 - title: Jeffrey Sachs Interivew - Strategies for China Amidst Potential US Dollar Default
# sa "https://www.youtube.com/watch?v=3wset8M2CWM" --language en # - date: 2023-06-06 - title: Jeffrey Sachs Interivew - A Historic Debt Default Averted.
# sa "https://www.youtube.com/watch?v=koVB4Z8s3UI" --language en # - date: 2023-06-05 - title: Jeffrey Sachs Interivew - Crisis in The US 2023
# sa "https://www.youtube.com/watch?v=reX4kV8uKrs" --language en # - date: 2023-06-04 - title: Jeffrey Sachs Interivew - War in Ukraine and The Recession.
# sa "https://www.youtube.com/watch?v=1VJLckpX3l0" --language en # - date: 2023-06-03 - title: Jeffrey Sachs Interivew - China's Role Model: Ending Extreme Poverty at Scale
# sa "https://www.youtube.com/watch?v=C7Q_lGIqvzs" --language en # - date: 2023-06-02 - title: Jeffrey Sachs Interivew - The Consequences of Russia Provoking NATO.
# sa "https://www.youtube.com/watch?v=eT4_Yn5ypRo" --language en # - date: 2023-06-01 - title: Jeffrey Sachs Interivew - China's Aggressive Stance
# sa "https://www.youtube.com/watch?v=3jBDjcPzNhs" --language en # - date: 2023-05-31 - title: Jeffrey Sachs Interivew - Ukraine Conflict as a Prelude to War with China
# sa "https://www.youtube.com/watch?v=fOHdE1h3AQw" --language en # - date: 2023-05-30 - title: Jeffrey Sachs Interivew - The Importance of Russia's Departure
# sa "https://www.youtube.com/watch?v=qpcZAP3lSKw" --language en # - date: 2023-05-29 - title: Jeffrey Sachs Interivew - Foreign Policy, Expansion and Overthrow Governments.
# sa "https://www.youtube.com/watch?v=GD5U1DQ7pR4" --language en # - date: 2023-05-29 - title: Jeffrey Sachs Interivew - The Consequences of Mishandling the Ukraine Crisis
# sa "https://www.youtube.com/watch?v=0hWlx3-uMvE" --language en # - date: 2023-05-29 - title: Jeffrey Sachs Interivew - A Continuous Cycle of War
# sa "https://www.youtube.com/watch?v=8K-I9SE10FQ" --language en # - date: 2023-05-27 - title: Jeffrey Sachs Interivew - Surround Russia in the Black Sea
# sa "https://www.youtube.com/watch?v=NrOAUXK6ywM" --language en # - date: 2023-05-26 - title: Jeffrey Sachs Interivew - All-Out War between the West and Russia
# sa "https://www.youtube.com/watch?v=nOWAvvcVnFI" --language en # - date: 2023-05-25 - title: Jeffrey Sachs Interivew - From Ukraine to China: New Drumbeats of War
# sa "https://www.youtube.com/watch?v=SIU_zFvSP9Q" --language en # - date: 2023-05-24 - title: Jeffrey Sachs - A Key Principle for Financing Adaptation and Losses & Damages
# sa "https://www.youtube.com/watch?v=oRX97T6ai4I" --language en # - date: 2023-05-24 - title: Jeffrey Sachs Interivew - Biden Administration's Failed Predictions
# sa "https://www.youtube.com/watch?v=JkqT31fOZe8" --language en # - date: 2023-05-22 - title: Jeffrey Sachs Interivew - The Deep Crisis - A Wake-Up Call for Global Cooperation
# sa "https://www.youtube.com/watch?v=VOhohAHL1BM" --language en # - date: 2023-05-21 - title: Jeffrey Sachs Interivew - The US-China Relationship: A New Cold War?
# sa "https://www.youtube.com/watch?v=gWYRg-sYzTw" --language en # - date: 2023-05-17 - title: Jeffrey Sachs Interivew - Prudence in the Face of Provocation
# sa "https://www.youtube.com/watch?v=3cK9VhC423Y" --language en # - date: 2023-05-16 - title: Jeffrey Sachs Interivew - Geopolitical Power Struggle
# sa "https://www.youtube.com/watch?v=5m7lZsna9sU" --language en # - date: 2023-05-15 - title: Jeffrey Sachs Interivew - The Threat of Nuclear War - A Concerning Trend
# sa "https://www.youtube.com/watch?v=oW8wYlB6RvA" --language en # - date: 2023-05-11 - title: Jeffrey Sachs Interivew - The US and China: Rivalry in the Quest for Global Dominance

# sa "https://www.youtube.com/watch?v=WBUHL-N2veM" --language en # - date: 2023-05-10 - title: Jeffrey Sachs Interivew - A Threat to Global Stability
# sa "https://www.youtube.com/watch?v=TGguipPKbWc" --language en # - date: 2023-05-09 - title: Jeffrey Sachs Interivew - The Limits of American Hegemony
# sa "https://www.youtube.com/watch?v=xuoAvwO-4N8" --language en # - date: 2023-05-07 - title: Jeffrey Sachs Interivew - Hegemonic Thinking
# sa "https://www.youtube.com/watch?v=O3rQXOZcrug" --language en # - date: 2023-05-07 - title: Jeffrey Sachs Interivew - China and the Solomon Islands: A Tizzy for the US
# sa "https://www.youtube.com/watch?v=P2s6alq1fRA" --language en # - date: 2023-05-06 - title: Jeffrey Sachs Interivew - NATO's Arrogance Towards Russia: A Cautionary Tale
# sa "https://www.youtube.com/watch?v=C9VEllBAMsQ" --language en # - date: 2023-05-06 - title: Jeffrey Sachs Interivew - US Views China as a Potential Threat
# sa "https://www.youtube.com/watch?v=2zyvMokZqYo" --language en # - date: 2023-05-01 - title: Jeffrey Sachs Interivew - A Superpower War in Ukraine
# sa "https://www.youtube.com/watch?v=IsqVKAamXZ8" --language en # - date: 2023-04-30 - title: Jeffrey Sachs Interivew - China's Emergence as a Major Player in The World Stage
# sa "https://www.youtube.com/watch?v=Ib0kc30dKsE" --language en # - date: 2023-04-26 - title: Jeffrey Sachs Interivew - Containment of China as a Harmful and Dangerous Idea
# sa "https://www.youtube.com/watch?v=83ltIdg81hs" --language en # - date: 2023-04-25 - title: Jeffrey Sachs Interview - Russia, China, and India Negotiating for Peace
# sa "https://www.youtube.com/watch?v=5OTvWieaKdY" --language en # - date: 2023-04-25 - title: Jeffrey Sachs Interview - China Pushes Back Against US Foreign Policy
# sa "https://www.youtube.com/watch?v=hvri-lTF768" --language en # - date: 2023-04-24 - title: Jeffrey Sachs Interivew - The Chinese quietly supported Russia in the Ukraine Conflict.
# sa "https://www.youtube.com/watch?v=gRhLpJ779Lw" --language en # - date: 2023-04-23 - title: Jeffrey Sachs Interivew - China's Stance on The Ukrainian-Russian Crisis
# sa "https://www.youtube.com/watch?v=FE0PgktWXmQ" --language en # - date: 2023-04-23 - title: Jeffrey Sachs Interivew - The US alleged involvement in the Nord Stream Pipeline Explosion.
# sa "https://www.youtube.com/watch?v=XVk5Ml0erjk" --language en # - date: 2023-04-22 - title: Jeffrey Sachs Interivew - The Geopolitical Crisis - From Counterparts to Enemies
# sa "https://www.youtube.com/watch?v=QGt5tUe3dr8" --language en # - date: 2023-04-22 - title: Jeffrey Sachs Interivew -  President Xi Jinping's Views on US-China Relations
# sa "https://www.youtube.com/watch?v=poBEOXodkRc" --language en # - date: 2023-04-22 - title: Jeffrey Sachs Interivew - The US Battle with Russia and China
# sa "https://www.youtube.com/watch?v=d-K5VJQHaTk" --language en # - date: 2023-04-21 - title: Jeffrey Sachs Interivew -  Encircling Russia: The True Objective of NATO Expansion
# sa "https://www.youtube.com/watch?v=myAdFd3L8Fw" --language en # - date: 2023-04-20 - title: Jeffrey Sachs Interivew -  The Reality of Russia's Nuclear Warheads
# sa "https://www.youtube.com/watch?v=_ie3vJCTxEM" --language en # - date: 2023-04-20 - title: Jeffrey Sachs Interivew -  Provoking China and Raising Tension
# sa "https://www.youtube.com/watch?v=_ddhCAvlL5Q" --language en # - date: 2023-04-19 - title: Jeffrey Sachs Interivew -  The Nuclear Threat of the US-Russian War
# sa "https://www.youtube.com/watch?v=K_6WCUpDS7I" --language en # - date: 2023-04-17 - title: Jeffrey Sachs Interivew - The Politics Behind the Conflict in Ukraine
# sa "https://www.youtube.com/watch?v=CQ744thBpVM" --language en # - date: 2023-04-17 - title: Jeffrey Sachs Interivew - The Rise of China - Shifting Balance of Power
# sa "https://www.youtube.com/watch?v=fAiTDdEldhs" --language en # - date: 2023-04-16 - title: Jeffrey Sachs Interview - The Provocation of Major Geopolitical Conflicts
# sa "https://www.youtube.com/watch?v=AmZoJ1vKEKk" --language en # - date: 2023-04-16 - title: Jeffrey Sachs Explanation - The Origins of the Ukraine War & The Truth about NATO
# sa "https://www.youtube.com/watch?v=IClH5fLMKc0" --language en # - date: 2023-04-15 - title: Jeffrey Sachs Interview - China's Economy is Also in Decline
# sa "https://www.youtube.com/watch?v=O9fO2vmNreY" --language en # - date: 2023-04-14 - title: Jeffrey Sachs Interview - NATO enlargement Exacerbates US-Russia Conflict
# sa "https://www.youtube.com/watch?v=LlkyWvBamXY" --language en # - date: 2023-04-13 - title: Jeffrey Sachs Interview - The Failing Global Politics - Exclusive Interview
# sa "https://www.youtube.com/watch?v=cLPrnbc_y0E" --language en # - date: 2023-04-13 - title: Jeffrey Sachs Interview - A Conspiracy Theory - Exclusive Interview
# sa "https://www.youtube.com/watch?v=Ic5PV78E7uo" --language en # - date: 2023-04-11 - title: Jeffrey Sachs Interview - Donbass: The Third Point of Putin's Stance on Ukraine
# sa "https://www.youtube.com/watch?v=FmvEvQtID3Y" --language en # - date: 2023-04-11 - title: Jeffrey Sachs Interview - Putin and the Idea of Recreating the Russian Empire
# sa "https://www.youtube.com/watch?v=AeHXugv20BA" --language en # - date: 2023-04-10 - title: Jeffrey Sachs Interview - Improving US-China Relations: What Will It Take?
# sa "https://www.youtube.com/watch?v=_QUmcxcGD0k" --language en # - date: 2023-04-10 - title: Jeffrey Sachs Interview - India and China, Neighbors to Watch Out For
# sa "https://www.youtube.com/watch?v=h63N2m04Crg" --language en # - date: 2023-04-09 - title: Jeffrey Sachs Interview - China's Reaction to US technology Containment.
# sa "https://www.youtube.com/watch?v=i_XAUI4K_ow" --language en # - date: 2023-03-22 - title: Jeffrey Sachs Interview - Conflict-ridden World
# sa "https://www.youtube.com/watch?v=aSUQBwglQmI" --language en # - date: 2023-03-22 - title: Jeffrey Sachs Interview - A New Economic Model
# sa "https://www.youtube.com/watch?v=VyZg5weaDP8" --language en # - date: 2023-03-21 - title: Jeffrey Sachs Interview - Exposing the Nord Stream Bombing
# sa "https://www.youtube.com/watch?v=t33YYhZR7ls" --language en # - date: 2023-03-20 - title: Jeffrey Sachs Interview - Preventing Nuclear War.
# sa "https://www.youtube.com/watch?v=stVMhp98b4I" --language en # - date: 2023-03-20 - title: Jeffrey Sachs Interview - Russia’s new Position on The War.
# sa "https://www.youtube.com/watch?v=LSa1YVN27rQ" --language en # - date: 2023-03-15 - title: Jeffrey Sachs Interview - A Plan to Help the Soviet Union with Financial Transformation
# sa "https://www.youtube.com/watch?v=Kfda-3xrk-M" --language en # - date: 2023-03-15 - title: Jeffrey Sachs Interview about War Ukraine - New Tanks Sent to Ukraine
# sa "https://www.youtube.com/watch?v=WDPSf0rSL8w" --language en # - date: 2023-03-14 - title: Jeffrey Sachs Interview about Geopolitics and Economic Growth
# sa "https://www.youtube.com/watch?v=UYKt28qQ4Vk" --language en # - date: 2023-03-14 - title: Jeffrey Sachs Interview about Geopolitical Crises and Hot War in Ukraine
# sa "https://www.youtube.com/watch?v=f6u6hJHm33E" --language en # - date: 2023-03-14 - title: Jeffrey Sachs Interview about Geopolitics & Global Injustice Threatens the World

# sa "https://www.youtube.com/watch?v=eIEkx8wu6WY" --language en # - date: 2023-03-14 - title: Jeffrey Sachs Interview - The Debt Crisis - The Complexity of Today's World
# sa "https://www.youtube.com/watch?v=755CcWd_fjg" --language en # - date: 2023-03-11 - title: Jeffrey Sachs Interview - China: An Existential Threat to American Primacy
# sa "https://www.youtube.com/watch?v=cZMUkiYwAt8" --language en # - date: 2023-03-08 - title: Jeffrey Sachs - Conspiracy or Fact: The Truth About Nord Stream Pipeline Bombing

# # sa "https://www.youtube.com/watch?v=-Lp8HuG_zhk"
# sa "https://x.com/EndWokeness/status/1836769685817246036"
# sa "https://x.com/wideawake_media/status/1837069080303440160"

# echo " \\" > add_fix.txt
# echo '	--tags="Candace Owens"' >> add_fix.txt

#sa "https://www.youtube.com/watch?v=5gmDHw-lO4Q" --language en

# echo " \\" > add_fix.txt
# echo '	--tags="Mind Control"' >> add_fix.txt
# sa "https://odysee.com/@vegsource:1/stop-falling-for-mind-control-do-this!:b" --language en # - date: 2023-03-14 - title: Jeffrey Sachs Interview - The Debt Crisis - The Complexity of Today's World
