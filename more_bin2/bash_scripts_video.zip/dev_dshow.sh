#!/bin/bash

ffmpeg -list_devices true -f dshow -i dummy 

