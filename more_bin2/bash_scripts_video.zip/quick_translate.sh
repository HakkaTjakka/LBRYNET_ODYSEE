#!/bin/bash

FILENAME=$*
BASENAME="${FILENAME%.*}"

LANGUAGE="${FILENAME%.*}"
LANGUAGE="${LANGUAGE%.*}"
BASENAME2="${LANGUAGE%.*}"
LANGUAGE="${LANGUAGE##*.}"
echo $LANGUAGE


echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"

strip_file() {
        RESET="1"
        ln=1
        if test -f "$BASENAME2.$LANGUAGE.txt"; then
                rm "$BASENAME2.$LANGUAGE.txt"
        fi
        if test -f "$BASENAME2.$LANGUAGE.time"; then
                rm "$BASENAME2.$LANGUAGE.time"
        fi
        echo "" > "$BASENAME2.$LANGUAGE.time"
        while IFS='' read -r line || [[ -n "$line" ]]; do
                if [[ "$line" != "" ]] ; then
                        if [[ "$RESET" == "1" ]] ; then
                                RESET="2"
                        else
                                if [[ "$RESET" == "2" ]] ; then
                                        RESET="3"
                                        echo $line >> "$BASENAME2.$LANGUAGE.time"
                                else
                                        echo $ln $line
                                        echo $line >> "$BASENAME2.$LANGUAGE.txt"
                                        ln=$((ln+1))
                                fi
                        fi
                else
                        RESET=1
                fi
        done < "$FILENAME"
#        echo "" >> "$BASENAME2.$LANGUAGE.txt"
#        echo "" >> "$BASENAME2.$LANGUAGE.time"
}


#        while IFS= read -r line1 && IFS= read -r line2 <&3 && IFS= read -r line3 <&4; do

#        done < $1 3< $2 4< $3



trans_file() {
        TO_LANGUAGE="$1"
#        COMMAND="cat \"$BASENAME2.$LANGUAGE.txt\" | trans -brief $LANGUAGE:$TO_LANGUAGE"
        COMMAND="cat \"$BASENAME2.$LANGUAGE.txt\" | argos-translate --from $LANGUAGE --to $TO_LANGUAGE"

        echo "$COMMAND" >> COMMANDS.SH
        echo "$COMMAND" > command.sh
        chmod +x command.sh
        ln=1
        if test -f "$BASENAME2.$TO_LANGUAGE.txt"; then
                rm "$BASENAME2.$TO_LANGUAGE.txt"
        fi
        if test -f "$BASENAME2.$TO_LANGUAGE.srt.double"; then
                rm "$BASENAME2.$TO_LANGUAGE.srt.double"
        fi

        stdbuf -i0 -o0 -e0 script -c ./command.sh -f | while read -r line1 && IFS= read -r line2 <&3; do
                test1=$(echo "$line1" | tr -d '\r')


                if [ "$test1" != "Script done." ]; then  
                        if [ "$test1" != "Script started, output log file is 'typescript'." ]; then  

                                echo "$ln $line1" | tr -d '\r'
                                printf "\r"
                                echo $line1 >> "$BASENAME2.$TO_LANGUAGE.txt"
                                echo $ln >> "$BASENAME2.$TO_LANGUAGE.srt.double"
                                echo $line2 >> "$BASENAME2.$TO_LANGUAGE.srt.double"
                                echo $line1 >> "$BASENAME2.$TO_LANGUAGE.srt.double"
                                echo "" >> "$BASENAME2.$TO_LANGUAGE.srt.double"
                                ln=$((ln+1))
                        fi
                fi
        done 3< "$BASENAME2.$LANGUAGE.time"
        echo "" >> "$BASENAME2.$TO_LANGUAGE.txt"
}

virtualenv ~/git/argos-translate/env
source ~/git/argos-translate/env/bin/activate

strip_file

if [ "$LANGUAGE" == "en"  ]; then
        if test -f "$BASENAME2.nl.srt.double"; then
                rm "$BASENAME2.nl.srt.double"
        fi
        if test -f "$BASENAME2.de.srt.double"; then
                rm "$BASENAME2.de.srt.double"
        fi
        if test -f "$BASENAME2.fr.srt.double"; then
                rm "$BASENAME2.fr.srt.double"
        fi
        trans_file nl
        trans_file de
        trans_file fr
else
        if [ "$LANGUAGE" == "nl"  ]; then
                if test -f "$BASENAME2.en.srt.double"; then
                        rm "$BASENAME2.en.srt.double"
                fi
                if test -f "$BASENAME2.de.srt.double"; then
                        rm "$BASENAME2.de.srt.double"
                fi
                if test -f "$BASENAME2.fr.srt.double"; then
                        rm "$BASENAME2.fr.srt.double"
                fi
                trans_file en
                trans_file de
                cp "$BASENAME2.$LANGUAGE.time" "$BASENAME2.en.time"
                LANGUAGE="en"
                trans_file fr
        else
                if test -f "$BASENAME2.nl.srt.double"; then
                        rm "$BASENAME2.nl.srt.double"
                fi
                if test -f "$BASENAME2.en.srt.double"; then
                        rm "$BASENAME2.en.srt.double"
                fi
                if test -f "$BASENAME2.de.srt.double"; then
                        rm "$BASENAME2.de.srt.double"
                fi
                if test -f "$BASENAME2.fr.srt.double"; then
                        rm "$BASENAME2.fr.srt.double"
                fi
                if test -f "$BASENAME2.it.srt.double"; then
                        rm "$BASENAME2.it.srt.double"
                fi
                trans_file en
                cp "$BASENAME2.$LANGUAGE.time" "$BASENAME2.en.time"
                LANGUAGE="en"
                trans_file nl
                trans_file de
                trans_file fr
        fi
fi
