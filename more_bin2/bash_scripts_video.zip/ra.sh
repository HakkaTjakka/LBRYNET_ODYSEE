ffmpeg -y -f pulse -ac 1 -i 1 output.mp3

#ffmpeg -y -f pulse -ac 1 -i 1 -codec:a libmp3lame -b:a 64k output.mp3

#-codec:a libmp3lame 
