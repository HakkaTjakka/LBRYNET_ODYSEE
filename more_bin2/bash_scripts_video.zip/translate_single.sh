#!/bin/bash

FILENAME=$*
BASENAME="${FILENAME%.*}"

LANGUAGE="${FILENAME%.*}"
LANGUAGE="${LANGUAGE%.*}"
BASENAME2="${LANGUAGE%.*}"
LANGUAGE="${LANGUAGE##*.}"
echo $LANGUAGE

#exit
#LANGUAGE="en"

echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"

while IFS='' read -r line || [[ -n "$line" ]]; do
    if [[ $line =~ [a-z] ]] ; then

        echo $line
        VAR=$(echo "$line" | trans -brief $LANGUAGE:nl)
        echo $VAR
        echo $VAR >> "$BASENAME2.nl.srt.single"
        VAR2=$(echo "$line" | trans -brief $LANGUAGE:en)
        echo $VAR2
        echo $VAR2 >> "$BASENAME2.en.srt.single"


#    echo translate
#    echo "$line" | trans -brief $LANGUAGE:nl >> "$BASENAME2.nl.srt.single"
    else
        echo $line
#        echo no translate
       echo $line >> "$BASENAME2.nl.srt.single"
       echo $line >> "$BASENAME2.en.srt.single"
    fi
done < "$1"

#trans [OPTIONS] [SOURCES]:[TARGETS] [TEXT]...