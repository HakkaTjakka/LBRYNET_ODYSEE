#!/bin/bash

folderPath=./

for folder in $folderPath*
do
        folderName=$(basename $folder)
        cd $folder
        echo "$folder"
        zip -r ../$folderName.zip .
        cd ..
done