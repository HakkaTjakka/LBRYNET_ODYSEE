#yt-dlp  --restrict-filenames "https://youtube.com/playlist?list=PL1kjtlmf25BXwGNj02M_zD_DbE2xhdHqY" --write-info-json --skip-download 

#yt-dlp  --restrict-filenames "$1" --write-info-json --skip-download 
#https://www.youtube.com/watch?v=fLiUlpm3Vro&list=UULFsXoGRbga9bP1YpWNiwiZIQ&ab_channel=DeGuldenMiddenweg
#exit

#yt-dlp  --restrict-filenames "https://www.youtube.com/playlist?list=PL5dr8FO6wClayIfx98Ps7xzEYO2LrsKyy" --write-info-json --skip-download 
#blue tiger
#yt-dlp  --restrict-filenames "https://www.youtube.com/@bluetigerstudio4200/videos" --write-info-json --skip-download 
#yt-dlp  --restrict-filenames "https://www.youtube.com/@DeNieuweWereldTV/videos" --write-info-json --skip-download


#find . -maxdepth 1 -type f -name "*.info.json" -print0 | sort -z | while IFS= read -r -d '' line; # do
rm json.list
find . -maxdepth 1 -type f -name "*.info.json" -print0 | sort -z | while IFS= read -r -d '' line;
do
#	echo $line
#	BASENAME="${FILENAME%.*}"
#	VAR=$(echo $BASENAME | sed 's/[][]/\\&/g' |  sed 's/ /\\ /g')
	get_json.sh "$line"
#	sleep 1
done

