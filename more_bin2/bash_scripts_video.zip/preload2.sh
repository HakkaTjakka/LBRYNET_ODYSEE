get_one() {
	echo "==============================="
	echo "===============================" >> get_errors2.log
	echo "URL:  $1"
	echo "URL:  $1" >> get_errors2.log

	yt-dlp -i "$1" \
		--merge-output-format mp4 \
		--restrict-filenames \
		--skip-unavailable-fragments \
		--geo-bypass \
		--get-filename \
		--no-playlist \
		--cookies cookies/twitter.com_cookies.txt > get_filename2.txt

	read -r FILENAME < get_filename2.txt
	echo "Filename: $FILENAME"
	BASENAME="${FILENAME%.*}"

	echo "File: $FILENAME"
	echo "File: $FILENAME" >> get_errors2.log

#		--downloader aria2c \
#		-R 5 \
	yt-dlp -i "$1" \
		--merge-output-format mp4 \
		-o "$FILENAME"

	ffmpeg -v error -i "$FILENAME" -f null - 2>get_error.log
	cat get_error.log
	cat get_error.log >> get_errors2.log
	cat get_error.log > "$BASENAME.log"
}

#date: 2021-09-09 - length:    30:02 - title: "Actiejournaal week #36 - Martina Groenveld met Michel Reijinga"
get_one "https://odysee.com/actiejournaal-week-------martina-groenveld-met-michel-reijinga:a6817cdefb4049924b12046e3328f1b1c728c45e" --language nl

#date: 2021-08-15 - length:    48:01 - title: "Bestaansrecht - Peter Toonen met Maarten Oversier"
get_one "https://odysee.com/bestaansrecht---peter-toonen-met-maarten-oversier:1d58733fbfec3e7cd82cb64bfc0d0bbd56fbd77a" --language nl

#date: 2021-07-16 - length:    50:08 - title: "Buitenlandse media over Russische ontwikkelingen - Marie Thérèse en Max von Kreyfeld"
get_one "https://odysee.com/buitenlandse-media-over-russische-ontwikkelingen---marie-th-r-se-en-max-von-kreyfeld:2c8400b4fed658b33d65d0ca0446ed407a9762f9" --language nl

#date: 2021-09-22 - length:    28:42 - title: "Corrupte machtssystemen: We worden voor de gek gehouden!"
get_one "https://odysee.com/corrupte-machtssystemen--we-worden-voor-de-gek-gehouden-:29d62ec2e0c15e555d618234475c06ade69b5ad7" --language nl

#date: 2021-09-07 - length:    40:35 - title: "Dagvaarding tegen de Gezondheidsraad - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/dagvaarding-tegen-de-gezondheidsraad---jeroen-pols-en-maria-louise-genet:1535668768e8ac0646f69fb9bff2e022dfe76941" --language nl

#date: 2021-07-30 - length:  1:05:07 - title: "De dictatuur is uitgeroepen - Erik van der Horst met Pieter Stuurman"
get_one "https://odysee.com/de-dictatuur-is-uitgeroepen---erik-van-der-horst-met-pieter-stuurman:719f767e606ddec1b77ca3bf120592077e98b61b" --language nl

#date: 2021-09-17 - length:    58:43 - title: "De échte reset is de Going Direct Reset - Elze van Hamelen en Catherine Austin Fitts"
get_one "https://odysee.com/de--chte-reset-is-de-going-direct-reset---elze-van-hamelen-en-catherine-austin-fitts:1dab718a4cd87f6e1594ab728253f9a8bf439e86" --language nl

#date: 2021-08-17 - length:  1:02:50 - title: "De man die keer op keer gelijk bleek te hebben - Erik van der Horst met David Icke"
get_one "https://odysee.com/de-man-die-keer-op-keer-gelijk-bleek-te-hebben---erik-van-der-horst-met-david-icke:330c07ac9ccfca6539d0278fa2c5eb13dd4dd5da" --language nl

#date: 2021-08-01 - length:    52:34 - title: "De oogst van de Angst - Peter Toonen met Willem Erné"
get_one "https://odysee.com/de-oogst-van-de-angst---peter-toonen-met-willem-ern-:aec93c6f631189b93235fc67127aa6c9e13009a0" --language nl

#date: 2021-07-12 - length:  1:40:34 - title: "Deutsche Bank #5 - 'Shadow Banking" - Arno Wellens"
get_one "https://odysee.com/deutsche-bank-------shadow-banking----arno-wellens:169cad7f8d16c6c2dc8fa2f4b7a593c8ee54d6cf" --language nl

#date: 2021-07-20 - length:  1:19:22 - title: "Fascisme zonder fascisten - Pieter Stuurman met René ten Bos"
get_one "https://odysee.com/fascisme-zonder-fascisten---pieter-stuurman-met-ren--ten-bos:4a0717f3df7c582d1acddc08e61b33c089b99906" --language nl

#date: 2021-09-14 - length:  1:03:47 - title: "Gezondheidsraad gedagvaard - Veiligheid en ernstige bijwerkingen - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/gezondheidsraad-gedagvaard---veiligheid-en-ernstige-bijwerkingen---jeroen-pols-en-maria-louise-genet:f21ac6ee76f416bd295dbd5f719e3d04f618b472" --language nl

#date: 2021-09-14 - length:  1:03:47 - title: "Gezondheidsraad gedagvaard - Veiligheid en ernstige bijwerkingen - Jeroen Pols en Maria-Louise Genet"
get_one "https://odysee.com/gezondheidsraad-gedagvaard---veiligheid-en-ernstige-bijwerkingen---jeroen-pols-en-maria-louise-genet:e506a54827e9dc7317f310160f28369e0f8930fc" --language nl

#date: 2021-08-12 - length:    52:16 - title: "Groene woestijn? - Martina Groenveld met Caroline van der Plas"
get_one "https://odysee.com/groene-woestijn----martina-groenveld-met-caroline-van-der-plas:2b24e8350b1d692eda397107fe842cd2673517c2" --language nl

#date: 2021-09-12 - length:    53:30 - title: "Rechteloze Werkelijkheid - Peter Toonen met Rients Hofstra"
get_one "https://odysee.com/rechteloze-werkelijkheid---peter-toonen-met-rients-hofstra:fce044f0f275ea779d7e5d50fd4a667b3e9ae2cf" --language nl

#date: 2021-09-12 - length:    53:30 - title: "Rechteloze Werkelijkheid - Peter Toonen met Rients Hofstra"
get_one "https://odysee.com/rechteloze-werkelijkheid---peter-toonen-met-rients-hofstra:b98034b3e9bddba787f42010d6d4247c4aeb8d61" --language nl

#date: 2021-09-28 - length:    35:39 - title: "Restaurant Waku Waku maakt de weg vrij voor de Nederlandse horeca - Max, Anna en Mordechaï"
get_one "https://odysee.com/Restaurant-Waku-Waku-maakt-de-weg-vrij-voor-de-Nederlandse-horeca---Max,-Anna-en-Mordechaï:846a79420c1175753d63874500299ad549113822" --language nl

#date: 2021-07-14 - length:    51:31 - title: "The Great Reset is een 'zot boekske' - Martina Groenveld met Michael Verstraete"
get_one "https://odysee.com/the-great-reset-is-een--zot-boekske----martina-groenveld-met-michael-verstraete:3866e9dc8a841f28c262f9fb536247bc8e4d4403" --language nl

#date: 2021-07-30 - length:    19:08 - title: "Uitsluiting uitgesloten -  Erik van der Horst met Olaf Weller"
get_one "https://odysee.com/uitsluiting-uitgesloten----erik-van-der-horst-met-olaf-weller:11973cdff23c264a1c93421687dd9303cc6833a6" --language nl

#date: 2021-08-19 - length:  1:07:03 - title: "Wat is erger, C19 of CO2? - Willem Engel met Marcel Crok"
get_one "https://odysee.com/wat-is-erger--c---of-co-----willem-engel-met-marcel-crok:72575dda633c8aed1f0b4fe935649a53cac25ace" --language nl

#date: 2021-08-25 - length:  1:14:07 - title: "Wees uw broeders hoeder - Peter Toonen en Gitta Sluijters"
get_one "https://odysee.com/wees-uw-broeders-hoeder---peter-toonen-en-gitta-sluijters:2e55ac47f4b8d9e1222015e0898b71b9c9fe32ee" --language nl

#date: 2021-08-22 - length:    45:45 - title: "We hoeven hier niet in mee te gaan - Erik van der Horst en Elke de Klerk"
get_one "https://odysee.com/we-hoeven-hier-niet-in-mee-te-gaan---erik-van-der-horst-en-elke-de-klerk:4066c4ef1b4ee8354f3790e6dadc997bf2f46527" --language nl

#date: 2021-07-06 - length:    15:33 - title: ""Het zal je kind maar zijn" - Anne-Marie Kroes en Frank Ruesink"
get_one "https://odysee.com/-het-zal-je-kind-maar-zijn----anne-marie-kroes-en-frank-ruesink:d9fc60e4da2b15908451124748177816be2fcbcb" --language nl

exit
