make_subs.sh  
