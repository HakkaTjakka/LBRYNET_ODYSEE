#!/bin/bash

FILENAME=$*
BASENAME="${FILENAME%.*}"

LANGUAGE="${FILENAME%.*}"
LANGUAGE="${LANGUAGE%.*}"
BASENAME2="${LANGUAGE%.*}"
LANGUAGE="${LANGUAGE##*.}"
echo $LANGUAGE


echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"

COMMAND="translate_spec.sh "$BASENAME.$LANGUAGE.srt.double""

echo "$COMMAND" >> COMMANDS.SH
echo "$COMMAND" > command.sh
chmod +x command.sh
./command.sh

#burn_video.sh nl
#burn_video.sh en
burn_video.sh uk
burn_video.sh ru
