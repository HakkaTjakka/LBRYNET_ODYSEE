echo " \\" > add_fix.txt
echo '	--tags="Ab Gietelink" \\' >> add_fix.txt
echo '	--tags="Alternatief.TV"' >> add_fix.txt

# 2008-07-18 -     4:21 - Gijsbrecht van Aemstel- Proloog -Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=Apxmq6dboi0"

# 2009-04-23 -     2:14 - Faust - Trailer Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=T3a7uVHqMeM"

# 2010-09-06 -     2:04 - Neerlands Trots in Barre Tijden 2 -Trailer - Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=z4yRGzAX2SE"

# 2011-06-01 -     1:20 - Danton en de Franse Revolutie - Trailer- Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=zajukO87o80"

# 2011-06-09 -     1:13 - Immortelle LX -Piet Paaltjens - Ab Gietelink
sa "https://www.youtube.com/watch?v=t4n4ILIlZY8"

# 2011-06-09 -     1:39 - Boutade - de Genestet - Rapversie - Ab Gietelink
sa "https://www.youtube.com/watch?v=8jVoOZtHTFY"

# 2011-06-09 -     2:05 - Aan Rika - Piet Paaltjens - Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=g4Zqrl_Aluc"

# 2011-06-09 -     3:24 - 1914-1918 Het lied 'Het Wijnglas' over WO1 van Dirk Witte. Door: Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=6j3J9Jj4riE"

# 2011-06-09 -     3:26 - Oote (Jan Hanlo) en De Stijl (Piet Mondriaan) door Ab Gietelink
sa "https://www.youtube.com/watch?v=O4HhES4GvMY"

# 2011-06-09 -     4:33 - Neerlands Trots 2 - Proloog - Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=LPNhDKdd5n4"

# 2011-06-16 -     1:04 - Colijn -Jaren 30 -Crisis- Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=xgTtzxqZwGw"

# 2011-06-16 -     1:37 - Anne Frank in Gaza - Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=wX7UjnbWc_M"

# 2011-06-16 -     1:38 - Euthenasie: Dood, veeg je voeten en wees welkom ! - Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=OS4f-1O4uEo"

# 2011-06-16 -     1:53 - 1973 Vakbondsman met Internationale- Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=LXgTHINLMc8"

# 2011-06-16 -     2:09 - Het Lied der Achttien Dooden - Jan Campert - Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=avvhgvGbsdQ"

# 2011-06-16 -     3:11 - Vincent van Gogh - Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=cCEsYbFLmOI"

# 2011-06-16 -     3:45 - Max Havelaar - Aanklacht Multatuli- Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=_G8ph7Uv5sc"

# 2011-06-16 -     3:47 - 1980 Geen Woning, Geen Kroning 1898 Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=jNbSe8s6PlQ"

# 2011-06-17 -     2:13 - Islamitische vrouwen tegen stropdas - Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=ElPqewLrKR8"

# 2011-06-23 -    13:20 - Gijsbrecht van Aemstel 03/12- Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=Iu4aUX3Yu_w"

# 2011-06-23 -     9:54 - Gijsbrecht van Aemstel 02/12 - Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=jfl0E9Ed21I"

# 2011-06-24 -     4:18 - Gijsbrecht van Aemstel 01/12 - Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=TjTmXfywM88"

# 2011-06-24 -     4:30 - Gijsbrecht van Aemstel 09/12 - Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=Mx4gX408gxY"

# 2011-06-24 -     4:53 - Gijsbrecht van Aemstel 04/12 - Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=mmQVkqfpgKc"

# 2011-06-24 -     6:39 - Gijsbrecht van Aemstel 05/12 - Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=KuEAlmNtnGU"

# 2011-06-24 -     6:52 - Gijsbrecht van Aemstel 07/12 - Stadsoorlog- Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=47TqhupDBqk"

# 2011-06-24 -     6:58 - Gijsbrecht van Aemstel 08/12 - Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=zNdtIlWJK3k"

# 2011-06-24 -     7:00 - Gijsbrecht van Aemstel 06/12 - O, Kerstnacht als Islamitisch gebed- Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=PzACfAxfJz8"

# 2011-06-25 -     2:59 - Bewakingsruimte-Islamiet moet stropdas om! - Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=VbDHnvkHsV0"

# 2011-06-25 -     3:42 - Noodpakket- Veiligheid- Paranoia- Ab Gietelink &Theater Nomade
sa "https://www.youtube.com/watch?v=UaETtP6wfPg"

# 2011-06-25 -     4:22 - Gijsbrecht van Aemstel 12/12 - Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=bGxTi8TLHkU"

# 2011-06-25 -     5:12 - Gijsbrecht van Aemstel 10/12 - Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=nvdSPYDGZeo"

# 2011-06-25 -     5:21 - Gijsbrecht van Aemstel 11/12 - Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=7DudxfIhmbs"

# 2012-01-15 -     2:13 - Danton en de Franse Revolutie 00/12 Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=NOXUOa40Nrk"

# 2012-01-15 -     4:07 - Danton en de Franse Revolutie 03/12 Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=8Wp9suSkBkY"

# 2012-01-15 -     5:49 - Danton en de Franse Revolutie  02/12 Theater Nomade & Ab  Gietelink
sa "https://www.youtube.com/watch?v=30rEfUh3SN0"

# 2012-01-15 -     6:01 - Danton en de Franse Revolutie 04/12 Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=Yak-hRVr7NA"

# 2012-01-16 -     5:24 - Danton en de Franse Revolutie  06/12- Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=r6Y_PNsM61I"

# 2012-01-16 -     7:15 - Danton en de Franse Revolutie  05/12- Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=nzEFnRjlOGg"

# 2012-01-16 -     9:17 - Danton en de Franse Revolutie 01/12- Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=zhvazi3trww"

# 2012-05-19 -     2:24 - The King's Speech Trailer Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=J4tCRlIgaiA"

# 2013-01-22 -  1:03:23 - The Kings Speech 1/2- Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=o-OTFr3rmYM"

# 2013-01-22 -    55:20 - The Kings Speech 2/2 -Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=o2j0hzeigbg"

# 2013-05-28 -    40:53 - Wij verlangen onze Vrijheid ! Cees Maris & Ab Gietelink
sa "https://www.youtube.com/watch?v=ENp4o-x8Rek"

# 2013-07-22 -     1:16 - Trailer Anthony Fokker. Met Albert Plesman op de ELTA (1919).- Ab Gietelink& Theater Nomade.
sa "https://www.youtube.com/watch?v=_tmQuIU2LzE"

# 2013-09-19 -     3:31 - Trailer Anthony Fokker.  Fokkerfabriek in Amsterdam Noord, Jaren 20
sa "https://www.youtube.com/watch?v=4fOvgD_jF_Y"

# 2014-04-28 -     5:54 - Trailer Anthony Fokker. Met de KLM naar Londen (1921)- Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=jL1lf0bnXdY"

# 2014-11-18 -    53:25 - Anthony Fokker, Documentaire van Ab Gietelink
sa "https://www.youtube.com/watch?v=NSpueGPvoVA"

# 2014-12-29 -    48:45 - Anthony Fokker, Muziektheatervoorstelling, 2e Deel- Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=cEaioF7oh1g"

# 2014-12-29 -    54:24 - Anthony Fokker, Muziektheaterproductie, 1e deel -  Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=gDrIRAoC9qo"

# 2015-03-19 -     1:10 - Als de Menschen kunnen Vliegen- Ab Gietelink
sa "https://www.youtube.com/watch?v=K5BeAS5Bjk4"

# 2015-03-19 -     2:27 - Anthony Fokker- Trailer 2015 -Ab Gietelink &Theater Nomade
sa "https://www.youtube.com/watch?v=9qGS1QXylBs"

# 2016-11-29 -  1:18:37 - 14-18 WO I Achter de Hollandse Waterlinie Theater Nomade & Ab Gietelink
sa "https://www.youtube.com/watch?v=LGWlAxj4ED0"

# 2019-01-10 -     1:06 - 20 De 5 sterren beweging brengt de verbeelding aan de macht. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=ZTxfFaiPpFk"

# 2019-01-10 -     1:07 - 19 Drone aanslagen. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=ftz1xFPmIQw"

# 2019-01-10 -     1:08 - 13 Babchenko, de fictieve moord op een Kremlincriticus. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=WFlTHgDNVRk"

# 2019-01-10 -     1:27 - 04 Er komen andere tijden. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=_AVO0kGkwC8"

# 2019-01-10 -     1:41 - 33 Hoe in Nederland alles Anders kan?  Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=XAPrEatNI5E"

# 2019-01-10 -     1:45 - 09 Het Russisch Volkslied. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=w7taDOcu0Ns"

# 2019-01-10 -     1:46 - 17 Minister President, slaap zacht. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=DcMyDK_F4cA"

# 2019-01-10 -     1:53 - 02 Tunnelvisie Regeert !   Ab Gietelink &Theater Nomade
sa "https://www.youtube.com/watch?v=VfnDi2PB38Y"

# 2019-01-10 -     2:01 - 14 Spionage, of de pot verwijt de ketel dat hij zwart ziet. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=Iej8YaHVfUw"

# 2019-01-10 -     2:10 - 21 Opstand in de Nederlanden en in Catalonie. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=N4QAgJH9c64"

# 2019-01-10 -     2:27 - 11 De gifgasleugen van Douma. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=tmjz_j6Uh-Y"

# 2019-01-10 -     2:33 - 10 Irakoorlog: Hoe Vijandsbeelden de Leugen laten regeren. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=ttPrIjZYAXU"

# 2019-01-10 -     2:42 - 26 Wij zijn hier de baas! Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=Q9S4HU6yysw"

# 2019-01-10 -     2:46 - 12 Valse beschuldigingen in de Skripal casus. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=YFa9BlP3fWY"

# 2019-01-10 -     2:50 - 30 Zelfmoordenaar moet betalen. Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=ZQbXHaesQiA"

# 2019-01-10 -     2:53 - 15 Tunnelvisie in het MH17 debat. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=8om3Jlq9mIA"

# 2019-01-10 -     2:58 - 29 Het onbehagen bij #MeToo. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=QWtcmAYX-VU"

# 2019-01-10 -     2:59 - 22 Inburgeringscursus Europees Volkslied. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=QORg_Eo5o2U"

# 2019-01-10 -     3:04 - 16 Den Haag, van Vredespaleis tot strafhof. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=jK4V07wdwZ4"

# 2019-01-10 -     3:37 - 07 Hoe het Westen de Nieuwe Koude Oorlog maakte. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=ydPY7_ebxbA"

# 2019-01-10 -     3:38 - 18 Trump, Kim, Poetin en Gdaffi. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=KdPC26jv73c"

# 2019-01-10 -     3:45 - 28 Verboden te masturberen in je eigen huis. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=V7mcvswuUZY"

# 2019-01-10 -     3:51 - 06 Churchill, No more heroes anymore. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=WuUfUdoCJXQ"

# 2019-01-10 -     3:58 - 24 Het verraad van D66. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=MNwqVXl32K0"

# 2019-01-10 -       39 - 27 De politie is mijn beste kameraad (Lied). Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=zF7IwOn69ps"

# 2019-01-10 -     4:15 - 25 Er was eens een godvrezend land. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=INrjaG-Da-I"

# 2019-01-10 -     4:17 - 03 Reis naar de Achterkant van het Gelijk. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=x7dipU_umAc"

# 2019-01-10 -     4:21 - 05 Hoe de wereldgeschiedenis anders had kunnen stromen. Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=Mo78wtUdAzM"

# 2019-01-10 -     4:24 - 01 De Leugen regeert! Ab Gietelink & Theater Nomade -
sa "https://www.youtube.com/watch?v=zttIRWNcyUM"

# 2019-01-10 -     4:52 - 32 Stop de fietsen razzia's. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=9cYOLh_4RXg"

# 2019-01-10 -     4:54 - 31 Het verdriet van zwarte Piet. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=4RIGzvwK_v4"

# 2019-01-10 -     5:04 - 08 De leugen van Halbe Zijlstra. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=kF67P6ZjjeY"

# 2019-01-10 -     9:14 - 23 Waarom Nederland een falende democratie is. Ab Gietelink & Theater Nomade.
sa "https://www.youtube.com/watch?v=TRqSd7BuRg8"

# 2019-06-06 -     2:39 - Willem van Oranje - Trailer Theatervoorstelling
sa "https://www.youtube.com/watch?v=xIgGBEo3rkU"

# 2020-12-05 -    17:47 - #37 Persconferentie van de nieuwe Minister President. Ab Gietelink
sa "https://www.youtube.com/watch?v=9RMlrDvLfCA"

# 2020-12-11 -     7:35 - #34 Performance tegen de Coronawet I Ab Gietelink
sa "https://www.youtube.com/watch?v=eAW1Vk1bew8"

# 2020-12-16 -    24:39 - #12 De Ionisator is de oplossing van de Pandemie Ton Rademaker en Ab Gietelink
sa "https://www.youtube.com/watch?v=02gcwpmh3ug"

# 2020-12-18 -    44:50 - #40 Media oorlog in Coronatijd   Ab Gietelink met Prof. Cees Hamelink
sa "https://www.youtube.com/watch?v=oXACNtFjS4c"

# 2020-12-19 -    59:21 - #42 Is de 'Coronastorm fascistisch' Prof  René ten Bos en Ab Gietelink
sa "https://www.youtube.com/watch?v=7dSPY2v4ug4"

# 2021-01-07 -    16:40 - #46 De Beschadiging van jongeren. Ab, Renate Tillema, Maartje Van De Berg en Aartjan Bergshoeff
sa "https://www.youtube.com/watch?v=k8txxAg2V20"

# 2021-01-23 -    47:44 - #45 Pandemie van de Angst I  Ab Gietelink interviewt Kees van der Pijl.
sa "https://www.youtube.com/watch?v=VYPPrjqvUEM"

# 2021-01-24 -    12:23 - #44 Ab Gietelink Column I Satirische Corona Encyclopedie
sa "https://www.youtube.com/watch?v=T2P0-W9t6sc"

# 2021-01-25 -    16:40 - #48 Kerstboodschap van de nieuwe minister-president I Ab Gietelink
sa "https://www.youtube.com/watch?v=7hDGn2fNv98"

# 2021-02-06 -     3:39 - #49 Mens durf te Leven I  Protestlied Ab Gietelink
sa "https://www.youtube.com/watch?v=vrdscXxs7aw"

# 2021-02-28 -     5:27 - #52 Ab Gietelink I Ik zou willen leven in een Nederland...
sa "https://www.youtube.com/watch?v=Rs4ZlQMo2Ho"

# 2021-03-22 -    56:02 - #38 Wat te verwachten van Trump en Biden? I  Ab Gietelink interviewt Kees van der Pijl.
sa "https://www.youtube.com/watch?v=UcSf9l8L8ks"

# 2021-03-26 -    43:15 - #33 Gevaarlijke sekteleider of wetenschappelijk criticus ?  Ab Gietelink interviewt Willem Engel
sa "https://www.youtube.com/watch?v=OSG9PD5abJ4"

# 2021-03-29 -    16:19 - #23 Ab Gietelink I  Burgemeester Halsema: Stop de Mondkapjesplicht! Deel 1
sa "https://www.youtube.com/watch?v=K1iPVW7Z1FU"

# 2021-03-31 -     9:34 - #24 Ab Gietelink I  Open brief aan Burgemeester Halsema. Deel 2
sa "https://www.youtube.com/watch?v=tTYFf25UzfU"

# 2021-04-02 -    40:53 - #28 Wat staat er in de Noodwet. Slapen de Kamerfracties?/ jeroen Pols en Ab Gietelink
sa "https://www.youtube.com/watch?v=zRfD8hXuXtA"

# 2021-04-03 -    29:49 - #36 Ab Gietelink I  Taboes in de Media en Alternatieven voor Lockdown
sa "https://www.youtube.com/watch?v=i4ruPrffcKI"

# 2021-04-06 -    41:24 - #39 Ab Gietelink I  Tunnelvisies in de Media tijdens Coronadictatuur
sa "https://www.youtube.com/watch?v=E-w6N_Wpb6A"

# 2021-04-09 -    35:19 - # 27  Honderden actiegroepen (ABC') tegen het Coronabeleid. Ferdinand van der Neut en Ab Gietelink
sa "https://www.youtube.com/watch?v=EhZXgeMnUSc"

# 2021-04-14 -     9:04 - #25 Ab Gietelink I  Open brief aan Minister Grapperhuis
sa "https://www.youtube.com/watch?v=xpr7-T21pf4"

# 2021-04-29 -    26:50 - #20 Ab Gietelink I  Het Censuurproces tegen YouTube en de Zelfcensuur van de media.
sa "https://www.youtube.com/watch?v=CBVRnkP7FEE"

# 2021-05-03 -    20:36 - #57 Ab Gietelink I  Brief aan onze kwaliteitsmedia in Coronatijd
sa "https://www.youtube.com/watch?v=kQkiieIJrQk"

# 2021-05-07 -    18:05 - #55 Ab Gietelink I  Brief van het Museumplein aan Burgemeester Femke Lukashenko
sa "https://www.youtube.com/watch?v=uzvKL28G2N0"

# 2021-05-17 -    15:48 - #58 Ab GietelinkI Persoonlijke Brief aan Premier Mark Rutte
sa "https://www.youtube.com/watch?v=PV-I9shdmE0"

# 2021-05-18 -    16:47 - #56 Ab Gietelink I Brief aan het OMT, Keizer zonder Kleren
sa "https://www.youtube.com/watch?v=iwOns4m6ouc"

# 2021-05-21 -     9:43 - #51 Ab Gietelink I Performance over Avondklok, Spreektaal en Quarantainefaciliteit
sa "https://www.youtube.com/watch?v=65M2bTrUvuI"

# 2021-05-26 -    54:09 - #53 Mediadisciplinering tijdens Krakersrellen en Coronacrisis  Ab Gietelink met Stan van Houcke
sa "https://www.youtube.com/watch?v=lWdSAJg6WCM"

# 2021-05-29 -     5:27 - #52 Ab Gietelink I Ik zou willen leven in een Nederland !
sa "https://www.youtube.com/watch?v=YOwPKYaFmaE"

# 2021-06-23 -    18:46 - #61 Column Ab Gietelink I  De schaduw van de Wuhan Lab fout in het Post Coronatijdperk
sa "https://www.youtube.com/watch?v=lVGnweju_dQ"

# 2021-06-30 -    15:32 - #59 Ab Gietelink – Was de 5 mei poster echt zo fout
sa "https://www.youtube.com/watch?v=xHwgp9N-8bs"

# 2021-07-07 -    16:01 - #50 Ab Gietelink I Je Suis Wappie !
sa "https://www.youtube.com/watch?v=oeLBktANuM4"

# 2021-09-25 -    18:19 - 63 Performance Ab Gietelink I Coronapas maakt Nederland tot Apartheidsstaat !
sa "https://www.youtube.com/watch?v=MmT02s_rCG8"

# 2021-09-27 -    45:51 - 64 Hoe interpreteren we de actuele oversterftecijfers ?  Ab Gietelink interviewt Ir.Luc Sala
sa "https://www.youtube.com/watch?v=H5pdxsuBtrU"

# 2021-09-30 -  1:10:03 - 65 ´Pandemie van de Angst' en Coronapas. Ab Gietelink interviewt Prof. Kees van der Pijl.
sa "https://www.youtube.com/watch?v=IrCfm8qwHmY"

# 2021-10-04 -    13:44 - 66  Pfizer bezorgde mijn zoon een gezichtsverlamming. Een persoonlijk verhaal van Ab Gietelink
sa "https://www.youtube.com/watch?v=20j1w1nFU6Y"

# 2021-10-07 -     1:43 - 00 Alternatief.TV. Introductiefilm van een nieuw Visionair, Kritisch en Dissident kanaal
sa "https://www.youtube.com/watch?v=nTeyfT4JXvs"

# 2021-10-09 -    53:11 - 67 Meldpunt Vaccinatie registreert de schade.  Ab  Gietelink interviewt Pieter en Jade Kuit
sa "https://www.youtube.com/watch?v=Ipf_4LiHPP4"

# 2021-10-12 -    17:52 - 68 Column Ab Gietelink. Hoe wegen we de morele argumentatie achter het QR Paspoort ?
sa "https://www.youtube.com/watch?v=4xTSfTnKXkY"

# 2021-10-16 -    56:54 - 69 Media zwijgt over de verloren oorlog in Afghanistan. Ab Gietelink ontvangt Stan van Houcke
sa "https://www.youtube.com/watch?v=FNPur9LyXFc"

# 2021-10-20 -    13:40 - 70 Column Ab Gietelink I De Media falen in kritiek op illusiepolitiek in Afghanistan.
sa "https://www.youtube.com/watch?v=RTuWpyBwz5w"

# 2021-10-23 -  1:04:19 - 71 Society 4.0 versus The Great Reset. Prof. Bob de Wit en Ab Gietelink
sa "https://www.youtube.com/watch?v=4yLjAAw75KM"

# 2021-10-27 -     9:26 - 72 Column Ab Gietelink. Crisis rechtsstaat en 19 fracties gebaat bij Extraparlementair Kabinet
sa "https://www.youtube.com/watch?v=Ll65rYUzocM"

# 2021-10-30 -    57:13 - 73 Mordechai Krispijn over Corona, Waku waku. QR code, Demos en Army of Love. Ab Gietelink vraagt
sa "https://www.youtube.com/watch?v=PVNx-JYiX5A"

# 2021-11-05 -     6:14 - 75 Column Ab Gietelink. De Begroetingsrevolutie in Coronatijd.
sa "https://www.youtube.com/watch?v=P9bV6pg9l88"

# 2021-11-11 -    59:06 - 77 Metje Blaak: Een leven in prostitutie en kunst. Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=HcPm-uFLYzE"

# 2021-11-16 -     8:55 - 78 Column Ab Gietelink. Demonstratie 7 November. Welke koers kiest het Coronaprotest?
sa "https://www.youtube.com/watch?v=M5yPUYZ-LEg"

# 2021-11-19 -     1:52 - 79 Fragment Ab Gietelink. De aanval op het vrouwelijk lichaam.
sa "https://www.youtube.com/watch?v=9gT1gvELzAU"

# 2021-11-20 -  1:11:35 - 80  We maken de Balans op met Maurice de Hond. Ab Gietelink interviewt.
sa "https://www.youtube.com/watch?v=i6uyJK9yMKI"

# 2021-11-26 -    53:55 - 81 De media kleurt en manipuleert de werkelijkheid. Ab Gietelink interviewt Cees Hamelink
sa "https://www.youtube.com/watch?v=NmUpGSmVDkY"

# 2021-11-29 -    18:17 - 82 Column Ab Gietelink. De Opstand van de Jongeren vs Excessief politiegeweld en eenzijdige media.
sa "https://www.youtube.com/watch?v=QS-t_UVBNgQ"

# 2021-12-02 -    10:45 - 83 Column Ab Gietelink. Krijgen ongevaccineerden met antistoffen met bloedtest een QR code ?
sa "https://www.youtube.com/watch?v=BRMmY7ZxELM"

# 2021-12-05 -    46:40 - 84 Ionisator schept virusvrije ruimten. Waterstofgas heeft Toekomst.  Ab Gietelink en Ton Rademaker
sa "https://www.youtube.com/watch?v=B7eR4YIAHNg"

# 2021-12-10 -    55:13 - 85 Wij streven naar Basisdemocratie en Referendum.  Ab Gietelink interviewt Niesco Dubbelboer
sa "https://www.youtube.com/watch?v=QLtP0EYOwTo"

# 2021-12-13 -     8:35 - 86 Persconferentie met nieuwe maatregelen. Theatermaker Ab Gietelink en Acteur Marcel Schouwstra.
sa "https://www.youtube.com/watch?v=SH5az_kxawc"

# 2021-12-17 -     1:35 - 87 Intro Column Ab Gietelink. SOS. CBS meldt aanhoudende oversterfte. Waar komt die vandaan?
sa "https://www.youtube.com/watch?v=h_J9QMZ5ICw"

# 2021-12-18 -     9:12 - 88 Column Ab Gietelink. Het Omikrontijdperk: Noodscenario of afschaffing van de maatregelen ?
sa "https://www.youtube.com/watch?v=FvRoxvg88F0"

# 2021-12-20 -    46:00 - 89  Willem Engel over zijn Dissertatie, van Ranst, Rechtszaken en Omikron. Ab Gietelink interviewt.
sa "https://www.youtube.com/watch?v=0ZpScQEO9VM"

# 2021-12-25 -     7:25 - 90 Kersttoespraak van de Nieuwe Minister-President. Performance Ab Gietelink
sa "https://www.youtube.com/watch?v=G-Vbk3jLIV8"

# 2021-12-28 -    42:01 - 91 'Coronabeleid heeft weinig wetenschappelijke onderbouw'. Ab Gietelink interviewt Dr. Peter Borger
sa "https://www.youtube.com/watch?v=HEMh6QWtKI0"

# 2022-01-02 -  1:02:09 - 92 Filosofische reflecties op het Coronatijdperk door Prof. René ten Bos. Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=GsU_Bwvburw"

# 2022-01-08 -    19:24 - 93 Brief van het Museumplein aan Burgemeester Halsema I Ab Gietelink
sa "https://www.youtube.com/watch?v=i2T22CjxjdI"

# 2022-01-17 -    12:20 - 94 Het OMT is het Hart van de Virologische Dictatuur
sa "https://www.youtube.com/watch?v=aCbLlfwyNjI"

# 2022-01-24 -     7:01 - 95. Engeland bleef open tijdens Omikrongolf. Nederlandse Lockdown was zinloos. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=qkQ-wxbm0AI"

# 2022-01-29 -    48:27 - 96  De Andere Krant durft dissident nieuws te brengen.  Ab Gietelink interviewt Sander Compagner
sa "https://www.youtube.com/watch?v=z1GriA4NHU4"

# 2022-02-01 -    51:10 - 97 Tom de Ket (Verleiders) over cancelcultuur en troostkunst. Ab Gietelink interviewt.
sa "https://www.youtube.com/watch?v=KDvkcnqzVS0"

# 2022-02-05 -    35:47 - 99 Hart voor Vrijheid is coronakritisch en links-midden. Pim van Galen en lijsttrekker Ab Gietelink
sa "https://www.youtube.com/watch?v=rBRYWaWHEKE"

# 2022-02-05 -     7:33 - 98. Ik heb Omikron ! /Column Ab Gietelink
sa "https://www.youtube.com/watch?v=28rWMgzFQvU"

# 2022-02-13 -    54:10 - 100 MH17 proces is moreel laakbaar en rust op onvoldoende bewijs. Ab Gietelink en Eric van de Beek.
sa "https://www.youtube.com/watch?v=SafM8NcR6nQ"

# 2022-02-27 -    11:56 - 101 Viroscience Lab van Erasmus MC wil nieuw ‘’hoog risico’’ Lab in Rotterdam I Ab Gietelink
sa "https://www.youtube.com/watch?v=gJHubAzVOTs"

# 2022-03-04 -    22:06 - 102. Stop de Navo expansie. Stop de EU Embargo's. Een Pacifistisch Manifest  I Ab Gietelink
sa "https://www.youtube.com/watch?v=Sz-IQ5weBlk"

# 2022-03-07 -  1:05:14 - 103  Wat zijn de oorzaken van de Oekraine oorlog?   Ab Gietelink interviewt Marie-Therese ter Haar
sa "https://www.youtube.com/watch?v=H1Jv8eEaje8"

# 2022-03-13 -    45:16 - 104. Hart voor Vrijheid Amsterdam, Corona kritisch. Antiautoritair en Links. Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=eyfvJf7yDxY"

# 2022-03-17 -    15:06 - 105. Vrede komt pas als het Westen Oekraïne aanzet tot rechtvaardig compromis. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=Qr3V3QjH83c"

# 2022-03-24 -     5:51 - 106. Intro televisietoespraak Poetin 21-02-2022. In Nederlands voorgelezen door Ab Gietelink
sa "https://www.youtube.com/watch?v=Ys8tsIzThic"

# 2022-03-26 -     9:20 - 107 Open brief aan Rechtbank Den Haag over burgerrechtenactivist Willem Engel. Brief Ab Gietelink
sa "https://www.youtube.com/watch?v=KlgRSuMLkSg"

# 2022-03-29 -    10:21 - 108. Wat deed het Westen fout? Welke vredesregeling voor Oekraïne is haalbaar? Column Ab Gietelink
sa "https://www.youtube.com/watch?v=ncXUSfXL8x0"

# 2022-04-02 -     6:09 - 109. Docu ‘Ukraine on Fire’ over Maidanrevolutie schetst oorzaken Oekraïne oorlog.  Ab Gietelink
sa "https://www.youtube.com/watch?v=Sgkw1YUSqeU"

# 2022-04-06 -  1:16:08 - 110. Interview met Aleksander Sjoelgin, de Russische Ambassadeur in Nederland, door Ab Gietelink
sa "https://www.youtube.com/watch?v=auBrkcn5QGQ"

# 2022-04-09 -    10:51 - 111. Wat wil Poetin? Wat zegt het Russisch persbureau TASS ? Column Ab Gietelink
sa "https://www.youtube.com/watch?v=xXTKvO5CfbM"

# 2022-04-15 -     6:22 - 112. Nederlandse internetproviders censureren Russische zenders van RT. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=Y2xUIgobY60"

# 2022-04-16 -     7:52 - 113 Hoe zou Jezus van Nazareth oordelen over Coronacrisis en Oekraïneoorlog? Paascolumn Ab Gietelink
sa "https://www.youtube.com/watch?v=JW-CCt4-pck"

# 2022-04-22 -    57:02 - 114 Hans Siepel: Klokkenluider over de Nederlandse bestuurscultuur. Ab Gietelink interviewt.
sa "https://www.youtube.com/watch?v=KEdqYVteArc"

# 2022-04-24 -     8:50 - 115 Open Brief aan President Zelenski. Auteur Ab Gietelink
sa "https://www.youtube.com/watch?v=R4GSBO_3Hnw"

# 2022-04-27 -     8:43 - 116. Regering Scholz streeft naar Duitse herbewapening en vaccinatieplicht. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=xROyQ3ZuXDY"

# 2022-04-30 -  1:06:22 - 117 Feiten in Oekraïne waar de 'Mainstream Media' over zwijgen. Ab Gietelink met Prof. Kees vd. Pijl
sa "https://www.youtube.com/watch?v=MNOGy1fEkRk"

# 2022-05-04 -  1:01:22 - 118. Dissidente reflecties over Rusland, Oekraïne en het Westen. Ab Gietelink met Prof. René ten Bos
sa "https://www.youtube.com/watch?v=4bn3V2LWe5g"

# 2022-05-07 -    11:54 - 119. Westen miskent zelfbeschikkingsrecht van de Krim. Opinieartikel Ab Gietelink
sa "https://www.youtube.com/watch?v=b4M27Uv6gXk"

# 2022-05-12 -    10:02 - 120 Herstelt Elon Musk met Twitter de Vrijheid van Meningsuiting op sociale media? door Ab Gietelink
sa "https://www.youtube.com/watch?v=fNUiHkuxD_0"

# 2022-05-14 -    37:34 - 121 Integrale Televisierede: Poetin 24 Febr. 2022 met inleiding door voorlezer Ab Gietelink.
sa "https://www.youtube.com/watch?v=xEUqdOmLFYY"

# 2022-05-19 -     5:16 - 122 Militaire dienstplicht bij Corona en Oekraïne is aanval op Burgerrechten. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=EualDxSQHOQ"

# 2022-05-21 -  1:04:30 - 123 De Sanctieoorlog faalt. De EU bevolking betaalt. Ab Gietelink met Frank Knopers
sa "https://www.youtube.com/watch?v=ZSCIV83NC0A"

# 2022-05-25 -    10:10 - 124 Voert Rusland in Oost-Oekraïne een bevrijdingsoorlog? Column Ab Gietelink.
sa "https://www.youtube.com/watch?v=B_O_J4FkyiM"

# 2022-05-28 -    19:39 - 125 NAVO expansie met Finland en Zweden verhoogt nucleaire dreiging. Column Ab Gietelink.
sa "https://www.youtube.com/watch?v=yef4ehc-aN4"

# 2022-05-31 -     9:40 - 126 Zelensky verbood 11 partijen en liet oppositieleider Medvedchuk opsluiten. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=OTJr82mB1t0"

# 2022-06-05 -     6:52 - 127  Westerse sanctieoorlog. Oekraineoorlg en  Lockdowns maken voedselcrisis. Column Ab Gietelink.
sa "https://www.youtube.com/watch?v=WxcYbOFy6xg"

# 2022-06-08 -    17:03 - 128 Internat. Strafhof is eenzijdig Westers/Oekraïens en moet worden afgeschaft. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=XnQAO6IKDss"

# 2022-06-13 -    12:13 - 129 Brief aan Zelensky. NLReferendumvoorstel: Stop bewapening en sanctieoorlog. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=uvf44E9VFU4"

# 2022-06-17 -  1:05:33 - 130  Crisis in onze economie Waarom en Hoe? Wat te doen?  Ab Gietelink en Eric Mecking
sa "https://www.youtube.com/watch?v=hMIP1M6coKk"

# 2022-06-22 -  1:11:10 - 106A Integrale televisietoespraak van Poetin 21-02-2022. In Nederlands voorgelezen door Ab Gietelink
sa "https://www.youtube.com/watch?v=u98fDVVnOE8"

# 2022-06-25 -  1:00:32 - 131 Wat willen de inwoners van Oost Oekraine? Ab Gietelink zoomt met reporter Sonja van den Ende.
sa "https://www.youtube.com/watch?v=wMJfZ78cSN0"

# 2022-06-29 -    12:28 - 132 Westerse media selecteren, kleuren en manipuleren informatie.  Analyse Ab Gietelink
sa "https://www.youtube.com/watch?v=I3PcGvPETe0"

# 2022-07-03 -  1:12:28 - 133 De wereldeconomie sinds 1944 en hoe nu verder? Ab Gietelink interviewt Sander Boon
sa "https://www.youtube.com/watch?v=4qd0g35iw7Q"

# 2022-07-08 -    15:51 - 134 Meneer Rutte, Stop wapens en sancties! Tijd voor opsplitsing van Oekraine! Brief Ab Gietelink
sa "https://www.youtube.com/watch?v=OSNOHXs9PZk"

# 2022-07-16 -  1:12:50 - 136 Hoe oordeelt SP over Referenda en Oekraïne oorlog? Ab Gietelink met 2e Kamerlid Jasper van Dijk.
sa "https://www.youtube.com/watch?v=5Wtvo2BPjWY"

# 2022-07-21 -    13:09 - 137 Nederland stelt sanctieoorlog Rusland boven energiebelang eigen bevolking. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=8KALLdVR9fI"

# 2022-07-26 -     8:10 - 138 Amsterdam wil verbanning van Wallen-prostitutie en introductie van wietpas. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=TlDL4pgT7dI"

# 2022-07-30 -    19:09 - 139 BRICS landen dagen Westerse dominantie uit. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=1a8Nu6o6yTQ"

# 2022-08-03 -    19:05 - 140 De Tragedie van Evropa 1e Deel. Een politiek sprookje van Ab Gietelink
sa "https://www.youtube.com/watch?v=RfGYfwSncio"

# 2022-08-05 -    18:46 - 141 De Tragedie van Evropa. 2e Deel  De broedertwist van Vladimir en Volodymir. Ab Gietelink
sa "https://www.youtube.com/watch?v=-lupn5d_NEA"

# 2022-08-10 -  1:19:18 - 142 Hoe het Russisch denken te begrijpen? Ab Gietelink interviewt Prof. Evert van der Zweerde
sa "https://www.youtube.com/watch?v=qzyQ7z2mORU"

# 2022-08-14 -  1:00:07 - 143 Rusland is positief over haar toekomst. Ab Gietelink interviewt zakenman Peter van Stigt
sa "https://www.youtube.com/watch?v=aGzbNJ4JjL4"

# 2022-08-26 -    55:12 - 144 Stikstof. Prof. Han Lindeboom. geeft alternatieven. Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=GQE7zFqCugE"

# 2022-08-31 -    11:59 - 145 Novorossiya of hoe Oekraïne op te delen? Column Ab Gietelink
sa "https://www.youtube.com/watch?v=yHBW1HFvL2M"

# 2022-09-03 -    49:17 - 146 Blckbx oprichter en TVmaker Flavio Pasquino over alternatieve media.  Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=ynIjf33I230"

# 2022-09-10 -    43:45 - 147 Van Bioboer naar LabVoedsel ?  Ab Gietelink interviewt Elze van Hamelen
sa "https://www.youtube.com/watch?v=_b8uomKFgUI"

# 2022-09-16 -  1:03:25 - 148. 5G schept gezondheidsrisico's en surveillancestaat. Ab Gietelink interviewt Sylvia Slegers
sa "https://www.youtube.com/watch?v=rUq6HufklC4"

# 2022-09-21 -    10:08 - 149 Het Stikstofdebat in 25 Kernbegrippen en namen ! Woordenlijst door Ab Gietelink
sa "https://www.youtube.com/watch?v=QIMVr8l848M"

# 2022-09-24 -  1:00:31 - 150 Alternatieven voor het Stikstofbeleid. Ab Gietelink interviewt Prof. Johan Sanders.
sa "https://www.youtube.com/watch?v=P0rFKkofCHs"

# 2022-09-27 -     9:46 - 151 Hoe had Gorbatsjov als Westers leider de Oekraïnecrisis opgelost ? Column Ab Gietelink
sa "https://www.youtube.com/watch?v=ycMOb1USZLk"

# 2022-09-30 -     9:06 - 152 Nordstream. Wie pleegde de terreuraanslag en waarom? Wat zijn de gevolgen ? Column Ab Gietelink
sa "https://www.youtube.com/watch?v=1_EPn5oY30Q"

# 2022-10-02 -    12:16 - 153 Wil de meerderheid in de Referenda-gebieden bij Rusland? Column Ab Gietelink
sa "https://www.youtube.com/watch?v=Lcktlxhu99Y"

# 2022-10-08 -    11:32 - 154 Hoe de Nederlands/ Europese sanctieoorlog ontploft in ons eigen gezicht. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=yX2MsNH_0y8"

# 2022-10-10 -     8:16 - 155 Troonrede. Waarom de Regering Nederland in een destructieve spiraal brengt? Column Ab Gietelink
sa "https://www.youtube.com/watch?v=kevbhJB7RnQ"

# 2022-10-15 -     9:38 - 156 Oekraïne, Rusland en het Westen zitten in zelfvernietigende spiraal. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=4PAPFlJZHJA"

# 2022-10-18 -    12:04 - 157 Brief aan vicepremier Kaag. D66 vernietigt haar eigen  erfgoed. Brief Ab Gietelink
sa "https://www.youtube.com/watch?v=WnV5C3Gl93g"

# 2022-10-21 -    14:00 - 158 Manifest Stop de wapenleveranties, sancties en laat referenda beslissen ! Tekst Ab Gietelink
sa "https://www.youtube.com/watch?v=3AIZZOeTatM"

# 2022-10-24 -    58:22 - 159 De Slag om Oekraïne. Ab Gietelink interviewt Prof. Kees van der Pijl
sa "https://www.youtube.com/watch?v=VoB0qVPtiiE"

# 2022-10-29 -    10:14 - 160 Premier Rutte is NLoorlogshitser nummer 1. Brief van Ab Gietelink
sa "https://www.youtube.com/watch?v=pHRW6wl0GII"

# 2022-11-05 -    11:53 - 161 Vermeend antisemitisme David Icke overschaduwt vredesdemonstratie. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=ehqpbCn6-g8"

# 2022-11-07 -     7:12 - 162 Elon Musk wil Vrijheid op Twitter en Vrede met Rusland ! Column Ab Gietelink
sa "https://www.youtube.com/watch?v=nLJPVisYZDs"

# 2022-11-12 -    47:25 - 163 Media voert propagandaoorlog tegen satan Poetin. Ab Gietelink interviewt Prof. Cees Hamelink.
sa "https://www.youtube.com/watch?v=bp7cWVTxctk"

# 2022-11-16 -     7:49 - 164 Hoe Vrede met Rusland te realiseren? 7 Voorstellen. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=OtmA6oroGWQ"

# 2022-11-20 -    31:40 - 165 Ruslandkenner ter Haar:"Referendacijfers in Russisch-Oekraine realistisch!'' Ab Gietelink vraagt
sa "https://www.youtube.com/watch?v=Pxc1oesQbro"

# 2022-11-23 -    13:01 - 166 Maak niet het voetbal en cultuur tot instrument van embargo en oorlog! Column Ab Gietelink
sa "https://www.youtube.com/watch?v=bH5MkscgzYY"

# 2022-12-01 -    11:28 - 167 Beschadigde Arib was tevens voorzitter enquêtecommissie coronamaatregelen. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=tzgBcS7rYYY"

# 2022-12-04 -     7:29 - 168 VN topadviseur Sachs bekritiseert Oekraïneverhaal en herkomst coronavirus. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=WoipsqWb58s"

# 2022-12-09 -     9:25 - 169 Maak de digitale euro anoniem en niet programmeerbaar. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=NvNI_FnREX0"

# 2022-12-11 -    52:23 - 170 Europa vernietigt zichzelf! Ab Gietelink interviewt journalist Stan van Houcke.
sa "https://www.youtube.com/watch?v=ueSwhqx4Zvg"

# 2022-12-15 -     7:34 - 171 The Twitter Files tonen censuursystemen sociale media. Artikel Ab Gietelink
sa "https://www.youtube.com/watch?v=vN839I_eplc"

# 2022-12-18 -    10:36 - 172 Mevr. Von der Leyen: U escaleert de oorlog ! Brief Ab Gietelink
sa "https://www.youtube.com/watch?v=FUyBw9xdl1U"

# 2022-12-23 -    11:00 - 173 Mediafixatie op ‘grensoverschrijdend gedrag’ leidt tot schandpaalcultuur!. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=1Sk2WYeJX2A"

# 2022-12-27 -     9:58 - 174 Oekraïne glijdt af naar dictatuur. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=jMhyYW2PNpI"

# 2023-01-06 -    58:23 - 175  Dissidente berichten uit Moskou. Ab Gietelink interviewt Sonja van den Ende
sa "https://www.youtube.com/watch?v=8j9aJdD9nGM"

# 2023-01-10 -    10:48 - 176 Laat een referendum onder VN toezicht beslissen over territoriale claims. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=78JhM7ATe1M"

# 2023-01-13 -    11:38 - 177 Coronaprotest, antiglobalisme & vredesactivisme breken Links-Rechts schema. Essay Ab Gietelink.
sa "https://www.youtube.com/watch?v=2hV8j3YnkZw"

# 2023-01-18 -     9:15 - 178 Reconstructie: Rusland vroeg 7 jaar om uitvoering Minskakkoorden. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=lohJPOrihOY"

# 2023-01-27 -     5:56 - 179 Journalist Chemeris: Oekraine is een totalitaire staat!. Artikel Ab Gietelink
sa "https://www.youtube.com/watch?v=Gb2kcXcYYzk"

# 2023-01-31 -     8:56 - 180 Elon Musk: ''Alle Complottheorieën over Twitter blijken waar!' Column Ab Gietelink
sa "https://www.youtube.com/watch?v=wO7lzg0yeT0"

# 2023-02-04 -    53:52 - 181 Het Wokisme bijt in haar eigen staart ! Ab Gietelink met UvA wetenschapper Laurens Buijs.
sa "https://www.youtube.com/watch?v=r4uQ7ffxYCg"

# 2023-02-11 -    56:24 - 182  Wat willen Oost-  en West Oekraïners ? Ab Gietelink in gesprek met Marie-Therese ter Haar.
sa "https://www.youtube.com/watch?v=CYpIcL4I08M"

# 2023-02-17 -     9:43 - 183 Vredesdemonstratie tegen wapenleveranties Oekraïne. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=nbymf4igAic"

# 2023-02-22 -     9:16 - 184 De pot verwijt de ketel of wat deed het westen fout? Column Ab Gietelink
sa "https://www.youtube.com/watch?v=4R-48JbOL4w"

# 2023-02-24 -     4:01 - 185 WO1 14-18 'Het wijnglas'', pacifistisch lied van Dirk Witte. Door Ab Gietelink & Theater Nomade
sa "https://www.youtube.com/watch?v=sZ1houaw2JM"

# 2023-02-26 -  1:23:22 - 186 Bedreigt de VS aanslag op Nordstream de NAVO? Ab Gietelink interviewt Prof Kees van der Pijl
sa "https://www.youtube.com/watch?v=zQ5yvOVbsMQ"

# 2023-03-01 -    22:19 - 187 1e Vredesdemonstratie in NL Zo 19 Febr. Reportage Hugo Gietelink
sa "https://www.youtube.com/watch?v=HNZMjI-BvYU"

# 2023-03-03 -     8:07 - 188 Geachte Bondskanselier, Brief over Nordstream en Stalingrad. Afzender Ab Gietelink.
sa "https://www.youtube.com/watch?v=LEOK01KYuFA"

# 2023-03-06 -    57:34 - 189 Complotcatalogus. Hoe complotdenker te worden? Ab Gietelink interviewt Patrick Savalle.
sa "https://www.youtube.com/watch?v=BMCZ__u-A7s"

# 2023-03-11 -    35:39 - 190 Wie Is Max de Fakkeldrager en hoe beoordelen we hem? Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=Sz1dBaL6NT0"

# 2023-03-17 -     9:03 - 191 Wapenleveranties Oekraïne leidt tot ontheemding bij klassiek linkse kiezers. Ab Gietelink
sa "https://www.youtube.com/watch?v=Z7RzVrSbk6I"

# 2023-03-19 -    10:05 - 192 Was Capitool 6 jan. ‘’dodelijke opstand’’ of ‘’grotendeels vreedzame chaos’’?  Ab Gietelink
sa "https://www.youtube.com/watch?v=LXLSvAW1I-o"

# 2023-03-21 -  1:00:32 - 193 Wie is Doegin? ’’Het brein van Poetin’’? Ab Gietelink interviewt Joost Niemoller
sa "https://www.youtube.com/watch?v=2Kbjf5dkMwk"

# 2023-03-25 -     2:32 - 194 Lied: Minister-president slaap zacht!  Ab Gietelink. Van Syrie naar Oekraine.
sa "https://www.youtube.com/watch?v=S5ya_IpJKsM"

# 2023-03-28 -    52:10 - 195 Stan van Houcke: 'VS verloor alle oorlogen sinds 1945. Incl. Oekraine. Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=-RBXhe-FDjQ"

# 2023-04-01 -     9:45 - 196 BBB = realistisch! Meer boeren, gezonder voedsel, minder gif en minder stikstof. Ab Gietelink
sa "https://www.youtube.com/watch?v=7HcU4CqMWkU"

# 2023-04-03 -  1:03:19 - 197 Verdiende BPOC haar donaties?  Oordeelt u zelf over hun vaccinatiemeldpunt ! Ab Gietelink.
sa "https://www.youtube.com/watch?v=g_RHr1iIxGw"

# 2023-04-07 -     8:12 - 198 Hoe zou Jezus van Nazareth oordelen over Coronacrisis en Oekraïneoorlog? Paascolumn Ab Gietelink
sa "https://www.youtube.com/watch?v=zx28OvtX_vU"

# 2023-04-10 -  1:04:42 - 199 Handen af van de Wallen!  Ab Gietelink interviewt oud-Sexwerkers Mariska Majoor en Metje Blaak
sa "https://www.youtube.com/watch?v=kRRC9zuhDk4"

# 2023-04-14 -    11:09 - 200 Strafzaak Trump bedreigt Amerikaanse democratie. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=Y_f4DkVCD1w"

# 2023-04-17 -     6:15 - 201 Voer 0% Btw-tarief voor groente en fruit in ! Ab Gietelink
sa "https://www.youtube.com/watch?v=HDRXk2zsEOU"

# 2023-04-20 -    49:14 - 202 Police for freedoms'' Dennis Spaanstra met kritiek op politieorganisatie. Ab Gietelink ontvangt
sa "https://www.youtube.com/watch?v=yMNFXkbhJbw"

# 2023-04-28 -    10:02 - 203 NL F16 piloten vuurden 2188 raketbommen af in Irak en Syrië. Hoeveel slachtoffers? Ab Gietelink
sa "https://www.youtube.com/watch?v=YOotllw_7LU"

# 2023-05-01 -    57:16 - 204 Wat gaat AI, ChatGPT en deeplearning ons brengen?  Ab Gietelink ontvangt Vincent Everts.
sa "https://www.youtube.com/watch?v=v38sTJ4suV0"

# 2023-05-04 -     2:58 - 205. Herdenking 4 en 5 mei. Het Lied der Achttien Dooden. Performance Ab Gietelink
sa "https://www.youtube.com/watch?v=e62TnFLEjnc"

# 2023-05-06 -    13:17 - 206 Mijn nieuwe boek beschikbaar! Tunnelvisies of Hoe realiseren we Vrede in Oekraine? Ab Gietelink
sa "https://www.youtube.com/watch?v=FX-1qfVhGbQ"

# 2023-05-10 -    11:09 - 207 Hoe hadden we Nederlands-Indië vreedzaam kunnen overdragen? Ab Gietelink
sa "https://www.youtube.com/watch?v=54243bp-XWU"

# 2023-05-19 -    10:23 - 208 Oud-president Medvedev zegt wat Russische hardliners denken. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=-FpjWfh_h-s"

# 2023-05-23 -     6:32 - 209 Richard de Mos verdient na vrijspraak eerherstel OM en terugkeer in Haags B&W. Ab Gietelink
sa "https://www.youtube.com/watch?v=OkNiwDp23Gk"

# 2023-05-27 -    53:38 - 210 Pepijn van Houwelingen (FvD) over Japan, EU, WPG en Oekraine. Ab Gietelink Interviewt.
sa "https://www.youtube.com/watch?v=fNq_FCYhrhU"

# 2023-06-04 -    12:26 - 211 Hoe kwamen we in de Oekraïne-oorlog? Hoe komen we er weer uit? Ab Gietelink
sa "https://www.youtube.com/watch?v=U8K7XqTwOEo"

# 2023-06-10 -    25:52 - 212 Vredestoespraak Kennedy uit 1963 inspiratiebron voor Oekraïne. Ab Gietelink
sa "https://www.youtube.com/watch?v=MCa443ypHJ0"

# 2023-06-13 -    46:46 - 213 Prof. Bob de Wits' Democratie 4.0 is vervolg op Society 4.0  Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=lxMJey9R85I"

# 2023-06-16 -    11:31 - 214 Herteken de grenzen van Kosovo met Servie !  Ab Gietelink
sa "https://www.youtube.com/watch?v=Tg5Fj8wRZjQ"

# 2023-06-19 -  1:02:22 - 215 De Tragedie van Oekraine. Ab Gietelink ontvangt Prof. Kees van der Pijl.
sa "https://www.youtube.com/watch?v=89Z3X14_330"

# 2023-06-23 -     7:35 - 216 Poetin opent SPIEF '23: ''Russische economie groeit 1,5%''. Ab Gietelink
sa "https://www.youtube.com/watch?v=UpYICd3rbvw"

# 2023-06-26 -     7:06 - 217 ‘Tucker on Twitter’ krijgt meer views dan MSM in VS.  Ab Gietelink.
sa "https://www.youtube.com/watch?v=5Mh4Mu_xM1k"

# 2023-06-30 -    13:24 - 218 Wagner muiterij tegen de afschaffing van hun Russische subsidies. Ab Gietelink
sa "https://www.youtube.com/watch?v=USdu-TGzlZY"

# 2023-07-02 -    59:53 - 219 Hoe gaat het nu in Rusland? Ab Gietelink ontvangt zakenman Peter van Stigt
sa "https://www.youtube.com/watch?v=DQVqq7KdZJA"

# 2023-07-09 -     8:41 - 220 Globale expansie NAVO vergroot kans op 3e Wereldoorlog. Ab Gietelink
sa "https://www.youtube.com/watch?v=-DKHgcUVj6c"

# 2023-07-16 -     7:26 - 221 Ukrainian PR Army voorziet westerse media van het politiek correcte nieuws. Ab Gietelink
sa "https://www.youtube.com/watch?v=-FsGm5hTDzc"

# 2023-07-23 -     3:59 - 222 Oekraine is in 2014 gebroken. Opdeling is noodzakelijk. Ab Gietelink bij ON
sa "https://www.youtube.com/watch?v=MtINguWNtlg"

# 2023-07-29 -    10:44 - 223 Rusland: ""Westen kwam graandeal niet na!"" Ab Gietelink
sa "https://www.youtube.com/watch?v=32TjnePGOd4"

# 2023-08-02 -    55:11 - 224 Zomergasten Alternatief 1: Prof.Jean Tilly, democratie, corona en kraakbeweging. Ab Gietelink
sa "https://www.youtube.com/watch?v=IAw9SQsnlUo"

# 2023-08-05 -     4:06 - 225 Vredesprotestsong: Zeg me waar de bloemen zijn? Liedtekst en uitvoering Ab Gietelink
sa "https://www.youtube.com/watch?v=FHQc1cYI220"

# 2023-08-10 -  1:02:09 - 226 Zomergasten Alternatief 2: Prof. Kees vd. Pijl over Polen en de Informatieoorlog. Ab Gietelink
sa "https://www.youtube.com/watch?v=yAvgtRfQRdY"

# 2023-08-15 -  1:10:25 - 227 Kritiek van Oekraïnse en Russische vrouwen.  Ab Gietelink interviewt Elena, Natalia en Elena.
sa "https://www.youtube.com/watch?v=HcK7kFRHndY"

# 2023-08-19 -  1:01:36 - 228 Oud-minister Jan Pronk: 'Internationale rechtsorde gebroken''. Ab Gietelink en Maurice van Ulden
sa "https://www.youtube.com/watch?v=gL00wVqHYkM"

# 2023-08-22 -    10:29 - 229 Is aanklacht tegen Arib instrument bij ondermijning parlementaire enquête corona?  Ab Gietelink
sa "https://www.youtube.com/watch?v=9IjpJjvXHo0"

# 2023-08-24 -    47:25 - 231 Hoe onderhandelen we over vrede in Oekraïne? Ab Gietelink interviewt Paul Meerts
sa "https://www.youtube.com/watch?v=T_N3EHbJC_k"

# 2023-08-24 -     8:20 - 230 Wie pleegde de vliegtuigaanslag op Prigozjin? Ab Gietelink
sa "https://www.youtube.com/watch?v=a3mMi0gWr08"

# 2023-08-28 -    10:35 - 232 Nieuw Sociaal Contract (NSC) van Omzigt gunstig voor kritiek en oppositie. Ab Gietelink
sa "https://www.youtube.com/watch?v=YU8xuwLVfDs"

# 2023-08-31 -  1:05:43 - 233 Waarom steunt NL de oorlog in Oekraïne? Vredesactivist  Jakob de Jonge en Ab Gietelink
sa "https://www.youtube.com/watch?v=u_TUdeKdOmc"

# 2023-09-03 -    51:13 - 234 Terugkijken op corona.  Toekomst met WHO-verdrag en Censuurwet. Ab Gietelink met Jeroen Pols
sa "https://www.youtube.com/watch?v=BWidu488OcI"

# 2023-09-08 -  1:21:37 - 235 Russian Ambassador, Alexander Shulgin about Ukraine. Interview Ab Gietelink
sa "https://www.youtube.com/watch?v=nLrlZsae5hY"

# 2023-09-12 -     4:22 - 236 Max Havelaar slottekst: ''Ik wil gelezen worden''  Performance Ab Gietelink
sa "https://www.youtube.com/watch?v=bmN5meFs4CE"

# 2023-09-15 -    16:58 - 237 BRICS versus Westerse dominantie. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=Bf_jmitd2NQ"

# 2023-09-19 -    19:16 - 238 Wie is Zelensky? Van televisiester tot proxy-dictator. Analyse Ab Gietelink
sa "https://www.youtube.com/watch?v=QWxtTmVFLwM"

# 2023-09-23 -    54:09 - 239 Hoe realiseren we Vrede in Oekraine?  Jelle van Baardewijk (DNW) interviewt Ab Gietelink
sa "https://www.youtube.com/watch?v=Eahx2K7tYZg"

# 2023-09-29 -     7:39 - 240  VN faalt. Geef Nagorno Karabach zelfbeschikking ! Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=5frGUIaES-k"

# 2023-10-06 -    49:10 - 241 Dedollarisatie, inflatie, krimp en herinvoering gulden. Ab Gietelink interviewt Jelena Postuma
sa "https://www.youtube.com/watch?v=cKMRm6cohvI"

# 2023-10-10 -    42:43 - 242 Journalistenforum De Andere Krant #1. Ab Gietelink, Sander Compagner, Eric vd Beek, Wouter Meijs
sa "https://www.youtube.com/watch?v=_DbOWHt9xtQ"

# 2023-10-13 -    12:14 - 243 Inzake Palestina staat Nederland aan de foute kant van de Geschiedenis. Ab Gietelink
sa "https://www.youtube.com/watch?v=fLDZ7jnFPIg"

# 2023-10-15 -    22:03 - 244 Reisverslag: Jezus in Israel & Palestina. Door Ab Gietelink
sa "https://www.youtube.com/watch?v=_7pfkWmiu0c"

# 2023-10-18 -  1:07:59 - 245  Geschiedenis van Israël & Palestina. Ab Gietelink in samenspraak met Prof. Kees van der Pijl
sa "https://www.youtube.com/watch?v=kLjYI0Qtaw4"

# 2023-10-20 -     8:06 - 246 Gaza-oorlog geeft film ‘Golda’ over Jom Kipour oorlog (1973) actualiteit. Ab Gietelink
sa "https://www.youtube.com/watch?v=o__HhIyA3Lk"

# 2023-10-22 -     8:56 - 247 Faciliteerde regering Netanyahu doelbewust de Hamasaanval? Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=MS5Ykpk-fB4"

# 2023-10-24 -    52:22 - 248 Journalistenforum De Andere Krant #2. Ab Gietelink, Sander Compagner, Toine Rongen, Ad Nuis
sa "https://www.youtube.com/watch?v=Uq9z7gWJIoM"

# 2023-10-27 -    12:47 - 249 NRC Journalisten verspreiden valse complottheorie over Vredesdemonstratie. Brief Ab Gietelink
sa "https://www.youtube.com/watch?v=zc5fVlP7Loc"

# 2023-10-29 -    22:16 - 250 Gaza, Hamas en Nakba historie. Worden de Palestijnen verdreven? Ab Gietelink
sa "https://www.youtube.com/watch?v=vOFZp0gpCzU"

# 2023-11-01 -  1:00:52 - 251 Linkse vredespolitiek,  Oekraïne en Palestina. Ab Gietelink interviewt Guido van Leemput
sa "https://www.youtube.com/watch?v=kCy5ASIfw-o"

# 2023-11-03 -    12:32 - 252 Premier Rutte, NAVO oorlogshitser #1  Column Ab Gietelink
sa "https://www.youtube.com/watch?v=0ce0b6J87Jo"

# 2023-11-05 -    57:43 - 253 Journalistenforum De Andere Krant #3. Karel Beckman, Erick Overveen, Kees vd Pijl, Ab Gietelink
sa "https://www.youtube.com/watch?v=pnIYAx-rBbQ"

# 2023-11-07 -    55:32 - 254 Medialeugens, Mensenrechten, Oekraïne en Palestina.  Ab Gietelink interviewt prof. Cees Hamelink
sa "https://www.youtube.com/watch?v=oHQF-gF8wyM"

# 2023-11-09 -    11:48 - 255 Hamas: Terreurgroep of verzetsbeweging? Column Ab Gietelink
sa "https://www.youtube.com/watch?v=LcLZNGc2KwM"

# 2023-11-11 -  1:03:14 - 256 Journalist Stan van Houcke met keiharde kritiek op Israel. Interview Ab Gietelink
sa "https://www.youtube.com/watch?v=BuCwgx1mhas"

# 2023-11-13 -     9:37 - 257 Docu ‘Roadmap to Apartheid’ vergelijkt Israëlische en Zuid-Afrikaanse Apartheid. Ab Gietelink
sa "https://www.youtube.com/watch?v=EA8dAc3v1bU"

# 2023-11-15 -    47:19 - 258  Onteigening van Boeren en Vissers. Koers 2030.  Ab Gietelink in gesprek met Elze van Hamelen
sa "https://www.youtube.com/watch?v=iJTvJZnmPxw"

# 2023-11-17 -     7:56 - 259 Wie is Netanyahu? Mr. security of oorlogsmisdadiger?
sa "https://www.youtube.com/watch?v=HzHvq8SHknc"

# 2023-11-19 -    55:56 - 260 Journalistenforum DAK #4. Pieter Stuurman, Barbara Le Noble, Bert Brandsma en Ab Gietelink
sa "https://www.youtube.com/watch?v=dChNx-iuVqM"

# 2023-11-21 -    12:55 - 261 Welke partij moeten we kiezen?  Waarom geen referenda? Ab Gietelink
sa "https://www.youtube.com/watch?v=T28j_hjodaE"

# 2023-11-26 -    15:18 - 262 Historie van Israël & Palestina Deel 1.  Auteur: Ab Gietelink
sa "https://www.youtube.com/watch?v=BZ2fFARFJRA"

# 2023-11-29 -    16:59 - 263 Historie van Israël & Palestina. Deel 2.  Auteur: Ab Gietelink
sa "https://www.youtube.com/watch?v=rEBAxITSwhc"

# 2023-12-01 -    17:37 - 264 Verkiezingsuitslag vraagt rechts Extraparlementair minderheidskabinet. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=rx3Xih7-DhY"

# 2023-12-03 -    15:46 - 265 Wie is Geert Wilders? Wat wil de PVV? Analyse Ab Gietelink
sa "https://www.youtube.com/watch?v=LwYmZG1_UjY"

# 2023-12-05 -    50:42 - 266 Journalistenforum De Andere Krant #5. Willem Ernee, Arjen Pasma, Jeroen Arents en Ab Gietelink
sa "https://www.youtube.com/watch?v=5zFAfVGoEVs"

# 2023-12-08 -    49:42 - 267 PVV grootste partij. Wat te doen? Ab Gietelink interviewt George van Houts.
sa "https://www.youtube.com/watch?v=OiQDp_X6iEQ"

# 2023-12-12 -    29:33 - 268 Wat wil Hamas? Hamas Handvest (Integrale tekst). Voorlezer Ab Gietelink
sa "https://www.youtube.com/watch?v=eQNDKSFgbm8"

# 2023-12-16 -    17:37 - 269 EU expansie met Oekraïne is stap naar nieuwe oorlog. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=WEy9ZcrrpJo"

# 2023-12-18 -    53:08 - 270 Journalistenforum DeAndereKrant #6 Sander Compagner, Karel Beckman, Ido Dijkstra en Ab Gietelink
sa "https://www.youtube.com/watch?v=XBDrKir4aJI"

# 2023-12-21 -  1:04:40 - 271 Wilders, PVV, Nieuwe Democratie en Referendum. Ab Gietelink interviewt Peter Baars
sa "https://www.youtube.com/watch?v=MLj2_UxjoK0"

# 2023-12-24 -    14:40 - 272 Mijn Kerstboodschap. Blijven de dominees van Europa de oorlogen legitimeren? Ab Gietelink
sa "https://www.youtube.com/watch?v=HthOprtvHIM"

# 2023-12-27 -    14:43 - 273 Militaire dienstplicht is ernstige mensenrechtenschending. Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=mznfRGCWdOo"

# 2023-12-30 -    50:19 - 274 Stotteren Is een ademhalingsprobleem ! The Kings'Speech. Ab Gietelink ontvangt Ingrid Del Ferro
sa "https://www.youtube.com/watch?v=7-2mWhA99qU"

# 2024-01-05 -    12:56 - 275 Zwitserland is een referendumdemocratie. Nederland een oligarchische meritocratie 1 Ab Gietelink
sa "https://www.youtube.com/watch?v=GTXDvKuNJ_A"

# 2024-01-07 -    14:52 - 276 Zwitserland is een referendumdemocratie. Nederland een oligarchische meritocratie 2 Ab Gietelink
sa "https://www.youtube.com/watch?v=TAd4TG4QR9w"

# 2024-01-10 -    49:53 - 277 'Israel heeft een Judeo-fascistische regering !' stelt Jaap Hamburger. Interview Ab Gietelink
sa "https://www.youtube.com/watch?v=dJKLOr33vCY"

# 2024-01-13 -     9:26 - 278 Processen tegen Trump bedreigen Amerikaanse democratie. Ab Gietelink
sa "https://www.youtube.com/watch?v=fJVbJCd1yXU"

# 2024-01-15 -  1:04:35 - 279 Wat is historisch Links en Rechts? #1 1789-1917. Presentatie: Ab Gietelink en Kees van der Pijl
sa "https://www.youtube.com/watch?v=cW0YPJu-lBk"

# 2024-01-18 -  1:05:32 - 280 Harry van Bommel over de PVV, de SP, Oost-Europa, Oekraine en Gaza. Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=NpNzLVscp8Q"

# 2024-01-21 -    12:20 - 281 Politie faciliteerde Koranverbranding door Pegida.  Ab Gietelink
sa "https://www.youtube.com/watch?v=zlA3Ey3naSU"

# 2024-01-23 -     7:44 - 282 Leegloop Kabinet Rutte. Wie regeert Nederland eigenlijk? Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=Rz1__fxGvVw"

# 2024-01-26 -  1:22:57 - 283 Wat is historisch Links en Rechts? #2 1917-1991. Prof. Kees vd Pijl en Ab Gietelink
sa "https://www.youtube.com/watch?v=sYb9wiqkJXw"

# 2024-01-28 -     7:43 - 284 Zal Trump Europa van Oekraïne-oorlog verlossen?  Column Ab Gietelink
sa "https://www.youtube.com/watch?v=xObj96CJTXo"

# 2024-01-31 -    50:30 - 285 Hoe verbeteren we de democratie? Ab Gietelink interviewt Rients Hofstra
sa "https://www.youtube.com/watch?v=RYiZpadRHdM"

# 2024-02-03 -    56:21 - 286 Falende Hulpinstanties en Verstoten Vaders. Jeroen Arents, Arthur Victorie en Ab Gietelink
sa "https://www.youtube.com/watch?v=m8XBvBhy7fA"

# 2024-02-06 -    10:17 - 287 Jemen: De burgeroorlog vraagt om 2-Statenoplossing. Analyse Ab Gietelink
sa "https://www.youtube.com/watch?v=DvDmPIJNzWc"

# 2024-02-09 -    11:21 - 288 ‘Imperium USA’ schetst ontluisterende geschiedenis van Amerikaanse wereldmacht. Ab Gietelink
sa "https://www.youtube.com/watch?v=vT-Z4VSzreY"

# 2024-02-12 -  1:33:30 - 289 Wat is historisch Links en Rechts? #3 1991-2024. Presentatie Kees van der Pijl en Ab Gietelink
sa "https://www.youtube.com/watch?v=pbIGzkMh5ZM"

# 2024-02-18 -    14:12 - 290 Argentijnse president Milei is een globalistische ultra-kapitalistische autocraat. Ab Gietelink
sa "https://www.youtube.com/watch?v=KnhgTTeWWvs"

# 2024-02-23 -     9:54 - 291 Navalny was een burgerrechtenactivist. Assange is de westerse Navalny. Ab Gietelink
sa "https://www.youtube.com/watch?v=gdy_i9hIoyE"

# 2024-02-26 -     9:39 - 292 Extraparlementair kabinet. Wat zijn de voordelen? Hoe werkt het? Ab Gietelink
sa "https://www.youtube.com/watch?v=wHWM9sI-5lM"

# 2024-02-29 -    15:10 - 293 Hoe de CIA de wereld destabiliseert. Tekst Prof. Sachs. Voorlezing Ab Gietelink
sa "https://www.youtube.com/watch?v=TnKyf6kayPc"

# 2024-03-02 -  1:23:25 - 294 Alternatief Forum #1 Assange, Navalny, Gaza, Oekraïne. Kees vd Pijl, Stan v Houcke, Ab Gietelink
sa "https://www.youtube.com/watch?v=IY6_iVKwXh4"

# 2024-03-05 -    37:06 - 295 Hamas over 7 okt 2023. Operatie Al-Aqsa Flood. Voorlezer Ab Gietelink
sa "https://www.youtube.com/watch?v=RpwHsWZBCJs"

# 2024-03-08 -    10:23 - 296 Gaza wordt verwoest en uitgemoord. Wat doet de wereld? Ab Gietelink
sa "https://www.youtube.com/watch?v=onWuXGeiWaQ"

# 2024-03-10 -    49:35 - 297 Willem Engel over Oekraïne, Gaza en Pacifisme. Ab Gietelink interviewt.
sa "https://www.youtube.com/watch?v=szZk14wyDcI"

# 2024-03-13 -    15:43 - 298 J''accuse. Stop de steun van politiek en media aan 10 jaar Oekraïense Burgeroorlog. Ab Gietelink
sa "https://www.youtube.com/watch?v=niK2Fd5i340"

# 2024-03-16 -    13:37 - 299 Waarom stemmen Russen voor Poetin? Hoe democratisch is de Russische federatie? Ab Gietelink
sa "https://www.youtube.com/watch?v=VGFNhDnZikY"

# 2024-03-20 -  1:04:01 - 300 Marcel van Silfhout over Joegoslavië jaren 90, Oekraïne en Graan. Ab Gietelink interviewt.
sa "https://www.youtube.com/watch?v=bpSt5E_kvd4"

# 2024-03-23 -    13:23 - 301 Programkabinet = Beter bestuur. Plasterk premier ? Ab Gietelink
sa "https://www.youtube.com/watch?v=-AHIaA_8HVQ"

# 2024-03-26 -  1:09:39 - 302 Misdaden van het Oranje Koningshuis. Ab Gietelink interviewt Frans Peeters.
sa "https://www.youtube.com/watch?v=wW7Zv8nGFGs"

# 2024-03-28 -  1:10:16 - 303 Van Euro Naar Gulden?  Willen we dat?  Waarom en Hoe? Ab Gietelink interviewt Paul Buitink
sa "https://www.youtube.com/watch?v=Mjnd1v6w_vM"

# 2024-03-31 -  1:13:29 - 304 Alternatief Forum #2. Formatie, Oekraïne en Gaza. Ab Gietelink en Kees van der Pijl
sa "https://www.youtube.com/watch?v=hR6e29Ex95Q"

# 2024-04-03 -    13:31 - 305 Terreuraanslag in Moskou. Wie had het motief?  IS of Oekraïne?  Ab Gietelink
sa "https://www.youtube.com/watch?v=Gk8r1FgTrPk"

# 2024-04-06 -    11:51 - 306 Antisemitisme, Islamofobie en Russofobie. Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=2SknS54iGbs"

# 2024-04-09 -  1:09:10 - 307 Huisarts vs Pharma. Welke alterrnatieven zijn er?  Ab Gietelink interviewt Felix van der Wissel.
sa "https://www.youtube.com/watch?v=lLRI-q3PVGQ"

# 2024-04-12 -    15:10 - 308 Het Verraad van Groen Links. Van Vredescollectief tot Oorlogspartij. Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=rOhXT2fErWI"

# 2024-04-15 -  1:12:37 - 309 Alternatief Forum #3. Klaver, Oekraïne en Gaza. Ab Gietelink en Peter Baars
sa "https://www.youtube.com/watch?v=1fE29Z4X3Hc"

# 2024-04-19 -     8:29 - 310 Vredesspeech Dam, Amsterdam. Ab Gietelink
sa "https://www.youtube.com/watch?v=rCBTwEvSh2I"

# 2024-04-23 -    39:20 - 311 Russofobie! Moeten Russische Nederlanders zwijgen? Ab Gietelink interview Natalia Vorontsova
sa "https://www.youtube.com/watch?v=ULaUjnMLQbU"

# 2024-04-27 -     9:21 - 312 ‘Civil War’ geeft dystopisch toekomstbeeld over burgeroorlog in Amerika. Recensie Ab Gietelink
sa "https://www.youtube.com/watch?v=KLNfYLaEde0"

# 2024-04-30 -  1:01:28 - 313 Deep State, MI Complex, MSM, Rothschild en Agenda 2030. Ab Gietelink met Diedert de Wagt
sa "https://www.youtube.com/watch?v=2V5k9X-MvdY"

# 2024-05-24 -    21:22 - 314 Rusland Dagboek #0 Herinneringen 1988-2019. Ab Gietelink
sa "https://www.youtube.com/watch?v=V0y-fO68KO8"

# 2024-05-26 -    19:05 - 315 Rusland Dagboek #1 Kaliningrad. Auteur Ab Gietelink
sa "https://www.youtube.com/watch?v=jN3cpC6wd_0"

# 2024-05-31 -    21:42 - 316 Rusland Dagboek #2. Sankt Petersburg. Auteur Ab Gietelink
sa "https://www.youtube.com/watch?v=qu_Um8EqE3U"

# 2024-06-02 -  1:18:33 - 317 Alternatief Forum #4 Schoof, EU, Gaza en Oekraïne. Ab Gietelink, Kees vd. Pijl en Peter Baars
sa "https://www.youtube.com/watch?v=ZnaSad9TDVY"

# 2024-06-05 -    17:04 - 318 Rusland Dagboek #3. Moskou. Auteur Ab Gietelink
sa "https://www.youtube.com/watch?v=jmfHVWDmK-w"

# 2024-06-07 -    20:21 - 319 Brengt de Europese Unie ons in de 3e Wereldoorlog? Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=SiG_zK1lmxQ"

# 2024-06-09 -    11:28 - 320 Kritische Plasterk krijgt dolksteek. Ex-spion Schoof wordt Premier. Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=VxeF119uKRM"

# 2024-06-12 -  1:04:13 - 321 New Russian Ambassador Vladimir Tarabrin on Ukraine (NL vertaling). Interview Ab Gietelink
sa "https://www.youtube.com/watch?v=0sAnqDRkw6w"

# 2024-06-14 -    13:37 - 322 EU: Lage opkomst en groei scepsis op links en rechts vraagt bescheidener rol EU.  Ab Gietelink
sa "https://www.youtube.com/watch?v=0i5rp12guQU"

# 2024-06-17 -    56:02 - 323 Tom de Ket over zijn locatietheater en de kunstwereld.  Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=AnJePSlayww"

# 2024-06-20 -    17:15 - 324 Rusland Dagboek #4 Vladimir & Suzdal. Ab Gietelink
sa "https://www.youtube.com/watch?v=aaLeoYW8KNg"

# 2024-06-23 -    51:17 - 325 Homeopathie. Hoe werkt het? Hoeveel succes heeft het? Ab Gietelink interviewt Arjen Pasma
sa "https://www.youtube.com/watch?v=LSY_PWk5_cs"

# 2024-06-28 -  1:16:16 - 326 Alternatief Forum #5: Regering, EU, Gaza, Oekraine. Kees vd Pijl, George v Houts, Ab Gietelink
sa "https://www.youtube.com/watch?v=qVoWyxpTeiw"

# 2024-06-30 -    15:07 - 327 Assange: Wat moeten we leren van zijn zaak? Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=SzsEVKz1jL8"

# 2024-07-03 -    19:44 - 328 Rusland Dagboek #5 Tallinn, Estland. Ab Gietelink
sa "https://www.youtube.com/watch?v=l1PPTExmhUM"

# 2024-07-06 -    15:27 - 329 Groeiend verzet in Westerse politiek tegen oorlogssteun Oekraïne. Ab Gietelink
sa "https://www.youtube.com/watch?v=QlO4utpIpQY"

# 2024-07-09 -     3:04 - 330  In 2010 was politiek links ook tegen Hoofddoekjes. Theaterscene door Ab Gietelink
sa "https://www.youtube.com/watch?v=gsl-x-sk-wk"

# 2024-07-12 -    13:42 - 331 Afscheidsbrief aan premier Rutte. Afzender Ab Gietelink
sa "https://www.youtube.com/watch?v=9n1rbQyujoI"

# 2024-07-15 -    12:34 - 332 Oekraïne splijt links Frankrijk. Mélenchon wil vredesregeling. Ab Gietelink
sa "https://www.youtube.com/watch?v=jgr91-pAmSU"

# 2024-07-18 -  1:27:29 - 333 Alternatief Forum #6. Regering, EU, NAVO en Links. Cees Hamelink, Kees vd. Pijl, Ab Gietelink
sa "https://www.youtube.com/watch?v=5hMAtAUSjOo"

# 2024-07-21 -    15:45 - 334 Trump versus Biden/Harris. Analyse Ab Gietelink
sa "https://www.youtube.com/watch?v=TTUjJprIdqE"

# 2024-07-27 -    12:01 - 335 Hezbollah en Israël bewegen richting ‘totale oorlog’! Analyse Ab Gietelink
sa "https://www.youtube.com/watch?v=4ddL7eIJu44"

# 2024-08-03 -    54:22 - 336 Euthanasiepraktijk faalt. Verstoten Vaders rechteloos. Documaker Elena Lindemans en Ab Gietelink
sa "https://www.youtube.com/watch?v=wF35_MkgM5Q"

# 2024-08-17 -    14:02 - 337 Catalonië verdient een onafhankelijkheidsreferendum. Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=ZSbLYl8iXio"

# 2024-08-20 -    21:29 - 338 Nederland in de Eerste Wereldoorlog. Tentoonstellingsteksten en beelden Ab Gietelink
sa "https://www.youtube.com/watch?v=I3-kuE2P9TM"

# 2024-08-25 -  1:13:42 - 339 Alternatief Forum #7.Olympics, VS, Gaza, Nordstream. Kees vd Pijl, Willem Erné, Ab Gietelink
sa "https://www.youtube.com/watch?v=otXkoKVF0tw"

# 2024-08-29 -    14:32 - 340 Wie = Wie?  Pleitbezorgers van Vrede in Oekraine? Onderzoek Ab Gietelink
sa "https://www.youtube.com/watch?v=csc0NnvrQos"

# 2024-09-01 -    11:46 - 341 Arrestatie Telegram eigenaar Pavel Doerov bedreigt Vrijheid van Publicatie. Door Ab Gietelink
sa "https://www.youtube.com/watch?v=h9llpqddPGo"

# 2024-09-04 -    13:51 - 342 Robert Kennedy ‘s steun voor Trump tekent diepe splijting op links. Ab Gietelink
sa "https://www.youtube.com/watch?v=1GYJmYeAbxk"

# 2024-09-08 -    19:39 - 343 Willem van Oranje Deel 1. Tentoonstelling Ab Gietelink
sa "https://www.youtube.com/watch?v=I7G8IR5L0Ck"

# 2024-09-10 -    19:58 - 344 Willem van Oranje Deel 2: 1568-1648 De Geboorte van Nederland. Tentoonstelling Ab Gietelink
sa "https://www.youtube.com/watch?v=PomPSr_TdN0"

# 2024-09-13 -    13:35 - 345 Sahra Wagenknecht. Bondskanselier voor links en rechts? Artikel Ab Gietelink
sa "https://www.youtube.com/watch?v=BW2aB6Exa7A"

# 2024-09-16 -    13:44 - 346 Wie is Kamala Harris? Hoe verschilt ze van Trump? Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=sGSy8yxwDk8"

# 2024-09-21 -    16:47 - 347 Geachte Oorlogspropagandisten! Manifest Ab Gietelink
sa "https://www.youtube.com/watch?v=j2gAh62oaSI"

# 2024-09-25 -     7:12 - 348 De Wolf en Roodkapje. Column Ab Gietelink
sa "https://www.youtube.com/watch?v=LeiZZ1-EJ_s"

# 2024-09-27 -  1:08:01 - 349 Alternatief Forum #8. NL Regeerakkoord, Libanon. Kees vd Pijl, Sjoerd de Groot, Ab Gietelink
sa "https://www.youtube.com/watch?v=vm9GrTEefis"

# 2024-09-30 -     8:40 - 350 Zwijgen Westerse politici over Israëlische terreur in Libanon is hypocriet. Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=d6zIgyGcIrs"

# 2024-10-05 -    54:46 - 351 Hoe kan het zorgsysteem goedkoper? Taiwan (6% BBP) vs. NL(12%). Ab Gietelink met Vincent Everts.
sa "https://www.youtube.com/watch?v=8ODk9CC0k6c"

# 2024-10-11 -  1:18:31 - 352 Alternatief Forum #9 Israel & Midden-Oosten. Kees vd. Pijl, Peter Baars en Ab Gietelink
sa "https://www.youtube.com/watch?v=7ESaeZVXs9s"

# 2024-10-14 -    14:33 - 353 Brief aan Premier Netanyahu. Afzender Ab Gietelink
sa "https://www.youtube.com/watch?v=vEu7fQKJd78"

# 2024-10-17 -     8:56 - 354 Hoe Israëli's zo gemakkelijk met bezetting leven- Speech Gideon Levy.  NL Voorlezer Ab Gietelink
sa "https://www.youtube.com/watch?v=9QUkZTTWELw"

# 2024-10-19 -    12:38 - 355  ''Nederland is een democratie!''   Polygoonparodie 'van Ab Gietelink
sa "https://www.youtube.com/watch?v=DyFBt0Yx8qI"

# 2024-10-23 -    25:14 - 356 ''Rusland bevrijdde Marioepol en bouwde het weer op !''. Ab Gietelink spreekt Nikolay Pilchuk
sa "https://www.youtube.com/watch?v=q-pTBsbQTWw"

# 2024-10-27 -  1:18:04 - 357 Alternatief Forum #10. BRICS. Peter van Stigt, Diedert de Wagt, Kees vd Pijl, Ab Gietelink
sa "https://www.youtube.com/watch?v=wTm_WXy1a3Y"

# 2024-10-31 -    20:37 - 358 Reisdagboek Iran. Herinneringen bij een dreigende oorlog tussen Israël en Iran. Ab Gietelink
sa "https://www.youtube.com/watch?v=GgEY4EXh47s"

# 2024-11-04 -    31:52 - 359 Speech Kennedy Jr. Minister Volksgezondheid onder Trump. Ab Gietelink
sa "https://www.youtube.com/watch?v=Q0YKU3HTd-E"

# 2024-11-08 -    12:23 - 360 President Trump. Wat kan de wereld verwachten? Ab Gietelink
sa "https://www.youtube.com/watch?v=J3L43lxiG9Y"

# 2024-11-10 -  1:10:50 - 361 Alternatief Forum #11. Trump & Amerika. Willem Engel, Kees vd. Pijl, Ab Gietelink
sa "https://www.youtube.com/watch?v=VmDagA5PUUU"

# 2024-11-15 -    13:40 - 362 Nederlandse politiek maakt van voetbalvandalisme en Israelkritiek ‘Antisemitisme’. Ab Gietelink
sa "https://www.youtube.com/watch?v=K0lntxtReRk"

# 2024-11-17 -    55:16 - 363  Alternatief Forum #12 Ajax-Maccabi, Palestina. Stan v Houcke, Max vd Berg, Ab Gietelink
sa "https://www.youtube.com/watch?v=Sf0v_HBfc-s"

# 2024-11-20 -    15:01 - 364 Pleidooi voor een progressieve alternatieve beweging. Ab Gietelink
sa "https://www.youtube.com/watch?v=tLJy9fd6lxs"

# 2024-11-22 -    15:00 - 365 Trump wint. Zelensky draait. Biden escaleert. Poetin waarschuwt. Analyse Ab Gietelink
sa "https://www.youtube.com/watch?v=49o3OiO7QcE"

# 2024-11-24 -  1:06:28 - 366 ''Praat met Soedan, Rusland, Hamas en Iran !'' Ex-Minister/ VN gezant Jan Pronk en Ab Gietelink.
sa "https://www.youtube.com/watch?v=3w5uAvZkejw"

# 2024-11-27 -  1:01:02 - 367 Falend overheidsmanagement: Incompetent of corrupt? Ab Gietelink interviewt Wybren van Haga
sa "https://www.youtube.com/watch?v=3D39KPV2mvE"

# 2024-11-29 -    21:16 - 368 De Regering Trump. Wie=Wie? Welk beleid is te verwachten? Ab Gietelink
sa "https://www.youtube.com/watch?v=5Vmb1kRg9VU"

# 2024-12-02 -  1:07:54 - 369 Alternatief Forum #13. Regering Trump, Oekraïne, Israel. Kees vd Pijl, Peter Baars, Ab Gietelink
sa "https://www.youtube.com/watch?v=EIheH45obyk"

# 2024-12-06 -    59:16 - 370 De strijd voor gezond voedsel. Ab Gietelink en Graanboernalist Marcel van Silfhout
sa "https://www.youtube.com/watch?v=-A7XBeG3S34"

# 2024-12-08 -  1:52:34 - 371 Thierry Baudet #1. Wie is hij?  Wat is zijn programma? Interview Ab Gietelink
sa "https://www.youtube.com/watch?v=RmYZKoa1nv8"

# 2024-12-11 -    46:01 - 372 Hart voor Humor. Jonathan Krispijn, Wouter Meijs, Badr Maghrani. Interview Ab Gietelink.
sa "https://www.youtube.com/watch?v=vVKyLtVXOoo"

# 2024-12-14 -    13:21 - 373 Georgië: Behoud neutraliteit tussen Russische Federatie en Europese Unie ! Ab Gietelink
sa "https://www.youtube.com/watch?v=JS0M0pmJJKQ"

# 2024-12-20 -    14:49 - 374 Syrië:  Waarom viel Assad en wat nu?  Opinie Ab Gietelink
sa "https://www.youtube.com/watch?v=7P8IwubKK5I"

# 2024-12-22 -    59:57 - 375 Alt. Forum #14.  Willem Engel was in Georgië. Nikko Norte over Syrië. Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=XEg4c-gQdoo"

# 2024-12-26 -     4:20 - 376 ''Bereid U voor op oorlog. Haal uw noodpakket in huis!''. Theaterscene Ab Gietelink
sa "https://www.youtube.com/watch?v=kFIYMNpIgXY"

# 2024-12-28 -  1:31:33 - 377 Uruzgan militair, stierenvechter, piloot en auteur Nikko Norte is te gast bij Ab Gietelink
sa "https://www.youtube.com/watch?v=hz-mZ2uNmAc"

# 2025-01-03 -    19:28 - 378 Reisdagboek Georgië. Georgische Droom ontworstelt zich aan VS en EU! Analyse Ab Gietelink
sa "https://www.youtube.com/watch?v=BxlXnQ_pI1g"

# 2025-01-05 -  1:14:05 - 379 Oud SP kamerlid Harry van Bommel over EU, Oost-Europa en Midden-Oosten. Ab Gietelink interviewt
sa "https://www.youtube.com/watch?v=QUrSgE06l8A"

# 2025-01-11 -  1:11:13 - 380 Kritische Joodse stemmen. Ab Gietelink In gesprek met Jaap Hamburger en Mordechai Krispijn
sa "https://www.youtube.com/watch?v=0UipLsD35aM"

# 2025-01-19 -     9:58 - 381 ''Nederland werkt aan Vrede en Veiligheid !'' Polygoonparodie: Ab Gietelink
sa "https://www.youtube.com/watch?v=lwWCGaYnd7Q"

