#!/bin/bash

get_one() {
    echo "==============================="
    echo "===============================" >> get_errors.log
    echo "URL:  $1"
    echo "URL:  $1" >> get_errors.log

    # Convert Odysee URL to LBRY URL
#    LBRY_URL=$(echo "$1" | sed 's|https://odysee.com/|lbry://|' | sed 's/:/#/' | sed 's|dummy123|lbry://|')
#    LBRY_URL=$(echo "$1" | sed 's|https://odysee.com/|lbry://|' | sed 's/.*\zs:/#/')
    LBRY_URL=$(echo "$1" | sed 's|https://odysee.com/|lbry://|' | sed 's/\(.*\):\([^:]*\)$/\1#\2/')

    echo "LBRY_URL:         $LBRY_URL"
    echo "LBRY_URL:         $LBRY_URL" >> get_errors.log

    # Get filename using yt-dlp for consistency
    bin/yt-dlp -i "$1" \
        --merge-output-format mp4 \
        --restrict-filenames \
        --skip-unavailable-fragments \
        --geo-bypass \
        --get-filename \
        --no-playlist \
        --cookies cookies/odysee.com_cookies.txt > get_filename.txt

    read -r FILENAME < get_filename.txt

    echo "Filename: $FILENAME"
    echo "Filename: $FILENAME" >> get_errors.log
    BASENAME="${FILENAME%.*}"

    # Get download directory from LBRY settings
    DOWNLOAD_DIR=$(grep download_dir ~/.local/share/lbry/lbrynet/daemon_settings.yml | cut -d' ' -f2)
    if [ -z "$DOWNLOAD_DIR" ]; then
        echo "Error: download_dir not set in daemon_settings.yml"
        echo "Error: download_dir not set in daemon_settings.yml" >> get_errors.log
        exit 1
    fi

    MAX_ATTEMPTS=1
    ATTEMPT=1
    while [ $ATTEMPT -le $MAX_ATTEMPTS ]; do
        echo "Attempt $ATTEMPT of $MAX_ATTEMPTS for $FILENAME"
        echo "Attempt $ATTEMPT of $MAX_ATTEMPTS for $FILENAME" >> get_errors.log

        # Start download using lbrynet
        /home/pacman/bin/lbrynet get "$LBRY_URL" --file_name="$FILENAME" --download_directory="$DOWNLOAD_DIR" --save_file --timeout=300

        # Wait for download to complete by monitoring file size
        DOWNLOADED_FILE="$DOWNLOAD_DIR/$FILENAME"
        if [ ! -f "$DOWNLOADED_FILE" ]; then
            echo "Error: File not downloaded at $DOWNLOADED_FILE"
            echo "Error: File not downloaded at $DOWNLOADED_FILE" >> get_errors.log
            ATTEMPT=$((ATTEMPT + 1))
            sleep 5
            continue
        fi

        echo "Waiting for download to complete..."
        echo "Waiting for download to complete..." >> get_errors.log
        LAST_SIZE=0
        STABLE_COUNT=0
        MAX_STABLE=3  # Number of checks with same size to confirm download is complete
        while true; do
            if [ ! -f "$DOWNLOADED_FILE" ]; then
                echo "Error: File $DOWNLOADED_FILE disappeared during download"
                echo "Error: File $DOWNLOADED_FILE disappeared during download" >> get_errors.log
                break
            fi
            CURRENT_SIZE=$(stat -c %s "$DOWNLOADED_FILE" 2>/dev/null || echo 0)
            if [ "$CURRENT_SIZE" -eq "$LAST_SIZE" ] && [ "$CURRENT_SIZE" -gt 0 ]; then
                STABLE_COUNT=$((STABLE_COUNT + 1))
                if [ "$STABLE_COUNT" -ge "$MAX_STABLE" ]; then
                    echo "Download completed: $FILENAME (size: $CURRENT_SIZE bytes)"
                    echo "Download completed: $FILENAME (size: $CURRENT_SIZE bytes)" >> get_errors.log
                    break
                fi
            else
                STABLE_COUNT=0
                LAST_SIZE="$CURRENT_SIZE"
            fi
            sleep 25  # Check every 5 seconds
        done

        # If download failed (file disappeared or size is 0), retry
        if [ ! -f "$DOWNLOADED_FILE" ] || [ "$CURRENT_SIZE" -eq 0 ]; then
            echo "Error: Download failed for $FILENAME"
            echo "Error: Download failed for $FILENAME" >> get_errors.log
            echo "DOWNLOAD FAILED: \"$FILENAME\"" >> files_not_ok.log
            ATTEMPT=$((ATTEMPT + 1))
            sleep 5
            continue
        fi

        # Move the file to the current directory
    #   mv "$DOWNLOADED_FILE" "$FILENAME"

        # Re-encode audio to fix AAC issues
        echo "Checking $FILENAME"
		ffmpeg -v error -i "$FILENAME" -f null - 2>get_error.log

#        ffmpeg -v error -i "$FILENAME" -c:v copy -c:a aac -b:a 192k "${BASENAME}_reencoded.mp4" 2>get_error.log
#        mv "${BASENAME}_reencoded.mp4" "$FILENAME"

        # Check ffmpeg log
        if [ -s get_error.log ]; then
            echo "Errors detected in $FILENAME:"
            cat get_error.log
            cat get_error.log >> get_errors.log
            cat get_error.log > "$BASENAME.log"
            ATTEMPT=$((ATTEMPT + 1))
            if [ $ATTEMPT -le $MAX_ATTEMPTS ]; then
                echo "Retrying download..."
                rm -f "$FILENAME"
                sleep 25
            else
                echo "Max attempts reached for $FILENAME. Giving up."
                echo "Max attempts reached for $FILENAME. Giving up." >> get_errors.log
                echo "NOT OK: \"$FILENAME\"" >> files_not_ok.log
                break
            fi
        else
            echo "No errors in $FILENAME. Download successful."
            echo "No errors in $FILENAME. Download successful." >> get_errors.log
            echo "OK: \"$FILENAME\"" >> files_ok.log
            break
        fi
    done
}

## get_one "https://odysee.com/af------trump--gaza--iran--oekra-ne-en-wapenwedloop---kees-vd-pijl---peter-baars---ab-gietelink:8be3c915ec9a99c5e1c502854b05c0ff5cbce3a1" --language nl
## #date: 2025-04-29 - length:  1:09:58 - title: "AF #18. Trump, Gaza, Iran, Oekraïne en Wapenwedloop | Kees vd Pijl | Peter Baars | Ab Gietelink"
## 
## get_one "https://odysee.com/trumps--tarievenstrijd--waarom---gaat-het-werken----prof--arjo-klamer---ab-gietelink:196686a78295c2f02436cd748f37629f222b5130" --language nl
## #date: 2025-04-29 - length:  1:16:42 - title: "Trumps' Tarievenstrijd. Waarom ? Gaat het werken? | Prof. Arjo Klamer | Ab Gietelink"
## 
## exit

## get_one "https://odysee.com/weltschmerz-live---gratis-gezondheid-door-heel-nederland-----mordechai-krispijn--anna-zeven:22bb1c10b10e2bc61dece79382baf4d771d229d5" --language nl
## #date: 2025-04-29 - length:  1:16:53 - title: "Weltschmerz LIVE | Gratis gezondheid door heel Nederland ? | Mordechai Krispijn, Anna Zeven"

## get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:35fcb894b890cddee5524f77b28bba958555c17d" --language nl
## #date: 2025-04-29 - length:  1:23:38 - title: "Willem Engel en Jeroen Pols Weekoverzicht #17 2025"

# exit

## get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:eaf8f399601285d84d56fadcdf0d69902dba260c" --language nl
## #date: 2025-04-29 - length:  1:35:54 - title: "Willem Engel en Jeroen Pols Weekoverzicht #15 2025"

## get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:25ece3a44d51481e4a411c972c79fd1c28398fde" --language nl
## #date: 2025-04-29 - length:  1:36:57 - title: "Willem Engel en Jeroen Pols Weekoverzicht #16 2025"
## 
## get_one "https://odysee.com/blckbx-in-crisis--bestuur-spreekt-zich-uit-over-flavio--geld---machtsstrijd:38dbae89110af8fad227b8a034746d1ca072af37" --language nl
## #date: 2025-04-29 - length:  2:06:37 - title: "Blckbx in Crisis: Bestuur spreekt zich uit over Flavio, geld & machtsstrijd"
## 
## get_one "https://odysee.com/kom-lokaal-in-actie-:2bfaa97cdc747daafef3a8ef8135c640e5551c60" --language nl
## #date: 2025-04-29 - length:    39:15 - title: "Kom lokaal in actie!"
## 
## get_one "https://odysee.com/steeds-meer-nederlanders-houden-hun-rug-recht---de-andere-tafel:7b0f2454d2f8b641f51384cdb55581637140f40e" --language nl
## #date: 2025-04-29 - length:    41:42 - title: "Steeds meer Nederlanders houden hun rug recht | De Andere Tafel"
## 
## get_one "https://odysee.com/easter-special--ex-satanist-john-ramirez-reveals-the-devil-s-playbook:c83a475048259890bbddba45afa9e9dff825de1f" --language nl
## #date: 2025-04-29 - length:    46:18 - title: "Easter Special: Ex-Satanist John Ramirez Reveals the Devil’s Playbook"
## 
## get_one "https://odysee.com/trump-verklaart-totale-economische-oorlog-aan-china---de-andere-tafel:86d95b83ede9d5d69b5c8758ced21295c9308596" --language nl
## #date: 2025-04-29 - length:    48:29 - title: "Trump verklaart totale economische oorlog aan China | De Andere Tafel"
## 
## get_one "https://odysee.com/d---wetsvoorstel-maakt-kinderen-en-jeugd-weerloos-tegen-genderideologie---sybilla-claus:0bdec451119052f3c10a1d5ca513577474c88663" --language nl
## #date: 2025-04-29 - length:    49:42 - title: "D66 WETSVOORSTEL MAAKT KINDEREN EN JEUGD WEERLOOS TEGEN GENDERIDEOLOGIE | Sybilla Claus"
## 
## get_one "https://odysee.com/de-dokter-van-de-toekomst-is-holistisch---de-andere-tafel:2db64c7373a90edc45f3da5df83aa811711cee6d" --language nl
## #date: 2025-04-29 - length:    49:47 - title: "De dokter van de toekomst is holistisch | De Andere Tafel"

## get_one "https://odysee.com/easter-special--ex-satanist-john-ramirez-reveals-the-devil-s-playbook:c83a475048259890bbddba45afa9e9dff825de1f" --language nl
## #date: 2025-04-29 - length:    46:18 - title: "Easter Special: Ex-Satanist John Ramirez Reveals the Devil’s Playbook"
## 
## get_one "https://odysee.com/trump--tarieven-en-herindustrialisatie--ab-gietelink-interviewt-fin-econ--adviseur-sander-boon:aabf3ec645358670edc6c84d9d663bcf66836fdb" --language nl
## #date: 2025-04-29 - length:    52:02 - title: "Trump, tarieven en herindustrialisatie. Ab Gietelink interviewt Fin-econ. adviseur Sander Boon"
## 
## get_one "https://odysee.com/de-dokter-van-de-toekomst-is-holistisch---de-andere-tafel:b6be19f355c1c48ac76fdd4c376a79515eaa187b" --language nl
## #date: 2025-04-29 - length:    52:53 - title: "De dokter van de toekomst is holistisch | De Andere Tafel"
## 
## get_one "https://odysee.com/economische-sprookjes-in-nederland----staat-s-schuld---lex-hoogduin:71fc5d9a69c5d0b6af74e013ddb5b7e937d38499" --language nl
## #date: 2025-04-29 - length:    56:03 - title: "Economische sprookjes in Nederland? | Staat's Schuld | Lex Hoogduin"
## 
## get_one "https://odysee.com/moet-iedereen-verplicht-naar-school----staat-s-schuld---carlo-fiscalini:db8b5b37ff2fc15cb99832bf046c3a56142deff6" --language nl
## #date: 2025-05-14 - length:    21:14 - title: "Moet iedereen verplicht naar school? | Staat's Schuld | Carlo Fiscalini"
## 
## get_one "https://odysee.com/hoe-klimaatpolitiek-leidt-tot-de-derde-weg--een-pact-tussen-karl-marx-en-de-markt:c4a10899f3603e2d8cc0b4ac6b255e53e1f45bd6" --language nl
## #date: 2025-05-18 - length:    49:13 - title: "Hoe klimaatpolitiek leidt tot De Derde Weg; een pact tussen Karl Marx en De Markt"
## 
## get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:b2d8192bd77d31d933a0745ce8adffae3e6d073d" --language nl
## #date: 2025-05-19 - length:  1:38:07 - title: "Willem Engel en Jeroen Pols Weekoverzicht #20 2025"
## 
## get_one "https://odysee.com/ik--de-burger----staat-s-schuld---caroline-vonhoff:a06ad0401348d7aa7f0934c2bcd575e69d483696" --language nl
## #date: 2025-05-22 - length:    32:05 - title: "Ik, de burger! | Staat's Schuld | Caroline Vonhoff"
## 
## get_one "https://odysee.com/who-pandemieverdrag-opmaat-naar-gezondheidsdictatuur----wybren-van-haga---vala-van-den-boomen:f38f2fa85a07b1ce750a187db5598fc157f40e1c" --language nl
## #date: 2025-05-23 - length:    49:21 - title: "WHO Pandemieverdrag opmaat naar gezondheidsdictatuur? | wybren van Haga | Vala van den Boomen"
## 
## get_one "https://odysee.com/trump-verklaart-totale-economische-oorlog-aan-china---de-andere-tafel:86d95b83ede9d5d69b5c8758ced21295c9308596" --language nl
## #date: 2025-04-29 - length:    48:29 - title: "Trump verklaart totale economische oorlog aan China | De Andere Tafel"
## 
## get_one "https://odysee.com/laat-van-je-horen---shohreh-feshtali---toos-heerebeek:e6fde36780fbdc1e4b3933c603be3455bef98b8d" --language nl
## #date: 2025-05-24 - length:     9:37 - title: "Laat van je horen | Shohreh Feshtali | Toos Heerebeek"
## 
## get_one "https://odysee.com/onafhankelijke-pers-geweerd-uit-rechtbank--nieuwe-media-buitenspel-gezet---de-andere-tafel:4974786cbe6a45d30bcf128e4361866840f58d88" --language nl
## #date: 2025-05-25 - length:    47:10 - title: "Onafhankelijke pers geweerd uit rechtbank, nieuwe media buitenspel gezet | De Andere Tafel"
## 
## get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:4dc628966f31d5df11642470b44f45ccc2e48e30" --language nl
## #date: 2025-05-26 - length:  1:52:10 - title: "Willem Engel en Jeroen Pols Weekoverzicht #21 2025"
## 
## get_one "https://odysee.com/de-jeugdzorg-faalt--alice-kruijen-schreef--zonder-bezieling--geen-zorg---ab-gietelink-interviewt:24d4f4fb159460b94e55dbef5bdf82d36b2fa3cf" --language nl
## #date: 2025-05-27 - length:    48:17 - title: "De jeugdzorg faalt. Alice Kruijen schreef 'Zonder bezieling, geen zorg'' Ab Gietelink interviewt"
## 
## get_one "https://odysee.com/oversterfte----staat-s-schuld---jona-walk:00f0690bdab7fe7607c16d8ef6345ea15e150813" --language nl
## #date: 2025-05-29 - length:    44:46 - title: "Oversterfte? | Staat's Schuld | Jona Walk"
## 
## get_one "https://odysee.com/de-onbesproken-kant-van-abortus---kees-van-helden---shohreh-feshtali:bcce509890c115c3c9b4a82e58703fce4255a917" --language nl
## #date: 2025-05-30 - length:  1:11:30 - title: "De onbesproken kant van abortus | Kees van Helden | Shohreh Feshtali"
## 
## get_one "https://odysee.com/het-hele-verhaal-achter-het-vertrek-van-gideon-van-meijeren-uit-de-corona-commissie:9b6dc8cfc4dcf2dd76644c5ccf44c91747532ea3" --language nl
## #date: 2025-05-31 - length:  1:01:38 - title: "Het hele verhaal achter het vertrek van Gideon van Meijeren uit de Corona Commissie"
## 
## get_one "https://odysee.com/de-illusie-van-koopkracht--cijfers-die-verbloemen---shohreh-feshtali:2e6e9ebb942e02da6772e2c52840da629b130904" --language nl
## #date: 2025-06-01 - length:     3:51 - title: "DE ILLUSIE VAN KOOPKRACHT: CIJFERS DIE VERBLOEMEN | Shohreh Feshtali"
## 
## get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:d66f5577693812c3e2451a4cc720d2f47624ab71" --language nl
## #date: 2025-06-02 - length:  1:49:41 - title: "Willem Engel en Jeroen Pols Weekoverzicht #22 2025"
## 
## get_one "https://odysee.com/aanval-op-arib-maakte-van-corona-enqu-tecommissie-een--doofpotcommissie---ab-gietelink:a0bf8c21661505fdc14a0df9c3146c17f8ef93d8" --language nl
## #date: 2025-06-03 - length:     9:00 - title: "Aanval op Arib maakte van corona-enquêtecommissie een ‘doofpotcommissie’. Ab Gietelink"
## 
## get_one "https://odysee.com/hoe-zeker-is-de-toekomst-van-caf--weltschmerz----shohreh-feshtali---mordecha--krispijn:f839c994dc835303767a4c505a6874028994ed3d" --language nl
## #date: 2025-06-05 - length:    33:35 - title: "Hoe zeker is de toekomst van café Weltschmerz? | Shohreh Feshtali | Mordechaï Krispijn"
## 
## get_one "https://odysee.com/meningen-onder-fascisme----cees-hamelink---staat-s-schuld--:ef923f394bb9b9d6bd606992817efb63c9a679cc" --language nl
## #date: 2025-06-05 - length:    38:45 - title: "Meningen onder fascisme? | Cees Hamelink | Staat's schuld |"
## 
## get_one "https://odysee.com/navo-is-de-baas-in-nederland--geheime-afspraken-zijn-het-zwarte-gat-van-de-nederlandse-democratie:d8cb553bb03cc9a8616d36bd49749314ffc7e356" --language nl
## #date: 2025-06-08 - length:    45:20 - title: "Navo is de baas in Nederland. Geheime afspraken zijn het zwarte gat van de Nederlandse democratie"
## 
## get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:f6bc53ac3c0aa0ab271579f20c965281b0871a59" --language nl
## #date: 2025-06-09 - length:  1:42:56 - title: "Willem Engel en Jeroen Pols Weekoverzicht #23 2025"
## 
## get_one "https://odysee.com/ze-verlangen-naar-palestina---ab-gietelink-met-fatima-kawash--gabriel-weij-en-mohammed-barakat:deb61f95c4058606ae8c43c4d9cd0f25959e94bf" --language nl
## #date: 2025-06-10 - length:    57:33 - title: "Ze verlangen naar Palestina ! Ab Gietelink met Fatima Kawash, Gabriel Weij en Mohammed Barakat"
## 
## get_one "https://odysee.com/shohreh-s-opinie---de-macht-liegt--het-volk-lijdt:a04059de3c4c59b7388f1410a6252810574ed8c9" --language nl
## #date: 2025-06-11 - length:     3:33 - title: "Shohreh's Opinie | De macht liegt, het volk lijdt"
## 
## get_one "https://odysee.com/financi-le-zelfbeschikking----serhan-meewisse---staat-s-schuld:13c0b1f61fa3e80972063ebe1495c131c09cae00" --language nl
## #date: 2025-06-12 - length:    19:47 - title: "Financiële zelfbeschikking? | Serhan Meewisse | Staat's Schuld"
## 
## get_one "https://odysee.com/-zwijg-niet-meer-over-seksueel-geweld--draag-niet-de-schande-van-een-ander----de-andere-tafel:5f23a3d69d55e4e71c5c316debbfaf0d23ef120f" --language nl
## #date: 2025-06-15 - length:    45:51 - title: ""Zwijg niet meer over seksueel geweld. Draag niet de schande van een ander" | De Andere Tafel"
## 
## get_one "https://odysee.com/-----------weekjournaal-willem-jeroen-wk---cws:8196d675e5b2dec7f024f7e6842ad2adbd3c32b8" --language nl
## #date: 2025-06-16 - length:  1:53:41 - title: "2025 06 14 Weekjournaal willem jeroen wk24 CWS"
## 
## get_one "https://odysee.com/alternatief-forum-----navo--prof--kees-vd-pijl--sjoerd-de-groot--ab-gietelink:3280da837b8d0385259d577e4f1ef6fe84c49530" --language nl
## #date: 2025-06-17 - length:  1:16:32 - title: "Alternatief Forum #19 NAVO. Prof. Kees vd Pijl, Sjoerd de Groot, Ab Gietelink"
## 
## get_one "https://odysee.com/hoe-red-je-jouw-vastgoed-in-nederland-van-de-box--terreur-:f5d98edfd989961f352079e329bfa15bbeda5c1a" --language nl
## #date: 2025-06-18 - length:  1:33:32 - title: "Hoe Red je jouw Vastgoed in Nederland van de Box3 Terreur?"
## 
## get_one "https://odysee.com/het-systeem-gaat-zichzelf-nooit-begrenzen---de-begrensers:44e7ad39e66346eb391f5cb4f424393d75e223d5" --language nl
## #date: 2025-06-18 - length:    43:17 - title: "Het Systeem gaat zichzelf Nooit Begrenzen | de Begrensers"
## 
## get_one "https://odysee.com/journalist-emily-van-uit-schuilkelder-tel-aviv:fe2b6184935f9a617e07d417d647a7ad9993e475" --language nl
## #date: 2025-06-20 - length:    42:42 - title: "Journalist Emily van uit schuilkelder Tel Aviv"
## 
## get_one "https://odysee.com/de-rode-pil-van-stuurman------juni-de-andere-wereld-dag---de-andere-tafel:64145c04607dd2c557db20f2ee7dfd4d3b041b77" --language nl
## #date: 2025-06-21 - length:    13:32 - title: "De rode pil van Stuurman + 29 juni De Andere Wereld Dag | De Andere Tafel"
## 
## get_one "https://odysee.com/ten-onder-aan-het-klimaatbeleid---de-andere-tafel:e4bb8dfc4d372c0ee8d18e8bbed4a34bc19655be" --language nl
## #date: 2025-06-22 - length:    46:06 - title: "Ten onder aan het klimaatbeleid | De Andere Tafel"
## 
## get_one "https://odysee.com/oorlog-in-iran-en-het-stockholmsyndroom-op-wereldschaal---opinie-shohreh-feshtali:2e3e987f1ffcf5e782da1665057f2c82b68dcec6" --language nl
## #date: 2025-06-22 - length:     8:44 - title: "Oorlog in Iran en het Stockholmsyndroom op wereldschaal | Opinie Shohreh Feshtali"
## 
## get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:70ed1df625eaac9db35d6479db9ae2c87e120540" --language nl
## #date: 2025-06-23 - length:  2:09:09 - title: "Willem Engel en Jeroen Pols Weekoverzicht #25 2025"
## 
## get_one "https://odysee.com/navo-expansie-in-europa-en-wereldwijd-schept-meer-onveiligheid--opinie-ab-gietelink:3d2df8647e55c1a87942c0f0c723990cc3c01457" --language nl
## #date: 2025-06-24 - length:    13:38 - title: "NAVO-expansie in Europa en wereldwijd schept meer onveiligheid! Opinie Ab Gietelink"
## 
## get_one "https://odysee.com/-we-kunnen-deze-oorlogsmachine-alleen-stoppen-door-ons-te-verenigen----de-ander-tafel:ae5f80811187a6b8c9b2163f0cbe1ddaf673ac53" --language nl
## #date: 2025-06-29 - length:    45:16 - title: ""We kunnen deze oorlogsmachine alleen stoppen door ons te verenigen" | De Ander Tafel"
## 
## get_one "https://odysee.com/liever-geen-dialoog-maar-gehoorzaamheid--prijs-van-vrije-journalistiek:7e468a900de89c2e97a4856d9e0d862c63ed173a" --language nl
## #date: 2025-06-29 - length:     5:40 - title: "Liever geen dialoog maar gehoorzaamheid! Prijs van vrije journalistiek"
## 
## get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:85303899c6e777a40139b18bd8ce419a0fdbf6f0" --language nl
## #date: 2025-06-30 - length:  2:01:11 - title: "Willem Engel en Jeroen Pols Weekoverzicht #26 2025"
## 
## get_one "https://odysee.com/amerika-en-isra-l-schenden-internationaal-recht--europa-legitimeert-en-ondersteunt--ab-gietelink:1f00045350b990ea9e89e8f428b423c10f426c43" --language nl
## #date: 2025-07-01 - length:    17:38 - title: "Amerika en Israël schenden internationaal recht. Europa legitimeert en ondersteunt. Ab Gietelink"
## 
## get_one "https://odysee.com/politiebescherming-nodig-om-mijn-mening-over-iran:a96f9a3068d8225a99437191fca3043f337142e8" --language nl
## #date: 2025-07-01 - length:    57:14 - title: "Politiebescherming nodig om mijn mening over Iran"
## 
## get_one "https://odysee.com/robert-jensen---komt-het-nog-goed-met-de-wereld-:bdacb6dbc3bae7f776179981fe08609f4a988c3a" --language nl
## #date: 2025-07-03 - length:  1:57:46 - title: "Robert Jensen | Komt het nog goed met de wereld?"
## 
## get_one "https://odysee.com/legale-corruptie----mees-wijnants---staat-s-schuld--:b4279c26a136c59df4882da5b29aee288e6a791a" --language nl
## #date: 2025-07-03 - length:    39:52 - title: "Legale corruptie? | Mees Wijnants | Staat's schuld |"
## 
## get_one "https://odysee.com/het-volk-diep-verdeeld--terwijl-de-elite-lacht-:0cc78b8254e5e3067b42aa318a12712eb063f381" --language nl
## #date: 2025-07-06 - length:     4:31 - title: "Het volk diep verdeeld, terwijl de elite lacht!"
## 
## get_one "https://odysee.com/de-explosieve-rechtszaak-tegen-rutte--gates-en-andere-hoofdrolspelers-uit-de-coronacrisis:c712192a3d68108f4df3ffa72ecbb0ca12ab7dc7" --language nl
## #date: 2025-07-06 - length:    49:06 - title: "De explosieve rechtszaak tegen Rutte, Gates en andere hoofdrolspelers uit de coronacrisis"
## 
## get_one "https://odysee.com/-----------weekjournaal-willem-jeroen-wk---cws:e7cfb63f5f50e8cb52217452704d5544ee675eb5" --language nl
## #date: 2025-07-07 - length:  1:44:52 - title: "2025 07 05 Weekjournaal willem jeroen wk27 CWS"
## 
## get_one "https://odysee.com/tot-hier--en-nu-verder---tjeu-berlijn---staat-s-schuld--:da114d8b82bd12850fe65803833dca407c37edd8" --language nl
## #date: 2025-07-10 - length:    34:13 - title: "Tot hier! En nu verder | Tjeu Berlijn | Staat's schuld |"
## 
## get_one "https://odysee.com/hoe-ziet-de-financi-le-revolutie-van-trump-eruit-en-is-het-een-vloek-of-een-zegen----de-andere-tafel:f079ebc95936f038f01553c6b9e6b1444d07431b" --language nl
## #date: 2025-07-13 - length:    42:56 - title: "Hoe ziet de financiële revolutie van Trump eruit en is het een vloek of een zegen? | De Andere Tafel"
## 
## get_one "https://odysee.com/de-prijs-van-zwijgen--tuckers-knieval-voor-khamenei----opinie-shohreh-feshtali:b6d043e4a089c92f59c1fc395da8f4ab6fad0f33" --language nl
## #date: 2025-07-13 - length:     6:04 - title: "De prijs van zwijgen: Tuckers knieval voor Khamenei! | Opinie Shohreh Feshtali"
## 
## get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:b8e9039023febcc0384d1d1e1b828399edf15343" --language nl
## #date: 2025-07-14 - length:  1:51:11 - title: "Willem Engel en Jeroen Pols Weekoverzicht #28 2025"
## 
## get_one "https://odysee.com/haal-dwang-uit-het-onderwijs----peter-hartkamp---staat-s-schuld:d8164df62354b1f9b4a046cad4f7baec6678c3b3" --language nl
## #date: 2025-07-17 - length:    44:32 - title: "Haal dwang uit het onderwijs! | Peter Hartkamp | Staat's schuld"

get_one "https://odysee.com/chazaren-theorie-stok-om-isra-l-mee-te-slaan----rypke-zeilmaker:205a1ac6f52161092cd637a1387a702520fef551" --language nl
#date: 2025-07-18 - length:    18:16 - title: "Chazaren theorie stok om israël mee te slaan? | Rypke Zeilmaker"

get_one "https://odysee.com/komt-in-actie-en-steun-arno-van-kessel:30c2c72ebca53fb9bcc12be21be1147bb31687c4" --language nl
#date: 2025-07-20 - length:    41:36 - title: "komt in actie en steun Arno van Kessel"

get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:90e8772d9b3cec190b1d454b9e774c58f8d2f96f" --language nl
#date: 2025-07-21 - length:  1:43:35 - title: "Willem Engel en Jeroen Pols Weekoverzicht #29 2025"

get_one "https://odysee.com/trump-op-de-epstein-lijst----robert-valentine---staat-s-schuld:f1aa760d6a37eeed7560513ee1ea66f8965a10df" --language nl
#date: 2025-07-24 - length:    39:52 - title: "Trump op de Epstein lijst? | Robert Valentine | Staat's schuld"

get_one "https://odysee.com/in-nagedachtenis-van-michel-reijinga:f7966093d534976fe61955f2ddb84261d9ecc26c" --language nl
#date: 2025-07-25 - length:    13:37 - title: "In nagedachtenis van Michel Reijinga"

get_one "https://odysee.com/de-protocollen--zionistisch-complot-of-machiavelli----rypke-zeilmaker:41bfb0b33d5ed03d5c0be74a245f6cff7eccac97" --language nl
#date: 2025-07-25 - length:    15:12 - title: "De Protocollen: Zionistisch complot of Machiavelli? | Rypke Zeilmaker"

get_one "https://odysee.com/brief-aan-mark-rutte---opinie-shohreh-feshtali:5dd243bc57da20b7a4da27f07dfc8b3702a67dae" --language nl
#date: 2025-07-27 - length:    11:19 - title: "Brief aan Mark Rutte | Opinie Shohreh Feshtali"

get_one "https://odysee.com/caf--weltschmerz-zomerbreak:2633161e3b427faf017486a19c0901f92cf36d0f" --language nl
#date: 2025-07-27 - length:       34 - title: "Café weltschmerz zomerbreak"

get_one "https://odysee.com/---------datversie----:89fb96b1a05e7f635384025157b55fcfc5396950" --language nl
#date: 2025-07-27 - length:    45:01 - title: "20240725 DATversie 1 4"

get_one "https://odysee.com/---------weekoverzicht-wk--:89ad009ead1c51331c4e468c8637a51dc87a293b" --language nl
#date: 2025-07-28 - length:  1:32:56 - title: "20250719 weekoverzicht wk30"

get_one "https://odysee.com/gideon-van-meijeren--fvd----de-arrestatie-van-arno-van-kessel-staat-niet-op-zichzelf-:012a8639b0d0a04b2e0d041f11f7c95a38d200d9" --language nl
#date: 2025-07-29 - length:    34:45 - title: "Gideon van Meijeren (FVD): "De arrestatie van Arno van Kessel staat niet op zichzelf""

get_one "https://odysee.com/gemeentepolitiek-gaat-over-jouw-straat----frederique-durlacher---staat-s-schuld:816b2a96845e1f454dca0e60351c34b8edfd61fe" --language nl
#date: 2025-07-31 - length:    36:09 - title: "Gemeentepolitiek gaat over jouw straat! | Frederique Durlacher | Staat's schuld"

get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:2016efadac34c2703edda235f674203183f1779e" --language nl
#date: 2025-08-04 - length:  1:53:06 - title: "Willem Engel en Jeroen Pols Weekoverzicht #31 2025"

get_one "https://odysee.com/rewind---ra-ra-wie-trekken-aan-de-touwtjes-binnen-groenlinks---joost-niem-ller-met-peter-siebelt:d410e479098507c8c9bb99712cdb353b175143f2" --language nl
#date: 2025-08-06 - length:    53:43 - title: "Rewind | Ra-Ra wie trekken aan de touwtjes binnen GroenLinks | Joost Niemöller met Peter Siebelt"

get_one "https://odysee.com/met-de-kennis-van-nu--de-ultieme-oorzaak-van-oorlog--george-van-houts-en-karel-van-van-wolferen:092c3dd04290dcf3760bfc4c33e7462d26d11ef5" --language nl
#date: 2025-08-07 - length:    45:48 - title: "Met de kennis van nu: De ultieme oorzaak van oorlog! George van Houts en Karel van Van Wolferen"

get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:fbda798d7a7647cad805fc34b9080cf2db6011e7" --language nl
#date: 2025-08-11 - length:  2:31:18 - title: "Willem Engel en Jeroen Pols Weekoverzicht #32 2025"

get_one "https://odysee.com/met-de-kennis-van-nu-ra-ra-wie-trekken-aan-de-touwtjes-binnen-groenlinks-joostniem-ller-petersiebelt:5be9ae55d639c43fc8f9764395cc591cf79e8eb5" --language nl
#date: 2025-08-14 - length:    53:46 - title: "Met de kennis van nu:Ra-Ra wie trekken aan de touwtjes binnen GroenLinks?JoostNiemöller PeterSiebelt"

get_one "https://odysee.com/draaiboek-van-onderdrukking--wanneer-zegt-een-volk-stop----shohreh-feshtali:e939145c1771a0e0a8729eefced533846e2bae97" --language nl
#date: 2025-08-17 - length:    23:40 - title: "DRAAIBOEK VAN ONDERDRUKKING: WANNEER ZEGT EEN VOLK STOP? | Shohreh Feshtali"

get_one "https://odysee.com/de-mannen-van-de-tekentafel---de-andere-tafel:060cc905246f950ea8ba4cf28bfd5225906b4344" --language nl
#date: 2025-08-17 - length:    50:50 - title: "De mannen van de tekentafel | De Andere Tafel"

get_one "https://odysee.com/willem-engel-en-jeroen-pols-weekoverzicht---------:eeaa4d2736662913562ef1f35510fa33e9b9c5fd" --language nl
#date: 2025-08-18 - length:  2:18:31 - title: "Willem Engel en Jeroen Pols Weekoverzicht #33 2025"

get_one "https://odysee.com/van-marechaussee-naar-succesvol-makelaar-in-dubai---het-verhaal-van-cor-zuidema-----:44c960e8d6c22f8b590701fc5b644aaf0416332a" --language nl
#date: 2025-08-19 - length:  1:24:27 - title: "Van marechaussee naar succesvol makelaar in Dubai | Het verhaal van Cor Zuidema (26)"
