
#!/bin/bash

#TRANSLATOR="en-us-0.42-gigaspeech"
#TRANSLATOR="vosk-model-small-en-us-0.4"
TRANSLATOR="en-us"
LANGUAGE="English"
FILENAME="CS_-_Dr._Byrne_-_hersendood_is_een_uitvi.-[1759667998170718209].mp4"

BASENAME="${FILENAME%.*}"
#VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')

#COMMAND="vosk-transcriber -l $TRANSLATOR -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""
#COMMAND="vosk-transcriber -l $TRANSLATOR -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""
COMMAND="vosk-transcriber -l $TRANSLATOR -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\" 2> >(grep \"INFO:root:{'result'\")"
#COMMAND="vosk-transcriber -l $TRANSLATOR -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\" 2> mypipe | grep \"INFO:root:{'result'\" mypipe"
#COMMAND="vosk-transcriber -l $TRANSLATOR -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\" 2> "

#command 2> mypipe | grep "pattern" mypipe
 # > shit.txt 2> shit2.txt

if test -f "execute.sh"; then
	rm execute.sh
fi
echo "$COMMAND" > execute.sh
chmod +x execute.sh
./execute.sh > shit.txt
