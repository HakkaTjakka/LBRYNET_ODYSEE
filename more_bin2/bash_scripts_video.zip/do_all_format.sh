#!/bin/bash

get_page() {
	curl  --location --request POST \
		'https://api.lbry.tv/api/v1/proxy' \
		--header 'Content-Type: application/json' \
		--data-raw '{
		"method": "claim_search",
			"params": {
				"channel": "@English_Subtitles:b",
				"order_by": "creation_timestamp",
				"page": '$1',
				"release_time": "<'$2'",
				"page_size": 50
			}
		}' > test.json

# 			"release_time": "<1725400800",
}

proces_json() {
	if [ -f "hoppa.txt" ]; then
		rm hoppa.txt 
	fi
	start=true
	while IFS= read -r line1 && IFS= read -r line2 <&3 && IFS= read -r line3 <&4; do
	  	counter=$((counter+1))
	  	counter_tot=$((counter_tot+1))
	  	date=$(date -d @$line1 +"%F %T")
		if [ $start == true ]; then 
			start=false
			date_start=$(date -d @$line1 +"%F_%T")
		fi
		timestamp_end=$line1
	  	printf "%4d timestamp: $line1 - date: %s - title: %s - ulr: %s\n" "$counter_tot" "$date" "$line2" "$line3" >> $4
	  	printf "%4d timestamp: $line1 - date: %s - title: %s - ulr: %s\n" "$counter_tot" "$date" "$line2" "$line3"
	  	printf "%s\n" "$date" >> dates.tot

	done < $1 3< $2 4< $3
}

proces_json2() {
	start=true
	while IFS= read -r line1 && IFS= read -r line2 <&3; do
	  	counter=$((counter+1))
	  	counter_tot=$((counter_tot+1))
	  	date=$(date -d @$line1 +"%F %T")
		if [ $start == true ]; then 
			start=false
			date_start=$(date -d @$line1 +"%F_%T")
		fi
		timestamp_end=$line1
	  	printf "%4d timestamp: $line1	- date: %s  - url/title: %s \n" "$counter_tot" "$date" "$line2" >> $3
	  	printf "%4d timestamp: $line1	- date: %s  - url/title: %s \n" "$counter_tot" "$date" "$line2"
	done < $1 3< $2
}

GET_1000_MAX() {
	if [ ! -d "output" ]; then
		mkdir output
	fi
	counter=0
	date_start=""
	date_end=""
	
	if [ -f "hoppa.tot" ]; then
		rm hoppa.tot 
	fi
	
	PAGE=1
	now=$1
	while : ; do
		get_page $PAGE $now

		jq -r '  .result.items.[].meta.creation_timestamp ' test.json > creation_timestamp.txt
		jq -r '  .result.items.[].canonical_url ' test.json > canonical_url.txt
		jq -r '  .result.items.[].value.title ' test.json > title.txt
		jq -r '  .result.items.[].value.tags | @sh ' test.json > tags.txt
		jq -r '  .result.items.[].value.video.duration ' test.json > duration.txt
		jq -r '  .result.items.[].value.thumbnail.url ' test.json > thumbnail.txt

		cat creation_timestamp.txt >> creation_timestamp.tot
		cat canonical_url.txt >> canonical_url.tot
		cat title.txt >> title.tot
		cat tags.txt >> tags.tot
		cat duration.txt >> duration.tot
		cat thumbnail.txt >> thumbnail.tot

#		date -d@12345 -u +%H:%M:%S

#		jq -r '  .result.items.[].short_url ' test.json > hoppa2.txt
	
		proces_json creation_timestamp.txt canonical_url.txt title.txt hoppa.txt
	
		filename="English_Subtitles_"$date_start".json"
		cp "test.json" "output/$filename"
	
		cat hoppa.txt >> hoppa.tot
		PAGES=$(jq -r '.result| "\(.page) \(.total_pages)"' test.json)
		IFS=' ' read PAGE TOTAL_PAGES	<<< $(echo $PAGES)
		echo "Page $PAGE of $TOTAL_PAGES"
		if [ $PAGE == $TOTAL_PAGES ]; then
		 	break
		else
		# 	echo -n "Sleeping 5"
		# 	sleep 1
		# 	echo -ne "\rSleeping 4"
		# 	sleep 1
		# 	echo -ne "\rSleeping 3"
		# 	sleep 1
		# 	echo -ne "\rSleeping 2"
		# 	sleep 1
		 	echo -ne "\rSleeping 1"
		 	sleep 1
		  	echo -ne "\r          \r"
		fi
		PAGE=$((PAGE+1))
	done
	
	sort --key=3 -r hoppa.tot >> hoppa.srt
	
	date_end=$(date -d @$timestamp_end +"%F_%T")
	filename="English_Subtitles_"$date_end".srt"
	cp "hoppa.srt" "output/$filename"
}

list_output_json() {
	rm creation_timestamp.tot
	rm canonical_url.tot
	rm title.tot
	rm tags.tot
	rm duration.tot
	rm duration_text.tot
	rm thumbnail.tot
	rm date.tot
   	counter=0
   	rm output.txt
	for file in output/*.json; do
    	echo "put $file"

		jq -r '  .result.items.[].meta.creation_timestamp ' 	"$file" > creation_timestamp.txt
		jq -r '  .result.items.[].canonical_url ' 				"$file" | sed 's|lbry://|https://odysee.com/|; s/#\([^/]\)/:\1/g' > canonical_url.txt
		jq -r '  .result.items.[].value.title ' 				"$file" > title.txt
		jq -r '  .result.items.[].value.tags | @sh ' 			"$file" > tags.txt
		jq -r '  .result.items.[].value.video.duration ' 		"$file" > duration.txt
		jq -r '  .result.items.[].value.thumbnail.url ' 		"$file" > thumbnail.txt


		while 	IFS= read -r creation_timestamp && \
				IFS= read -r canonical_url <&2 && \
				IFS= read -r title <&3 && \
				IFS= read -r tags <&4 && \
				IFS= read -r duration <&5 && \
				IFS= read -r thumbnail <&6; do
		  	counter=$((counter+1))
		  	date=$(date -d @$creation_timestamp +"%F %T")
		  	printf "index: %04d\n" "$counter" \
		  	>> output.txt
		  	printf "title: %s \n" "$title" \
		  	>> output.txt
		  	printf "date: %s  (timestamp: %s)\n" "$date" "$creation_timestamp" \
		  	>> output.txt
		  	printf "duration: %02d:%02d:%02d  (seconds: %s) \n" $((duration/3600)) $((duration%3600/60)) $((duration%60)) "$duration" \
		  	>> output.txt
		  	printf "tags: %s \n" "$tags" \
		  	>> output.txt
		  	printf "url: %s \n" "$canonical_url" \
		  	>> output.txt
		  	printf "thumbnail: %s \n" "$thumbnail" \
		  	>> output.txt
		  	printf "**********************************************\n" \
		  	>> output.txt
		  	printf "%s\n" "$date" >> date.tot

		  	printf "duration: %02d:%02d:%02d  (seconds: %s) \n" $((duration/3600)) $((duration%3600/60)) $((duration%60)) "$duration" \
		  	>> duration_text.tot

		done < "creation_timestamp.txt" 2< "canonical_url.txt" 3< "title.txt" 4< "tags.txt" 5< "duration.txt" 6< "thumbnail.txt"

		cat creation_timestamp.txt 	>> creation_timestamp.tot
		cat canonical_url.txt 		>> canonical_url.tot
		cat title.txt				>> title.tot
		cat tags.txt 				>> tags.tot
		cat duration.txt 			>> duration.tot
		cat thumbnail.txt 			>> thumbnail.tot
	done
## 	sed "s///"
##     https://odysee.com/@English_Subtitles:b/Miljoenenstrop_-_het_Rijk_betaalt_meer_dan_4_miljoen_per_week_voor_opvang_asielzoekers_in_hotels_Weekoverzicht_13_2024_-_Willem_Engel_en_Jeroen_Pols-v4juknx.English:a
##     lbry://@English_Subtitles#b/Miljoenenstrop_-_het_Rijk_betaalt_meer_dan_4_miljoen_per_week_voor_opvang_asielzoekers_in_hotels_Weekoverzicht_13_2024_-_Willem_Engel_en_Jeroen_Pols-v4juknx.English#a
## string="lbry://@English_Subtitles#b/Miljoenenstrop_-_het_Rijk_betaalt_meer_dan_4_miljoen_per_week_voor_opvang_asielzoekers_in_hotels_Weekoverzicht_13_2024_-_Willem_Engel_en_Jeroen_Pols-v4juknx.English#a"
## echo "$string" | sed 's|lbry://|https://odysee.com/|; s/#\([^/]\)/:\1/g'
}

format_json() {
	start=true
	while IFS= read -r line1 && IFS= read -r line2 <&3 && IFS= read -r line3 <&4; do
	  	counter=$((counter+1))
	  	counter_tot=$((counter_tot+1))
	  	date=$(date -d @$line1 +"%F %T")
	  	printf "%4d timestamp: $line1 - date: %s - title: %s - ulr: %s\n" "$counter_tot" "$date" "$line2" "$line3" >> $4
	  	printf "%4d timestamp: $line1 - date: %s - title: %s - ulr: %s\n" "$counter_tot" "$date" "$line2" "$line3"
	  	printf "%s\n" "$date" >> dates.tot

	done < $1 3< $2 4< $3
}

# format_json creation_timestamp.tot title.tot canonical_url.tot final.tot

list_output_json

exit

timestamp_end=0
counter_tot=0
counter=0

## rm creation_timestamp.tot
## rm canonical_url.tot
## rm title.tot
## rm tags.tot
## rm duration.tot
## rm thumbnail.tot
## 
## GET_1000_MAX $(date +%s)
## while [ $counter == 1000 ];
## do
## 	GET_1000_MAX $timestamp_end
## done
## 
rm dates.tot

#now=$(date +%s)
#now=1731514873
#now=1727389683

rm url.tot
rm total_title.tot
rm title_url.tot

counter_tot=0
counter=0

proces_json2 creation_timestamp.tot canonical_url.tot url.tot

counter_tot=0
counter=0

proces_json2 creation_timestamp.tot title.tot total_title.tot

counter_tot=0
counter=0

proces_json creation_timestamp.tot title.tot canonical_url.tot title_url.tot

sort --key=3 -r url.tot > url.srt
sort --key=3 -r total_title.tot > total_title.srt
sort --key=3 -r title_url.tot > total_title_url.srt

sort --key=10 url.tot > url2.srt
sort --key=10 total_title.tot > total_title2.srt
sort --key=10 title_url.tot > total_title_url2.srt


