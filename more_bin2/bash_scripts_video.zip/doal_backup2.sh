#!/bin/bash

get_page() {
	 
#	'https://api.lbry.tv/api/v1/proxy'	 
#curl --header "Content-Type: application/json" --data '{ "method": "resolve", "params": { "urls": "RVTYE34#cab68f64fe27e2123d5c805469e5c36796e017d2" }}' http://localhost:5279    
# curl -d'{"method": "channel_list", "params": {"name": [], "claim_id": [], "is_spent": false, "resolve": false, "no_totals": false}}' http://localhost:5279/
# curl -d'{
# 		"method": "channel_list",
# 		"params": {
# 			"name": [],
# 			"claim_id": [],
# 			"is_spent": false,
# 			"resolve": false,
# 			"no_totals": false
# 		}
#	}' http://localhost:5279/ > test.json

##	PLAYLISTS
##		curl -d'{
##			"method": "collection_list",
##			"params": {
##				"resolve_claims": 1,
##				"page": '$1',
##				"account_id": "0f39e5c18b119190fe35ff5b10e5c5955cc387bb",
##				"resolve": true
##			}
##		}' http://localhost:5279/ > test.json
#		"account_id": 'b0a87e02bbc7397ed2b84f08bf0da5d4f309d1f4',


#		"account_id": "b0a87e02bbc7397ed2b84f08bf0da5d4f309d1f4",
#Curl -d'{"method": "collection_list", "params": {"resolve_claims": 1, "resolve": true}}' http://localhost:5279/
#		"account_id": "b0a87e02bbc7397ed2b84f08bf0da5d4f309d1f4"
#		"page": '$1',
#		"page_size": 50
# 		"release_time": "<1725400800"
# --trace-time --verbose

#	'http://localhost:5279' \
#	'https://api.lbry.tv/api/v1/proxy' \

# lbrynet collection list --resolve --resolve_claims=1 >test.json 2>&1
#lbrynet channel list >test.json 2>&1
#echo -n $output > test.json


# http://localhost:5279/ >test.json
#'https://api.lbry.tv/api/v1/proxy'
#			"channel_name": "@English_Subtitles:b", 

# CHANNEL LIST
#	curl  --location --request POST \
#	'https://api.lbry.tv/api/v1/proxy' \
# 	--header 'Content-Type: application/json' \
# 	--data-raw '{
# 		"method": "claim_search",
# 		"params": {
# 			"channel": "@English_Subtitles:b",
# 			"order_by": "creation_timestamp",
# 			"page": '$1',
#	 		"release_time": "<1725400800",
# 			"page_size": 50
# 		}
# 	}' > test.json

# curl -d'{
#  		"method": "claim_search",
#  		"params": {
#  			"channel": "@English_Subtitles:b",
#  			"order_by": "creation_timestamp",
#  			"page": '$1',
# 	 		"release_time": "<1725400800"
# 		}
# }' https://api.lbry.tv/api/v1/proxy > test.json
# 			"page_size": 50

# 'https://api.lbry.tv/api/v1/proxy'

# lbrynet file list >test.json 2>&1
#curl -d'{ 
#	"method": "file_list", 
#	"params": {
#			"page": '$1',
#			"page_size": 50,
#			"channel_claim_id": "b0a87e02bbc7397ed2b84f08bf0da5d4f309d1f4",
#			"reverse": false
# 	}
#}' http://localhost:5279/ >test.json

#http://localhost:5279/
# 			"channel": "@English_Subtitles:b",

curl  --location --request POST \
	'https://api.lbry.tv/api/v1/proxy' \
	--header 'Content-Type: application/json' \
	--data-raw '{
	"method": "claim_search",
		"params": {
			"channel": "@English_Subtitles:b",
			"order_by": "creation_timestamp",
			"page": '$1',
			"release_time": "<=1731512847",
			"page_size": 50
		}
	}' > test.json

# 			"release_time": "<1725400800",


}

counter=0
#counter_start=1
#counter_end=0
proces_json() {
	if [ -f "hoppa.txt" ]; then
		rm hoppa.txt 
	fi
  counter_start=$((counter+1))
	start=true
	while IFS= read -r line1 && IFS= read -r line2 <&3; do
	  counter=$((counter+1))
	  date=$(date -d @$line1 +"%F %T")
		if [ $start == true ]; then 
			start=false
			counter_start=$(date -d @$line1 +"%F_%T")
		fi
  
	  printf "%4d timestamp: $line1	- date: $date  - url: $line2\n" $counter >> $3
	done < $1 3< $2
#	counter_end=date=$(date -d @$line1 +"%F_%T")
}

if [ -f "hoppa.tot" ]; then
	rm hoppa.tot 
fi

PAGE=1
while : ; do
	get_page $PAGE
#	jq -r '  items.[].meta.creation_timestamp ' test.json > hoppa1.txt
#	jq -r '  items.[].short_url ' test.json > hoppa2.txt

	jq -r '  .result.items.[].meta.creation_timestamp ' test.json > hoppa1.txt
	jq -r '  .result.items.[].short_url ' test.json > hoppa2.txt

#	jq -r '  .result.items.[].meta.creation_timestamp ' test.json > hoppa1.txt
#	jq -r '  .result.items.[].canonical_url ' test.json > hoppa2.txt

	proces_json hoppa1.txt hoppa2.txt hoppa.txt
#  filename=$(printf "English_Subtitles_%04d-%04d.json" $counter_start $counter_end)
	filename="English_Subtitles_"$counter_start".json"

	cp "test.json" "$filename"

	cat hoppa.txt >> hoppa.tot
	PAGES=$(jq -r '.result| "\(.page) \(.total_pages)"' test.json)
	IFS=' ' read PAGE TOTAL_PAGES	<<< $(echo $PAGES)
	echo "Page $PAGE of $TOTAL_PAGES"
  if [ $PAGE == $TOTAL_PAGES ]; then
  	break
  else
 # 	echo -n "Sleeping 5"
 # 	sleep 1
 # 	echo -ne "\rSleeping 4"
 # 	sleep 1
 # 	echo -ne "\rSleeping 3"
 # 	sleep 1
 # 	echo -ne "\rSleeping 2"
 # 	sleep 1
  	echo -ne "\rSleeping 1"
  	sleep 1
	  echo -ne "\r          \r"
  fi
	PAGE=$((PAGE+1))
done
sort --key=3 -r hoppa.tot >> hoppa.srt

#echo "PAGES=$PAGES"



# read -d "," PAGE TOTAL_PAGES hoppa	<<< $(jq -r '.result| "\(.page),\(.total_pages)"' test.json)
# echo "Page $PAGE / $TOTAL_PAGES"

# jq -r '.result| "\(.page) \(.total_pages)"' test.json
# 
#    "page": 1,
#     "page_size": 50,
#     "total_items": 65,
#     "total_pages": 2
 

#jq -r '  .result.items.[].value.release_time ' test.json > hoppa1.txt
#jq -r '  .result.items.[].timestamp ' test.json > hoppa1.txt

#proces_json hoppa0.txt hoppa3.txt hoppa.txt
exit


# curl --location --request POST 'http://localhost:5279/' \
# --header 'Content-Type: application/json' \
# --data-raw '{
# 	"method": "file_list", \
# 	"params": { \
# 		"params": {"reverse": false} \
# 	} \
# }' > test.json
# exit

#curl -d'{"method": "stream_list", "params": {"name": [], "claim_id": [], "is_spent": false, "resolve": false, "no_totals": false}}' http://localhost:5279/


# curl -d'{"method": "file_list",	"params": { "reverse": false, "page": 2, "page_size": 50}}' http://localhost:5279/ >> test.json
# curl -d'{"method": "file_list",	"params": { "reverse": false, "page": 3, "page_size": 50}}' http://localhost:5279/ >> test.json

# curl -d'{"method": "file_list",	"params": { "reverse": false }}' https://api.lbry.tv/api/v1/proxy/ > test.json

curl -d'{"method": "file_list",	"params": { "reverse": false, "page": 100, "page_size": 50}}' http://localhost:5279/ > test.json

jq -r ' .result.items.[].added_on ' test.json > hoppa1.txt
jq -r ' .result.items.[].metadata.title ' test.json > hoppa2.txt

cnt=0
rm hoppa.txt
while IFS= read -r line1 && IFS= read -r line2 <&3; do
  counter=$((counter+1))
  line1=$(date -d @$line1)

  printf "%4d timestamp: $line1	url: $line2\n" $counter >> hoppa.txt
#  echo "timestamp: $line1	url: $line2"
#  echo "File 2: $line2"
done < hoppa1.txt 3< hoppa2.txt


exit

# jq -r '  "\(.result.items.[].meta.creation_timestamp)  (.result.items.[].canonical_url)"  ' test.json > hoppa.txt
jq -r '  .result.items.[].meta.creation_timestamp ' test.json > hoppa1.txt
jq -r '  .result.items.[].canonical_url ' test.json > hoppa2.txt

cnt=0
rm hoppa.txt
while IFS= read -r line1 && IFS= read -r line2 <&3; do
  counter=$((counter+1))
  line1=$(date -d @$line1)

  printf "%4d timestamp: $line1	url: $line2\n" $counter >> hoppa.txt
#  echo "timestamp: $line1	url: $line2"
#  echo "File 2: $line2"
done < hoppa1.txt 3< hoppa2.txt

#printf "One %d Two %d Three %d\\n" 1 2 3 4
  

#order_by: release_time, add release_time: <=release_time_of_the_last_claim
#jq -r '.fmep| "\(.foo) \(.bar)"'
#jq -r '.fmep | [.foo, .bar] | @tsv'
exit

mkdir English_Subtitles
cd English_Subtitles
# flip "https://odysee.com/@English_Subtitles:b?view=content"
doall

sort --key=3 -r download.list | sed "s/ <BREAK> /\n/g" > download.srt

#sort --key=2 -r download.list | sed "s/$/ --language nl\n/" | sed "s/ - url: /\nsa /"  > download.sh

doall() {
	rm download.list
	rm download.srt
	rm spreadsheet.txt
	find . -maxdepth 1 -type f -name "*.info.json" -print0 | sort -z | while IFS= read -r -d '' line;
	do
	#	echo $line
	#	BASENAME="${FILENAME%.*}"
	#	VAR=$(echo $BASENAME | sed 's/[][]/\\&/g' |  sed 's/ /\\ /g')
		l2=$(../bin/get_json_odysee.sh "$line")
		echo $l2
#		echo $l2 >> json.list
#		sleep 2
	done
}

flip() {
#		--downloader aria2c -N 10 \
	../bin/yt-dlp \
		--restrict-filenames "$1" \
		--write-info-json \
		--skip-download \
		--yes-playlist \
		--sleep-requests 5 \
		--retry-sleep 5 

#		--dateafter 20241103

#	--sleep-requests 1	
#	flop "$1"
}
# curl --location --request POST 'https://api.lbry.tv/api/v1/proxy' \
# --header 'Content-Type: application/json' \
# --data-raw '{
# "method": "claim_search",
# "params": {
# "channel": "@English_Subtitles:b",
# "order_by": "release_time",
# "page": 1,
# "page_size": 50
# }
# }' > test.json
# 
# jq '.result.items.[].canonical_url' test.json > hoppa.txt
# 
# sleep 5
# 
# 		"reverse": true, 
# 		"release_time": "<1725400800",

#date -d '2024-10-10 ' +%s

#		"reverse": true, 

#order_by: release_time, add release_time: <=release_time_of_the_last_claim

#curl -d'{"method": "claim_search",	"params": { "channel": "@English_Subtitles:b", "order_by": "release_time", "page": 1, "page_size": 50}}' https://api.lbry.tv/api/v1/proxy > test.json

#jq -r '  .result .page,  ' test.json > hoppa1.txt
