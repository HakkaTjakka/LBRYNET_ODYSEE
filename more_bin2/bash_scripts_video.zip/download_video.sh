#!/bin/bash

echo -------------------------------------------------------------------------- >> error.log

echo Getting filename from URL: $*
echo Getting filename from URL: $* >> error.log

		## yt-dlp -i --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "ytsearch:$*" > filename.txt

yt-dlp -i --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" > filename.txt

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')
#echo "Basename: $BASENAME"

#yt-dlp --restrict-filenames --abort-on-error --no-mtime --sub-lang "nl,en,de" --write-subs --convert-subs srt --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "ytsearch:$*"
#--default-search "ytsearch"
COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "nl,en" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

# COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "en-us,en" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

#COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "nl-id" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""
#COMMAND="yt-dlp --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --sub-lang "nl-en-US" --write-subs --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

#COMMAND="yt-dlp  --restrict-filenames --abort-on-error --no-mtime --sub-langs all --write-subs --write-auto-subs --embed-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""

echo "$COMMAND" >> COMMANDS.SH
echo "$COMMAND" > command.sh
chmod +x command.sh
./command.sh

if test -f "$FILENAME"; then
	echo "DOWNLOADED: $FILENAME"
else 
	if test -f "$BASENAME.mkv"; then
		FILENAME="$BASENAME.mkv"
		echo "$BASENAME.mkv exists. Changing filename."
		echo "$FILENAME" > filename.txt
	fi
fi

if [ ! -d "subs" ]; then
	mkdir "subs"
fi	
# convert .vtt to .srt. Can also be done by yt-dlp with --convert-subs srt but only after/when downloading. So when interrupted can be continued.
for line in $VAR.*.vtt
do
	LANGUAGE="${line%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	echo "Converting subtitle file to .srt and fixing: $line"
	echo "Converting subtitle file to .srt and fixing: $line" >> error.log
	ffmpeg -n -hide_banner -i $BASENAME.$LANGUAGE.vtt $BASENAME.$LANGUAGE.srt
#	rm -f $BASENAME.$LANGUAGE.vtt
	echo "sof/sof $BASENAME.$LANGUAGE.srt" >> COMMANDS.SH
	sof/sof $BASENAME.$LANGUAGE.srt
#	echo "Moving $BASENAME.$LANGUAGE.srt* to dir: subs/$LANGUAGE"
	if [ ! -d "subs/$BASENAME" ]; then
		mkdir "subs/$BASENAME"
	fi	

	if [ ! -d "subs/$BASENAME/$LANGUAGE" ]; then
		mkdir "subs/$BASENAME/$LANGUAGE"
	fi	
	mv "$BASENAME.$LANGUAGE.vtt" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt.single" "subs/$BASENAME/$LANGUAGE"
	mv "$BASENAME.$LANGUAGE.srt.double" "subs/$BASENAME/$LANGUAGE"
done

# select wanted languages
#LANG="nl"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Dutch	nl
LANG="nl"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Dutch	nl
#LANG="en"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# English	en
#LANG="de"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# German	de
#LANG="fr"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# French	fr
#LANG="tr"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Turkish	tr
#LANG="ar"; 		mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Arabic	ar
#LANG="zh-Hans"; 	mv "subs/$BASENAME/$LANG/$BASENAME.$LANG.srt.double" .	# Chinese	zh-Hans

if [ ! -d "out" ]; then
	mkdir "out"
fi	
for line in $VAR.*.srt.double
#for line in $VAR.*.srt.single
do
	echo "Subtitle fixed: $line"
	echo "Subtitle fixed: $line" >> error.log
	
	LANGUAGE="${line%.*}"
	LANGUAGE="${LANGUAGE%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	echo "Language: $LANGUAGE"

	if test -f "out/$BASENAME.$LANGUAGE.mp4"; then
		echo "out/$BASENAME.$LANGUAGE.mp4 exists."
	else
		if test -f "out/DOING/$BASENAME.$LANGUAGE.mp4"; then
			echo "out/DOING/$BASENAME.$LANGUAGE.mp4 exists."
		else
			if test -f "out/DOING/DONE/$BASENAME.$LANGUAGE.mp4"; then
				echo "out/DOING/DONE/$BASENAME.$LANGUAGE.mp4 exists."
			else

#				# FONTNAME="Simply Rounded Bold"
#				FONTNAME="AdobeCorpID-MyriadBl"
#				# FONTNAME="Akkordeon-Ten"
#				# FONTNAME="BMWHelvetica-BlackCond"
#
#				FONTSIZE="28"
#				OUTLINE="1"
#				FORCE_STYLE="'Fontname=$FONTNAME,FontSize=$FONTSIZE,Outline=$OUTLINE'"
#				# echo $FORCE_STYLE
#
#				COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style=$FORCE_STYLE\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""

				# FONTNAME="Simply Rounded Bold"
				# FONTNAME="AdobeCorpID-MyriadBl"
				# FONTNAME="Akkordeon-Ten"
				FONTNAME="BMWHelvetica-BlackCond"

				FONTSIZE="26"
				# OUTLINE="1.1"
				OUTLINE="1.0"
				COLOR="00FFFFFF"
				OUTLINE_COLOR="00000000"
				BACK_COLOR="C0000000"
				SHADOW="0.0"
				ANGLE="0.0"
				BORDERSTYLE="0"
				ALIGNMENT="2"
				# ALIGNMENT="6"

				FORCE_STYLE="'Fontname=$FONTNAME,FontSize=$FONTSIZE,Outline=$OUTLINE,PrimaryColour=&H$COLOR,OutlineColour=&H$OUTLINE_COLOR,BackColour=&H$BACK_COLOR,Shadow=$SHADOW,Angle=$ANGLE,BorderStyle=$BORDERSTYLE,Alignment=$ALIGNMENT'"
				SUBTITLES="subtitles=f='$line':force_style=$FORCE_STYLE"

				PARMS_OUT="-strict -2 -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy"
				PARMS_IN="-y -hide_banner -progress url -nostdin"
				MAP="-map 0:v:0 -map 0:a:0"
				IN="-i \"$FILENAME\""

#				SCALE="scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black"
#				FILTER="-filter_complex \"[0:v]$SCALE,$SUBTITLES\""

#				SCALE="scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black"
				FILTER="-filter_complex \"[0:v]$SUBTITLES\""

				# FILTER="-filter_complex \"[0:v]$SCALE,tblend=all_expr='if(eq(mod(X,2),mod(Y,2)),A,B)',$SUBTITLES\""
				OUT="\"out/$BASENAME.$LANGUAGE.PART.mp4\""

				FFMPEG="ffmpeg"
				# echo $FORCE_STYLE

				COMMAND="$FFMPEG $PARMS_IN $IN $MAP $FILTER $PARMS_OUT $OUT"

				echo "$COMMAND" >> COMMANDS.SH
				echo "$COMMAND" > command.sh
				chmod +x command.sh
				./command.sh

				COMMAND="mv \"out/$BASENAME.$LANGUAGE.PART.mp4\" \"out/$BASENAME.$LANGUAGE.mp4\""
				echo "$COMMAND" >> COMMANDS.SH
				echo "$COMMAND" > command.sh
				chmod +x command.sh
				# burn *(&'r burn
				./command.sh
			fi
		fi
	fi
#	mv "$BASENAME.$LANGUAGE.srt.double" "subs/$BASENAME/$LANGUAGE"
done


#		COMMAND="~/ffmpeg-n4.4-latest-linux64-gpl-4.4/bin/ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -i \"$line\" -map 0:v:0 -map 0:a:0 -map 1:s:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		~/nvidia/ffmpeg/ffmpeg -y -hide_banner -progress url -nostdin -i "$FILENAME" -strict -2 -filter_complex "[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -preset slow -c:a copy "out/$BASENAME.$LANGUAGE.PART.mp4"
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
#		COMMAND="ffmpeg -y -hide_banner -progress url -nostdin -i \"$FILENAME\" -map 0:v:0 -map 0:a:0 -strict -2 -filter_complex \"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black,subtitles=f='$line':force_style='Fontname=Simply Rounded Bold,FontSize=24,Outline=1'\" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy \"out/$BASENAME.$LANGUAGE.PART.mp4\""
