
ffmpeg -y -hide_banner -i "Robin_De_Ruiter_Interview-[PBnF7L9RfRE].mp4" -i "Robin_De_Ruiter_Interview-[PBnF7L9RfRE].nl.srt.double" -map 0:v:0 -map 0:a:0 -map 1:s:0 -strict -2 -filter_complex "[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black" -c:s mov_text -c:v h264_nvenc -profile:v high -pix_fmt yuv420p -bf:v 3 -preset slow -rc-lookahead 32 -c:a copy "out/Robin_De_Ruiter_Interview-[PBnF7L9RfRE].nl.PART.mp4"

mv "out/Robin_De_Ruiter_Interview-[PBnF7L9RfRE].nl.PART.mp4" "out/Robin_De_Ruiter_Interview-[PBnF7L9RfRE].nl.mp4"
