#!/bin/bash

LANGUAGE="en"

echo $* > filename.txt

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"

COMMAND="vosk-transcriber -l $LANGUAGE -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""

echo "$COMMAND" >> COMMANDS.SH
echo "$COMMAND" > command.sh
chmod +x command.sh
./command.sh

COMMAND="sof/sof "$BASENAME.$LANGUAGE.srt""

echo "$COMMAND" >> COMMANDS.SH
echo "$COMMAND" > command.sh
chmod +x command.sh
./command.sh

burn_video.sh $LANGUAGE


if test -f "out/$BASENAME.nl.mp4"; then
	echo "out/$BASENAME.nl.mp4 exists."
else
	if test -f "$BASENAME.nl.srt.double"; then
		rm "$BASENAME.nl.srt.double"
	fi

	COMMAND="translate.sh "$BASENAME.$LANGUAGE.srt.double""

	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	./command.sh

	burn_video.sh nl
fi