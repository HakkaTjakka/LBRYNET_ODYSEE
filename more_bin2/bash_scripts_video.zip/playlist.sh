#yt-dlp  --restrict-filenames "https://youtube.com/playlist?list=PL1kjtlmf25BXwGNj02M_zD_DbE2xhdHqY" --write-info-json --skip-download 

#yt-dlp  --restrict-filenames "$1" --write-info-json --skip-download 
#https://www.youtube.com/watch?v=fLiUlpm3Vro&list=UULFsXoGRbga9bP1YpWNiwiZIQ&ab_channel=DeGuldenMiddenweg
#yt-dlp  --yes-playlist --flat-playlist --restrict-filenames "https://rumble.com/c/THEPEOPLESVOICE/videos" --write-info-json --skip-download 

#yt-dlp  --restrict-filenames "https://rumble.com/c/THEPEOPLESVOICE/videos?page=3" --write-info-json --skip-download 
#https://openrss.org/rumble.com/russellbrand
#exit

#find . -maxdepth 1 -type f -name "*.info.json" -print0 | sort -z | while IFS= read -r -d '' line; # do

#https://odysee.com/@English_Subtitles:b/Random-English-Subs:8?lid=8c0c9f52009ba9718fbe929e3a2a8c1207253af4

doall() {
	rm json.list
	rm json.url.list
	rm list.json.sh
	rm download.list
	rm download.sh
	rm thumbnails.sh
	find . -maxdepth 1 -type f -name "*.info.json" -print0 | sort -z | while IFS= read -r -d '' line;
	do
	#	echo $line
	#	BASENAME="${FILENAME%.*}"
	#	VAR=$(echo $BASENAME | sed 's/[][]/\\&/g' |  sed 's/ /\\ /g')
		l2=$(../bin/get_json.sh "$line")
		echo $l2
		echo $l2 >> json.list
#		sleep 2
	done
}

flop() {
	l2=$(get_json.sh "$1")
	echo $l2
	echo $l2 >> json.list
}

flip() {
#		--downloader aria2c -N 10 \
	COOKIES="cookies/youtube.com_cookies.txt"

	../bin/yt-dlp \
		--cookies "$COOKIES" \
		--restrict-filenames "$1" \
		--write-info-json \
		--yes-playlist \
		--skip-download \
		--sleep-requests 2 \
		--retry-sleep 2 \
		--dateafter $2

#		--dateafter $2
#		--dateafter 20250307
#		--dateafter 20250427
#		--dateafter 20250329
#		--dateafter 20250228
#		--dateafter 20241103
#	--sleep-requests 1	
#	flop "$1"
}
#flip "https://www.youtube.com/playlist?list=PL1D42C1B674EFBCBA"

# mkdir WBS
# cd WBS
# flip "https://www.youtube.com/playlist?list=PLOosJrK6HH-VYEq16BypDc4YZrhr5LSEk"
# doall

## mkdir rabit
## cd rabit
## flip "https://rumble.com/c/c-4978660/videos"
## doall

mkdir meeswynants
cd meeswynants
flip "https://www.youtube.com/@meeswynants/shorts" 20201215

## mkdir JornLuka
## cd JornLuka
## flip "https://www.youtube.com/@JornLuka/videos" 20201215

# mkdir kevin_roberts
# cd kevin_roberts
# flip "https://www.youtube.com/playlist?list=PLhiObk1mf8nkibZsE6m36L0fVhcsSQ_fd"

# mkdir wierd
# cd wierd
# 
# flip "https://www.youtube.com/playlist?list=PLut--Mdm79Agp6sWR01DLO7WM_16L0-od"

# 
# mkdir dvo
# cd dvo
# 
# flip "https://odysee.com/$/playlist/2a8b933b48290db7b039bbf50dda55253cd11a05"
# flip "https://odysee.com/$/playlist/86b8240fb0bdb1a4fdd6008ad4ff5aab52b68b8f"

# mkdir lighthouse-tv
# cd lighthouse-tv
#flip "https://www.youtube.com/watch?v=pKyB-5PaqrI&list=PL9_tsJAOcjeDEX54WoSwNP78FSFBzGilN"
# flip "https://www.youtube.com/watch?v=2qUaS-Rt5h0&list=PL9_tsJAOcjeCQ03rto-VyJxarPQARBfzw"
# flip "https://www.youtube.com/@lighthousetvnl/streams"

#flip "https://www.youtube.com/@blckbx/videos" 20250101

#flip "https://www.youtube.com/@lighthousetvnl/videos" 20250821
doall

## mkdir HGC
## cd HGC
## flip "youtube.com/@RuimtelijkFiguur/search?query=complot"
## doall

# https://www.youtube.com/@Hayden.Schreier/videos
# 
# mkdir Hayden_Schreier
# cd Hayden_Schreier
# flip "https://www.youtube.com/@Hayden.Schreier/videos"
# doall

#flip "https://www.youtube.com/playlist?list=PL3GeTIrfzqmZ8DeXzAC0LR_mJKtXLbA_u" # boven het maaiveld

#mkdir RealCandaceO
#cd RealCandaceO
#flip "https://www.youtube.com/@RealCandaceO/videos"

# mkdir BVNL
# cd BVNL
# #flip "https://www.youtube.com/playlist?list=PL3GeTIrfzqmZ8DeXzAC0LR_mJKtXLbA_u" # boven het maaiveld
# flip "https://www.youtube.com/@WybrenVanHagaBVNL/videos"



## mkdir MiddleNation
## cd MiddleNation
## flip "https://www.youtube.com/@MiddleNation/videos"
## doall

# mkdir cws
# cd cws
# flip "https://odysee.com/@CafeWeltschmerz:f?view=content"

# mkdir xnxx
# cd xnxx
# flip "https://www.xnxx.com/search/xtreme+Face+Fuck+Throat+Gagging+tied/1"
# exit

# mkdir LarkenRose
# cd LarkenRose
# # flip "https://www.youtube.com/@LarkenRose/videos"
# doall

# mkdir DNW
# cd DNW
# flip "https://www.youtube.com/playlist?list=PLOosJrK6HH-UXx9Z6cqI3dOmyRtUIyjs0"
# #flip "https://www.youtube.com/watch?v=kEiunPY41rk&list=PLOosJrK6HH-UXx9Z6cqI3dOmyRtUIyjs0&ab_channel=DeNieuweWereld"
# #flip "https://www.youtube.com/@DeNieuweWereldTV/videos"
# #https://www.youtube.com/watch?v=kEiunPY41rk&list=PLOosJrK6HH-UXx9Z6cqI3dOmyRtUIyjs0&ab_channel=DeNieuweWereld
# doall


# mkdir STIRLING
# cd STIRLING
# # flip "https://www.youtube.com/results?search_query=stirling+engines"
# doall

# mkdir V
# cd V
# flip "https://www.youtube.com/watch?v=1gC_qVN1NUM&list=PL4dEeyKa1GPmwkFWTMtJU925ZHaFooxf-"
# doall
# exit

# mkdir cooper
# cd cooper
# flip "https://www.youtube.com/playlist?list=PL9W32G3-uE8mtP0jtJ28GlZsFXuMfIx1v"
# doall
# 

sort -r json.url.list > json.url.sort
sort --key=6 -r list.json.sh > list.sorted.sh
sort --key=2 -r download.list | sed "s/$/ --language nl\n/" | sed "s/ - url: /\nsa /"  > download.sh

# flip "https://odysee.com/$/playlist/35cb275384176e88b4afc72ea02eb81db2933148"
# flip "https://www.youtube.com/@RealCandaceO/videos"
# flip "https://npo.nl/start/serie/ongehoord-nieuws/seizoen-2/ongehoord-nieuws_120"
# flip "https://www.youtube.com/@OngehoordNederlandTV/videos"
# exit
