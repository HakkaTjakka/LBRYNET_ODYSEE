FILENAME1="$1"
BASENAME1="${FILENAME1%.*}"

FILENAME2=~/movies/bin/yes.mp4
BASENAME2="${FILENAME2%.*}"
echo "FILENAME1=$FILENAME1"
echo "FILENAME2=$FILENAME2"
# ffmpeg -y -i "$FILENAME" -vf "fps=11,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse"   "$BASENAME.gif"

DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$FILENAME1")
echo "DURATION1=$DURATION"

read -d " " XX YY 	<<< $(ffprobe -v error -show_entries stream=width,height -of default=noprint_wrappers=1:nokey=1 "$FILENAME2")

XX2=$(echo "$XX/1.8" | bc)
YY2=$(echo "$YY/1.8" | bc)

#XX2=$((XX/2))
#YY2=$((YY/2))
SCALE2="$XX2:$YY2"
echo "SCALE2=$SCALE2"

read FPS1			<<< $(ffprobe -v error -select_streams v -of default=noprint_wrappers=1:nokey=1 -show_entries stream=r_frame_rate "$FILENAME1")
echo "FPS1=$FPS1"
FPS1=30

ffmpeg -y \
	-i "$FILENAME1" \
	-ss 0.0 -stream_loop -1 -i "$FILENAME2" \
	-filter_complex "[0:v]fps=$FPS1,scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:-1:-1:color=black[v0];
	[1:v]scale=$SCALE2,fps=$FPS1[v1];
	[0:a]aresample=44100,volume=1.0[aa]; \
	[v0][v1]overlay=x='40':y='main_h/2-overlay_h/2-100'[vvv]; \
	[vvv]scale=1280:720[vv]" \
	-map "[vv]" -map "[aa]" \
	-t $DURATION \
	-c:v h264_nvenc -pix_fmt yuv420p \
	"$BASENAME1.blend.mp4"
#	[v0][v1]overlay=x='240':y='main_h/2-overlay_h/2-50'[vv]" \
#	[v0][v1]overlay=x='40':y='40'[vv]" \
#	[v0][v1]overlay=x='40':y='main_h-overlay_h-40'[vv]" \

#	[1:v]scale=300:-1,fps=30[v1];

#	-filter_complex '[1:v][0:v]scale2ref[ckout][vid];[vid][ckout]blend=all_mode='multiply'[out]' \

#[o3b][ss13]overlay=x='main_w - mod(main_w/2+((main_w+500  * (main_w/4000))-(main_w/1000)*1.8* (n*(($XX1+overlay_w))/($SPEED))),main_w*2)':y='(main_h +20-overlay_h-(main_h/1000)*180* (1.0-sin(n/60)/1.5)  * abs(  sin( sin(n/60)*1 + 28 *3.1415*n/500) )+00 )'[o3c];
	
#ffmpeg -i input.mov -i overlay.mov \
#-filter_complex "[1:v]setpts=PTS-10/TB[a]; \
#                 [0:v][a]overlay=enable=gte(t\,5):shortest=1[out]" \
#-map [out] -map 0:a \
#-c:v libx264 -crf 18 -pix_fmt yuv420p \
#-c:a copy \
#output.mov