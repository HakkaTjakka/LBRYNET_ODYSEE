#!/bin/bash

FILENAME="$*"
echo FILENAME=$FILENAME
BASENAME="${FILENAME%.*}"

BIT_RATE=$(ffprobe -v error -show_entries format=bit_rate -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
echo BIT_RATE=$BIT_RATE

FILELENGTH=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$FILENAME")
RATE=$(ffprobe -v error -show_entries stream=sample_rate -of default=noprint_wrappers=1:nokey=1 "$FILENAME")

PITCH="1.00"
SPEED=$(echo "(139/$FILELENGTH)"| bc -l)
echo $FILELENGTH
echo $FILENAME
echo $BASENAME
echo $RATE
echo $SPEED

ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:v]setpts=$SPEED*PTS,fps=fps=60[v];[0:a]asetrate=$RATE/$PITCH,aresample=44100,atempo=(1.0/($SPEED/$PITCH))[a]" \
	-map "[v]" -map "[a]" -c:v h264_nvenc -pix_fmt yuv420p -preset slow -c:a aac -ac 2 -b:a 64k "$BASENAME.TWITTER.MP4"

#ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:v]setpts=$SPEED*PTS,scale=1280:720:force_original_aspect_ratio=increase[v];[0:a]asetrate=$RATE/$PITCH,aresample=44100,atempo=(1.0/($SPEED/$PITCH))[a]" -map "[v]" -map "[a]" -c:v h264_nvenc -pix_fmt yuv420p -preset slow -c:a aac -ac 2 -b:a 64k "$BASENAME.TWITTER.MP4"
