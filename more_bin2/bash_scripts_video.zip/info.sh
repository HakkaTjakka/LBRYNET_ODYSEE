#!/bin/bash

#yt-dlp --get-filename --write-info-json --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass --cookies cookies/twitter.com_cookies.txt \"$*\"

FILENAME="$*"

yt-dlp -i "$FILENAME" \
	--geo-bypass \
	--get-filename \
	--skip-download \
	--cookies cookies/twitter.com_cookies.txt > info.txt

DESCRIPTION2=$(cat info.txt)

echo "=========================================" >> info.txt
yt-dlp -i "$FILENAME" \
	--write-info-json \
	--trim-filenames 20 \
	--restrict-filenames \
	--skip-unavailable-fragments --geo-bypass \
	--skip-download \
	--cookies cookies/twitter.com_cookies.txt >> info.txt

FILENAME=$(yt-dlp -i \
	--restrict-filenames \
	--trim-filenames 20 \
	--cookies cookies/twitter.com_cookies.txt \
	--geo-bypass \
	--get-filename \
	"$FILENAME")

#	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass --cookies cookies/twitter.com_cookies.txt "$*""

BASENAME="${FILENAME%.*}"
echo "FILENAME=$FILENAME"
echo "BASENAME=$BASENAME"
#exit

DESCRIPTION=$(jq -r .description $BASENAME.info.json; echo -n "Filename: $DESCRIPTION2")
echo -n "$DESCRIPTION"

#	--get-filename \
# --restrict-filenames
# --get-filename
# --sub-langs en,nl --write-subs --write-auto-subs
