#!/bin/bash

FILENAME=$*
BASENAME="${FILENAME%.*}"

LANGUAGE="${FILENAME%.*}"
LANGUAGE="${LANGUAGE%.*}"
BASENAME2="${LANGUAGE%.*}"
LANGUAGE="${LANGUAGE##*.}"
echo $LANGUAGE

#exit
#LANGUAGE="en"

RESET="1"

echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"
if [ "$LANGUAGE" == "en"  ]; then
        if test -f "$BASENAME2.nl.srt.double"; then
                rm "$BASENAME2.nl.srt.double"
        fi
        if test -f "$BASENAME2.de.srt.double"; then
                rm "$BASENAME2.de.srt.double"
        fi
        while IFS='' read -r line || [[ -n "$line" ]]; do
                if [[ "$line" != "" ]] ; then
                        if [[ "$RESET" == "1" ]] ; then
                                VAR1=$line
                                VAR2=$line
                                echo NO TRANSLATE: $line - LINE NUMBER
                                RESET="2"
                        else
                                if [[ "$RESET" == "2" ]] ; then
                                        VAR1=$line
                                        VAR2=$line
                                        echo NO TRANSLATE: $line - TIMER
                                        RESET="3"
                                else
                                        echo ORIGINAL___$LANGUAGE: $line
                                        VAR1=$(echo "$line" | trans -brief $LANGUAGE:nl)
                                        sleep 0.5
                                        echo TRANSLATED_NL: $VAR1
                                        VAR2=$(echo "$line" | trans -brief $LANGUAGE:de)
                                        sleep 0.5
                                        echo TRANSLATED_DE: $VAR2
                                fi
                        fi
                else
                        RESET=1
                        VAR1=$line
                        VAR2=$line
                        echo NO TRANSLATE: $line
                fi
                echo $VAR1 >> "$BASENAME2.nl.srt.double"
                echo $VAR2 >> "$BASENAME2.de.srt.double"
        done < "$FILENAME"
else
        if [ "$LANGUAGE" == "nl"  ]; then
                if test -f "$BASENAME2.en.srt.double"; then
                        rm "$BASENAME2.en.srt.double"
                fi
                if test -f "$BASENAME2.de.srt.double"; then
                        rm "$BASENAME2.de.srt.double"
                fi
                if test -f "$BASENAME2.fr.srt.double"; then
                        rm "$BASENAME2.fr.srt.double"
                fi
                while IFS='' read -r line || [[ -n "$line" ]]; do
                        if [[ "$line" != "" ]] ; then
                                if [[ "$RESET" == "1" ]] ; then
                                        VAR1=$line
                                        VAR2=$line
                                        VAR3=$line
                                        echo NO TRANSLATE: $line - LINE NUMBER
                                        RESET="2"
                                else
                                        if [[ "$RESET" == "2" ]] ; then
                                                VAR1=$line
                                                VAR2=$line
                                                VAR3=$line
                                                echo NO TRANSLATE: $line - TIMER
                                                RESET="3"
                                        else
                                                echo ORIGINAL___$LANGUAGE: $line
                                                VAR1=$(echo "$line" | trans -brief $LANGUAGE:en)
                                                sleep 0.5
                                                echo TRANSLATED_EN: $VAR1
                                                VAR2=$(echo "$line" | trans -brief $LANGUAGE:de)
                                                sleep 0.5
                                                echo TRANSLATED_DE: $VAR2
                                                VAR3=$(echo "$line" | trans -brief $LANGUAGE:fr)
                                                sleep 0.5
                                                echo TRANSLATED_FR: $VAR3
                                        fi
                                fi
                        else
                                RESET=1
                                VAR1=$line
                                VAR2=$line
                                VAR3=$line
                                echo NO TRANSLATE: $line
                        fi
                        echo $VAR1 >> "$BASENAME2.en.srt.double"
                        echo $VAR2 >> "$BASENAME2.de.srt.double"
                        echo $VAR3 >> "$BASENAME2.fr.srt.double"
                done < "$FILENAME"
        else
                if test -f "$BASENAME2.nl.srt.double"; then
                        rm "$BASENAME2.nl.srt.double"
                fi
                if test -f "$BASENAME2.en.srt.double"; then
                        rm "$BASENAME2.en.srt.double"
                fi
                if test -f "$BASENAME2.de.srt.double"; then
                        rm "$BASENAME2.de.srt.double"
                fi
                while IFS='' read -r line || [[ -n "$line" ]]; do
                        if [[ "$line" != "" ]] ; then
                                if [[ "$RESET" == "1" ]] ; then
                                        VAR1=$line
                                        VAR2=$line
                                        VAR3=$line
                                        echo NO TRANSLATE: $line - LINE NUMBER
                                        RESET="2"
                                else
                                        if [[ "$RESET" == "2" ]] ; then
                                                VAR1=$line
                                                VAR2=$line
                                                VAR3=$line
                                                echo NO TRANSLATE: $line - TIMER
                                                RESET="3"
                                        else
                                                echo ORIGINAL___$LANGUAGE: $line
                                                VAR1=$(echo "$line" | trans -brief $LANGUAGE:nl)
                                                sleep 0.5
                                                echo TRANSLATED_NL: $VAR1
                                                VAR2=$(echo "$line" | trans -brief $LANGUAGE:en)
                                                sleep 0.5
                                                echo TRANSLATED_EN: $VAR2
                                                VAR3=$(echo "$line" | trans -brief $LANGUAGE:de)
                                                sleep 0.5
                                                echo TRANSLATED_DE: $VAR3
                                        fi

                                fi
                        else
                                RESET=1
                                VAR1=$line
                                VAR2=$line
                                VAR3=$line
                                echo NO TRANSLATE: $line
                        fi
                        echo $VAR1 >> "$BASENAME2.nl.srt.double"
                        echo $VAR2 >> "$BASENAME2.en.srt.double"
                        echo $VAR3 >> "$BASENAME2.de.srt.double"
                done < "$FILENAME"
        fi
fi
