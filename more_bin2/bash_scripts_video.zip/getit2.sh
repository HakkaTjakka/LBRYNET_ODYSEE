yt-dlp $* --cookies cookies/twitter.com_cookies2.txt --restrict-filenames --trim-filenames 80 --merge-output-format mp4 --audio-format aac
