#!/bin/bash

LANGUAGE="ua"

echo -------------------------------------------------------------------------- >> error.log

echo Getting filename from URL: $*
echo Getting filename from URL: $* >> error.log


# yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 100 --skip-unavailable-fragments --geo-bypass --get-filename "$*" > filename.txt
yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')

if test -f "out/$BASENAME.$LANGUAGE.mp4"; then
	echo "out/$BASENAME.$LANGUAGE.mp4 exists."
else
	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 100 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""
	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass --cookies cookies/twitter.com_cookies.txt "$*""

	rm COMMANDS.SH
	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	./command.sh

	if test -f "$BASENAME.mkv"; then
		FILENAME="$BASENAME.mkv"
		echo "$BASENAME.mkv exists. Changing filename."
		echo "$FILENAME" > filename.txt
	fi

#	COMMAND="autosub -S $LANGUAGE -D $LANGUAGE \"$FILENAME\" -o \"$BASENAME.$LANGUAGE.srt\""

	COMMAND="vosk-transcriber -l $LANGUAGE -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""

	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	./command.sh

	COMMAND="sof/sof "$BASENAME.$LANGUAGE.srt""

	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	./command.sh

	burn_video.sh $LANGUAGE

fi

if test -f "out/$BASENAME.nl.mp4"; then
	echo "out/$BASENAME.nl.mp4 exists."
else
	if test -f "$BASENAME.nl.srt.double"; then
		rm "$BASENAME.nl.srt.double"
	fi
	if test -f "$BASENAME.en.srt.double"; then
		rm "$BASENAME.en.srt.double"
	fi
	if test -f "$BASENAME.ua.srt.double"; then
		rm "$BASENAME.ur.srt.double"
	fi

	COMMAND="translate_uk.sh "$BASENAME.$LANGUAGE.srt.double""

	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh
	./command.sh

	burn_video.sh nl
	burn_video.sh en
	burn_video.sh uk
fi