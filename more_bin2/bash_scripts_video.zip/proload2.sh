get_one() {
	echo "==============================="
	echo "===============================" >> get_errors.log
	echo "URL:  $1"
	echo "URL:  $1" >> get_errors.log

	yt-dlp -i "$1" \
		--merge-output-format mp4 \
		--restrict-filenames \
		--skip-unavailable-fragments \
		--geo-bypass \
		--get-filename \
		--no-playlist \
		--cookies cookies/twitter.com_cookies.txt > get_filename.txt

	read -r FILENAME < get_filename.txt
	echo "Filename: $FILENAME"
	BASENAME="${FILENAME%.*}"

	echo "File: $FILENAME"
	echo "File: $FILENAME" >> get_errors.log

	yt-dlp -i "$1" \
		--downloader aria2c \
		-R 5 \
		--merge-output-format mp4 \
		-o "$FILENAME"

	ffmpeg -v error -i "$FILENAME" -f null - 2>get_error.log
	cat get_error.log
	cat get_error.log >> get_errors.log
	cat get_error.log > "$BASENAME.log"
}

