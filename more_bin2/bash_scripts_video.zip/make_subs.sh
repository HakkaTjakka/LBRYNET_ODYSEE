#!/bin/bash

FILENAME=$1
BASENAME="${FILENAME%.*}"
LANGUAGE=$2

#sub="$*"
echo VIDEO: $1
echo LANGUAGE: $2
#echo SUBS__: \"$2\"
#autosub -S $LANGUAGE -D $LANGUAGE "$1" -o "$BASENAME.$LANGUAGE.srt.single"


echo vosk-transcriber -l $LANGUAGE -i "$FILENAME" -t srt -o "$BASENAME.$LANGUAGE.srt"
vosk-transcriber -l $LANGUAGE -i "$FILENAME" -t srt -o "$BASENAME.$LANGUAGE.srt"
sof/sof "$BASENAME.$LANGUAGE.srt"