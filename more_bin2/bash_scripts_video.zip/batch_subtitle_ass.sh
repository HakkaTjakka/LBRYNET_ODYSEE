#!/bin/bash

LANGUAGE="unknown"
TRANSLATOR="en-us-0.42-gigaspeech"

echo -------------------------------------------------------------------------- >> error.log

echo Getting filename from URL: $*
echo Getting filename from URL: $* >> error.log

#yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --skip-unavailable-fragments --geo-bypass --get-filename "$*" -o "kut.mp4" > filename.txt
#yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --skip-unavailable-fragments --geo-bypass --get-filename "$*" > filename.txt
#yt-dlp -i --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt
#--list-thumbnails
#yt-dlp -i --trim-filenames 40 --write-thumbnail --merge-output-format mp4 --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt

#yt-dlp -i --trim-filenames 60 --write-thumbnail --merge-output-format mp4 --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt
#yt-dlp -i "$1" --write-thumbnail --merge-output-format mp4 --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename --cookies cookies/twitter.com_cookies.txt > filename.txt

#	--write-thumbnail \

#bin/yt-dlp -vU --downloader aria2c -N 10 
FILENAMELENGTH=50
yt-dlp -i "$1" \
	--merge-output-format mp4 \
	--trim-filenames $FILENAMELENGTH \
	--restrict-filenames \
	--skip-unavailable-fragments \
	--geo-bypass \
	--get-filename \
	--cookies cookies/twitter.com_cookies.txt > filename.txt

#yt-dlp -i --write-thumbnail --merge-output-format mp4 --restrict-filenames --skip-unavailable-fragments --geo-bypass --get-filename "$*" --cookies cookies/twitter.com_cookies.txt > filename.txt
#yt-dlp "$*" --restrict-filenames --list-thumbnails --cookies cookies/twitter.com_cookies.txt > thumbnails.txt

read -r FILENAME < filename.txt
echo "Filename: $FILENAME"
echo "Filename: $FILENAME" >> error.log

BASENAME="${FILENAME%.*}"
VAR=$(echo $BASENAME | sed 's/[][]/\\&/g')


if test -f "out/$BASENAME.$LANGUAGE.mp4"; then
	echo "out/$BASENAME.$LANGUAGE.mp4 exists."
else
	LANGUAGE="$3"
	LANGUAGE_FULL="$3"
	if [ ! "$2" == "" ]; then
		if [ "$3" == "Chinese"    ] || [ "$3" == "zh" ] ; then LANGUAGE="zh" ; LANGUAGE_FULL="Chinese"    ; fi
		if [ "$3" == "Korean"     ] || [ "$3" == "ko" ] ; then LANGUAGE="ko" ; LANGUAGE_FULL="Korean"     ; fi
		if [ "$3" == "Dutch"      ] || [ "$3" == "nl" ] ; then LANGUAGE="nl" ; LANGUAGE_FULL="Dutch"      ; fi
		if [ "$3" == "English"    ] || [ "$3" == "en" ] ; then LANGUAGE="en" ; LANGUAGE_FULL="English"    ; fi
		if [ "$3" == "French"     ] || [ "$3" == "fr" ] ; then LANGUAGE="fr" ; LANGUAGE_FULL="French"     ; fi
		if [ "$3" == "Italian"    ] || [ "$3" == "it" ] ; then LANGUAGE="it" ; LANGUAGE_FULL="Italian"    ; fi
		if [ "$3" == "German"     ] || [ "$3" == "de" ] ; then LANGUAGE="de" ; LANGUAGE_FULL="German"     ; fi
		if [ "$3" == "Turkish"    ] || [ "$3" == "tr" ] ; then LANGUAGE="tr" ; LANGUAGE_FULL="Turkish"    ; fi
		if [ "$3" == "Portuguese" ] || [ "$3" == "pt" ] ; then LANGUAGE="pt" ; LANGUAGE_FULL="Portuguese" ; fi
		if [ "$3" == "Russian"    ] || [ "$3" == "ru" ] ; then LANGUAGE="ru" ; LANGUAGE_FULL="Russian"    ; fi
		if [ "$3" == "Ukrainian"  ] || [ "$3" == "uk" ] ; then LANGUAGE="uk" ; LANGUAGE_FULL="Ukrainian"  ; fi
		if [ "$3" == "Arabic"     ] || [ "$3" == "ar" ] ; then LANGUAGE="ar" ; LANGUAGE_FULL="Arabic"     ; fi
		if [ "$3" == "Japanese"   ] || [ "$3" == "ja" ] ; then LANGUAGE="ja" ; LANGUAGE_FULL="Japanese"   ; fi
		if [ "$3" == "Urdu"       ] || [ "$3" == "ur" ] ; then LANGUAGE="ur" ; LANGUAGE_FULL="Urdu"       ; fi

		echo $LANGUAGE > language.txt
		echo $LANGUAGE_FULL > language_full.txt
		echo "LANGUAGE=$LANGUAGE"
		echo "LANGUAGE_FULL=$LANGUAGE_FULL"
	else
		echo "LANGUAGE=UNKNOWN"
	fi

	echo "===================== End of Original Description =====================" > "$BASENAME.description"
	echo "Video Source: $1" >> "$BASENAME.description"
	echo "Translation(s) by Pacman Graphics: https://odysee.com/@PMG:5?view=channels"  >> "$BASENAME.description"
	echo "Speech Recognition & Translation (to English): Whisper, medium/turbo model" >> "$BASENAME.description"
	echo "Or https://github.com/soimort/translate-shell" >> "$BASENAME.description"
	echo "Subtitles Archive: https://drive.google.com/drive/folders/14RMVjdIla_OZ4TagWQUIDIWnb9dPcjtN" >> "$BASENAME.description"
	echo "👊 Buy me a Coffee: Bitcoin (BTC): 14eueBv7NuDGMqv4mBWLDFmU2g76h8vkYS" >> "$BASENAME.description"
	echo "==============================================================" >> "$BASENAME.description"
	echo "Other Channels 👉 https://odysee.com/@TheLastBattle:3?view=channels" >> "$BASENAME.description"
	echo "Featuring: (Click the 'Playlists' tab for selections)" >> "$BASENAME.description"
	echo "Europe: The Last Battle (2017) 👉 https://odysee.com/@TheLastBattle:3" >> "$BASENAME.description"
	echo "English Subtitles 👉 https://odysee.com/@English_Subtitles:b" >> "$BASENAME.description"
	echo "Actuele Video's Nederlands Ondertiteld. 👉 https://odysee.com/@Nederlands_Ondertiteld:0" >> "$BASENAME.description"
	echo "Unheard of 👉 https://odysee.com/@Unheard:5" >> "$BASENAME.description"
	echo "Fall of the Cabal 👉 https://odysee.com/@FalloftheCabal:0" >> "$BASENAME.description"
	echo "George Carlin - All My Stuff 👉 https://odysee.com/@AllMyStuff:2" >> "$BASENAME.description"
	echo "Vladimir Putin interview by Tucker Carlson 👉 https://odysee.com/@Putin_interview_by_Tucker_Carlson:f" >> "$BASENAME.description"
	echo "Pacman Graphics 👉 https://odysee.com/@PMG:5" >> "$BASENAME.description"
	echo "(🇬🇧EN) Ongehoord Nederland (English Subtitles) 👉 https://odysee.com/@Reserve3:c" >> "$BASENAME.description"
	echo "PDF DOCUMENTS 👉 https://odysee.com/@Reserve1:8" >> "$BASENAME.description"
	echo "==============================================================" >> "$BASENAME.description"


#	COMMAND="yt-dlp --write-info-json --merge-output-format mp4 --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass --cookies cookies/twitter.com_cookies.txt "$*""
 #--cookies cookies/twitter.com_cookies.txt
	COMMAND="bin/yt-dlp     --downloader aria2c -N 10 --write-info-json --merge-output-format mp4 --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass \"$1\" -o $FILENAME"
#	echo $COMMAND >> "$BASENAME.description"
#	COMMAND="yt-dlp --write-info-json --merge-output-format mp4 --restrict-filenames --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass --cookies cookies/twitter.com_cookies.txt \"$*\" -o $FILENAME"

#	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --geo-bypass --cookies cookies/twitter.com_cookies.txt "$*""
#	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*""
#	COMMAND="yt-dlp --merge-output-format mp4 --restrict-filenames --trim-filenames 40 --default-search "ytsearch" --abort-on-error --no-mtime --write-auto-subs --download-archive ARCHIVE.TXT --skip-unavailable-fragments --write-thumbnail --geo-bypass "$*" -o "kut.mp4""

	rm COMMANDS.SH
	echo "$COMMAND" > COMMANDS.SH
    echo >> COMMANDS.SH

	echo "$COMMAND" > command.sh
	chmod +x command.sh
#exit
	./command.sh

	if test -f "$BASENAME.mkv"; then
		FILENAME="$BASENAME.mkv"
		echo "$BASENAME.mkv exists. Changing filename."
		echo "$FILENAME" > filename.txt
	fi

#	echo -e "\n\nVideo Source:" > "$BASENAME.description"

#	mv "$BASENAME.description" "$BASENAME.backup.description"

	
#	echo "$*" >> "$BASENAME.description"
#	COMMAND="autosub -S $LANGUAGE -D $LANGUAGE \"$FILENAME\" -o \"$BASENAME.$LANGUAGE.srt\""
#	COMMAND="vosk-transcriber -l $LANGUAGE -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""

	#COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_width 40 --max_line_count 2"
	#COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_width 40 --max_line_count 2"
	#COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_count 1 --no_speech_threshold 0.5"
#	COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_count 1 --language nl"

#	COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --word_timestamps True --max_line_count 1 $2 $3"

#	COMMAND="whisper \"$FILENAME\" --task translate --model medium $2 $3"

	COMMAND="whisper \"$FILENAME\" --model medium --highlight_words True --max_line_count 1 --word_timestamps True $2 $3"
#	COMMAND="whisper \"$FILENAME\" --task translate --model medium --no_speech_threshold 0.4 $2 $3"

#	echo $COMMAND >> "$BASENAME.description"

	# --no_speech_threshold NO_SPEECH_THRESHOLD
	# --max_line_width 30
	# --max_line_width 80

# 	--language Dutch 
#	COMMAND="vosk-transcriber -l $TRANSLATOR -i \"$FILENAME\" -t srt -o \"$BASENAME.$LANGUAGE.srt\""

	echo "$COMMAND" >> COMMANDS.SH
    echo >> COMMANDS.SH

	echo "$COMMAND" > command.sh
	chmod +x command.sh
	#./command.sh
	ln=1
	# for i in $("./command.sh"); do
    # 	echo "whisper: "$ln" = \"$i\""
    # 	ln=$ln+1
	# done
	#IFS=$'\r'
	#./command.sh | while read -r line ; do
	#| tr -d '\r'
	script -c ./command.sh -f | while read -r line1; do
    	#echo "$line"
    	BAR=$(printf "whisper: "$ln" = \"'$line1'\"" | tr -d '\r')
    	#echo $(printf "whisper: "$ln" = \"$line1\"" | tr -d '\r')
    	echo -n $BAR
    	printf "\r\n"
    	ln=$((ln+1))
    	#IFS=$' '
	    #echo "Unknown" > language.txt
    	echo $line1 | while read -r line_a line_b line_c; do
    		if [ "$line_a" = "Detected" ]; then  
	    		if [ "$line_b" = "language:" ]; then
	    			LANGUAGE=$(echo $line_c | tr -d '\r')
	    			echo $LANGUAGE > language.txt
	    			echo $LANGUAGE > language_full.txt
					read -r LANGUAGE_FULL < language.txt
    				echo "LANGUAGE="$line_c

					if [ "$LANGUAGE_FULL" == "Hungarian"  ];           then LANGUAGE="hu" ; fi
					if [ "$LANGUAGE_FULL" == "Chinese"    ];           then LANGUAGE="zh" ; fi
					if [ "$LANGUAGE_FULL" == "Dutch"      ];           then LANGUAGE="nl" ; fi
					if [ "$LANGUAGE_FULL" == "English"    ];           then LANGUAGE="en" ; fi
					if [ "$LANGUAGE_FULL" == "French"     ];           then LANGUAGE="fr" ; fi
					if [ "$LANGUAGE_FULL" == "Italian"    ];           then LANGUAGE="it" ; fi
					if [ "$LANGUAGE_FULL" == "German"     ];           then LANGUAGE="de" ; fi
					if [ "$LANGUAGE_FULL" == "Turkish"    ];           then LANGUAGE="tr" ; fi
					if [ "$LANGUAGE_FULL" == "Portuguese" ];           then LANGUAGE="pt" ; fi
					if [ "$LANGUAGE_FULL" == "Russian"    ];           then LANGUAGE="ru" ; fi
					if [ "$LANGUAGE_FULL" == "Ukrainian"  ];           then LANGUAGE="uk" ; fi
					if [ "$LANGUAGE_FULL" == "Arabic"     ];           then LANGUAGE="ar" ; fi
					if [ "$LANGUAGE_FULL" == "Japanese"   ];           then LANGUAGE="ja" ; fi
					if [ "$LANGUAGE_FULL" == "Urdu"       ];           then LANGUAGE="ur" ; fi
					echo $LANGUAGE > language.txt
    				printf "LANGUAGE=$LANGUAGE\r\n"

	    		fi
    		fi
    		#printf "line_a="$line_a"  line_b="$line_b"\r\n"
    	done
	done

#exit
# 	echo English > language_full.txt
# 	echo en > language.txt
#	echo Dutch > language_full.txt
#	echo nl > language.txt

	read -r LANGUAGE < language.txt
	read -r LANGUAGE_FULL < language_full.txt

#	COMMAND="sof/sof "$BASENAME.$LANGUAGE.srt""
	COMMAND="ffmpeg -y -hide_banner -i \"$BASENAME.srt\" \"$BASENAME.$LANGUAGE.ass\""

	echo "$COMMAND" >> COMMANDS.SH
    echo >> COMMANDS.SH

	echo "$COMMAND" > command.sh
	chmod +x command.sh
	
	./command.sh

	cat "$BASENAME.$LANGUAGE.ass" | sed "s/\u1/c\&HA0FFA0\&/g" | sed "s/\u0/c\&HFFFFFF\&/g" > "$BASENAME.$LANGUAGE.ass.double"
#	cat "$BASENAME.$LANGUAGE.ass" | sed "s/\u1/c\&HFFFFA0\&/g" | sed "s/\u0/c\&HFFFFFF\&/g" > "$BASENAME.$LANGUAGE.ass.double"

	#batch_burn_video_ass.sh $LANGUAGE

	mv "$BASENAME.single" "$BASENAME.$LANGUAGE.srt.double"

 	COMMAND="batch_translate.sh \"$BASENAME.$LANGUAGE.srt.double\""
 
 	echo "$COMMAND" >> COMMANDS.SH
 	echo "$COMMAND" > command.sh
 	chmod +x command.sh
 	
 	./command.sh

	cp "$BASENAME.en.srt.double" "$BASENAME.en.srt"
	COMMAND="ffmpeg -y -hide_banner -i \"$BASENAME.en.srt\" \"$BASENAME.en.ass\"; mv \"$BASENAME.en.ass\" \"$BASENAME.en.ass.double\""
	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh

	cp "$BASENAME.nl.srt.double" "$BASENAME.nl.srt"
	COMMAND="ffmpeg -y -hide_banner -i \"$BASENAME.nl.srt\" \"$BASENAME.nl.ass\"; mv \"$BASENAME.nl.ass\" \"$BASENAME.nl.ass.double\""
	echo "$COMMAND" >> COMMANDS.SH
	echo "$COMMAND" > command.sh
	chmod +x command.sh

	if [ "$LANGUAGE" == "en"  ]; then
		batch_burn_video.sh nl
		cp command3.sh "$BASENAME.command3.nl.sh"
	else
		if [ "$LANGUAGE" == "nl"  ]; then
			batch_burn_video.sh en
			cp command3.sh "$BASENAME.command3.en.sh"
		else
			batch_burn_video.sh nl
			cp command3.sh "$BASENAME.command3.nl.sh"
			batch_burn_video.sh en
			cp command3.sh "$BASENAME.command3.en.sh"

		fi
	fi
#	cat COMMANDS.SH >> "$BASENAME.description"
	batch_burn_video_ass.sh $LANGUAGE

	cp command3.sh "$BASENAME.command3.$LANGUAGE.sh"

	mkdir "$BASENAME"
	find -maxdepth 1 -type f -name "$VAR*" -exec mv {} "$BASENAME" ';'
#	mv thumbnails.txt "$BASENAME"
	cp filename.txt "$BASENAME"
	mv COMMANDS.SH "$BASENAME"
	mv command.sh "$BASENAME"
	mv command2.sh "$BASENAME"
	find -maxdepth 1 -type f -name "$BASENAME.command3.*.sh" -exec mv {} "$BASENAME" ';'
	#mv "command3.sh" "$BASENAME"
	mv typescript "$BASENAME"
	mv error.log "$BASENAME"
fi
