#!/bin/bash

FILENAME=$1
BASENAME="${FILENAME%.*}"

adapt() {
	F=$1
	B="${F%.*}"
	ffmpeg -y -hide_banner -i $1 -t 00:02:15 -filter_complex \
		" \
		[0:v]fps=fps=60,scale=640:360:force_original_aspect_ratio=decrease,pad=640:360:-1:0:color=0x000000[v]; [0:a]aresample=44100[a] \
	 	" \
		-map "[v]" -map "[a]" -ac 2 -shortest -c:v h264_nvenc -pix_fmt yuv420p -preset fast $B.fix.mp4

#  printf "%.${2}f" "${1}"
}


## ffmpeg -y -hide_banner \
## 	-stream_loop -1 -ss 0 -i bin/thug_life.mp3 \
## 	-stream_loop -1 -ss 0 -i sad1.mp4 \
## 	-stream_loop -1 -ss 4 -i sad1.mp4 \
## 	-stream_loop -1 -ss 8 -i sad1.mp4 \
## 	-stream_loop -1 -ss 12 -i sad1.mp4 \
## 	-t 20 \
## 	-filter_complex \
##  	" \
## 	[ 1:v][ 2:v][ 3:v][ 4:v]hstack=inputs=4[k]; \
## 	[k]scale=1280:720:force_original_aspect_ratio=decrease[v]; \
##   	[0:a]volume=12[a0]; \
##   	[1:a]volume=0.5[a1]; \
## 	[a0][a1]amerge=inputs=2[a] \
##   	" \
##  	-map "[v]" -map "[a]" -ac 2 -shortest -c:v h264_nvenc -pix_fmt yuv420p -preset slow output.mp4




adapt 1.mp4
adapt 2.mp4
adapt 3.mp4
adapt 4.mp4
#adapt 5.mp4
#adapt 6.mp4
#adapt 7.mp4
#adapt 8.mp4
#adapt 9.mp4
#adapt 10.mp4
#adapt 11.mp4
#adapt 12.mp4
#adapt 13.mp4
#adapt 14.mp4
#adapt 15.mp4
#adapt 16.mp4

## ffmpeg -i 1.fix.mp4 -i 2.fix.mp4 -i 3.fix.mp4 -i 4.fix.mp4 -filter_complex \
##  	" \
##  	[0:v][1:v][2:v]hstack[k]; \
##  	[3:v][4:v][5:v]hstack[l]; \
##  	[6:v][7:v][8:v]hstack[m]; \
##  	[k][l][m]vstack[v]; \
##   	[0:a][1:a][2:a][3:a]amerge=inputs=4[a] \
##   	" \
##  	-map "[v]" -map "[a]" -ac 2 -shortest -c:v h264_nvenc -pix_fmt yuv420p -preset slow output.mp4

ffmpeg -i 1.fix.mp4 -i 2.fix.mp4 -i 3.fix.mp4 -i 4.fix.mp4 -filter_complex \
 	" \
 	[0:v][1:v]hstack[t];[2:v][3:]hstack[b];[t][b]vstack[v]; \
  	[0:a][1:a][2:a][3:a]amerge=inputs=4[a] \
  	" \
 	-map "[v]" -map "[a]" -ac 2 -shortest -c:v h264_nvenc -pix_fmt yuv420p -preset slow output.mp4


##  ffmpeg -y -hide_banner \
##  	-i 1.fix.mp4 \
##  	-i 2.fix.mp4 \
##  	-i 3.fix.mp4 \
##  	-i 4.fix.mp4 \
##  	-i 5.fix.mp4 \
##  	-i 6.fix.mp4 \
##  	-i 7.fix.mp4 \
##  	-i 8.fix.mp4 \
##  	-i 9.fix.mp4 \
##  	-i 10.fix.mp4 \
##  	-i 11.fix.mp4 \
##  	-i 12.fix.mp4 \
##  	-i 13.fix.mp4 \
##  	-i 14.fix.mp4 \
##  	-i 15.fix.mp4 \
##  	-i 16.fix.mp4 \
##  	 -filter_complex \
##   	" \
## 	[ 0:v][ 1:v][ 2:v][ 3:v]hstack=inputs=4[k]; \
##  	[ 4:v][ 5:v][ 6:v][ 7:v]hstack=inputs=4[l]; \
## 	[ 8:v][ 9:v][10:v][11:v]hstack=inputs=4[m]; \
## 	[12:v][13:v][14:v][15:v]hstack=inputs=4[n]; \
## 	[k][l][m][n]vstack=inputs=4,scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:-1:0:color=0x000000[v]; \
## 	[0:a][1:a][2:a][3:a][4:a][5:a][6:a][7:a][8:a][9:a][10:a][11:a][12:a][13:a][14:a][15:a]amerge=inputs=16[a] \
##    	" \
##   	-map "[v]" -map "[a]" -ac 2 -shortest -c:v h264_nvenc -pix_fmt yuv420p -preset slow output.mp4

#	ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:v]setpts=$SPEED*PTS,fps=fps=60[v];[0:a]asetrate=$RATE/$PITCH,aresample=44100,atempo=(1.0/($SPEED/$PITCH))[a]" \
#	-map "[v]" -map "[a]" -c:v h264_nvenc -pix_fmt yuv420p -preset slow -c:a aac -ac 2 -b:a 64k "$BASENAME.TWITTER.MP4"
#ffmpeg -hide_banner -i "$FILENAME" -filter_complex "[0:v]setpts=$SPEED*PTS,scale=1280:720:force_original_aspect_ratio=increase[v];[0:a]asetrate=$RATE/$PITCH,aresample=44100,atempo=(1.0/($SPEED/$PITCH))[a]" -map "[v]" -map "[a]" -c:v h264_nvenc -pix_fmt yuv420p -preset slow -c:a aac -ac 2 -b:a 64k "$BASENAME.TWITTER.MP4"
