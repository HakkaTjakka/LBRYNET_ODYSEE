#!/bin/bash

FILENAME=$*
BASENAME="${FILENAME%.*}"
#ffmpeg -y -loop 1 -i "$1" -t 00:00:01 -c:v libx264 -tune stillimage -pix_fmt yuv420p "$BASENAME.mp4"



# ffmpeg -y -i "$*.mp4" -vf palettegen "$*.png"

# ffmpeg -y -i "$*.mp4" -i "$*.png" -filter_complex "[0:v][1:v]paletteuse" "$*.gif"


#ffmpeg -y -i "$*.mp4" -i "$*.png" -filter_complex "[0:v][1:v]paletteuse,fps=20.0,scale=640:-1" "$*.gif"
#ffmpeg -y -i "$*.mp4" -i "$*.png" -filter_complex "[0:v][1:v]paletteuse" "$*.gif"

#ffmpeg -y -i "$*.mp4" -i "$*.png" -filter_complex "[0:v][1:v]paletteuse,fps=10,scale=720:-1" "$*.gif"

#ffmpeg -y -i "$*.mp4" -t 00:00:06 -i "$*.png" -filter_complex "[0:v][1:v]paletteuse,scale=320:-1" "$*.gif"

# ffmpeg -y -i "$*.mp4" -i "$*.png" -filter_complex "[0:v][1:v]paletteuse,scale=720:-1" "$*.gif"

# ffmpeg -y -i "$*.mp4" -i "$*.png" -filter_complex "[0:v][1:v]paletteuse" "$*.gif"

# ffmpeg -y -i "3x6qcr.mp4" -i "3x6qcr.png" -filter_complex "[0:v][1:v]paletteuse,fps=25,scale=720:-1" "3x6qcr.gif"

#scale=300:-1:sws_dither=ed
#-gifflags +transdiff
#ffmpeg -y -i "$*.mp4" -vf "fps=20,scale=640:-1:sws_dither=ed:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse"  "$*.gif"

ffmpeg -y -loop 1  -i "$FILENAME" -t 00:00:01 -vf "fps=20,scale=640:-1:sws_dither=none:flags=lanczos[q];[q]split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse" "$BASENAME.gif"

#ffmpeg -y -i "$*.mp4" -vf "fps=20,scale=640:-1:sws_dither=none,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse"   "$*.2.gif"
#ffmpeg -y -i "$*.mp4" -vf "fps=20,scale=640:-1:sws_dither=ed:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse"  "$*.gif"

