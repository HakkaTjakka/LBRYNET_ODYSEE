#!/bin/bash

round() {
  printf "%.${2}f" "${1}"
}

FILENAME1=$1
BASENAME1="${FILENAME1%.*}"

FILENAME2=$2

read -d " " XX YY <<< $(ffprobe -v error -show_entries stream=width,height -of default=noprint_wrappers=1:nokey=1 "$FILENAME1")
SCALE="$XX":"$YY"

DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$FILENAME2")
DURATION=$(round ${DURATION} 2)
FADE=$(echo "($DURATION-3)"| bc -l)

echo DURATION=$DURATION
echo FADE    =$FADE
echo SCALE=$SCALE
#exit

#ffmpeg -y -loop 1 -i "$FILENAME1" -t $DURATION -i "$FILENAME2" -c:v libx264 -tune stillimage -pix_fmt yuv420p -c:a aac -ac 2 "$BASENAME1.mp4"

ffmpeg -y -hide_banner \
	-loop 1 -framerate 25 -i "$FILENAME1" -t $DURATION \
	-i "$FILENAME2" \
	-filter_complex "[1:a]aresample=44100,afade=type=out:duration=3:start_time=$FADE" \
	-c:v h264_nvenc -pix_fmt yuv420p -preset slow \
	-c:a aac -ac 2 \
	-shortest "$BASENAME1.mp4"
#	-b:v 100k \
#[0:v]scale=$SCALE;
#ffmpeg -y -loop 1 -i "$FILENAME" -t 00:00:04 -vf scale=616:-1 -c:v libx264 -tune stillimage -pix_fmt yuv420p "$BASENAME.mp4"
#ffmpeg -y -i "$FILENAME2" -i 1.mp4 -shortest -c:a aac -ac 2 hoppa.mp4
#ffmpeg -i input.mp4 -filter_complex "[0:v]fade=type=in:duration=1,fade=type=out:duration=1:start_time=9[v];[0:a]afade=type=in:duration=1,afade=type=out:duration=1:start_time=9[a]" -map "[v]" -map "[a]" output.mp4