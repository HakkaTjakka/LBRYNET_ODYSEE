#!/bin/bash

FILENAME=$*
BASENAME="${FILENAME%.*}"

LANGUAGE="${FILENAME%.*}"
LANGUAGE="${LANGUAGE%.*}"
BASENAME2="${LANGUAGE%.*}"
LANGUAGE="${LANGUAGE##*.}"
echo $LANGUAGE


echo "Filename: $FILENAME" >> error.log
BASENAME="${FILENAME%.*}"

while IFS='' read -r line || [[ -n "$line" ]]; do
        if [[ "$line" != "" ]] ; then
                if [[ ! $line =~ [0-9] ]] ; then
                        echo ORIGINAL___RU: $line
                        VAR=$(echo "$line" | trans -brief ru:nl)
                        VAR2=$(echo "$line" | trans -brief ru:en)
                        VAR3=$(echo "$line" | trans -brief ru:uk)
                        VAR4=$(echo "$line" | trans -brief ru:de)
                        echo TRANSLATED_NL: $VAR
                        echo TRANSLATED_EN: $VAR2
                        echo TRANSLATED_UK: $VAR3
                        echo TRANSLATED_UK: $VAR4
                else
                        VAR=$line
                        VAR2=$line
                        VAR3=$line
                        VAR4=$line
                        echo NO TRANSLATE: $line
                fi
        else
                VAR=$line
                VAR2=$line
                VAR3=$line
                VAR4=$line
                echo NO TRANSLATE: $line
        fi
#        echo original  $line
#        echo translate $VAR
        echo $VAR >> "$BASENAME2.nl.srt.double"
        echo $VAR2 >> "$BASENAME2.en.srt.double"
        echo $VAR3 >> "$BASENAME2.uk.srt.double"
        echo $VAR4 >> "$BASENAME2.de.srt.double"

done < "$FILENAME"

