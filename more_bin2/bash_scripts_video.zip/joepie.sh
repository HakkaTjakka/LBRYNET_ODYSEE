#!/bin/bash

line2="lbry://@English_Subtitles#b/Niet_vergeten_-_Ad_Nuis_column-f2aea96a9b7ee94ee662be7e6599aaeb37b1c0e9.English#2"
echo "line2=$line2"
length=$(echo "$line2"|wc -m)
echo "lenght=$length"
length1=$((length-1))
echo "lenght1=$length1"
length2=$((length-2))
echo "lenght2=$length2"

echo $(line2:0:length2):$(line2:length1:length)
echo $line2b
