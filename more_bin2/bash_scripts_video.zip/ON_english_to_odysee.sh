#!/bin/bash

upload() {

	#FILENAME="$1"
	LANGUAGE="${FILENAME%.*}"
	LANGUAGE="${LANGUAGE##*.}"
	#LANGUAGE="${FILENAME##*.}"
	
	echo LANGUAGE=$LANGUAGE
	
	FILENAME="/home/pacman/movies/out/$FILENAME"
	
	# THUMBNAIL_URL="https://thumbs.odycdn.com/984001f009b7913f48b876282fccd0e0.webp"
	THUMBNAIL_URL="$THUMBNAIL"
	
	#CHANNEL_ID="c10491c11bf087350305fda5aab3b68ae3672b88"
	#CHANNEL_ID="0f39e5c18b119190fe35ff5b10e5c5955cc387bb"
	
	# english
#	CHANNEL_ID="b0a87e02bbc7397ed2b84f08bf0da5d4f309d1f4"
#CHANNEL_ID="0f39e5c18b119190fe35ff5b10e5c5955cc387bb"
CHANNEL_ID="ce4780d158e6141c00a183a62d1df6f8e186b585"
	
	
	BID_AMT="0.00011"
	
	COMMAND='lbrynet publish \
	--name="'${NAME}'" \
	--title='${TITLE}' \
	--description='${DESCRIPTION}'
	--file_path="'${FILENAME}'" \
	--tags="English" \
	--tags="Subtitles" \
	--tags="Ongehoord Nederland" \
	--tags="Unheard Netherlands" \
	--thumbnail_url="'${THUMBNAIL_URL}'" \
	--channel_id="'${CHANNEL_ID}'" \
	--bid="'${BID_AMT}'"'
	
	#echo "$COMMAND" >> COMMANDS.SH
	
	echo "STR=$'\n\n'" > command3.sh
	echo "STR1=$'\n'" >> command3.sh
	echo -n "$COMMAND" >> command3.sh 
	
	chmod +x command3.sh
	
	echo UPLOADING LANGUAGE=$LANGUAGE
#	return
	./command3.sh
	
	echo UPLOADED LANGUAGE=$LANGUAGE
}
#            	5a2e06b836f46dcd906ec2b637015b1dc45e0439
#				fe7851f3d3c5e8de401ec7943cd67ef3fd6efb9e Nederlands_Ondertiteld
#			CHANNEL_ID="f09c1ff6e402fdff707afd56b71f43c0f968c00f"
#						f09c1ff6e402fdff707afd56b71f43c0f968c00f

echo "======"

THUMBNAIL=$(jq -r .thumbnail $2.info.json)

echo "Thumbnail=$THUMBNAIL"
#THUMBNAIL="$(echo $THUMBNAIL | cut -d' ' -f4)"
#echo "Thumbnail=$THUMBNAIL"
echo "======"

UPLOAD_DATE=$(jq --raw-output .upload_date "$2.info.json")
UPLOAD_DATE=$(echo "$UPLOAD_DATE" | sed -E 's/(....)(..)(..)/\1\-\2\-\3/')
echo "Upload_date=$UPLOAD_DATE"

TITLE=$(jq -r .title $2.info.json)
TITLE=$(echo -n $TITLE | sed "s|\"|\\\\\\\"|g"  )
TITLE="\"(🇬🇧EN "$UPLOAD_DATE") "$TITLE"\""
echo "Title=$TITLE"
echo "======"

DESCRIPTION2=$(cat $2.description)
DESCRIPTION=$(jq -r .description $2.info.json; echo -n "$DESCRIPTION2")

DESCRIPTION=$(echo -n "$DESCRIPTION" | sed "s|Show more |\\n|g"  )
DESCRIPTION=$(echo -n "$DESCRIPTION" | sed "s| Show less||g"  )

DESCRIPTION=$(echo -n "$DESCRIPTION" | sed "s|\"|\\\\\\\"|g"  )

#DESCRIPTION=$(echo -n "$DESCRIPTION" | sed "s|\\\\$|\\\\\\\\|g"  )

DESCRIPTION=$(echo -n "$DESCRIPTION" | sed "s|$|\"\"\$STR\"\"\\\|g"  )

#DESCRIPTION3=$(cat COMMANDS.SH)
#DESCRIPTION3=$(echo -n "$DESCRIPTION3" | sed "s|\"|\\\\\\\"|g"  )
#DESCRIPTION3=$(echo -n "$DESCRIPTION3" | sed "s|\\\\$|\\\\\\\\|g"  )
#DESCRIPTION3=$(echo -n "$DESCRIPTION3" | sed "s|$|\"\"\$STR1\"\"\\\|g"  )
#DESCRIPTION=$(echo -n "$DESCRIPTION" ; echo ; echo -n "$DESCRIPTION3"  )
#cat COMMANDS.SH >> "$BASENAME.description"

STR=$'\n'

DESCRIPTION="\""$DESCRIPTION""$STR"\" \\"

echo "Description=$DESCRIPTION"
echo "======"

FILENAME="$1"
NAME="${FILENAME%.*}"
echo "Name=$NAME"
NAME=$(echo $NAME | sed 's/\[//g' | sed 's/\]//g')
echo "Name=$NAME"
upload
